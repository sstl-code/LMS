(function(window) {
    window.__env = window.__env || {};
    window.__env.apiBaseURL = 'http://localhost:8080'; //replace this path with environment specific Application base Url
    window.__env.pwa_logoUrl = 'http://localhost:8080/RuleServer/files/default/monitor/5c81d47f-c369-4e7a-973a-de0bd59d3323/stream';
    window.__env.pwa_app_name ='Landlord Self Service';
    window.__env.pwa_des = 'For quick and easy access install this App by adding it to your home screen';
}(this));
