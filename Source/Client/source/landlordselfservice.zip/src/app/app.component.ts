import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, HostListener, ViewChild } from '@angular/core';
import { EnvService } from './services/env.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  animations: [
    trigger('SlideInOut', [
      state('intialState', style({ bottom: '-28%', display: 'none' })),
      state('finalState', style({ bottom: '0%' })),
      transition('intialState=>finalState', [
        animate('500ms  ease-in'),
      ]),
      transition('finalState=>intialState', [
        animate('500ms ease-out'),
      ]),
    ]),
    trigger('fadeInOut', [
      state('initialOverlay', style({
        opacity: '0'
      })),
      state('finalOverlay', style({
        opacity: '1'
      })),
      transition('initialOverlay=>finalOverlay', [
        animate('500ms ease-in')
      ]),
      transition('finalOverlay=>initialOverlay', [
        animate('500ms ease-out')
      ])
    ])
  ],
  styleUrls: ['./app.component.scss']
})

export class AppComponent {

  title = 'admin-template';

  constructor(private envService: EnvService) { }

  currentStateOfOverlay: any = "initialOverlay"
  currentStateOfDialog: any = "intialState";
  disPlayNone: Boolean = false;
  deferredPrompt: any;
  showPopUp = false;
  clientChoiceResult!: Boolean;

  @HostListener('window:beforeinstallprompt', ['$event'])
  onbeforeinstallprompt(e: { preventDefault: () => void; }) {
    setTimeout(() => {
      this.openInstallApp();
    }, 10000)
    e.preventDefault();
    this.deferredPrompt = e;
  }

  close() {
    this.currentStateOfOverlay = this.currentStateOfOverlay === 'finalOverlay' ? 'initialOverlay' : 'finalOverlay';
    this.currentStateOfDialog = this.currentStateOfDialog === 'finalState' ? 'intialState' : 'finalState';
    this.showPopUp = false;
  }

  getPwaLogo(){
    return this.envService.pwa_logoUrl;
  
  }

  getPwaAppName(){
    return this.envService.pwa_app_name ;
    
  }
  getPwaDes(){
    return this.envService.pwa_des;
  
  }
openInstallApp(){
  this.getPwaAppName();
  this.getPwaDes();
  setTimeout(()=>{
    if(this.clientChoiceResult == false){
      this.close();
      this.showPopUp = false;
    }else{
      this.currentStateOfOverlay = this.currentStateOfOverlay === 'initialOverlay' ? 'finalOverlay' : 'initialOverlay';
      this.currentStateOfDialog = this.currentStateOfDialog === 'intialState' ? 'finalState' : 'intialState';
      this.showPopUp = true;
    }
  }, 5000)  
}

  addDisplayClass() {
    this.disPlayNone = true;
  }

  addToHomeScreen() {
    this.showPopUp = false;
    this.deferredPrompt.prompt();
    this.deferredPrompt.userChoice
      .then((choiceResult: { outcome: string; }) => {
        if (choiceResult.outcome === 'accepted') {
          this.clientChoiceResult = true;
          this.close();
        } else {
          this.clientChoiceResult = false;
        }
        this.deferredPrompt = null;
      });
  }
}