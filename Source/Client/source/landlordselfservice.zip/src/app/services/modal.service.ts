import { Injectable, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Injectable({
  providedIn: 'root'
})
export class ModalService {

  size: string = 'md';
  constructor(private bsModalService: BsModalService) { }

  openModal(template: TemplateRef<any>, size: string): BsModalRef {
    this.size = size == null ? 'md' : size;
    return this.bsModalService.show(
      template,
      Object.assign({ ignoreBackdropClick: true }, { class: `modal-${this.size} modal-dialog-centered` })
    );
  }

}
