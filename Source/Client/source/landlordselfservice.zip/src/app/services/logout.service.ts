import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class LogoutService {

  constructor(private http: HttpClient,
    private envService: EnvService) { }

  apiBaseURL:any = `${this.envService.apiBaseURL}/RuleServer/services/`;
  withCredential: boolean = true;

  logout() {
    localStorage.clear();
    return this.http.post<any>(this.apiBaseURL + 'logout_token','',{ withCredentials: this.withCredential});
  }
}
