import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { DialogComponent } from '../shared/dialog/dialog.component';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  constructor(private dialog: MatDialog) { }
  dialogRef!: MatDialogRef<DialogComponent>;

   open(options:any) {
    this.dialogRef = this.dialog.open(DialogComponent, {    
         data: {
          confirm: options.confirm,
          error:options.error,
          title: options.title,
          message : options.message,
          confirmButtonLabel: options.confirmButtonLabel,
          cancelButtonLabel: options.cancelButtonLabel
         }
    });  
  }

   confirmed(): Observable<any> {    
    return this.dialogRef.afterClosed().pipe(take(1), map(res => {
        return res;
      }
    ));
  }
}
