import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class DocumentsService {

  constructor(private http: HttpClient,
    private envService: EnvService) { }

  apiBaseURL = `${this.envService.apiBaseURL}/RuleServer/services/LandlordSelfService/assets/`;
  withCredential: boolean = true;

  getLandlordDocumentTypes() {
    return this.http.get<any>(this.apiBaseURL + 'getLandlordDocumentTypes', { withCredentials: this.withCredential });
  }

  retrieveLandlordDocuments() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordDocuments', { withCredentials: this.withCredential });
  }

  uploadLandlordDocument(req: any) {
    req.Content = req.Content.replace(/\+/gi, '%2B');
    var params = new HttpParams()
    .set('FileName', req.Name)
    .set('FileType', req.Type)
    .set('FileDescription', req.Description)
    .set('FileContent', (req.Content) );

  //  return this.http.post<any>(this.apiBaseURL + 'uploadLandlordDocumentNew', params, { withCredentials: this.withCredential });
  return this.http.post<any>(this.apiBaseURL + 'uploadLandlordDocument', params, { withCredentials: this.withCredential });
  }

  removeLandlordDocument(fileUid: any) {
    var params = new HttpParams()
      .set('FileUID', fileUid)
    return this.http.delete<any>(this.apiBaseURL + 'removeLandlordDocument', { withCredentials: this.withCredential, body: params });
  }
}
