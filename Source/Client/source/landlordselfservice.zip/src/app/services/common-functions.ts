import { EnvService } from "./env.service";

export class commonFunction {

    constructor(private envService: EnvService) {}




    allowNumeric(event: any): boolean {
        if ((event.keyCode >= 48 && event.keyCode <= 57)) {
            return true;
        }
        else if (event.keyCode == 46) {                
            if ((event.target.value) && (event.target.value.indexOf('.') >= 0)) {
                event.preventDefault();
                return false; 
            }                          
            else               
                 return true;               
            }
        else {
            event.preventDefault();
            return false;
        }

    }
    allowAlphaNumeric(event: any): boolean {
        const charCode = event.which ? event.which : event.keyCode;
        if ((event.keyCode >= 48 && event.keyCode <= 57)) {
            return true;
        }
        else if (event.keyCode == 46) {                
            if ((event.target.value) && (event.target.value.indexOf('.') >= 0)) {
                event.preventDefault();
                return false; 
            }                          
            else               
                 return true;               
            }
        else if (charCode == 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
                return true;
              }
        else {
            event.preventDefault();
            return false;
        }

    }
    dateFormat(timeStamp:any){
        let date = new Date(timeStamp).toString().split('GMT')[0].split(' ');
        let formattedDate = date[2] + '-' + date[1] + '-' + date[3] + ' ' + date[4];
        return formattedDate;
    }
    generateImage1(fileContent:any,sanitizer:any)
    {
        let base64!: string;
        var thumbNailImgSrc!: any;
        thumbNailImgSrc = sanitizer?.bypassSecurityTrustResourceUrl(fileContent);
             // thumbNailImgSrc = 'assets/icons/file.png';
        return thumbNailImgSrc;

    }


    previewThumbNail(fieldValue:any,sanitizer:any){
    let base64!: string;
    var thumbNailImgSrc!: any;
    base64=""
    thumbNailImgSrc = sanitizer?.bypassSecurityTrustResourceUrl(base64);
    base64 = base64.replace(/ /g, "+");
    let w = window.open('_self');
    w?.document.write('<iframe src="' + base64  + '" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>')
    w?.document.close();
    return thumbNailImgSrc;
   /* location.replace("http://localhost:8080/RuleServer/files/acmeinte0027/Inventory/5325c653-2a6c-468f-a509-8a45c4975bce/stream")*/
    }

    base64ToArrayBuffer(base64: any): ArrayBuffer {
        var binary_string = window.atob(base64);
        var len = binary_string.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    }

    isPasswordValid(textValue:any)
    {
        let isvalid:boolean=true;
        let  i_lowercasecnt:number = 0;
		let i_uppercasecnt:number = 0;
		let i_digitcnt :number= 0;
		let i_specialcharcnt:number = 0;
		let i_count:number= 0;
		let i_spclcharnotfound:number= 0;
        // #PASSWORD POLICY
        // PASSWORD_MIN_LENGTH=8
        // PASSWORD_MAX_LENGTH=20
        // PASSWORD_UPPERCASE_CNT=1
        // PASSWORD_SMALLCASE_CNT=1
        // PASSWORD_DIGIT_CNT=1
        // SPECIAL_CHAR_CNT=1
        // SPECIAL_CHAR_ALLOWED=$_@*.!~
        // PASSWORD_POLICY=Password Policy :\n\nMin Length = 8\nMax Length = 20\nMin UpperCase Character(s) = 1\nMin LowerCase Character(s) = 1\nMin Digit = 1\nMin Special Character(s) = 1\nSpecial Character(s) Allowed = $_@*.!~

        // if(event.length()>20)
        // {
        //     isvalid=false;
        // }
        // else if(event.length()<8)
        // {
        //     isvalid=false;
        // }
        for(let i=0;i<textValue.length;i++)
        {
            let ch = textValue.charAt(i);
            if(ch >= 'A' && ch <= 'Z')
    	    {
    	    	i_uppercasecnt++;
    	    }
    	    else if(ch >='a' && ch <= 'z')
    	    {
    	    	i_lowercasecnt++;
    	    }
    	    else if(ch >= '0' && ch <= '9')
    	    {
    	    	i_digitcnt++;
    	    }else{

            }
        }


    }
}
