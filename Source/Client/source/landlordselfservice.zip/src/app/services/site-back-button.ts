import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class siteBackButton {

  observer = new Subject();
  public subscriber$ = this.observer.asObservable();

  headerName = new Subject();
  public subscribeHeaderName = this.headerName.asObservable();

  private backBtnClicked = new Subject<any>();

  emitData(data: any) {
    this.observer.next(data);
  }
  setNavbarHeaderName(data: any){
    this.headerName.next(data);
  }

  getAfterBackBtnClickFunc() {
    this.backBtnClicked.next('');
  }

  setAfterBackBtnClickFunc(): Observable<any> {
    return this.backBtnClicked.asObservable();
  }

}