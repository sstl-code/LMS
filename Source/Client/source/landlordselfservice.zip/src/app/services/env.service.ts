import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvService {
  public apiBaseURL = '';
  public pwa_logoUrl='';
  public pwa_app_name='';
  public pwa_des='';
  constructor() { }
}
