import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { ChangePasswordService } from './change-password.service';
import { DecodeTokenService } from './decode-token.service';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    token;

    constructor(private cookieService: CookieService,
        private decodeToken: DecodeTokenService,
        private changePw: ChangePasswordService) {
        this.token = this.cookieService.get('truebyl_token');
    }


    isAuthorised(): boolean {
        if (this.token != '') {
            return true;
        }
        else {
            return false;
        }
    }
    // getEmail() {
    //     let email;
    //     if (this.token != '') {
    //         this.decodeToken.decode_token().subscribe(resp => {
    //             email = resp?.sub
    //         })
    //     }
    //     console.log("email=" + email)
    //     return email;
    // }
    // getUserAttributes() {
    //     let pwFlag!: any; let email!:any;
    //     // let email=this.getEmail();
    //     this.decodeToken.decode_token().subscribe(resp => {
    //         email = resp?.sub
    //         this.changePw.getuserAttr(email).subscribe(resp => {
    //             pwFlag = resp?.ChangePasswordFlag
    //         })

    //     })
    //     console.log("email=" + email)
    //     console.log("authpwFlag=" + pwFlag)
    //     return pwFlag
    // }



}
