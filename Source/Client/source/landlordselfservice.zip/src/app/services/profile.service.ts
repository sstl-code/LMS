import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { EnvService } from './env.service';
import { LogoutService } from './logout.service';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  public profileDetails = new Subject<any>();

  constructor(private http: HttpClient,
    private envService: EnvService) { }

  apiBaseURL = `${this.envService.apiBaseURL}/RuleServer/services/LandlordSelfService/assets/`;
  apiBaseURL_2 = `${this.envService.apiBaseURL}/RuleServer/services/Master/assets/`;
  withCredential: boolean = true;

  retrieveLandlordProfile() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordProfile', { withCredentials: this.withCredential });
  }
  setProfile(details: string) {
    this.profileDetails.next(details);
  }
  getProfile(): Observable<any> {
    return this.profileDetails.asObservable();
  }

  shareProfileDetails(details: any) {
    this.profileDetails.next(details);
  }
  retrieveLandlordAdditionalInfo() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordAdditionalInfo', { withCredentials: this.withCredential });
  }
  updateLandlordProfile(req: any) {
    var params = new HttpParams()
    for (let key in req) {
      if (req[key] instanceof Object) {
        params = params.set(key, JSON.stringify(req[key]))
      }
    }
    return this.http.put<any>(this.apiBaseURL + 'updateLandlordProfile', params, { withCredentials: this.withCredential });
  }
  updateLandlordAdditionalInfo(req: any) {
    var params = new HttpParams()
    for (let key in req) {
      if (req[key] instanceof Object) {
        params = params.set(key, JSON.stringify(req[key]))
      }
    }
    return this.http.put<any>(this.apiBaseURL + 'updateLandlordAdditionalInfo', params, { withCredentials: this.withCredential });
  }
  retrieveLandlordTickets() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordTickets', { withCredentials: this.withCredential });
  }
  updateLandlordPhoto(photo: any) {
    var params = new HttpParams()
      .set('Photo', photo)
    return this.http.put<any>(this.apiBaseURL + 'updateLandlordPhoto', params, { withCredentials: this.withCredential });
  }
  getAttribute(attributeType: any) {
    const params = new HttpParams()
      .set('AttributeType', attributeType);
    return this.http.get<any>(this.apiBaseURL_2 + 'getAttribute', { params: params, withCredentials: this.withCredential });

  }

}
