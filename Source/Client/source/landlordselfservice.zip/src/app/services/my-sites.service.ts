import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MySiteService {

  constructor(private http: HttpClient,
    private envService: EnvService) { }

  apiBaseURL = `${this.envService.apiBaseURL}/RuleServer/services/LandlordSelfService/assets/`;
  apiBaseURL2 = `${this.envService.apiBaseURL}/RuleServer/services/InvoiceService/assets/`;
  apiBaseURL3 = `${this.envService.apiBaseURL}/RuleServer/services/Landlord/assets/`;
  withCredential: boolean = false;

  retrieveLandlordSiteList() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordSiteList', { withCredentials: this.withCredential });
  }
  retrieveLandlordSiteAgreement(siteCode:any){
    const params = new HttpParams()
//    .set('SiteCode',siteCode)
  .set('SiteCode',encodeURIComponent(siteCode))
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordSiteAgreement',{ params: params, withCredentials: this.withCredential});
  }
  retrieveLandlordSiteDetails(siteCode:any){
    const params = new HttpParams()
   // .set('SiteCode',siteCode)
   .set('SiteCode',encodeURIComponent(siteCode))
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordSiteDetails',{ params: params,withCredentials: this.withCredential});
  }
  retrieveLandlordSiteEvents(siteCode:any){
    const params = new HttpParams()
 //   .set('SiteCode',siteCode)
 .set('SiteCode',encodeURIComponent(siteCode))
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordSiteEvents',{ params: params,withCredentials: this.withCredential});
  }
  retrieveLandlordSiteDocuments(siteCode:any){
    const params = new HttpParams()
    //.set('SiteCode',siteCode)
    .set('SiteCode',encodeURIComponent(siteCode))
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordSiteDocuments',{ params: params, withCredentials: this.withCredential});
  }
  retrieveLandlordPayments(siteCode:any){
    const params = new HttpParams()
   // .set('SiteCode',siteCode)
   .set('SiteCode',encodeURIComponent(siteCode))
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordPayments',{ params: params,withCredentials: this.withCredential});
  
  }
  retrieveLandlordInvoices(siteCode:any,landlordId:any){
    const params = new HttpParams()
    .set('LandlordId',landlordId)
    .set('SiteCode',siteCode)  
  return this.http.get<any>(this.apiBaseURL3 + 'getLandlordInvoices',{params: params,withCredentials: this.withCredential});
  }
  retrieveLandlordProfile() {
    return this.http.get<any>(this.apiBaseURL + 'retrieveLandlordProfile', { withCredentials: this.withCredential });
  }

}
