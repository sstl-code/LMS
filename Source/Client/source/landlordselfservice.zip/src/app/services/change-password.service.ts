import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {

  constructor(private http: HttpClient,
  private envService: EnvService) { }

  apiBaseURL:any = `${this.envService.apiBaseURL}/RuleServer/services/`;
  withCredential: boolean = true;
  saveFlag:boolean=false;

  getuserAttr(userName:any)
  {
    var params=new HttpParams()
    .set("username",userName)

    return this.http.get<any>(this.apiBaseURL + 'userattrs', { params,withCredentials: this.withCredential });
  }


  changeLandlordPassword(req:any)
  {
        var params=new HttpParams()
    .set("OldPassword",req.OldPassword)
    .set("NewPassword",req.NewPassword)

    console.log(params)

    return this.http.put<any>(this.apiBaseURL + 'LandlordSelfService/assets/changeLandlordPassword', params, { withCredentials: this.withCredential });
  }
  updatesaveFlag(data:any)
  {
    this.saveFlag=data
  }
  getsaveFlag()
  {
    return this.saveFlag
  }
}
