import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class DecodeTokenService {

  constructor(private http: HttpClient,
    private envService: EnvService) { }

    apiBaseURL = `${this.envService.apiBaseURL}/RuleServer/`;
    withCredential: boolean = true;

  decode_token() {
    return this.http.get<any>(this.apiBaseURL + 'auth/tokendata',{ withCredentials: this.withCredential});
  }
}
