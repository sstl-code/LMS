import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocumentsComponent } from './components/documents/documents.component';
import { HomeComponent } from './components/home/home.component';
import { MainLayoutComponent } from './components/layout/main-layout/main-layout.component';
import { NoLayoutComponent } from './components/layout/no-layout/no-layout.component';
import { LoginComponent } from './components/login';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { TicketsComponent } from './components/tickets/tickets.component';
import { AuthGuard } from './guards/auth.guard';
import { SiteDetailsComponent } from './components/site-details/site-details.component';
import { ProfilePictureEditComponent } from './components/profile-picture-edit/profile-picture-edit.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';

const routes: Routes = [
  {
    path: "",
    component: MainLayoutComponent,
    children: [
      { path: '', component: HomeComponent,canActivate:[AuthGuard]},
      { path: 'home', component: HomeComponent },
      { path: 'profile', component: MyProfileComponent },
      { path: 'profile-pic-edit', component: ProfilePictureEditComponent},
      { path: 'tickets', component: TicketsComponent },
      { path: 'documents', component: DocumentsComponent },
      { path: 'details', component: SiteDetailsComponent },
      { path: 'payments', component: SiteDetailsComponent },
      { path: 'change-password', component: ChangePasswordComponent }
    ]
  },
  {
    path: "",
    component: NoLayoutComponent,
    children: [
      { path: 'login', component: LoginComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
