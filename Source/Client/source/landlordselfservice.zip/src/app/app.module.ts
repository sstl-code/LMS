import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import { CustomMaterialModule } from './custom/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './components/login';
import { TextInputComponent } from './shared/text-input/text-input.component';
import { SelectOptionComponent } from './shared/select-option/select-option.component';
import { CheckboxComponent } from './shared/checkbox/checkbox.component';
import { ButtonComponent } from './shared/button/button.component';
import { ModalComponent } from './shared/modal/modal.component';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { FileInputComponent } from './shared/file-input/file-input.component';
import { FilterPipe } from './pipes/filter.pipe';
import { TicketsComponent } from './components/tickets/tickets.component';
import { FormatDatePipe } from './pipes/format-date.pipe';
import { AddHoursPipe } from './pipes/add-hours.pipe';
import { MainLayoutComponent } from './components/layout/main-layout/main-layout.component';
import { NoLayoutComponent } from './components/layout/no-layout/no-layout.component';
import { EnvServiceProvider } from './services/env.service.provider';
import { HomeComponent } from './components/home/home.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { SiteDetailsComponent } from './components/site-details/site-details.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { ImageCropperModule } from 'ngx-image-cropper';
import { ProfilePictureEditComponent } from './components/profile-picture-edit/profile-picture-edit.component';
import { DialogComponent } from './shared/dialog/dialog.component';
import { FormatStringPipe } from './pipes/format-string.pipe';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SpinnerInterceptor } from './interceptors/spinner.interceptor';
import { SpinnerComponent } from './shared/spinner/spinner.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { NgxImageCompressService } from 'ngx-image-compress';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TextInputComponent,
    SelectOptionComponent,
    CheckboxComponent,
    ButtonComponent,
    ModalComponent,
    FileInputComponent,
    FilterPipe,
    TicketsComponent,
    FormatDatePipe,
    AddHoursPipe,
    MainLayoutComponent,
    NoLayoutComponent,
    HomeComponent,
    MyProfileComponent,
    DocumentsComponent,
    SiteDetailsComponent,
    ProfilePictureEditComponent,
    DialogComponent,
    FormatStringPipe,
    SpinnerComponent,
    ChangePasswordComponent,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    CustomMaterialModule,
    ModalModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    NgxMaterialTimepickerModule,
    ImageCropperModule,
    NgxSpinnerModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
  ],
  providers: [  
    NgxImageCompressService,
    EnvServiceProvider,
    BsModalService,
    CookieService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SpinnerInterceptor,
      multi: true,
    },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
