import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
  HttpHeaders,
  HttpResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { DialogService } from '../services/dialog.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private dialogService: DialogService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    request = request.clone({
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
      })
    });
  
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if(error.status == 403){
          let option = {
            confirm: false,
            error: true,
            title: "Error",
            message: error.error.message.split('Access violation-')[1],
            confirmButtonLabel: "OK",
            cancelButtonLabel: "No"
          };
          this.dialogService.open(option);
        }else{
          let option = {
            confirm: false,
            error: true,
            title: "Error",
            message: error.error.message.split('<<<')[1].split('>>>')[0],
            confirmButtonLabel: "OK",
            cancelButtonLabel: "No"
          };
          this.dialogService.open(option);
        }

        
        return throwError(error);
      })
    )
  }
}
