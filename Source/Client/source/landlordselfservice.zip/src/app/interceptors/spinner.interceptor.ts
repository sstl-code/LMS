import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize } from 'rxjs/operators';

@Injectable()
export class SpinnerInterceptor implements HttpInterceptor {
  service_count = 0; // initialize the counter.

  constructor(private ngxSpinnerService: NgxSpinnerService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    this.service_count++; // increment the count for each intercepted http request.
    this.ngxSpinnerService.show();// show spinner.
    return next.handle(request).pipe(
      finalize(() => {
        this.service_count--;
        // decrement when service is completed (success/failed both handled when finalize rxjs operator used)
        if (this.service_count === 0) {
          this.ngxSpinnerService.hide();// hide spinner
        }
      })
    );
  }
}
