import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ChangePasswordService } from 'src/app/services/change-password.service';
import { DecodeTokenService } from 'src/app/services/decode-token.service';
import { LogoutService } from 'src/app/services/logout.service';
import { MySiteService } from 'src/app/services/my-sites.service';
import { ProfileService } from 'src/app/services/profile.service';
import { siteBackButton } from 'src/app/services/site-back-button';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  profileInfo !: any;
  paymentDetails: any = [];
  recentTickets: any = [];
  totalOpenTickets: any;
  profileImgSrc !: any;
  latestPaymentDetails:any=[];


  constructor(private route: Router,
    private profileService: ProfileService,
    private mySiteService: MySiteService,
    private sanitizer: DomSanitizer,
    private bck_btn: siteBackButton,
    private cookieService: CookieService,
    private logoutService: LogoutService,
    private decodeToken:DecodeTokenService,private changePw:ChangePasswordService)
    {
        this.checkChangePwFlag();
        this.retrievelandlordprofile();
    }

  ngOnInit(): void {
    this.bck_btn.setNavbarHeaderName('Home');
    this.retrieveLandLordPayments();
    this.retrieveLandLordTickets();
  }

  enableScanner() {
    this.route.navigate(['/scan']);
  }

  retrievelandlordprofile() {
    this.profileService.retrieveLandlordProfile().subscribe(resp => {
      this.profileInfo = resp;
      this.profileService.setProfile(this.profileInfo);
      if (this.profileInfo?.Photo != "") {
        this.profileImgSrc = this.profileInfo?.Photo.replace(/ /g, "+");
        if(!this.profileInfo?.Photo.includes('data:image')){
          this.profileImgSrc = [this.profileImgSrc.slice(0, 0), 'data:image/jpeg;base64,', this.profileImgSrc.slice(0)].join('');
        }
        this.profileImgSrc = this.sanitizer?.bypassSecurityTrustResourceUrl(this.profileImgSrc);
      }
      else {
        this.profileImgSrc = "assets/icons/profilepic_m.png";
      }
    }, (error: any) => {
      //console.log('error: ', error);
      this.logoutService.logout().subscribe(resp => {
        this.cookieService.delete('truebyl_token');
        this.route.navigate(['/login']);
      },
        (error: any) => {
          this.cookieService.delete('truebyl_token');
          this.route.navigate(['/login']);
        }
      );
    });
  }
//   retrieveLandLordPayments() {
//     this.mySiteService.retrieveLandlordPayments('').subscribe(resp => {
//       this.paymentDetails = [];
//       let latestPaymentDetails: any = [];
//       resp.forEach((element: any) => {
//         if (element?.Status == 2)
//         latestPaymentDetails.push(element);
//       });
//       const maxDate = new Date(Math.max(...latestPaymentDetails.map((e:any) => new Date(e.PaymentDate))))
//       this.paymentDetails = latestPaymentDetails.filter((s:any) => new Date(s.PaymentDate).toDateString() == maxDate.toDateString());
//     });
//   }
retrieveLandLordPayments() {
    this.mySiteService.retrieveLandlordPayments('').subscribe(resp => {
      this.paymentDetails = [];
      this.latestPaymentDetails = [];
      resp.forEach((element: any) => {
      //  if (element?.Status == 2)
      if (element?.Status == 1)
        this.latestPaymentDetails.push(element);
      });
      const maxDate = new Date(Math.max(...this.latestPaymentDetails.map((e:any) => new Date(e.PaymentDate))))
      this.paymentDetails = this.latestPaymentDetails.filter((s:any) => new Date(s.PaymentDate).toDateString() == maxDate.toDateString());
    });
  }

retrieveLandLordTickets() {
    this.profileService.retrieveLandlordTickets().subscribe(resp => {
      // this.recentTickets = resp;
       let openTickets = [];
      // this.recentTickets.forEach((element: any) => {
      //   if (element.Status == 1) {
      //     openTickets.push(element);
      //   }
      // });
      // this.totalOpenTickets = openTickets.length;
     resp.forEach((el:any)=>{
        if(el.Status==1){
          this.recentTickets.push(el)
          openTickets.push(el);
        }
     })
     this.totalOpenTickets = openTickets.length;
    });
  }

  navigateProfile() {
    this.route.navigate(['/profile']);
    this.bck_btn.emitData(true);
    this.bck_btn.setNavbarHeaderName('My Profile');
    this.bck_btn.setAfterBackBtnClickFunc().subscribe(resp => {
      this.route.navigate(['/home']);
    });
  }
  checkChangePwFlag()
  {
    let email;
    //let  pwFlag:boolean;
    this.decodeToken.decode_token().subscribe(resp=>{
        email=resp?.sub

        this.changePw.getuserAttr(email).subscribe(resp=>{
          let  pwFlag=resp?.ChangePasswordFlag
         // let  pwFlag='false'
            //console.log("pwFlag="+pwFlag);
            if(pwFlag=='true')
            {
                this.route.navigate(['/change-password']);
                this.bck_btn.setNavbarHeaderName('Change Password');
            }

        })
        let flg=this.changePw.getsaveFlag()
        //console.log("flg="+flg)
        if(flg==true)
        {
            window.location.reload()
        }
    })


  }
}
