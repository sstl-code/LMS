import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { commonFunction } from 'src/app/services/common-functions';
import { EnvService } from 'src/app/services/env.service';
import { MySiteService } from 'src/app/services/my-sites.service';
import { siteBackButton } from 'src/app/services/site-back-button';


@Component({
  selector: 'app-site-details',
  templateUrl: './site-details.component.html',
  styleUrls: ['./site-details.component.scss']
  // encapsulation: ViewEncapsulation.None
})
export class SiteDetailsComponent implements OnInit {

  paramSitecode!: string;
  tabindex: number = 0;
  siteDetails !: any;
  siteAssetDetails !: any
  activeAssets: any = [];
  activeAssetDetails: any = [];
  passiveAssets: any = [];
  agreementDetails !: any;
  agreementDocs: any = [];
  hasAgreement: boolean = true;
  hasActiveAsset: boolean = true;
  hasPassiveAsset: boolean = true;
  siteChngeHistory: any = [];
  hasSiteHistory: boolean = true;
  siteDocuments: any = [];
  hasSiteDocuments: boolean = true;
  sitePaymentDetails: any = [];
  hasPayments: boolean = true;
  isPaymentDetailsVisible !: boolean;
  viewSelectedPaymentDetails !: any;
  viewPayments: any = [];
  totalPayment: number = 0;
  agreementDoc!: any;
  activeAssetClicked: boolean = false;
  isInfoVisible: boolean = false;
  selectedDiv!: number;
  iframeSrc!: any;
  viewDoc!: boolean;
  docTypeIsImg!:boolean;

  invoice:any=[];
  mapObj = new Map();
  map1 = new Map<String, String>();
  hasInvoices: boolean = true;
  isVisible:boolean=false;
  landlordId:any;
  invoiceList:any=[];
  matTabIndex : Tabs = Tabs.details;

  constructor(private mySiteService: MySiteService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private sanitizer: DomSanitizer,
    private envService: EnvService,
    private bck_btn: siteBackButton,
    private fb: FormBuilder) { }



 

  ngOnInit(): void {
   
    this.getSiteCode();
    this.retrieveSiteDetails();
    this.retrieveAggreementDetails();
    this.retrievelandlordSiteEvents();
    this.retrieveDoccuments();
    this.retrieveLandLordPayments();
    this.retrievelandlordprofile();
    //this.retrieveInvoices();
    
  }
  
  setTab(tab : Tabs){
    this.matTabIndex = tab; 
  }
  getSiteCode() {
    this.activatedRoute.queryParams.subscribe(params => {
      this.paramSitecode = params['sitecode'];
      this.bck_btn.setNavbarHeaderName(`Site - ${this.paramSitecode}`); 
    });
  }

  //------------ AGREEMENTS --------------
  retrieveAggreementDetails() {
    if (this.paramSitecode != undefined) {
      this.mySiteService.retrieveLandlordSiteAgreement(this.paramSitecode).subscribe(resp => {
        //console.log(Object.keys(resp).length)
        if (Object.keys(resp).length != 0) {
          this.agreementDetails = resp;
          this.hasAgreement = true;
          this.agreementDocs = JSON.parse((resp?.FileDetails));
        }
        else {
          this.hasAgreement = false;
          this.agreementDetails = 'No Agreement Found';
        }
      });
    }
  }
  generateAgreementDocThumbNail(fileName: any) {
    let src = "";
    if (fileName.includes('.txt')) {
      src = "assets/icons/documents2.png";
    }
    else if (fileName.includes('.png') || fileName.includes('.jpg') || fileName.includes('.jpeg')) {
      src = "assets/icons/jpg.png";
    }
    else if (fileName.includes('.exe') || fileName.includes('.xlsx')) {
      src = "assets/icons/xls.png";
    }
    else if (fileName.includes('.doc') || fileName.includes('.docx')) {
      src = "assets/icons/doc.png";
    }
    else {
      src = "assets/icons/others.png";
    }
    return src;
  }
  ViewAgreementDoc(url: any,fileName:any) {
    let baseulr = this.envService.apiBaseURL;
    let fileNameArr = fileName.split('.');
    let fileNameExtension = fileNameArr[fileNameArr.length-1];
    this.docTypeIsImg = fileNameExtension=='jpg' || fileNameExtension=='jpeg'|| fileNameExtension=='png'? true : false;
    let docUrl = url.split('/RuleServer/')[1];
    let src = `${baseulr}/RuleServer/${docUrl}`;
    this.viewDoc = true;
    this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl(src);
    this.bck_btn.emitData(true);
    this.bck_btn.setAfterBackBtnClickFunc().subscribe(resp => {
      this.viewDoc = false;
      this.tabindex = 0;
    });
  }

  //------ TENANTS / INFRASTRUCTURE -------
  retrieveSiteDetails() {
    if (this.paramSitecode != undefined) {
      this.mySiteService.retrieveLandlordSiteDetails(this.paramSitecode).subscribe(resp => {

        this.siteDetails = JSON.parse(resp?.SiteDetails);

        this.siteAssetDetails = JSON.parse(resp?.SiteAssetDetails);
        //------- Active asset --------
        if (this.siteAssetDetails?.ActiveAssets?.length != 0) {
          this.hasActiveAsset = true;
          const countDict = this.siteAssetDetails?.ActiveAssets.reduce((acc: any, curr: any) => {
            const { OperatorName } = curr;
            if (acc[OperatorName]) ++acc[OperatorName];
            else acc[OperatorName] = 1;
            return acc;
          }, {});
          const result = this.siteAssetDetails?.ActiveAssets.map((obj: any) => {
            obj["count"] = countDict[obj.OperatorName];
            return obj;
          });
          const key = 'OperatorName';
          const uniqueActiveAsset = [...new Map(result.map((item: any) =>
            [item[key], item])).values()];
          this.activeAssets = uniqueActiveAsset;
        }
        else {
          this.hasActiveAsset = false;
        }
        //------- Passive asset --------
        if (this.siteAssetDetails?.PassiveAssets.length != 0) {
          this.hasPassiveAsset = true;
          const _countDict = this.siteAssetDetails?.PassiveAssets.reduce((acc: any, curr: any) => {
            const { EquipmentType } = curr;
            if (acc[EquipmentType]) ++acc[EquipmentType];
            else acc[EquipmentType] = 1;
            return acc;
          }, {});
          const _result = this.siteAssetDetails?.PassiveAssets.map((obj: any) => {
            obj["count"] = _countDict[obj.EquipmentType];
            return obj;
          });
          const _key = 'EquipmentType';
          const uniquePassiveAsset = [...new Map(_result.map((item: any) =>
            [item[_key], item])).values()];
          this.passiveAssets = uniquePassiveAsset;
        }
        else {
          this.hasPassiveAsset = false;
        }
      });
    }
  }
  onClickTenants(asset: any) {
    this.activeAssetClicked = true;
    let assets: any = [];
    this.activeAssetDetails = [];
    this.siteAssetDetails?.ActiveAssets.forEach((element: any) => {
      if (element?.OperatorName == asset?.OperatorName) {
        assets.push(element);
      }
    });
    const countDict = assets.reduce((acc: any, curr: any) => {
      const { EquipmentType } = curr;
      if (acc[EquipmentType]) ++acc[EquipmentType];
      else acc[EquipmentType] = 1;
      return acc;
    }, {});
    const result = assets.map((obj: any) => {
      obj["count"] = countDict[obj.EquipmentType];
      return obj;
    });
    const key = 'EquipmentType';
    const uniqueEquipmentType = [...new Map(result.map((item: any) =>
      [item[key], item])).values()];
    this.activeAssetDetails = uniqueEquipmentType;
    //console.log(this.activeAssetDetails)
  }

  //------------- SITE HISTORY --------------
  retrievelandlordSiteEvents() {
    if (this.paramSitecode != undefined) {
      this.mySiteService.retrieveLandlordSiteEvents(this.paramSitecode).subscribe(resp => {
        this.siteChngeHistory = [];
        if (resp.length != 0) {
          this.hasSiteHistory = true;
          resp.forEach((element: any) => {
            let _details: any = [];
            let activityInfo = (JSON.parse(element?.ActivityInfo));
            let _keys = Object.keys(activityInfo);
            let _values = Object.values(activityInfo);
            for (var i = 0; i < _keys.length; i++) {
              _details.push({
                fieldName: _keys[i],
                fieldValue: _values[i] as any
              });
            }
            this.siteChngeHistory.push({
              Event: element?.Event,
              EventTime: element?.EventTime,
              ActivityInfo: _details
            })
          });
        }
        else {
          this.hasSiteHistory = false;
        }
      })
    }
  }

  //------------- DOCUMENTS --------------
  retrieveDoccuments() {
    if (this.paramSitecode != undefined) {
      this.mySiteService.retrieveLandlordSiteDocuments(this.paramSitecode).subscribe(resp => {
        if (resp?.length != 0) {
          this.hasSiteDocuments = true;
          this.siteDocuments = resp;
        }
        else {
          this.hasSiteDocuments = false;
        }
      });
    }
  }
  getDocumentType(attribute: any) {
    let docDescription = JSON.parse(attribute)?.type;
    return docDescription;
  }
  getSiteDocumentDescription(attribute: any) {
    let docDescription = JSON.parse(attribute)?.description;
    return docDescription;
  }
  generateSiteDocDocThumbNail(fileName: any) {
    let src = "";
    if (fileName.includes('.txt')) {
      src = "assets/icons/documents2.png";
    }
    else if (fileName.includes('.png') || fileName.includes('.jpg') || fileName.includes('.jpeg')) {
      src = "assets/icons/jpg.png";
    }
    else if (fileName.includes('.exe') || fileName.includes('.xlsx')) {
      src = "assets/icons/xls.png";
    }
    else if (fileName.includes('.doc') || fileName.includes('.docx')) {
      src = "assets/icons/doc.png";
    }
    else {
      src = "assets/icons/others.png";
    }
    return src;
  }
  ViewSiteDoc(url: any,fileName:any) {
    let fileNameArr = fileName.split('.');
    let fileNameExtension = fileNameArr[fileNameArr.length-1];
    this.docTypeIsImg = fileNameExtension=='jpg' || fileNameExtension=='jpeg'|| fileNameExtension=='png'? true : false;
    let baseulr = this.envService.apiBaseURL;
    let docUrl = url.split('/RuleServer/')[1];
    let src = `${baseulr}/RuleServer/${docUrl}`;    
    this.viewDoc = true;
    this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl(src);
    this.bck_btn.emitData(true);
    this.bck_btn.setAfterBackBtnClickFunc().subscribe(resp => {
      this.viewDoc = false;
      this.tabindex = 2;
    });
  }

  //-------------- PAYMENTS --------------

  retrieveLandLordPayments() {
    this.sitePaymentDetails = [];
    if (this.paramSitecode != undefined) {
      this.mySiteService.retrieveLandlordPayments(this.paramSitecode).subscribe(resp => {
        if (resp!=null && resp!="{}" && resp!="[]"&& resp?.length>0) {
          this.hasPayments = true;
          resp.forEach((element: any) => {
            if (element?.Status == 1) { //changed from element?.Status == 2 (failed payment) to element?.Status == 1 (success payment) on 01.08.23 during crest-lms as per discussion with Rakesh Sir'
              this.sitePaymentDetails.push(element);
            }
          });
        }
        else {
          this.hasPayments = false;
        }
      });
    }
  }

  getSitePaymentDetails(details: any) {
    let _details = [];
    if (details != "") {
      let paymentDetails = JSON.parse(details);
      let _keys = Object.keys(paymentDetails);
      let _values = Object.values(paymentDetails);
      for (var i = 0; i < _keys.length; i++) {
        _details.push({
          fieldName: _keys[i],
          fieldValue: _values[i] as any
        });
      }
    }
    return _details
  }

  
  viewPaymentDetails(details: any) {
 
    this.viewPayments = [];    
    this.totalPayment = 0;
    this.isPaymentDetailsVisible = true;
    this.viewSelectedPaymentDetails = details;    
    this.viewPayments = JSON.parse((details.Details));
   
    //let paymentDetails = (JSON.parse((details.Details)));
    ////console.log(paymentDetails)
    // let _keys = Object.keys(paymentDetails);
    // let _values = Object.values(paymentDetails);
    // for (var i = 0; i < _keys.length; i++) {
    //   this.viewPayments.push({
    //     fieldName: _keys[i],
    //     fieldValue: _values[i]
    //   });
    // }
    // this.viewPayments.forEach((element: any) => {
    //   this.totalPayment += element?.fieldValue;
    // });
   
  }
  onClickPaymentDetailsbackIcon() {
    this.isPaymentDetailsVisible = false;
    //this.tabindex = 1;
    this.setTab(1);
  }

  onIconClick(i: number, icon: any) {
    this.isInfoVisible = !this.isInfoVisible;
    this.selectedDiv = i;

  }
  counter(i: number) {
    // //console.log(new Array(i))
    // if(i%2==0){
    //   return new Array(i);
    // }else{
    //   return new Array(i+1);
    // }
    return new Array(i);
}
calcLength(element:any){
  ////console.log("len="+JSON.stringify(element))
  
  return element.length
}
retrievelandlordprofile(){
 
  if (this.paramSitecode != undefined) {
    //console.log("inside")
    this.mySiteService.retrieveLandlordProfile().subscribe(resp=>{
      //console.log(resp)
      if(resp!=null || resp!="{}"|| resp!="[]" || resp.length>0){
       
        this.landlordId=resp.Landlordid;
        this.retrieveInvoices(this.landlordId);
      }
     
    })
  }
}
retrieveInvoices(landlordId:any){
  this.invoiceList = [];
  if (this.paramSitecode != undefined) {
   this.mySiteService.retrieveLandlordInvoices(this.paramSitecode,this.landlordId).subscribe(resp=>{
    if(resp!=null && resp!="{}" && resp!="[]"&& resp.length>0){
      this.hasInvoices=true;
      this.invoiceList=resp; 
    }else{
      this.hasInvoices=false;
      this.invoiceList=[];
    }    
   })
  }
 }
  getInvoiceType(invoiceType: any) {
    let invoiceTypeStr: any = ""

    if (invoiceType == "1") {
      invoiceTypeStr = "Rent";
    } else if (invoiceType == "2") {
      invoiceTypeStr = "Maintenance";
    } else if (invoiceType == "3") {
      invoiceTypeStr = "Escalation";
    } else if (invoiceType == "4") {
      invoiceTypeStr = "Rent+ Space Charges + Conservancy Fee";
    } else if (invoiceType == "5") {
      invoiceTypeStr = "Space Charges & Conservancy Fee";
    } else if (invoiceType == "6") {
      invoiceTypeStr = "Space Charges";
    }
    else if (invoiceType == "7") {
      invoiceTypeStr = "Waiver";
    }
    else if (invoiceType == "8") {
      invoiceTypeStr = "Debit Note";
    }
    else if (invoiceType == "9") {
      invoiceTypeStr = "Credit Note";
    }
    else if (invoiceType == "10") {
      invoiceTypeStr = "Interest Charges";
    }
    else if (invoiceType == "11") {
      invoiceTypeStr = "NFA";
    }
    else if (invoiceType == "12") {
      invoiceTypeStr = "SD - License Fee";
    }
    else if (invoiceType == "13") {
      invoiceTypeStr = "Others";
    }
    else if (invoiceType == "14") {
      invoiceTypeStr = "Advance";
    }

    else if (invoiceType == "15") {
      invoiceTypeStr = "SD-EB";
    }
    else if (invoiceType == "16") {
      invoiceTypeStr = "EB-Advance";
    }
    else if (invoiceType == "17") {
      invoiceTypeStr = "EB";
    }
    else if (invoiceType == "18") {
      invoiceTypeStr = "FCU";
    }
    else if (invoiceType == "19") {
      invoiceTypeStr = "DG";
    }
    else if (invoiceType == "20") {
      invoiceTypeStr = "EB+FCU";
    }
    else if (invoiceType == "21") {
      invoiceTypeStr = "EB+DG";
    }

    else if (invoiceType == "22") {
      invoiceTypeStr = "EBFixedCharges";
    } else { }
    return invoiceTypeStr
  }
 tabChanged(tabChangeEvent: MatTabChangeEvent): void {
 // //console.log('tabChangeEvent => ', tabChangeEvent);
  //console.log('index => ', tabChangeEvent.index);
}
}

enum Tabs{
 details = 0,
 payments = 1,
 invoice = 2
}