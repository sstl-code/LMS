import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormArray, FormBuilder,  FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { commonFunction } from 'src/app/services/common-functions';
import { DialogService } from 'src/app/services/dialog.service';
import { LogoutService } from 'src/app/services/logout.service';
import { ModalService } from 'src/app/services/modal.service';
import { ProfileService } from 'src/app/services/profile.service';
import { siteBackButton } from 'src/app/services/site-back-button';
import { __values } from 'tslib';


@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss'],
  // encapsulation: ViewEncapsulation.None
})

export class MyProfileComponent implements OnInit {

  profileImgSrc !: any;
  basicInfo_fg !: FormGroup;
  additionalInfo_fg !: FormGroup;
  attributeList: any = [];
  isBasicinfoEditable: Boolean = false;
  isAdditionalInfoEditable: Boolean = false;
  landLordProfileBasicInfo!: any;
  landLordAdditionalInfo: any = [];
  landLordOtherInfo !: any;
  matchedArr: any = [];
  unmatchedArr: any = [];
  saveBasicInfoModalRef!: BsModalRef;
  saveAdditionalInfoModalRef!: BsModalRef;
  isVisible:boolean=false;
  multiselectList:any=[];

  constructor(private route: Router,
    private profileService: ProfileService,
    private fb: FormBuilder,
    private sanitizer: DomSanitizer,
    private cookieService: CookieService,
    private logoutService: LogoutService,
    private dialogService: DialogService,
    private bck_btn: siteBackButton,
    private modalService: ModalService,
    private ngxSpinnerService: NgxSpinnerService) { }

  ngOnInit(): void {
    //this.ngxSpinnerService.show()
   // console.log("xxxxxxx",navigator.userAgent);
    this.bck_btn.setNavbarHeaderName('My Profile');
    this.retrievelandlordprofile();
    this.createAdditionalInfoForm();
  //  this.retrievelandlordadditionalinfo();
  this.retrievelandlordadditionalinfo2();
  }
  ngAfterContentInit() {
    //this.ngxSpinnerService.hide()
  }
  retrievelandlordprofile() {
    this.profileService.retrieveLandlordProfile().subscribe(resp => {
      this.landLordProfileBasicInfo = resp;
      this.profileService.setProfile(this.landLordProfileBasicInfo);
      this.createBasicInfoForm();
      if (this.landLordProfileBasicInfo?.Photo != "") {
        this.profileImgSrc = this.landLordProfileBasicInfo?.Photo.replace(/ /g, "+");
        if (!this.landLordProfileBasicInfo?.Photo.includes('data:image')) {
          this.profileImgSrc = [this.profileImgSrc.slice(0, 0), 'data:image/jpeg;base64,', this.profileImgSrc.slice(0)].join('');
        }
        this.profileImgSrc = this.sanitizer?.bypassSecurityTrustResourceUrl(this.profileImgSrc);
      }
      else {
        this.profileImgSrc = "assets/icons/profilepic_m.png";
      }
    }, (error: any) => {
      console.log('error: ', error);
      this.logoutService.logout().subscribe(resp => {
        this.cookieService.delete('truebyl_token');
        this.route.navigate(['/login']);
      },
        (error: any) => {
          this.cookieService.delete('truebyl_token');
          this.route.navigate(['/login']);
        }
      );
    });
  }
  createBasicInfoForm() {
    this.basicInfo_fg = this.fb.group({
      Name: [this.landLordProfileBasicInfo?.LandlordName, Validators.required],
      Address: [this.landLordProfileBasicInfo?.Address, Validators.required],
      ContactNo: [this.landLordProfileBasicInfo?.ContactNo, Validators.required],
      Region: [this.landLordProfileBasicInfo?.Region, Validators.required],
      Photo: ['']
    });
  }
  get fc() {
    return this.basicInfo_fg.controls;
  }
  saveBasicInfo(template: TemplateRef<any>) {
    let formValue = { LandlordDetails: this.basicInfo_fg.value };
    formValue.LandlordDetails.Photo = this.landLordProfileBasicInfo?.Photo;
    if (this.basicInfo_fg.value?.Address != '' && this.basicInfo_fg.value?.ContactNo != '' && this.basicInfo_fg.value?.Region != '') {
      this.profileService.updateLandlordProfile(formValue).subscribe(resp => {
        this.saveBasicInfoModalRef = this.modalService.openModal(template, "md");
      }, (error: any) => {
        console.error('error', error);
      });
    }
    else {
      let option = {
        confirm: false,
        error: true,
        title: "Error",
        message: 'Please Fill All the Mandatory ( * ) Fields',
        confirmButtonLabel: "OK",
        cancelButtonLabel: "No"
      };
      this.dialogService.open(option);
    }
  }
  refreshBasicInfo = () => {
    this.retrievelandlordprofile();
    this.isBasicinfoEditable = !this.isBasicinfoEditable;
  }
  retrievelandlordadditionalinfo2() {
    this.profileService.getAttribute(8).subscribe(item => {
      this.attributeList = [];
      item.forEach((element: any) => {
        if (element.AttributeType == 8) {
             this.attributeList.push(element);
          //  this.attributeList=[{"AttributeId":163,"AttributeName":"Contact No 2","AttributeType":8,"AttributeDatatype":1,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":164,"AttributeName":"Whatsapp No","AttributeType":8,"AttributeDatatype":1,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":165,"AttributeName":"DOB","AttributeType":8,"AttributeDatatype":4,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":166,"AttributeName":"Landlord City","AttributeType":8,"AttributeDatatype":3,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":167,"AttributeName":"State","AttributeType":8,"AttributeDatatype":5,"Mandatory":1,"DefaultValue":" Haryana ","FLOV":"Andhra Pradesh , Arunachal Pradesh , Assam, Bihar , Chhattisgarh , Goa , Gujarat , Haryana , Himachal Pradesh , Jharkhand , Karnataka , Kerala , Madhya Pradesh , Maharashtra , Manipur , Meghalaya, Mizoram , Nagaland , Odisha , Punjab , Rajasthan , Sikkim  ,Tamil Nadu , Telangana , Tripura,Uttarakhand,Uttar Pradesh,West Bengal "},{"AttributeId":168,"AttributeName":"PIN","AttributeType":8,"AttributeDatatype":1,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":169,"AttributeName":"Group Entity Name","AttributeType":8,"AttributeDatatype":5,"Mandatory":0,"DefaultValue":"","FLOV":"Laxmi Telecom,City Realty & Development Pvt Ltd,M/s Flagship Developers Pvt Ltd,JMD Maintenance Service Pvt Ltd,Best International Projectes Pvt Ltd,Bestech India Pvt Ltd,"},{"AttributeId":170,"AttributeName":"PAN Status","AttributeType":8,"AttributeDatatype":5,"Mandatory":1,"DefaultValue":"Available ","FLOV":"Available,Not Available"},{"AttributeId":171,"AttributeName":"PAN","AttributeType":8,"AttributeDatatype":2,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":172,"AttributeName":"PAN Document","AttributeType":8,"AttributeDatatype":10,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":191,"AttributeName":"TDS","AttributeType":8,"AttributeDatatype":7,"Mandatory":0,"DefaultValue":"","FLOV":"A,B,C"},{"AttributeId":191,"AttributeName":"TDS2222","AttributeType":9,"AttributeDatatype":7,"Mandatory":0,"DefaultValue":"","FLOV":"A,B,C"},{"AttributeId":173,"AttributeName":"MSME Status","AttributeType":8,"AttributeDatatype":5,"Mandatory":1,"DefaultValue":"Available","FLOV":"Available,Not Available"},{"AttributeId":174,"AttributeName":"MSME Document","AttributeType":8,"AttributeDatatype":10,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":175,"AttributeName":"MSME Registration Number","AttributeType":8,"AttributeDatatype":2,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":176,"AttributeName":"GST Status","AttributeType":8,"AttributeDatatype":5,"Mandatory":1,"DefaultValue":"Available","FLOV":"Available,Not Available"},{"AttributeId":177,"AttributeName":"GST RC Document","AttributeType":8,"AttributeDatatype":10,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":178,"AttributeName":"GST Number","AttributeType":8,"AttributeDatatype":2,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":179,"AttributeName":"SAP Vendor Code","AttributeType":8,"AttributeDatatype":3,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":180,"AttributeName":"Bank Account Number Rental","AttributeType":8,"AttributeDatatype":1,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":181,"AttributeName":"Beneficiary Name Rental","AttributeType":8,"AttributeDatatype":3,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":182,"AttributeName":"IFSC Code Rental","AttributeType":8,"AttributeDatatype":2,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":183,"AttributeName":"Bank Name Rental","AttributeType":8,"AttributeDatatype":3,"Mandatory":1,"DefaultValue":"","FLOV":""},{"AttributeId":184,"AttributeName":"Cancelled Cheque Document","AttributeType":8,"AttributeDatatype":10,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":185,"AttributeName":"Additional Bank Required","AttributeType":8,"AttributeDatatype":5,"Mandatory":0,"DefaultValue":"No","FLOV":"Yes,No"},{"AttributeId":186,"AttributeName":"Bank Account Number EB","AttributeType":8,"AttributeDatatype":1,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":187,"AttributeName":"Beneficiary Name EB","AttributeType":8,"AttributeDatatype":2,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":188,"AttributeName":"IFSC Code EB","AttributeType":8,"AttributeDatatype":2,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":189,"AttributeName":"Bank Name EB","AttributeType":8,"AttributeDatatype":3,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":190,"AttributeName":"Cancelled Cheque EB Document ","AttributeType":8,"AttributeDatatype":10,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":191,"AttributeName":"TDS","AttributeType":8,"AttributeDatatype":1,"Mandatory":0,"DefaultValue":"","FLOV":""},{"AttributeId":191,"AttributeName":"TDS","AttributeType":8,"AttributeDatatype":6,"Mandatory":0,"DefaultValue":"true","FLOV":""},{"AttributeId":192,"AttributeName":"Description","AttributeType":8,
          //  "AttributeDatatype":3,"Mandatory":0,"DefaultValue":"","FLOV":""}]
        
          // if(((element.AttributeDatatype==1) || (element.AttributeDatatype==2)) ||
          //  (element.AttributeDatatype==3) || (element.AttributeDatatype==4) || (element.AttributeDatatype==5)){
          //   this.attributeList.push(element);
          // }
         
        }
      });
  //    console.log(JSON.stringify(this.attributeList))
      this.profileService.retrieveLandlordAdditionalInfo().subscribe(resp => {
        let otherInfo = JSON.parse(JSON.parse(JSON.stringify(resp)).OtherInfo);
        this.landLordAdditionalInfo = [];
        this.fields.clear();
        let _arr: any = []
        let _keys = Object.keys(otherInfo);
        let _values = Object.values(otherInfo);
        for (var i = 0; i < _keys.length; i++) {
          _arr.push({
            AttributeName: _keys[i],
            AttributeValue: _values[i]
          });
        }
        const createMatchedAttr1 = (arr1: any, arr2: any) => {
          let res = [];
          res = arr1.filter((el: any) => {
            return arr2.find((element: any) => {
              return element.AttributeName === el.AttributeName;
            });
          });
          return res;
        }
        const createMatchedAttr2 = (arr1: any, arr2: any) => {
          let res = [];
          res = arr1.filter((el: any) => {
            return arr2.find((element: any) => {
              return element.AttributeName === el.AttributeName;
            });
          });
          return res;
        }
        const matchedAttr1 = createMatchedAttr1(_arr, this.attributeList);
        const matchedAttr2 = createMatchedAttr2(this.attributeList, _arr);
        const merge = (array1: any, array2: any) =>
          array1.map((itm: any) => ({
            ...array2.find((item: any) => (item.AttributeName === itm.AttributeName) && item),
            ...itm
          }));
        const matchedAttr = merge(matchedAttr1, matchedAttr2);
        const unmatchedAttr = this.attributeList.filter(function (obj1: any) {
          return !_arr.some(function (obj2: any) {
            return obj1.AttributeName == obj2.AttributeName;
          });
        });
   //     console.log("matchedAttr",matchedAttr)
        matchedAttr.forEach((element: any) => {
          this.fields.push(this.newEditableField(element?.AttributeName, element?.AttributeValue, element?.AttributeDatatype, element?.Mandatory, element?.FLOV));
          this.landLordAdditionalInfo.push({
            fieldName: element?.AttributeName,
            fieldValue: element?.AttributeValue == "" ? '--' : element?.AttributeValue,
            attributedatatype:element?.AttributeDatatype
          });
        });
        unmatchedAttr.forEach((element: any) => {
          this.fields.push(this.newEditableField(element?.AttributeName, '', element?.AttributeDatatype, element?.Mandatory, element?.FLOV));
          this.landLordAdditionalInfo.push({
            fieldName: element?.AttributeName,
            fieldValue: '--',
            attributedatatype:element?.AttributeDatatype
          });
        });
   //     console.log(JSON.stringify(this.landLordAdditionalInfo));
      });

     
    });

  }

  retrievelandlordadditionalinfo() {
    this.profileService.getAttribute(8).subscribe(item => {
      this.attributeList = [];
      item.forEach((element: any) => {
        if (element.AttributeType == 8) {
          this.attributeList.push(element);
        }
      });
      this.profileService.retrieveLandlordAdditionalInfo().subscribe(resp => {
        let otherInfo = JSON.parse(JSON.parse(JSON.stringify(resp)).OtherInfo);
        this.landLordAdditionalInfo = [];
        this.fields.clear();
        let _arr: any = []
        let _keys = Object.keys(otherInfo);
        let _values = Object.values(otherInfo);
        for (var i = 0; i < _keys.length; i++) {
          _arr.push({
            AttributeName: _keys[i],
            AttributeValue: _values[i]
          });
        }
        const createMatchedAttr1 = (arr1: any, arr2: any) => {
          let res = [];
          res = arr1.filter((el: any) => {
            return arr2.find((element: any) => {
              return element.AttributeName === el.AttributeName;
            });
          });
          return res;
        }
        const createMatchedAttr2 = (arr1: any, arr2: any) => {
          let res = [];
          res = arr1.filter((el: any) => {
            return arr2.find((element: any) => {
              return element.AttributeName === el.AttributeName;
            });
          });
          return res;
        }
        const matchedAttr1 = createMatchedAttr1(_arr, this.attributeList);
        const matchedAttr2 = createMatchedAttr2(this.attributeList, _arr);
        const merge = (array1: any, array2: any) =>
          array1.map((itm: any) => ({
            ...array2.find((item: any) => (item.AttributeName === itm.AttributeName) && item),
            ...itm
          }));
        const matchedAttr = merge(matchedAttr1, matchedAttr2);
        const unmatchedAttr = this.attributeList.filter(function (obj1: any) {
          return !_arr.some(function (obj2: any) {
            return obj1.AttributeName == obj2.AttributeName;
          });
        });
        matchedAttr.forEach((element: any) => {
          this.fields.push(this.newEditableField(element?.AttributeName, element?.AttributeValue, element?.AttributeDatatype, element?.Mandatory, element?.FLOV));
          this.landLordAdditionalInfo.push({
            fieldName: element?.AttributeName,
            fieldValue: element?.AttributeValue == "" ? '--' : element?.AttributeValue
          });
        });
        unmatchedAttr.forEach((element: any) => {
          this.fields.push(this.newEditableField(element?.AttributeName, '', element?.AttributeDatatype, element?.Mandatory, element?.FLOV));
          this.landLordAdditionalInfo.push({
            fieldName: element?.AttributeName,
            fieldValue: '--'
          });
        });
      //  console.log(this.landLordAdditionalInfo);
      });

     
    });

  }
  createAdditionalInfoForm() {
    this.additionalInfo_fg = this.fb.group({
      fields: this.fb.array([]),
    });
  }
  get fields() {
    return this.additionalInfo_fg.get("fields") as FormArray;
  }
  getAdditionalFormGroupByIdex(index: any) {
    const additional_fg = this.additionalInfo_fg.get("fields") as FormArray;
    const addition_fg_By_index = additional_fg.controls[index] as FormGroup;
    return addition_fg_By_index;
  }

  newEditableField(fieldName: any, fieldValue: any, AttributeDatatype: any, mandatory: any, FLOV: any): FormGroup {
    return this.fb.group({
      attributeName: [fieldName],
      attributeValue: [fieldValue, Validators.compose([this.onInit_validateAdditionalField(mandatory, fieldValue)])],
      attributeDatatype: [AttributeDatatype],
      mandatory: [mandatory],
      flov: [FLOV]
    });
  }

  onKeyUp_ValidateAdditionalInfo(index: any) {
    console.log(this.getAdditionalFormGroupByIdex(index).controls['attributeValue'].value)
    let value = this.getAdditionalFormGroupByIdex(index).controls['attributeValue'].value;
    let mandatory = this.getAdditionalFormGroupByIdex(index).controls['mandatory'].value
    if ((mandatory == 1 && value == "") || (mandatory == 1 && value == 0)) {
      this.getAdditionalFormGroupByIdex(index).controls['attributeValue'].setErrors({ 'required': true });
    }
  }

  onInit_validateAdditionalField(mandatory: any, fieldValue: any): any {
    if ((mandatory == 1 && fieldValue == "") || mandatory == 1 && fieldValue == 0) {
      return Validators.required;
    }
  }
  uploadImg() {
    this.route.navigate(['/profile-pic-edit']);
    //localStorage.setItem("back_url", this.route.url);
    this.bck_btn.setAfterBackBtnClickFunc().subscribe(resp => {
      this.route.navigate(['/profile']);
    });
    this.bck_btn.emitData(true);
  }

  saveAdditionalInfo(template: TemplateRef<any>) {
    let formValue = this.additionalInfo_fg.value.fields;
    if (this.fields.valid) {
      let obj: any = {};
      for (var i = 0; i < formValue.length; i++) {
        obj[formValue[i].attributeName] = formValue[i].attributeValue;
      };
      let _obj = { OtherInfo: obj }
      this.profileService.updateLandlordAdditionalInfo(_obj).subscribe(resp => {
        this.saveAdditionalInfoModalRef = this.modalService.openModal(template, "md");
      }, (error: any) => {
        console.error('error', error);
      });
    }
    else {
      let option = {
        confirm: false,
        error: true,
        title: "Error",
        message: 'Please Fill All the Mandatory ( * ) Fields',
        confirmButtonLabel: "OK",
        cancelButtonLabel: "No"
      };
      this.dialogService.open(option);
    }
  }
  refreshAdditionalInfo = () => {
    this.retrievelandlordadditionalinfo();
    this.isAdditionalInfoEditable = !this.isAdditionalInfoEditable
  }
  onkeypressAdditionalInfo(event: any, attributeDatatype: any) {
    if (attributeDatatype == 1) {
      return commonFunction.prototype.allowNumeric(event);
    }
    if (attributeDatatype == 2) {
      return commonFunction.prototype.allowAlphaNumeric(event);
    }
    else {
      return true;
    }
  }
  getFLOVs(floves: any): any {
    let _flov = [];
    if (floves != "") {
      _flov = floves.split(',')
    }
    return _flov;
  }

  populateFiles(fieldValue:any,datatype:any){
    let name="";
      if(fieldValue!="--"){
       name=JSON.parse(fieldValue).Name
      
      }else{
        name="--"
      }
      return name
  }

  getmultiselectList(fieldValue:any){
    this.multiselectList=[]
    if(fieldValue!="--"){
 
    //  console.log(JSON.parse(fieldValue))
     let obj= JSON.parse((JSON.parse(fieldValue).MultiSelectValue))
  //   console.log(JSON.parse(JSON.stringify(obj)))
     this.multiselectList=JSON.parse(JSON.stringify(obj))
    // this.multiselectList.push(obj)
    }
  }

}
