import { Component, OnInit } from '@angular/core';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { Router } from '@angular/router';
import { ProfileService } from 'src/app/services/profile.service';
import { DOC_ORIENTATION, NgxImageCompressService, DataUrl, UploadResponse } from "ngx-image-compress";

@Component({
    selector: 'app-profile-picture-edit',
    templateUrl: './profile-picture-edit.component.html',
    styleUrls: ['./profile-picture-edit.component.scss']
})
export class ProfilePictureEditComponent implements OnInit {

    profileDetails !: any;
    constructor(private route: Router,
        private profileService: ProfileService,
        private imageCompress: NgxImageCompressService) { }

    ngOnInit(): void {
    }
    imageChangedEvent = '';
    imageAfterCompress: DataUrl = '';
    croppedImage: any = '';
    imgResultBeforeCompress: DataUrl = "";
    imgResultAfterCompress: DataUrl = "";

    fileChangeEvent(event: any): void {
        this.imageChangedEvent = event;
    }
    imageCropped(event: ImageCroppedEvent) {
        this.croppedImage = event.base64;
    }
    cropperReady() { }

    compressFile() {
        console.log("work!")
        return this.imageCompress
            .uploadFile()
            .then(({ image, orientation, fileName }: UploadResponse) => {

                console.warn('File Name:', fileName);
                console.log("upload: " + image);
                console.warn(
                    `Original: ${image.substring(0, 50)}... (${image.length} characters)`
                );
                console.warn('Size in bytes was:', this.imageCompress.byteCount(image));
                console.log("Image: " + image);

                this.imageCompress
                    .compressFile(image, orientation, 50, 50)
                    .then((result: DataUrl) => {
                        this.imageChangedEvent = result;
                        console.warn(
                            `Compressed: ${result.substring(0, 50)}... (${result.length
                            } characters)`
                        );
                        console.warn(
                            'Size in bytes is now:',
                            this.imageCompress.byteCount(result)
                        );
                    });
            });
    }
    saveImage() {
        console.log(this.croppedImage)
        this.croppedImage = this.croppedImage.split('base64,')[1];
        this.profileService.updateLandlordPhoto(this.croppedImage).subscribe(resp => {
            this.route.navigate(['/profile']);
        }, (error: any) => {
            console.error('error', error);
        });
    }
    loadImageFailed() {
        // show message
    }

}
