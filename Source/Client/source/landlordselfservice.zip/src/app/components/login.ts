import { Component, OnInit } from "@angular/core";
import { EnvService } from "../services/env.service";
@Component({
    selector: "redirect",
    template: "redirecting...",
})
export class LoginComponent implements OnInit {
    

    constructor(private envService: EnvService) {}

    ngOnInit() {  
        let loginURL = `${this.envService.apiBaseURL}/RuleServer/auth/validate?target=${this.envService.apiBaseURL}/landlordselfservice&wildcard=true`;
        window.location.href = loginURL;
    }
}
