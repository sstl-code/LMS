import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSidenav } from '@angular/material/sidenav';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from 'src/app/services/auth.service';
import { ChangePasswordService } from 'src/app/services/change-password.service';
import { commonFunction } from 'src/app/services/common-functions';
import { DecodeTokenService } from 'src/app/services/decode-token.service';
import { LogoutService } from 'src/app/services/logout.service';
import { MySiteService } from 'src/app/services/my-sites.service';
import { ProfileService } from 'src/app/services/profile.service';
import { siteBackButton } from 'src/app/services/site-back-button';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent implements OnInit {

  @ViewChild('sidenav') sidenav!: MatSidenav;
  viewArrow: Boolean = false;
  reason = '';
  pageHeader: string = 'My Tasks';
  profileInfo !: any;
  profileImgSrc !: any;
  siteChange_fg!: FormGroup;
  siteList!: any;
  selectedSite!: any;
  selectedSite2!:any;
  navHeader: any = "My Site Details";
  isVisibleSiteChange: boolean = true;
  isVisibleSiteId: boolean = true;
  isMenuVisible: boolean = true;
  menuItem: any = [];
  userAttr!:any;

  isMenuVisible2: boolean = true;
  disableMenu!:boolean;
  sitecodeVal:any = '';

  constructor(private cookieService: CookieService,
    private router: Router,
    private logoutService: LogoutService,
    private fb: FormBuilder,
    private mySiteService: MySiteService,
    private profileService: ProfileService,
    private sanitizer: DomSanitizer,
    private bckBtn: siteBackButton,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private changePw:ChangePasswordService,private decodeToken:DecodeTokenService,
    public authService: AuthService
    ) {
      this.activatedRoute.queryParams.subscribe(params => {
        this.sitecodeVal = params['sitecode'];        
      });
        this.checkChangePwFlag();
      // this.retrievelandlordsitelist();
    }


  ngOnInit(): void {
    this.checkChangePwFlag();
    this.retrievelandlordprofile()
    this.getProfileInfo();
    this.createSiteChangeForm();
   // this.retrievelandlordsitelist();
    this.bckBtn.subscriber$.subscribe(data => {
      this.viewArrow = Boolean(data);
    });
    this.bckBtn.subscribeHeaderName.subscribe(data => {
      this.navHeader = data;
    });
    // this.bckBtn.menuVisible.subscribe(data => {
    //     this.disableMenu = data;
    //   });
    console.log("path="+window.location.href)
    if(window.location.href.includes('change-password'))
    {
        this.navHeader = 'Change Password';
    }

  }
  retrievelandlordprofile() {
    this.profileService.retrieveLandlordProfile().subscribe(resp => {
      this.profileInfo = resp;
      this.profileService.setProfile(this.profileInfo);
      if (this.profileInfo?.Photo != "") {
        this.profileImgSrc = this.profileInfo?.Photo.replace(/ /g, "+");
        if(!this.profileInfo?.Photo.includes('data:image')){
          this.profileImgSrc = [this.profileImgSrc.slice(0, 0), 'data:image/jpeg;base64,', this.profileImgSrc.slice(0)].join('');
        }
        this.profileImgSrc = this.sanitizer?.bypassSecurityTrustResourceUrl(this.profileImgSrc);
      }
      else {
        this.profileImgSrc = "assets/icons/profilepic_m.png";
      }
    }, (error: any) => {
      console.log('error: ', error);
      this.logoutService.logout().subscribe(resp => {
        this.cookieService.delete('truebyl_token');
        this.route.navigate(['/login']);
      },
        (error: any) => {
          this.cookieService.delete('truebyl_token');
          this.route.navigate(['/login']);
        }
      );
    });
  }

  getProfileInfo() {
    this.profileService.getProfile().subscribe(resp => {
      this.profileInfo = resp;
      if (this.profileInfo?.Photo != "") {
        this.profileImgSrc = this.profileInfo?.Photo.replace(/ /g, "+");
        if(!this.profileInfo?.Photo.includes('data:image')){
          this.profileImgSrc = [this.profileImgSrc.slice(0, 0), 'data:image/jpeg;base64,', this.profileImgSrc.slice(0)].join('');
        }
        this.profileImgSrc = this.sanitizer?.bypassSecurityTrustResourceUrl(this.profileImgSrc);
      }
      else {
        this.profileImgSrc = "assets/icons/profilepic_m.png";
      }
    });
  }

  getValue(menuName: any) {
    if (menuName == 'Documents') {
      this.navHeader = 'Documents';
    }
    if (menuName == 'My Site Details') {

      this.router.navigate(['/details'], { queryParams: { sitecode: this.selectedSite } }).then(() => {
        window.location.reload();
        this.navHeader = "Site-" + this.selectedSite;
        this.selectedSite2=this.selectedSite;
      });
    }
    if (menuName == 'Home') {
      this.navHeader = "Home";
    }
    if (menuName == 'My Profile') {

      this.navHeader = "My Profile";
    }
    if (menuName == 'Helpdesk') {
      this.navHeader = "Helpdesk";
    }
    if (menuName == 'Log-out') {
      this.logoutService.logout().subscribe(resp => {
        this.cookieService.delete('truebyl_token');
        this.router.navigate(['/login']);
      });
    }
    if (menuName == 'Change Password') {
        this.navHeader = "Change Password";
      }
  }
  back_btn() {
    this.bckBtn.emitData(false);
    this.bckBtn.getAfterBackBtnClickFunc();
  }

  createSiteChangeForm() {
    this.siteChange_fg = this.fb.group({
      site: ['']
    });
  }

  retrievelandlordsitelist() {
   // this.checkChangePwFlag();
    this.mySiteService.retrieveLandlordSiteList().subscribe(resp => {
      this.siteList = resp;
      if (this.siteList.length == 1) {
        this.isVisibleSiteChange = false;
      }
      if (this.siteList.length == 0) {
        this.isVisibleSiteChange = false;
        this.isVisibleSiteId = false;
        this.isMenuVisible = false;
      }
    //  this.selectedSite = this.siteList[0]?.Sitecode;
      console.log("this.disableMenu="+this.disableMenu);


      if(this.sitecodeVal==undefined){
        this.selectedSite = this.siteList[0]?.Sitecode;
      }
      else{
        this.selectedSite = this.sitecodeVal;
      }
      this.menuItem = [
        // { menu: "Home", redirectTo: "/home", iconSrc: "assets/icons/home.png", visible: true },
        // { menu: "My Profile", redirectTo: "/profile", iconSrc: "assets/icons/profile.png", visible: true },
        // { menu: "My Site Details", redirectTo: "/details", iconSrc: "assets/icons/sites.png", visible: this.isMenuVisible },
        // { menu: "Tickets", redirectTo: "/tickets", iconSrc: "assets/icons/tickets.png", visible: true },
        // { menu: "Documents", redirectTo: "/documents", iconSrc: "assets/icons/documents2.png", visible: true },
        // { menu: "Change Password", redirectTo: "/change-password", iconSrc: "assets/icons/change_password.png", visible: true },
        // { menu: "Log-out", redirectTo: "/login", iconSrc: "assets/icons/logout.png", visible: true }

        // { menu: "Home", redirectTo: "/home", iconSrc: "assets/icons/home.png", visible: this.isMenuVisible2 },
        // { menu: "My Profile", redirectTo: "/profile", iconSrc: "assets/icons/profile.png", visible: this.isMenuVisible2 },
        // { menu: "My Site Details", redirectTo: "/details", iconSrc: "assets/icons/sites.png", visible: this.isMenuVisible },
        // { menu: "Tickets", redirectTo: "/tickets", iconSrc: "assets/icons/tickets.png", visible: this.isMenuVisible2 },
        // { menu: "Documents", redirectTo: "/documents", iconSrc: "assets/icons/documents2.png", visible: this.isMenuVisible2 },
        // { menu: "Change Password", redirectTo: "/change-password", iconSrc: "assets/icons/change_password.png", visible: true },
        // { menu: "Log-out", redirectTo: "/login", iconSrc: "assets/icons/logout.png", visible: true }


        { menu: "Home", redirectTo: "/home", iconSrc: "assets/icons/home.png", visible: true ,isDisabled:this.disableMenu},
        { menu: "My Profile", redirectTo: "/profile", iconSrc: "assets/icons/profile.png", visible: true,isDisabled:this.disableMenu },
        { menu: "My Site Details", redirectTo: "/details", iconSrc: "assets/icons/sites.png", visible: this.isMenuVisible,isDisabled:this.disableMenu },
        { menu: "Helpdesk", redirectTo: "/tickets", iconSrc: "assets/icons/tickets.png", visible: true,isDisabled:this.disableMenu },
        { menu: "Documents", redirectTo: "/documents", iconSrc: "assets/icons/documents2.png", visible: true,isDisabled:this.disableMenu },
        { menu: "Change Password", redirectTo: "/change-password", iconSrc: "assets/icons/change_password.png", visible: true,isDisabled:false },
        { menu: "Log-out", redirectTo: "/login", iconSrc: "assets/icons/logout.png", visible: true,isDisabled:false}


      ];
    });
  }

  close(reason: string) {
    this.reason = reason;
    this.sidenav.close();
  }
  onChangeSite(siteValue: any) {
    this.selectedSite = siteValue;
    this.siteChange_fg.patchValue({ site: '' });
    this.selectedSite2=siteValue;
  }


  checkChangePwFlag()
  {
    let email,pwFlag;
    this.decodeToken.decode_token().subscribe(resp=>{
        email=resp?.sub

        this.changePw.getuserAttr(email).subscribe(resp=>{
            pwFlag=resp?.ChangePasswordFlag
         // pwFlag='false'
            console.log("pwFlag2="+pwFlag);
            if(pwFlag=='true')
            {
               // this.isMenuVisible2=false
               this.disableMenu=true;
                console.log("this.isMenuVisible2="+this.isMenuVisible2);
               // console.log("this.disableMenu="+this.disableMenu);
            }
            this.retrievelandlordsitelist();

        })
    })

  }

}
