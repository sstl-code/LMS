import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-layout',
  templateUrl: './no-layout.component.html',
  styleUrls: ['./no-layout.component.scss']
})
export class NoLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
