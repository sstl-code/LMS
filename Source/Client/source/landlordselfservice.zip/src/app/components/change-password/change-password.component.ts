import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ChangePasswordService } from 'src/app/services/change-password.service';
import { commonFunction } from 'src/app/services/common-functions';
import { DecodeTokenService } from 'src/app/services/decode-token.service';
import { DialogService } from 'src/app/services/dialog.service';
import { ModalService } from 'src/app/services/modal.service';
import { siteBackButton } from 'src/app/services/site-back-button';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html',
    styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

    changePwModalRef!: BsModalRef;
    changePWForm!: FormGroup;
    email!: any;

    i_lowercasecnt: number = 0;
    i_uppercasecnt: number = 0;
    i_digitcnt: number = 0;
    i_count: number = 0;
    i_spclcharcnt: number = 0;
    i_notAllowedspclchar:number=0;
    hide = true;
    hide1 = true;
    hide2 = true;

    constructor(private modalService: ModalService,
        private fb: FormBuilder,
        private changePw: ChangePasswordService,
        private dialogService: DialogService,
        private decodeToken: DecodeTokenService,
        private route: Router,
        private bck_btn: siteBackButton,) { }

    ngOnInit(): void {
        this.createForm();
    }
    createForm() {
        this.changePWForm = this.fb.group(
            {
                OldPassword: ["", Validators.required],
                NewPassword: ["", Validators.required],
                ConfirmPassword: ["", Validators.required]
            }
        )
    }
    saveClicked(template: TemplateRef<any>) {
        let formValue = this.changePWForm.value
        console.log(formValue)

        let pwvalid = this.isPasswordValid(formValue.NewPassword,formValue.ConfirmPassword)
        console.log('pwvalid' + pwvalid)
        console.log("this.i_spclcharcnt="+this.i_spclcharcnt)
        console.log("this.i_notspclcharcnt="+this.i_notAllowedspclchar)
        this.resetField();

        if (formValue.NewPassword != formValue.ConfirmPassword) {
            let option = {
                confirm: false,
                error: true,
                title: "Error",
                message: "New Password & Confirm Password doesnot match",
                confirmButtonLabel: "OK",
                cancelButtonLabel: "No"
            };
            this.dialogService.open(option);
        }else if(pwvalid==false)
        {
            let option = {
                confirm: false,
                error: true,
                title: "Error",
                message: "Password must have a minimum length of 8 and maximum length of 20 and it must contain an uppercase,a lower case,a digit,special characters allowed are $_@*.!~ ",
                confirmButtonLabel: "OK",
                cancelButtonLabel: "No"
            };
            this.dialogService.open(option);
        }
        else {
                this.changePw.changeLandlordPassword(formValue).subscribe(resp=>{
                this.route.navigate(['/home']);
                this.resetField();
                console.log("success")
                this.changePwModalRef=this.modalService.openModal(template, "md");
                //window.location.reload();
               this.changePw.updatesaveFlag(true)
            })

        }


    }
    viewPasswordClicked(myInput: any) {
        if (myInput.type === "password") {
            myInput.type = "text";
        } else {
            myInput.type = "password";
        }
    }

    isPasswordValid(textValue: any,confirmpw:any) {
        // PASSWORD_POLICY=Password Policy :\n\nMin Length = 8\nMax Length = 20\nMin UpperCase Character(s) = 1\nMin LowerCase Character(s) = 1\nMin Digit = 1\nMin Special Character(s) = 1\nSpecial Character(s) Allowed = $_@*.!~

        // console.log("code="+textValue.charCodeAt(0))
        for (let i = 0; i < textValue.length; i++) {
            let chars = textValue.charAt(i);
            let ch = textValue.charCodeAt(i);
            // console.log(ch)
            // console.log(ch.keyCode)
            if (ch >= 65 && ch <= 90) {
                this.i_uppercasecnt++;
            }
            else if (ch >= 97 && ch <= 122) {
                this.i_lowercasecnt++;
            }
            else if (ch >= 48 && ch <= 57) {
                this.i_digitcnt++;
            } else if (chars.includes('$') || chars.includes('_') || chars.includes('~') ||
                chars.includes('@') || chars.includes('*') || chars.includes('.') || chars.includes('!')) {
                this.i_spclcharcnt++;
            }else if (ch!=33 && ch!=36 && ch!=42 && ch!=46 && ch!=64 && ch!=95) {
                this.i_notAllowedspclchar++;
            }
            else {
                console.log("pw error")
            }
        }
        if (textValue.length < 8 && textValue.length > 20) {
            //console.log(formValue.NewPassword.length)
            console.log("error4")
            return false;
        }
        else if (this.i_uppercasecnt < 1) {
            // console.log(this.i_uppercasecnt)
            console.log("error1")
            return false
        }
        else if (this.i_lowercasecnt < 1) {
            // console.log(this.i_lowercasecnt)

            console.log("error2")
            return false;
        }
        else if (this.i_digitcnt < 1) {
            //console.log(this.i_digitcnt)
            console.log("error3")
            return false;
        }
        else if (this.i_spclcharcnt < 1) {
            //console.log(this.i_digitcnt)
            console.log("error5")
            return false;
        }
        else if (this.i_notAllowedspclchar > 0) {
            //console.log(this.i_digitcnt)
            console.log("error6")
            return false;
        }
        else{

        }
        return true;

    }


    resetField() {
    this.i_lowercasecnt = 0;
    this.i_uppercasecnt = 0;
    this.i_digitcnt= 0;
    this.i_count = 0;
    this.i_spclcharcnt = 0;
    this.i_notAllowedspclchar=0

    }

}
