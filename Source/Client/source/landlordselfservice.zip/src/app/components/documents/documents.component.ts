import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ModalService } from 'src/app/services/modal.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from 'src/app/services/documents.service';
import { EnvService } from 'src/app/services/env.service';
import { siteBackButton } from 'src/app/services/site-back-button';




@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {

  documents !: any;
  uploadDocForm!: FormGroup;
  documentType !: any;
  uploadedFileName !: string;
  isUploadedFileAvailable !: boolean;
  isUploadClicked: boolean = false;
  isFileUploaded: boolean = false;
  saveDocumentModalRef!: BsModalRef;
  uploadDocErrorModalRef!: BsModalRef;
  deleteDocConfirmationModalRef!: BsModalRef;
  fileUid!: any;
  isViewBtnClicked: boolean = false;
  errorMsg!: string;
  iframeSrc!: any;
  viewImg: boolean = false;
  docTypeIsImg!:boolean;
  isVisible:boolean=false;

  constructor(
    private fb: FormBuilder,
    private modalService: ModalService,
    private sanitizer: DomSanitizer,
    private documentsService: DocumentsService,
    private envService: EnvService,
    private bck_btn: siteBackButton) { }

  ngOnInit(): void {
    this.bck_btn.setNavbarHeaderName('Documents');
    this.retrieveLandlordDocuments();
    this.createUploadDocForm();
    this.retrievedocumenttypes();
  }

  retrieveLandlordDocuments() {
    this.documentsService.retrieveLandlordDocuments().subscribe(resp => {
      this.documents = resp;
    })
  }
  getDocumentType(attribute: any) {
    let attr = JSON.parse(attribute);
    return attr?.type;
  }
  getDocumentDescription(attribute: any) {
    let attr = JSON.parse(attribute);
    return attr?.description;
  }
  generateThumbNail(fileName: any) {
    let src = "";
    if (fileName.includes('.txt')) {
      src = "assets/icons/documents2.png";
    }
    else if (fileName.includes('.png') || fileName.includes('.jpg') || fileName.includes('.jpeg')) {
      src = "assets/icons/jpg.png";
    }
    else if (fileName.includes('.exe') || fileName.includes('.xlsx')) {
      src = "assets/icons/xls.png";
    }
    else if (fileName.includes('.doc') || fileName.includes('.docx')) {
      src = "assets/icons/doc.png";
    }
    else {
      src = "assets/icons/others.png";
    }
    return src;
  }
  viewDocumentContent(url: any,fileName:any) {
    let fileNameArr = fileName.split('.');
    let fileNameExtension = fileNameArr[fileNameArr.length-1];
    this.docTypeIsImg = fileNameExtension=='jpg' || fileNameExtension=='jpeg'|| fileNameExtension=='png'? true : false;
    this.viewImg = true;
    let baseulr = this.envService.apiBaseURL;
    let docUrl = url.split('/RuleServer/')[1];
    let src = `${baseulr}/RuleServer/${docUrl}`;
    this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl(src);
    this.bck_btn.emitData(true);
    this.bck_btn.setAfterBackBtnClickFunc().subscribe(resp => {
      this.viewImg = false;
    });
  }
  openDeleteConfirmation(template: TemplateRef<any>, fileUid: any) {
    this.deleteDocConfirmationModalRef = this.modalService.openModal(template, "sm");
    this.fileUid = fileUid;
  }
  deleteDoc(e: any) {
    this.documentsService.removeLandlordDocument(this.fileUid).subscribe(resp => {
      this.deleteDocConfirmationModalRef.hide();
      this.retrieveLandlordDocuments();
    });
  }
  backIconClicked() {
    this.isUploadClicked = false;
    this.isUploadedFileAvailable = false;
    this.uploadedFileName = '';
    this.createUploadDocForm();
  }
  createUploadDocForm() {
    this.uploadDocForm = this.fb.group({
      Name: ["", Validators.required],
      Type: ["", Validators.required],
      Description: ["", Validators.required],
      Content: [""]
    });
  }
  retrievedocumenttypes() {
    this.documentsService.getLandlordDocumentTypes().subscribe(resp => {
      this.documentType = resp.documenttypes;
    })
  }
  handleFileInput(event: any, template: TemplateRef<any>) {
    let reader = new FileReader();
    let file = event.target.files[0];
    let fileName = event.target.files[0].name;
    var fileSize = event.target.files[0].size / 1024;

    reader.readAsDataURL(file)
    reader.onload = (ev: any) => {
      if (fileSize > 5000) {
        this.errorMsg = "File size is large, maximum file size allowed is 5Mb";
        this.uploadDocForm.patchValue({ Content: "" });
        this.uploadDocForm.patchValue({ Name: fileName });
        this.isUploadedFileAvailable = false;
      }
      else {
        this.uploadDocForm.patchValue({ Name: fileName });
        //this.uploadDocForm.patchValue({ Content: reader.result?.toString() });
        this.uploadDocForm.patchValue({ Content: reader.result as string });
        this.uploadedFileName = fileName
        this.isUploadedFileAvailable = true;
      }
    };
  }
  deleteUploadedDoc() {
    this.uploadDocForm.patchValue({ Name: '' });
    this.uploadDocForm.patchValue({ Content: '' });
    this.uploadedFileName = '';
    this.isUploadedFileAvailable = false;
  }
  saveUploadedDocument(template: TemplateRef<any>) {
    let obj = this.uploadDocForm.value;
    obj.Content = obj.Content.split('base64,')[1];
    this.documentsService.uploadLandlordDocument(obj).subscribe(resp => {
      this.saveDocumentModalRef = this.modalService.openModal(template, "md");
    }, (error: any) => {
      console.error('error', error);
    });
  }
  refreshDocumentList = () => {
    this.retrieveLandlordDocuments();
    this.isUploadClicked = false;
  }

}
