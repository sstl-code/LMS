import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { EnvService } from 'src/app/services/env.service';
import { ProfileService } from 'src/app/services/profile.service';
import { siteBackButton } from 'src/app/services/site-back-button';

@Component({
  selector: 'app-tickets',
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.scss']
})
export class TicketsComponent implements OnInit {

  ticket_iframeSrc!:any;

  constructor(private envService: EnvService,
    private sanitizer: DomSanitizer,
    private profileService: ProfileService,
    private bck_btn: siteBackButton) { }

  ngOnInit(): void {
    this.bck_btn.setNavbarHeaderName('Helpdesk');
    this.retrievelandlordprofile();   
  }

  retrievelandlordprofile() {
    this.profileService.retrieveLandlordProfile().subscribe(resp => {
     let landlordId = resp.Landlordid;
      let ticket_url = `${this.envService.apiBaseURL}/workflow/#/tickets?instanceFilter=landlordid:${landlordId}&templateFilter=LandlordTroubleTicket&createFlag=true&data=LandlordId:${landlordId}`;
      this.ticket_iframeSrc = this.sanitizer?.bypassSecurityTrustResourceUrl(ticket_url);
    });
  }

}
