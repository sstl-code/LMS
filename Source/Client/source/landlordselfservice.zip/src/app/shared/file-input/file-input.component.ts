import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, Self } from '@angular/core';
import { ControlValueAccessor, FormControl, NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { finalize, subscribeOn } from 'rxjs/operators';

@Component({
  selector: 'app-file-input',
  templateUrl: './file-input.component.html',
  styleUrls: ['./file-input.component.scss']
})
export class FileInputComponent implements ControlValueAccessor {

  @Input() acceptedFileType!: string;
  @Input() mandatory!: boolean;
  @Input() disable!: boolean;
  fileName = '';
  uploadSub!: any ;

  constructor(@Self() public ngControl: NgControl,private http: HttpClient) {
    this.ngControl.valueAccessor = this;
  }
  get control() {
    return this.ngControl.control as FormControl
  }
  writeValue(obj: any): void {
  }

  registerOnChange(fn: any): void {
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState?(isDisabled: boolean): void {
  }

  onFileSelected(event:any) {
    // const file:File = event.target.files[0];
  
    // if (file) {
    //     this.fileName = file.name;
    //     const formData = new FormData();
    //     formData.append("thumbnail", file);

    //     const upload$ = this.http.post("/api/thumbnail-upload", formData, {
    //         reportProgress: true,
    //         observe: 'events'
    //     })
    //     .pipe(
    //         finalize(() => this.reset())
    //     );
      
    // }
}

cancelUpload() {
// this.uploadSub.unsubscribe();
// this.reset();
}
reset() {
  //this.uploadSub = '';
}

}
