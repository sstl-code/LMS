import { Component, EventEmitter, Input, OnInit, Output, Self } from '@angular/core';
import { ControlValueAccessor, FormControl, NgControl } from '@angular/forms';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent implements ControlValueAccessor {

  @Input() label!: string;
  @Input() disable!: boolean;
  @Output() selectedValueChange = new EventEmitter<boolean>();

  constructor(@Self() public ngControl: NgControl) {
    this.ngControl.valueAccessor = this;
  }
  get control() {
    return this.ngControl.control as FormControl
  }
  writeValue(obj: any): void { }

  registerOnChange(fn: any): void { }

  registerOnTouched(fn: any): void { }

  onCheck(value:boolean){
    this.selectedValueChange.emit(value);
  }
}
