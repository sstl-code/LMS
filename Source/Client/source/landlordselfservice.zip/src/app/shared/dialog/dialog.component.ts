import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface DialgData{
  confirm: boolean;
  error:boolean;
  title: string;
  message : string;
  confirmButtonLabel: string;
  cancelButtonLabel: string;
} 
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss'],
  encapsulation: ViewEncapsulation.None 
})
export class DialogComponent implements OnInit {
  dialogData!: DialgData;
  confirm!: boolean;
  error!:boolean;
  title!: string;
  message !: string;
  confirmButtonLabel!: string;
  cancelButtonLabel!: string;

  constructor(public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialgData) { }

  ngOnInit(): void {
  }

  public _cancel() {
    this.dialogRef.close(false);
  }
  public _confirm() {
    this.dialogRef.close(true);
  }

}
