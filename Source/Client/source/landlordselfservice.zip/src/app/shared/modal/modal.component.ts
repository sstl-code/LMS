import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
 
  @Input() title!: string;
  @Input() dismissBtnLabel: string = '';   
  @Input() disMissCallback =():void =>{} ;
  @Input() btnTwoLabel: string = '';
  @Output() btnTwoFunction = new EventEmitter<boolean>();
  showBtnTwo: boolean = false;
  @Input() showFooter: boolean =true;
  @Input() modalReference!: BsModalRef;

  constructor(public bsModalRef: BsModalRef,
    private bsModalService: BsModalService) { }

    ngOnInit(): void {
      this.showBtnTwo = this.btnTwoLabel=='' ? false : true;
    }
    dismissModal() {
      this.modalReference.hide();
      this.disMissCallback();
    }
    btnTowTasks(e:any){
      this.btnTwoFunction.emit();
    }

}
