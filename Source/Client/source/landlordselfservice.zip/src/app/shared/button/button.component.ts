import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements ControlValueAccessor {

  @Input() label!: string;
  @Input() disable: boolean =false;
  @Output() clicked = new EventEmitter<boolean>();
  
  constructor() { }

  writeValue(obj: any): void {

  }
  registerOnChange(fn: any): void {

  }
  registerOnTouched(fn: any): void {

  }
  onClick(value:any){
    this.clicked.emit(value);
  }
}
