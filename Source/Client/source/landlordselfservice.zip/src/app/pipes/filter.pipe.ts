import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if(!value)return null;
    if(!args)return value;
    const tasks :any[] =[];
    for(let i=0; i<value.length;i++){
      let workflow = value[i]?.workflow;
      let taskName = value[i]?.taskName;
      let instanceId = value[i]?.instanceId;
      if(workflow?.includes(args) || taskName?.includes(args) || instanceId.includes(args)){
        tasks.push(value[i])
      }
    }
    return tasks;
}

}
