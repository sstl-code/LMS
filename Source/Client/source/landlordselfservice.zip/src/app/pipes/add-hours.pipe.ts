import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'addHours'
})
export class AddHoursPipe implements PipeTransform {

  transform(startTimeStamp: any, addHour: any) {
    let finalDate = (new Date(new Date(startTimeStamp).setHours(new Date(startTimeStamp).getHours() + addHour))).toString().split('GMT')[0].split(' ');
    let formattedFinalDate = finalDate[2] + '-' + finalDate[1] + '-' + finalDate[3] + ' ' + finalDate[4];
    return formattedFinalDate;
  }

}
