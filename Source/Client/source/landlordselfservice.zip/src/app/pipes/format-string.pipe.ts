import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatString'
})
export class FormatStringPipe implements PipeTransform {

  transform(str: string) {
    let _string = str.replace(/([a-z])([A-Z])/g, '$1 $2');
     return _string;
   }

}
