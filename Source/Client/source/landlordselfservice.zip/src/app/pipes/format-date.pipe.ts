import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatDate'
})
export class FormatDatePipe implements PipeTransform {

  transform(dateTime: any) {
    let formattedDate!: any;
    if (dateTime != null) {
      let date = new Date(dateTime).toString().split('GMT')[0].split(' ');
      formattedDate = date[2] + '-' + date[1] + '-' + date[3];
    }
    return formattedDate;
  }

}
