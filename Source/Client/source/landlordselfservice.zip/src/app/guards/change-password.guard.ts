import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { ChangePasswordService } from '../services/change-password.service';
import { DecodeTokenService } from '../services/decode-token.service';

@Injectable({
    providedIn: 'root'
})
export class ChangePasswordGuard implements CanActivate {

    constructor(public authService: AuthService,
        public router: Router,
        public changePw: ChangePasswordService,
        public decodeToken: DecodeTokenService
    ) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        // if (this.authService.isAuthorised() && this.authService.getUserAttributes()==true ) {
        //     return true;
        //   }
        // else if (this.authService.isAuthorised() && this.authService.getUserAttributes()==false) {
        //     return this.router.navigate(['/home']);
        // }
        // else {
        //     return this.router.parseUrl('/login');
        // }
        if (this.authService.isAuthorised()) {
            return true;
          }
          else {
            return this.router.parseUrl('/login');
          }

    }





}
