var map;
var arrayOfMarker = [];
var geoFenceArea;
var mapCenterMarker;
var iconType;
//const towerSVGPath = "M12 5C12.5523 5 13 4.55228 13 4C13 3.44772 12.5523 3 12 3C11.4477 3 11 3.44772 11 4C11 4.55228 11.4477 5 12 5Z M16 1C16 1 17.5 2 17.5 4C17.5 6 16 7 16 7 M8 1C8 1 6.5 2 6.5 4C6.5 6 8 7 8 7 M7 23L8.11111 19M17 23L15.8889 19M14.5 14L12 5L9.5 14M14.5 14H9.5M14.5 14L15.8889 19M9.5 14L8.11111 19M8.11111 19H15.8889";
//const assetSVGPath = "M2 15V9C2 5.68629 4.68629 3 8 3H16C19.3137 3 22 5.68629 22 9V15C22 18.3137 19.3137 21 16 21H8C4.68629 21 2 18.3137 2 15Z M11.6667 8L10 12H14L12.3333 16";
//const landlordSVGPath = "M10 9.01L10.01 8.99889 M14 9.01L14.01 8.99889 M10 13.01L10.01 12.9989 M14 13.01L14.01 12.9989 M10 17.01L10.01 16.9989 M14 17.01L14.01 16.9989 M6 20.4V5.6C6 5.26863 6.26863 5 6.6 5H12V3.6C12 3.26863 12.2686 3 12.6 3H17.4C17.7314 3 18 3.26863 18 3.6V20.4C18 20.7314 17.7314 21 17.4 21H6.6C6.26863 21 6 20.7314 6 20.4Z";

const towerSVGPath = "M20 10C20 14.4183 12 22 12 22C12 22 4 14.4183 4 10C4 5.58172 7.58172 2 12 2C16.4183 2 20 5.58172 20 10Z M12 11C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9C11.4477 9 11 9.44772 11 10C11 10.5523 11.4477 11 12 11Z";
const assetSVGPath = "M20 10C20 14.4183 12 22 12 22C12 22 4 14.4183 4 10C4 5.58172 7.58172 2 12 2C16.4183 2 20 5.58172 20 10Z M12 11C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9C11.4477 9 11 9.44772 11 10C11 10.5523 11.4477 11 12 11Z";
const landlordSVGPath = "M20 10C20 14.4183 12 22 12 22C12 22 4 14.4183 4 10C4 5.58172 7.58172 2 12 2C16.4183 2 20 5.58172 20 10Z M12 11C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9C11.4477 9 11 9.44772 11 10C11 10.5523 11.4477 11 12 11Z";

const svgDefaultFillColor = "#4169E1";
const svgDefaultStrokeColor = "#4169E1";
const svgOutsideFenceFillColor = "#A9A9A9";
const svgOutsideFenceStrokeColor = "#696969";

var infoWindow;

var arrayOfUID = [];
var gmapid;

window.loadMap = function(center, locationType,mapdivid) {
	iconType = locationType;
	gmapid=mapdivid;
	//alert("mapdivid::"+mapdivid);
	console.log(mapdivid);
	var initialCenter = new google.maps.LatLng(parseFloat(center.lat), parseFloat(center.lng)); //'{"lat":' + parseFloat(center.lat) + ', "lng":' + parseFloat(center.lng) + '}';
//	map = new google.maps.Map(document.getElementById('custom-google-map'), {
	map = new google.maps.Map(document.getElementById(gmapid), {
      scrollwheel: true,
      mapTypeControl: true,
      center: initialCenter,
   //   zoom: 10,
      zoom: 7,
      streetViewControl: true,
      zoomControl: true
    });
	
	const svgMarker = {
		    //path: "M12 19C15.866 19 19 15.866 19 12C19 8.13401 15.866 5 12 5C8.13401 5 5 8.13401 5 12C5 15.866 8.13401 19 12 19Z M12 19V21 M5 12H3 M12 5V3 M19 12H21",
			//fillColor: "#2E8B57",
			path: "M3.68478 18.7826L11.5642 4.77473C11.7554 4.43491 12.2446 4.43491 12.4358 4.77473L20.3152 18.7826C20.5454 19.1918 20.1357 19.6639 19.6982 19.4937L12.1812 16.5705C12.0647 16.5251 11.9353 16.5251 11.8188 16.5705L4.30179 19.4937C3.86426 19.6639 3.45463 19.1918 3.68478 18.7826Z",
		    fillColor: "#708090",
			
			
		    fillOpacity: 0.5,
		    strokeWeight: 2,
		    strokeColor: "#708090",
		    rotation: 0,
		    scale: 1,
		    anchor: new google.maps.Point(13, 25),
	};
	
	mapCenterMarker = new google.maps.Marker({
	    position: initialCenter,
	    map: map,
	    draggable: true,
	    animation: google.maps.Animation.DROP,
	    title: 'Center',
	    //icon: svgMarker
	});
	
	google.maps.event.addListener(mapCenterMarker, 'dragend', function(e) {
	    map.panTo(mapCenterMarker.getPosition());
	    
	    if(geoFenceArea && geoFenceArea.getMap()) {
	    	geoFenceArea.setOptions({
	  	      center: e.latLng
	  	    });
	    	filterMarkers();
	    }
	});
}

window.clearMarkers = function() {
	console.log("inside clearMarkers");
	console.log("arrayOfMarker.length="+arrayOfMarker.length);
	if(arrayOfMarker) {
		for(let i = 0; i < arrayOfMarker.length; i++) {
			arrayOfMarker[i].marker.setMap(null);
		}
		arrayOfMarker.length = 0;
		arrayOfMarker = [];
	}
}


window.populateMarkers = function(markerData) {
//	console.log((markerData));
//	console.log("markerData.length="+markerData.length);
	//console.log("inside populateMarkers  arrayOfMarker "+arrayOfMarker);
	clearMarkers();
	var propertyIcontype;
	
	for(let i = 0; i < markerData.length; i++) {
        let eachMarkerData = markerData[i];
        let markerLatLng = new google.maps.LatLng(parseFloat(eachMarkerData.lat), parseFloat(parseFloat(eachMarkerData.lng))); //'{"lat":' + parseFloat(eachMarkerData.lat) + ', "lng":' + parseFloat(eachMarkerData.lng) + '}';
        
        var svgPath;
        
        if (iconType === 1) {
        	svgPath = towerSVGPath;
        } else if (iconType === 2) {
        	svgPath = assetSVGPath;
        } else {
        	svgPath = landlordSVGPath;
        }
        
        var svgLocationMarker = {
		    path: svgPath,
		    fillColor: svgDefaultFillColor,
		    fillOpacity: 0.5,
		    strokeWeight: 2,
		    strokeColor: svgDefaultStrokeColor,
		    rotation: 0,
		    scale: 1.5,
		    anchor: new google.maps.Point(13, 25),
    	};
        
        if(iconType==1){
        //	console.log(eachMarkerData.PropertyType)
            let propertytype=eachMarkerData.PropertyType
            if(propertytype=="Private"){
                //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
                	propertyIcontype="./icons/private.png";
                }else if(propertytype=="Rental"){
                //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/parking_lot_maps.png";
                	propertyIcontype=svgLocationMarker;
                }else if(propertytype=="Public"){
                	//propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/info-i_maps.png";
                	propertyIcontype="./icons/public.png";
                }else if(propertytype=="Contractual"){
                	//propertyIcontype="http://maps.google.com/mapfiles/ms/icons/pink-dot.png";
                	propertyIcontype=svgLocationMarker;
                }else if(propertytype=="Commercial"){
                //	propertyIcontype="http://maps.google.com/mapfiles/ms/icons/green-dot.png";
                	propertyIcontype="./icons/commercial.png";
                }else if(propertytype=="Institutional"){
                	//propertyIcontype="./icons/radio-station-2.png";
                //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
                	propertyIcontype="./icons/govt.png";
                }else{
                	propertyIcontype=svgLocationMarker;
                }
        }else if(iconType==2){
        	propertyIcontype=svgLocationMarker;
        }else {
        	propertyIcontype=svgLocationMarker;
        }
        
                
        let marker = new google.maps.Marker({
            position: markerLatLng,
            map,
          //  icon: svgLocationMarker,
           // icon: "https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png",
            icon:propertyIcontype,
            title: eachMarkerData.title.toString(),
        });
        
        eachMarkerData.marker = marker;
        arrayOfMarker.push(eachMarkerData);
        console.log(eachMarkerData);
        marker.addListener("click", () => {
        	var eventMarkerClick = new CustomEvent('custom-gmap-marker-click', {
      		  bubbles: true,
      		  detail: eachMarkerData.uniqueId,
      		  
      		//  detail:eachMarkerData.uniqueId+eachMarkerData.lat+eachMarkerData.lng,
      	//	  lati:eachMarkerData.lat,
      	//	  longi:eachMarkerData.lng,
	      	});
	    //  	document.getElementById('custom-google-map').dispatchEvent(eventMarkerClick);
        //	alert("gmapid::"+gmapid+dispatchEvent(eventMarkerClick));
        //	alert("dispatchEvent(eventMarkerClick)::"+dispatchEvent(eventMarkerClick));
        	document.getElementById(gmapid).dispatchEvent(eventMarkerClick);
	      	displayInfoWindow(eachMarkerData.uniqueId);
	     
        	// 	console.log("ID="+eachMarkerData.uniqueId);
        });
	}
	 
}

window.displayInfoWindow = function(uniqueId) {
	console.log("inside display fn");
	console.log("ID2="+uniqueId);
	console.log("displayInfoWindow(" + uniqueId + ")");
	console.log(arrayOfMarker);
	if(infoWindow) {
		infoWindow.close();
		infoWindow = null;
	}
	if(uniqueId && arrayOfMarker) {
		for(let i = 0; i < arrayOfMarker.length; i++) {
			if(arrayOfMarker[i].uniqueId.localeCompare(uniqueId) == 0) {
				infoWindow = new google.maps.InfoWindow({
				    content: arrayOfMarker[i].contentString,
				});
				
				console.log(arrayOfMarker[i].contentString)
				
				infoWindow.open({
				    anchor: arrayOfMarker[i].marker,
				    map,
				    shouldFocus: false,
				});
				
				break;
			}
		}
	}
}

window.displayMarkerInfoWindow = function(uniqueIdArray) {
	
	
	//console.log("displayInfoWindow(" + uniqueIdArray.toString() + ")");
	//console.log("arrayOfMarker="+arrayOfMarker);
	arrayOfUID.length = 0;
	arrayOfUID = [];
	
	for(let i = 0; i < uniqueIdArray.length; i++) {
		let eachUID = uniqueIdArray[i];
		arrayOfUID.push(eachUID);
	}
	
	if(infoWindow) {
		infoWindow.close();
		infoWindow = null;
	}
	if(uniqueIdArray && arrayOfMarker) {
		for(let i = 0; i < arrayOfMarker.length; i++) {
			
			let a = arrayOfMarker[i].uniqueId.toString();
			let b=arrayOfUID[0].UID.toString();
			let result = a.localeCompare(b);
			
			
	//		if(arrayOfMarker[i].uniqueId.localeCompare(arrayOfUID[0].UID) == 0) {
			if(result == 0) {
			//	alert(arrayOfMarker[i].contentString);
				infoWindow = new google.maps.InfoWindow({
				    content: arrayOfMarker[i].contentString,
				});
				
				console.log(arrayOfMarker[i].contentString)
				
				infoWindow.open({
				    anchor: arrayOfMarker[i].marker,
				    map,
				    shouldFocus: false,
				});
				
				break;
			}
		}
	}
}



window.clearGeofence = function() {
	if(geoFenceArea) {
		geoFenceArea.setMap(null)
	}
	
	clearFilter();
}

window.applyGeofence = function(radius) {
	clearGeofence();
	
	geoFenceArea = new google.maps.Circle({
	    strokeColor: '#1E90FF',
	    strokeOpacity: 0.5,
	    strokeWeight: 2,
	    fillColor: '#1E90FF',
	    fillOpacity: 0.2,
	    map: map,
	    center: mapCenterMarker.getPosition(),
	    radius: radius
	});
	
	filterMarkers();
}

window.filterMarkers = function() {
	var propertyIcontype;
	
	if(arrayOfMarker) {
		for(let i = 0; i < arrayOfMarker.length; i++) {
			var fillColor = svgDefaultFillColor;
			var strokeColor = svgDefaultStrokeColor;
			var svgPath = towerSVGPath;
		        //arrayOfMarker[i].marker.setIcon('http://maps.google.com/mapfiles/ms/icons/green-dot.png');
			if (google.maps.geometry.spherical.computeDistanceBetween(arrayOfMarker[i].marker.getPosition(), geoFenceArea.getCenter()) <= geoFenceArea.getRadius()) {
				fillColor = svgDefaultFillColor;
				strokeColor = svgDefaultStrokeColor;
		    } else {
		        //arrayOfMarker[i].marker.setIcon('http://maps.google.com/mapfiles/ms/icons/pink-dot.png');
		    	fillColor = svgOutsideFenceFillColor;
				strokeColor = svgOutsideFenceStrokeColor;
		    }
			
			if (iconType === 1) {
	        	svgPath = towerSVGPath;
	        } else if (iconType === 2) {
	        	svgPath = assetSVGPath;
	        } else {
	        	svgPath = landlordSVGPath;
	        }
	        
	        var svgLocationMarker = {
			    path: svgPath,
			    fillColor: fillColor,
			    fillOpacity: 0.5,
			    strokeWeight: 2,
			    strokeColor: strokeColor,
			    rotation: 0,
			    scale: 1.5,
			    anchor: new google.maps.Point(13, 25),
	    	};
	        
	  //      arrayOfMarker[i].marker.setIcon(svgLocationMarker);
	        
	        if(iconType==1){
	            //	console.log(eachMarkerData.PropertyType)
	                let propertytype=arrayOfMarker[i].PropertyType
	                if(propertytype=="Private"){
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
	                    	propertyIcontype="./icons/private.png";
	                    }else if(propertytype=="Rental"){
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/parking_lot_maps.png";
	                    	propertyIcontype=svgLocationMarker;
	                    }else if(propertytype=="Public"){
	                    	//propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/info-i_maps.png";
	                    	propertyIcontype="./icons/public.png";
	                    }else if(propertytype=="Contractual"){
	                    	//propertyIcontype="http://maps.google.com/mapfiles/ms/icons/pink-dot.png";
	                    	propertyIcontype=svgLocationMarker;
	                    }else if(propertytype=="Commercial"){
	                    //	propertyIcontype="http://maps.google.com/mapfiles/ms/icons/green-dot.png";
	                    	propertyIcontype="./icons/commercial.png";
	                    }else if(propertytype=="Institutional"){
	                    	//propertyIcontype="./icons/radio-station-2.png";
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
	                    	propertyIcontype="./icons/govt.png";
	                    }else{
	                    	propertyIcontype=svgLocationMarker;
	                    }
	            }else if(iconType==2){
	            	propertyIcontype=svgLocationMarker;
	            }else {
	            	propertyIcontype=svgLocationMarker;
	            }
	        arrayOfMarker[i].marker.setIcon(propertyIcontype);
	        
		}
	}
}

window.clearFilter = function() {
	var propertyIcontype;
	if(arrayOfMarker) {
		for(let i = 0; i < arrayOfMarker.length; i++) {
			//arrayOfMarker[i].marker.setIcon('http://maps.google.com/mapfiles/ms/icons/green-dot.png');
			var svgPath = towerSVGPath;
			if (iconType === 1) {
	        	svgPath = towerSVGPath;
	        } else if (iconType === 2) {
	        	svgPath = assetSVGPath;
	        } else {
	        	svgPath = landlordSVGPath;
	        }
	        
	        var svgLocationMarker = {
			    path: svgPath,
			    fillColor: svgDefaultFillColor,
			    fillOpacity: 0.5,
			    strokeWeight: 2,
			    strokeColor: svgDefaultStrokeColor,
			    rotation: 0,
			    scale: 1.5,
			    anchor: new google.maps.Point(13, 25),
	    	};
	        
	     //   arrayOfMarker[i].marker.setIcon(svgLocationMarker);
	        if(iconType==1){
	            //	console.log(eachMarkerData.PropertyType)
	                let propertytype=arrayOfMarker[i].PropertyType
	                if(propertytype=="Private"){
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
	                    	propertyIcontype="./icons/private.png";
	                    }else if(propertytype=="Rental"){
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/parking_lot_maps.png";
	                    	propertyIcontype=svgLocationMarker;
	                    }else if(propertytype=="Public"){
	                    	//propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/info-i_maps.png";
	                    	propertyIcontype="./icons/public.png";
	                    }else if(propertytype=="Contractual"){
	                    	//propertyIcontype="http://maps.google.com/mapfiles/ms/icons/pink-dot.png";
	                    	propertyIcontype=svgLocationMarker;
	                    }else if(propertytype=="Commercial"){
	                    //	propertyIcontype="http://maps.google.com/mapfiles/ms/icons/green-dot.png";
	                    	propertyIcontype="./icons/commercial.png";
	                    }else if(propertytype=="Institutional"){
	                    	//propertyIcontype="./icons/radio-station-2.png";
	                    //	propertyIcontype="https://developers.google.com/maps/documentation/javascript/examples/full/images/library_maps.png";
	                    	propertyIcontype="./icons/govt.png";
	                    }else{
	                    	propertyIcontype=svgLocationMarker;
	                    }
	            }else if(iconType==2){
	            	propertyIcontype=svgLocationMarker;
	            }else {
	            	propertyIcontype=svgLocationMarker;
	            }
	        arrayOfMarker[i].marker.setIcon(propertyIcontype);
		}
	}
}
