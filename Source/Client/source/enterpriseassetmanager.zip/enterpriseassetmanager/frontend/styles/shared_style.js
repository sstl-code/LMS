const $_documentContainer = document.createElement('template');

$_documentContainer.innerHTML = `<dom-module id="umt_portal_email_field" theme-for="vaadin-email-field">
<template>
<style>
[part~="input-field"] {
	background: white;
	border-bottom: 1px solid darkgray;
	border-radius:0;
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';			
}

[part~="input-field"]::after {
	background: white;
}

[part~="label"] {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';		
}

[part~="label"] ::after {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

:host ([focused] )  [part~="input-field"] {
	box-shadow: 1px 1px 2px 2px violet;
	border-bottom: 1px solid darkgray;
	border-radius:0;
}

:host ([focused] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px violet;
}

:host ([disabled] )  [part~="input-field"] {
	background-color: white;
}

:host ([disabled] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px violet;
	background-color: white;
}
</style>
</template> </dom-module>

<dom-module id="umt_portal_dialog_overlay_theme" theme-for="vaadin-dialog-overlay">
  <template>
    <style>
     
    :host(vaadin-dialog-overlay) [part~="overlay"] {
    	width: 400px;
    }
     
    :host(vaadin-dialog-overlay) [part~="content"] {
		padding:0px;
    }
    [part="backdrop"]{
background-color: hsl(0deg 0% 91% / 62%);
}
    
    :host([theme~="capture-timed-value-dialog"]) [part~="overlay"] {
	    width: auto;
	}

    </style>
  </template>
</dom-module>

<dom-module id="umt_portal_password_field"
	theme-for="vaadin-password-field"> <template>
<style>
[part~="input-field"] {
	background: white;
	border-bottom: 1px solid darkgray;
	border-radius:0;
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="input-field"]::after {
	background: white;
}

[part~="label"] {
	font-size: 14px;
	 font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="label"] ::after {
	font-size: 14px;
	 font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

:host ([focused] )  [part~="input-field"] {
	box-shadow: 1px 1px 2px 2px violet;
	border-bottom: 1px solid darkgray;
	border-radius:0;
}

:host ([focused] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px violet;
}
</style>
</template> </dom-module>
<dom-module id="umt_portal_combobox" theme-for="vaadin-combo-box">
<template>
<style>
[part~="label"] {
font-size: 14px !important;
}


</style>
</template> </dom-module>

<dom-module id="umt_portal_text_field" theme-for="vaadin-text-field">
<template>
<style>
:host([required]) [part="label"]{
padding-bottom: 15px;
}
[part~="input-field"] {
	background: white;
	border-bottom: 1px solid darkgray;
	border-radius:0;
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="input-field"]::after {
	background: white;
}

[part~="label"] {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="label"] ::after {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

:host ([focused] )  [part~="input-field"] {
	box-shadow: 1px 1px 2px 2px violet;
	border-bottom: 1px solid darkgray;
	border-radius:0;
}

:host ([focused] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px violet;
}

:host ([disabled] )  [part~="input-field"] {
	background-color: white;
	color: rgb(84, 84, 84);
    -webkit-text-fill-color: rgb(84, 84, 84);
}

:host ([disabled] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px violet;
	background-color: white;
	color: rgb(84, 84, 84);
    -webkit-text-fill-color: rgb(84, 84, 84);
}

:host([disabled]) [part="label"], :host([disabled]) [part="value"], :host([disabled]) [part="input-field"] ::slotted(*) {
	color: rgb(84, 84, 84);
    -webkit-text-fill-color: rgb(84, 84, 84);
}
:host([theme="HOME_TOP_NAV_SEARCHBOX"]) [part~="input-field"] {
	height: 38px;
	border: none;
}
:host([theme="NO_ROUNDED_EDGES"]) [part~="input-field"] {
	border-radius: 0px;
}
:host([theme="UMT_TXT_FLD_AUTO_WIDTH"]) .vaadin-text-field-container {
	
}
:host([theme="HOME_TOP_NAV_SEARCHBOX"]) [part~="input-field"] {
    height: 38px;
    border: none;
    background: #f2f3f5 !important;
}

</style>
</template> </dom-module>

<dom-module id="umt_portal_text_area_field" theme-for="vaadin-text-area">
<template>
<style>
[part~="input-field"] {
	background-color: white;
	border-bottom: 1px solid darkgray;
	border-radius:0;
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="input-field"]::after {
	background-color: white;
}

[part~="label"] {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

[part~="label"] ::after {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}

:host ([focused] )  [part~="input-field"] {
	box-shadow: 1px 1px 2px 2px darkgray;
	border-bottom: 1px solid darkgray;
	border-radius:0;
	background-color: white;
}

:host ([focused] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px darkgray;
	background-color: white;
}

:host ([disabled] )  [part~="input-field"] {
	background-color: white;
}

:host ([disabled] ) [part~="input-field"]::after {
	box-shadow: 1px 1px 2px 2px darkgray;
	background-color: white;
}

:host (:hover:not ([readonly] ):not ([focused] )) [part="input-field"] {
	background-color: white;
}
</style>
</template> 
</dom-module>

<dom-module id=umt_portal_vaadin-radio-button theme-for=vaadin-radio-button>
<template>
<style>
:host([disabled]) {
				color: rgb(84,84,84);
			}
			
			:host([disabled]) ::after {
				color: rgb(84,84,84);
			}
</style>
</template>
</dom-module>

<dom-module id=umt_portal_vaadin-button theme-for=vaadin-button>
<template>
<style>
:host([disabled][disabled]) {
    pointer-events: auto;
    
}
			:host([disabled]) {
				opacity: 0.5;

    color: black !important;
    cursor: not-allowed;
			}
			
			:host([disabled]) ::after {
				opacity: 0.5;

    color: black !important;
    cursor: not-allowed;
			}
			
			:host {
                font-weight: 700;
    color: #202C55 ;
    background: none ;
    cursor: pointer;
    border: 1px solid lightgray;
}

:host(:hover) {
                border: 1px solid lightgray;
    background: #e7eef4;        
}

</style>
</template>
</dom-module>

<dom-module id="umt_portal_combo_box_item"
	theme-for="vaadin-combo-box-item"> 
<template>
	<style>
	[part~="label"] {
	font-size: 14px !important;
	}
:host ([theme~=custom-combo-box] ) {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';	
}
</style>
</template> 
</dom-module>

<dom-module id=umt_portal_combo-box-dropdown theme-for=vaadin-combo-box-overlay�>
<template>
<style>
:host([theme~="custom"]) [part="overlay"] {
				width: 300px;
			}
</style>
</template>
</dom-module>

<dom-module id="umt_portal_upload" theme-for="vaadin-upload">
<template>
<style>
:host (:not ([nodrop] )) {
	border-bottom: 1px solid violet;
	border-radius:0;
}

[part="drop-label"] {
	font-size: 16px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';   
}

[part="file-list"] {
	 margin-top: -40px;
}

[part="progress"] {
	 width: 15px;
}

:host([theme~="capture-timed-value-upload"]) [part~="file-list"] {
   display: block;
   width: 178%;
   margin-top: -40px;
   margin-left: 130px;
}

</style>
</template> </dom-module>


<dom-module id="umt_portal_button" theme-for="vaadin-button">
<template>
<style>
:host {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	cursor: pointer;     
}
</style>
</template> </dom-module>



<!--Grid Pro Common Style Sheet  -->
<dom-module id="custom-grid" theme-for="vaadin-grid-pro"> <template>
<style>
:host #table {
	text-align: left;
	font-size: 16px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';		
}

:host #header th {
	font-size: 16px;
	font-weight: bold;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';		
}

:host ([theme~="compact"] ) [part~="cell"] ::slotted(vaadin-grid-cell-content)
	{
	text-align: left !important;
}
</style>
</template> </dom-module>

<dom-module id="umt_portal_tab" theme-for="vaadin-tab">
	<template>
        <style>
        :host::before, :host::after{
        height: 3px;
        width: 100%;
        
        }
        :host([selected])::before, :host([selected])::after{
        background-color: #202c55;
        }
        :host {
        	font-size: 14px;
      		font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
      		padding-bottom: 0px;
            padding-left: 8px;
            font-weight: bold;
            padding-right:8px;
        }
        :host([selected]){
        color: #202c55;
        }
        
        :host([focus-ring]) {
        	box-shadow: none;
        }
        
        </style>
    </template>
</dom-module>

<dom-module id="umt_portal_tabs" theme-for="vaadin-tabs">
<template>
        <style>
        :host(:not([orientation="vertical"])){
        box-shadow: none;
        }
         </style>
    </template>
</dom-module>

<dom-module id="umt_portal_grid" theme-for="vaadin-grid">
    <template>
        <style>
            :host #table {
               font-size: 12px;
               font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
            }
                       
            :host #header tr {
                text-align: left;
                border-bottom: none;
                background-color:rgba(245, 249, 255, 1);
            }
            
			[part~="row"]:hover [part~="body-cell"] {
            	background-color: rgba(22, 118, 243, 0.1);
            }
            
            :host([theme="GRID_ROW_AS_LINKS"]) [part~="cell"] ::slotted(vaadin-grid-cell-content) {
            	cursor: pointer;
            }
            			
            :host #header th
            {
                white-space: pre-line;
                word-wrap: break-word;
                font-weight: bold;
                font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
                background-color: #e7eef4; 
                color: #202C55;
                border-right: var(--_lumo-grid-border-width) solid var(--_lumo-grid-border-color);
            }
            
            :host [part~="header-cell"] ::slotted(vaadin-grid-cell-content) {
            	font-weight: bold;
            }

            :host #header th:last-child
            {
                border-right:none;
            }

            :host [part~="cell"]
            {
                white-space: pre-line;
                word-wrap: break-word;
                border-right: var(--_lumo-grid-border-width) solid var(--_lumo-grid-border-color);
                cursor: pointer;
                border-bottom: var(--_lumo-grid-border-width) solid var(--_lumo-grid-border-color);
            }
            
            :host([theme="CELL_WHITESPACE_NORMAL_THEME"]) [part~="cell"] ::slotted(vaadin-grid-cell-content) 
            {
            	white-space: normal;
			}
			
			:host([theme="CELL_WHITESPACE_NORMAL_THEME"]) #header th
			{
				white-space: normal;
			}
			
			:host([theme="CELL_WHITESPACE_NOWRAP_THEME"]) [part~="cell"] ::slotted(vaadin-grid-cell-content) 
            {
            	white-space: nowrap;
			}
			
			:host([theme="CELL_WHITESPACE_NOWRAP_THEME"]) #header th
            {
            	white-space: nowrap;
			}
			
            :host [part~="cell"]:last-child
            {
                border-right:none;
            }
            
            :host(:not([theme~="no-row-borders"])) [part~="cell"]:not([part~="details-cell"]) {
            	 border-top: none;
            }
            
            [part="row"]:only-child [part~="header-cell"] {
				min-height: auto;
			}

        </style>
    </template>
</dom-module>

<dom-module id="umt_portal_grid_sorter" theme-for="vaadin-grid-sorter">
    <template>
        <style>
		
		:host [part="content"]
		{
			display: flex;
			align-items: baseline;
			flex: unset;
			white-space: pre-line;
            word-wrap: break-word;
            font-size: 12px;
            font-weight: bold;
            font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
		}
		
		:host [part="indicators"]
		{
			display: flex;
			align-items: end;
			align-self:end;
		}

		</style>
    </template>
</dom-module>

<dom-module id="umt_portal_chart" theme-for="vaadin-chart">
    <template>
        <style include="vaadin-chart-default-theme">
			
		  :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-background,	
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-background {
	        fill: transparent;
	      }
	
	      :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-minor-grid-line,
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-grid-line {
	        stroke: rgba(255, 255, 255, 0.8);
	      }
	
	      :host(.column-chart) .highcharts-point.highcharts-color-0 {
	        stroke: rgba(34, 70, 117, 0.5);
	        fill: rgba(34, 70, 117, 0.5);
	      }
					
	      :host(.column-chart) .highcharts-xaxis .highcharts-axis-line {
	        stroke: rgba(255, 255, 255, 0.8);
	        fill: none;
	      }
	
	      :host(.column-chart) .highcharts-title,
	      :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-title,
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-title {
	        fill: #343a40;
	        font-size: 16px;
	        font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	      }
			
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-color-0,  	
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-color-0 {
	        stroke: #18ddf2;
	        fill: #18ddf2;
	      }
			
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-color-1,	
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-color-1 {
	        stroke: #1877f3;
	        fill: #1877f3;
	      }
			
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-color-2,
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-color-2 {
	        stroke: #1bca66;
	        fill: #1bca66;
	      }
			
			:host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-grid-line,
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-grid-line {
	        stroke: #343a40;
	      }
			
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-area,	
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-area {
	        fill-opacity: 0.1;
	      }
			
		  :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-axis-labels,
	      :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-axis-labels text {
	        font-size: 12px;
	        font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	        fill: #343a40;
	      }
		   
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-axis-title, 
		  :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-axis-title {
		  	font-size: 12px;
	        font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	        fill: #343a40;
		  }
		  
		  :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-root,
		  :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-root {
		  	width: 90%;
		  }  	
			
		   :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-legend-item text,
		  :host(.CUSTOMER_DETAIL_INVOICE_CHART) .highcharts-legend-item text {
		  	font-size: 12px;
	        font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	        fill: #343a40;	
	        		  
		  }
	     	
	      :host(.column-chart),
	      :host(.column-chart) #chart,
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART),
	      :host(.CUSTOMER_DETAIL_INVOICE_CHART) #chart,
	      :host(.CUSTOMER_DETAIL_PAYMENT_CHART),
	      :host(.CUSTOMER_DETAIL_PAYMENT_CHART) #chart {
	        height: 100%;
	      }	


		</style>
    </template>
</dom-module>

<dom-module id="umt_portal_detail" theme-for="vaadin-details">
	<template>
        <style>
        	:host([theme="DEFAULT_DETAIL_PROPERTIES"])
        	{
        		width:100%;
        	}        	
        	
        </style>
    </template>
</dom-module>   

<dom-module id="umt_portal_dashboardchart" theme-for="vaadin-chart">
    <template>
        <style include="vaadin-chart-default-theme">

          :host(.CUSTOMER_DETAIL_PAYMENT_CHART) .highcharts-background,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-background {
            fill: white;
          }

          :host(.DASHBOARD_CHART1) .highcharts-minor-grid-line,
          :host(.DASHBOARD_PIECHART) .highcharts-grid-line,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-grid-line,
          :host(.DASHBOARD_CHART) .highcharts-grid-line,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-grid-line,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-grid-line {
            stroke: rgba(166, 171, 168, 0.5);
          }

          :host(.column-chart) .highcharts-point.highcharts-color-0 {
            stroke: rgba(34, 70, 117, 0.5);
            fill: rgba(34, 70, 117, 0.5);
          }

          :host(.column-chart) .highcharts-xaxis .highcharts-axis-line {
            stroke: rgba(255, 255, 255, 0.8);
            fill: none;
          }

          :host(.column-chart) .highcharts-title,
          :host(.DASHBOARD_CHART1) .highcharts-title,
          :host(.DASHBOARD_PIECHART) .highcharts-title,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-title,
          :host(.DASHBOARD_CHART) .highcharts-title,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-title,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-title {
            fill: rgba(0, 0, 0, 0.7);
            font-weight:bold;
            font-size: 16px;
            font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
          }

           :host(.DASHBOARD_CHART1) .highcharts-color-0,
           :host(.DASHBOARD_PIECHART) .highcharts-color-0,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-color-0,
          :host(.DASHBOARD_CHART) .highcharts-color-0,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-color-0,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-color-0 {
            stroke:#7cb5ec;
            fill: #7cb5ec;
          }

            :host(.DASHBOARD_CHART1) .highcharts-color-1,
           :host(.DASHBOARD_PIECHART) .highcharts-color-1,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-color-1,
          :host(.DASHBOARD_CHART) .highcharts-color-1,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-color-1,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-color-1 {
            stroke: #1877f2;
            fill: #1877f2;
          }

            :host(.DASHBOARD_CHART1) .highcharts-color-2,
           :host(.DASHBOARD_PIECHART) .highcharts-color-2,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-color-2,
          :host(.DASHBOARD_CHART) .highcharts-color-2,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-color-2,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-color-2 {
            stroke: #1bca66;
            fill: #1bca66;
          }

          :host(.DASHBOARD_CHART1) .highcharts-grid-line,
           :host(.DASHBOARD_PIECHART) .highcharts-grid-line,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-grid-line,
          :host(.DASHBOARD_CHART) .highcharts-grid-line,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-grid-line,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-grid-line {
            stroke: rgba(166, 171, 168, 0.6);
          }

           :host(.DASHBOARD_CHART1) .highcharts-area,
           :host(.DASHBOARD_PIECHART) .highcharts-area,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-area,
          :host(.DASHBOARD_CHART) .highcharts-area,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-area,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-area {
            fill-opacity: 0.1;
          }

         
          :host(.DASHBOARD_CHART1) .highcharts-axis-labels,
           :host(.DASHBOARD_PIECHART) .highcharts-axis-labels,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-axis-labels,
          :host(.DASHBOARD_CHART) .highcharts-axis-labels,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-axis-labels,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-axis-labels,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-axis-labels text {
            font-size: 12px;
            font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
            fill: rgba(0, 0, 0, 0.8);
          }

          :host(.DASHBOARD_CHART1) .highcharts-axis-title,
           :host(.DASHBOARD_PIECHART) .highcharts-axis-title,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-axis-title,
          :host(.DASHBOARD_CHART) .highcharts-axis-title,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-axis-title,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-axis-title {
              font-size: 12px;
            font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
            fill: rgba(0, 0, 0, 0.8);
          }

         :host(.DASHBOARD_CHART1) .highcharts-root,
           :host(.DASHBOARD_PIECHART) .highcharts-root,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-root,
          :host(.DASHBOARD_CHART) .highcharts-root,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-root,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-root {
              width: 100%;
          }

         :host(.DASHBOARD_CHART1) .highcharts-legend-item text,
           :host(.DASHBOARD_PIECHART) .highcharts-legend-item text,
          :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-legend-item text,
          :host(.DASHBOARD_CHART) .highcharts-legend-item text,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) .highcharts-legend-item text,
          :host(.DASHBOARD_CHURN_CHART) .highcharts-legend-item text {
              font-size: 14px;
            font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
            fill: rgba(0, 0, 0, 0.8);

          }


          :host(.column-chart),
          :host(.column-chart) #chart,
         :host(.DASHBOARD_CHART1) ,
         :host(.DASHBOARD_CHART1)#chart ,
         :host(.DASHBOARD_PIECHART),
         :host(.DASHBOARD_PIECHART)#chart,
          :host(.DASHBOARD_CHART) ,
          :host(.DASHBOARD_CHART) #chart,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) ,
          :host(.DASHBOARD_CHART_SUBSCRIBER_REG) #chart ,
          :host(.DASHBOARD_CHURN_CHART)
          :host(.DASHBOARD_CHURN_CHART) #chart {
            height: 80%;
          }
			
          /*  :host(.DASHBOARD_CHART_SALES_SUMMARY) .highcharts-root
           {
           	 height: 100%;
           } */
          
		:host(.DASHBOARD_CHART) .highcharts-axis-labels.highcharts-xaxis-labels 
		{
			display:none;
		}

        </style>
    </template>
</dom-module>

<dom-module id="umt_portal_progress_bar" theme-for="vaadin-progress-bar">
<template>
<style>
[part="value"] {
	background-color: #263445;
}
</style>
</template> </dom-module>

<dom-module id="umt_portal_checkbox" theme-for="vaadin-checkbox">
<template>
<style>
:host {
	font-size: 14px;
	font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
	cursor: pointer;     
}
</style>
</template> </dom-module>

<custom-style>
<style>
a
{
  margin-left:0px!important;
  margin-right:0px!important;
  text-decoration: none !important;
}

.HOME_CONTAINER_LAYOUT {
	margin: 0px !important;
	padding: 0px !important;
}

.HOME_NAVIGATION_LAYOUT
{
 padding-bottom:0px;
 padding-top:5px;
 /*  box-shadow: 0 1px 0 0 #e2e5e8; */
}

.HOME_NAVIGATION_CONTENTENT_LAYOUT
{
 padding-bottom:0px;
 padding-top:0px;
}
.HOME_NAVIGATION_CONTENTENT_BOTTOM_LAYOUT
{
 padding-top: 3px;
 margin:0;
}

.HOME_HEADING_NAV_LABEL
{
  color:#000;
  font-size:20px;

}
.HOME_HOME_NAV_ICON
{
    width:13px;
    height:13px;
    cursor:pointer;
    margin-right:7px;   
}

.HOME_NAVIGATION_CONTENTENT_BOTTOM_LAYOUT
{
  font-size: 12px;
  font-style: italic;
  color: #2196f3;
  font-family: 'Roboto', 'Open Sans', 'Calibri', 'Arial', 'Tahoma', 'Lato', 'Oswald', 'Raleway',  'Helvetica', 'Times New Roman';
 /*  word-spacing: 5px; */
  letter-spacing: 1px;
}
.HOME_CONTENT_LAYOUT
{
  /* padding-left:0px; */
}

.SAVE_BUTTON
{
 color:#fff;
 background-color:#1676f3;
 cursor:pointer;
}

.CANCEL_BUTTON
{
 color:#fff;
 background-color:#555758;
 cursor:pointer;
}

.COMMON_DIALOG_MAIN_LAYOUT,
.COMMON_WARNING_DIALOG_MAIN_LAYOUT {
	padding: 0px;
}

.COMMON_DIALOG_TITLE,
.COMMON_WARNING_DIALOG_TITLE {
	padding: 8px;
	background-color: #e7eef4;
	font-size: 0.9rem;
	color: #212c55;
	width: 384px;
	font-weight: 700;
}

.COMMON_DIALOG_CONTENT_HL,
.COMMON_WARNING_DIALOG_CONTENT_HL {
	margin-left: 16px;
	min-height: 50px;
}

.COMMON_DIALOG_ADDR_CONTENT_VL {
	margin-top: 0;
	padding: 0;
}

.COMMON_DIALOG_INFO_ICON,
.COMMON_DIALOG_ERROR_ICON,
.COMMON_WARNING_DIALOG_EXCLAMATION_ICON {
	width: 24px;
	height:24px;
	color: darkred;
	margin-top: 3px;
}

.COMMON_DIALOG_INFO_ICON {
	color: #212c55;
    margin-top: 2px;
}

.COMMON_DIALOG_ERROR_ICON {
	color: red;
    margin-top: 2px;
}

.COMMON_DIALOG_TXT,
.COMMON_WARNING_DIALOG_TXT {
	padding-right: 16px;
	font-size: 1rem;
	word-break: break-word;
	color: #212c55;
}

.COMMON_REASON_AREA {
	width: 87%;
    padding-left: 24px;
    font-size: 0.95rem;
    word-break: break-word;
}

.COMMON_DIALOG_BUTTON_BAR,
.COMMON_WARNING_DIALOG_BUTTON_BAR {
	width: 100%;
	padding-right: 16px;
}

.COMMON_DIALOG_SUBMIT_BTN,
.COMMON_DIALOG_CONFIRM_PURCHASE_BTN,
.COMMON_DIALOG_CONFIRM_ADDRESS_BTN {
	margin-left: auto;
	background: #4A86E8;
	color: #d0f7f7
}

.COMMON_DIALOG_OK_BTN,
.COMMON_WARNING_DIALOG_YES_BTN {
	background: none;
	color: #212c55;
	margin-left:auto;
	font-weight: 700;
	
}

.COMMON_DIALOG_CANCEL_BTN,
.COMMON_WARNING_DIALOG_NO_BTN {
	background: none;
	color: #212c55;
	font-weight: 700;
}

.COMMON_DIALOG_OK_BTN:hover,
.COMMON_WARNING_DIALOG_YES_BTN:hover,
.COMMON_DIALOG_CANCEL_BTN:hover,
.COMMON_WARNING_DIALOG_NO_BTN:hover {
	background-color: #e7eef4;
	color: #212c55;
}

.COMMON_UPLOAD_BUTTON {
	margin-left: auto;
	margin-top: auto;
/*	font-weight: 700;
	color: #202C55;
	border: none;
	background: none;*/
}

.COMMON_UPLOAD_BUTTON:hover {
	border: 1px solid lightgray;
	background: #e7eef4;
}

#vaadin-license-validation-notification-vaadin-chart {
	display:none;
}

#vaadin-license-validation-notification-vaadin-board {
	display:none;
}

::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
::-webkit-scrollbar-thumb {
  background: #888; 
}

::-webkit-scrollbar-thumb:hover {
  background: #555; 
}

.UITIMEPICKER_MAIN_LAYOUT {
	display:flex;
	width:128px;
	flex-direction:column;
}

.UITIMEPICKER_SET_TIME_DIV {
	display:flex;
	align-items: flex-end;
}

.UITIMEPICKER_TIME_TXT_FLD {
	width: 100px;
}

.UITIMEPICKER_SET_TIME_BTN {
	background-color: #ffffff;
    color: #444d89;
	cursor:pointer;
	border-radius:0px;
	height:38px;
	margin-bottom:3px;
}

.UITIMEPICKER_ERROR_LBL {
	font-size: 12px;
    color: red;
}

.UITIMEPICKER_DIALOG_MAIN_LAYOUT,
.UITIMEPICKER_DIALOG_TITLE_BAR,
.UITIMEPICKER_DIALOG_BODY_LAYOUT,
.UITIMEPICKER_DIALOG_BUTTON_BAR {
	display:flex;
}

.UITIMEPICKER_DIALOG_TITLE_BAR {
	padding: 16px;
    background: #e7edff;
    font-size: 0.9rem;
    color: #282828;
    padding-bottom: 8px;
    padding-top: 8px;
}

.UITIMEPICKER_DIALOG_MAIN_LAYOUT {
	flex-direction: column;
	width: 340px;
    height: 180px;
}

.UITIMEPICKER_DIALOG_BUTTON_BAR {
	width: 100%;
    background: #f8f8f8;
  
    margin-top: auto;
    padding: 4px;
    box-sizing: border-box;
    padding-right: 16px;
}

.UITIMEPICKER_DIALOG_OK_BTN {
	font-size: 0.9rem;
      margin-left: auto;
    margin-right: 5px;
   
    background: #66666600;
    color: #242424;
    font-weight: 800;
}

.UITIMEPICKER_DIALOG_CANCEL_BTN {
	margin-left:8px;
	font-size: 0.9rem;
  
    margin-right: 5px;
   
    background: #66666600;
    color: #242424;
    font-weight: 800;
}
.UITIMEPICKER_DIALOG_OK_BTN:hover{
 border: 1px solid lightgray;
}

.UITIMEPICKER_DIALOG_CANCEL_BTN:hover {
	 border: 1px solid lightgray;
}

.UITIMEPICKER_DIALOG_HOURS,
.UITIMEPICKER_DIALOG_MINUTES,
.UITIMEPICKER_DIALOG_SECONDS {
	width:96px;
}

.UITIMEPICKER_DIALOG_BODY_LAYOUT {
	padding-left: 16px;
    justify-content: space-between;
    padding-right: 16px;
}

.UITIMEPICKER_DIALOG_ERROR_LBL {
	font-size: 0.8rem;
    margin-left: 16px;
    margin-top: 4px;
    color: red;
}

.UITOGGLEBUTTON_MAIN_LAYOUT {
	display:flex;
    margin-left: 12px;
    font-size: 11px;
    align-items: center;
    border-radius: 8px;
    cursor: pointer;
    box-sizing: border-box;
    overflow:hidden;
    border:1px solid gray;
    min-width: max-content;
    height: max-content;
}

.UITOGGLEBUTTON_ON_DIV, 
.UITOGGLEBUTTON_OFF_DIV {
	display:flex;
}

.UITOGGLEBUTTON_ON_LBL, 
.UITOGGLEBUTTON_OFF_LBL {
	cursor:pointer;
}

.UITOGGLEBUTTON_ON_LBL {
	padding-left: 6px;
	padding-right: 4px;
}

.UITOGGLEBUTTON_ON_LBL_DISABLED, 
.UITOGGLEBUTTON_OFF_LBL_DISABLED {
	cursor:auto;
}

.UITOGGLEBUTTON_MAIN_LAYOUT_DISABLED {
	opacity:50%;
	cursor:auto;
}


.UITOGGLEBUTTON_OFF_LBL {
	padding-right: 6px;
    padding-left: 4px;
}

.UITOGGLEBUTTON_ON_LBL_VISIBLE,
.UITOGGLEBUTTON_OFF_LBL_VISIBLE {
    background: #dae7ff;
    color: blue;
    font-weight: 700; 
}

.CONFIGURATION_EDIT_ICON {
	height: 17px;
    width: 17px;
}

.g-recaptcha
{
	padding-left: 56px;
	padding-top: 10px;
    padding-bottom: 18px;
}

.FILE_ATTRIBUTE_COMPONENT_MAIN_LAYOUT {
	font-size: 14px;
    display: flex;
    flex-direction: column;
}

.FILE_ATTRIBUTE_COMPONENT_ATTRIBUTE_NAME_DIV {
	display: flex;
}

.FILE_ATTRIBUTE_COMPONENT_FILE_INFO_DIV {
	display: flex;
	align-items: baseline;
	margin-top:6px;
}

.FILE_ATTRIBUTE_COMPONENT_UPLOAD_BTN {
	margin-left: 12px;
	min-width: fit-content;
}

.FILE_ATTRIBUTE_COMPONENTFILE_HYPER_LINK {
	display: block;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

.FILE_ATTRIBUTE_COMPONENT_FILE_NAME_LBL {
	white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

</style>
</custom-style>`;

document.head.appendChild($_documentContainer.content);
