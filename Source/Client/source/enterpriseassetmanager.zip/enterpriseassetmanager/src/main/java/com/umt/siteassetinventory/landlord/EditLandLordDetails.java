package com.umt.siteassetinventory.landlord;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.server.InputStreamFactory;
import com.vaadin.flow.server.StreamResource;

@CssImport("./styles/landlord_details_edit-style.css")
public class EditLandLordDetails extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_EDIT_DETAILS";
	private Div uploadpicDiv;
	private TextField idField;
	private TextField emailField,nameField;
	private TextField addressField;
	//private TextField regionField;
	private TextField contactField;
//	public TextField idField,nameField,emailField,addressField,regionField,contactField;
	private Div row3Div;
	private Div bodyDiv,additionalAttrDiv;
	private Div col1Div,col2Div;
	private String base64EncodedFileContent1;
	private String base64EncodedFileContent="";
	private Image fileImage;
	private ComboBox<String> regionField;
	private List<String> circleList=new ArrayList<String>();


	public EditLandLordDetails(String landLordID, LandlordView landLordView, String name, String address, String email, String contact, String reg, String base64) {
		addClassName(SCREENCD + "_MAIN_BODY");
		Div row1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV1");
		this.base64EncodedFileContent=base64;


		uploadpicDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOAD_PIC_DIV");
		Image defaultImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
		uploadpicDiv.add(defaultImage);
		Div cameraIcondiv=UIHtmlFieldFactory.createDiv(SCREENCD, "CAMERA_ICON_DIV");
		Icon imgUploadIcon = FontAwesome.Solid.CAMERA.create();
		imgUploadIcon.addClassName(SCREENCD+"_CAMERA_ICON");
		cameraIcondiv.add(imgUploadIcon);

		VerticalLayout imageLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "IMG_LAYOUT_VL");
		imageLayoutVL.add(uploadpicDiv,cameraIcondiv);

		if(base64 != null && base64.trim().length()>0) {
			populateImgPreviewDiv(base64);
		}

		VerticalLayout fieldLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "FIELD_LAYOUT_VL");

		nameField= UIFieldFactory.createTextField(name, true, SCREENCD,"NAME_FIELD");
		addressField= UIFieldFactory.createTextField(address, true, SCREENCD,"ADDRESS_FIELD");

		fieldLayoutVL.add(nameField,addressField);
		row1Div.add(imageLayoutVL,fieldLayoutVL);

		emailField= UIFieldFactory.createTextField(email, /*true*/false, SCREENCD,"EMAIL_FIELD");
		emailField.setValueChangeMode(ValueChangeMode.EAGER);
//		emailField.setRequiredIndicatorVisible(true);
		
	//	regionField= UIFieldFactory.createTextField(reg, true, SCREENCD,"REGION_FIELD");
		regionField = UIFieldFactory.createComboBox(circleList, true,SCREENCD, "REGION_FIELD");
//		populateCircleList();
		regionField.setValue(reg);
		contactField= UIFieldFactory.createTextField(contact, /*true*/false, SCREENCD,"CONTACT_FIELD");
		contactField.setPattern("[0-9]+");
		contactField.setPreventInvalidInput(true);
//		contactField.setRequiredIndicatorVisible(true);

		Div row2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV2");
		row3Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV3");

		row2Div.add(emailField,contactField);
	//	row3Div.add(regionField);


		additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
		col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
		col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
		Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
		colRowDiv.add(col1Div,col2Div);
		additionalAttrDiv.add(colRowDiv);

		add(row1Div,row2Div/*,row3Div*/);
		emailField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0 && !CommonUtils.isEmailAddress(emailField.getValue()))
				{
					emailField.setInvalid(true);
					emailField.setErrorMessage("Please enter a valid email.");
					
				}else if(value.length()>0 && CommonUtils.isEmailAddress(emailField.getValue())){
					emailField.setInvalid(false);
					emailField.setErrorMessage("");
				}else {
					emailField.setInvalid(false);
					emailField.setErrorMessage("");
				}


			}
		});
		
		
		cameraIcondiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				try {
					UploadDocumentDialog dlg =new UploadDocumentDialog("Image",base64EncodedFileContent1);
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;

						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							UploadDocumentDialog srcDlg = (UploadDocumentDialog)event.getSource();

							if(!srcDlg.isOpened()&&(srcDlg.isGetDocUploadStatus()==true))
							{
								base64EncodedFileContent = srcDlg.getFileContent();
								populateImgPreviewDiv(base64EncodedFileContent);


							}
						}

					});
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});

		EditLandLordDetailsPopUp edit = new EditLandLordDetailsPopUp("Edit Landlord Details", this, landLordID, landLordView);
	}
	protected void populateImgPreviewDiv(String base64EncodedFileContent2) {
		try {
			if(base64EncodedFileContent2 != null && base64EncodedFileContent2.trim().length() > 0) 
			{
				base64EncodedFileContent1=base64EncodedFileContent2;
				byte[] imageFileContent = Base64.getDecoder().decode(base64EncodedFileContent2);
				StreamResource fileStreamResource = new StreamResource("FILE_IMAGE", new InputStreamFactory() {
					private static final long serialVersionUID = 1L;

					@Override
					public InputStream createInputStream() {

						return new ByteArrayInputStream(imageFileContent);
					}
				});

				fileImage = new Image(fileStreamResource, "NEW_FILE_IMAGE1");
				fileImage.addClassName(SCREENCD + "_NEW_FILE_IMAGE1");
			}
			else {
				fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");

			}
			uploadpicDiv.removeAll();
			uploadpicDiv.add(fileImage);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	public String getName() {
		return nameField.getValue();
	}
	public String getAddress() {
		return addressField.getValue();
	}
	public String getEmail() {
		return emailField.getValue();
	}
	public String getContact() {
		return contactField.getValue();
	}
	public String getRegion() {
		return regionField.getValue();
	}
	public String getBase64() {
		return base64EncodedFileContent;
	}
	
	
	public TextField getNameField() {
		return nameField;
	}
	public TextField getAddressField() {
		return addressField;
	}
	public TextField getEmailField() {
		return emailField;
	}
	public ComboBox<String> getRegionField() {
		return regionField;
	}
	private void populateCircleList() {
		circleList.clear();
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETCIRCLELIST");
			String resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
	
			
			if(resp!=null || resp.length()>0) {
				JSONArray ja = new JSONArray(resp);
				if(ja.length()>0) {
					for (int i = 0; i < ja.length(); i++) {
						JSONObject jo = ja.getJSONObject(i);
						circleList.add(jo.getString("CircleName"));
					}
					regionField.setItems(circleList);
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			
		}		
		
	}

}
