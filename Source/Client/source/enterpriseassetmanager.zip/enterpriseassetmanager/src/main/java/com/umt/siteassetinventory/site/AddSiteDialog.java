package com.umt.siteassetinventory.site;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.FileTypeAttributeUploadDialog;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/site-view.css")
public class AddSiteDialog extends Dialog
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_SITE_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv,additionalAttrDiv;
	private Div mainLayout,closeBtnDiv;
	private Button saveBtn,cancelBtn;

	private TextField sitecodeField,sitenameField,descriptionField,addressField,regionField;
	private NumberField latitudeField,longitudeField;
	private Div row4;

	private HashMap<String, List<Object>> dynamicSiteAttributesMap, dynamicPropertyAttributesMap;
	private String attrname;
	private Div col1Div,col2Div;
	private String mandatoryFlag;
	private boolean mandatoryFlagChk=true;
	private String attributeDatatype;
	private DatePicker rfaiDateField;
	private ComboBox<String> statusCombo;
	private RadioButtonGroup<String> siteOrPropertyRadio;
	private boolean isSuccess=false;
	Map<String, JSONArray> attributeMap;
	Map<String, JSONObject> fileAttributeMap = new HashMap<String, JSONObject>();
	private Div eachDataDiv8;
	private HashMap<String, List<Object>> updateddynamicSiteAttributesMap;
	private Div containerDiv;
	private Div booleanAttributeDiv;
	private Div multiSelectAttributeDiv;
	private Div fileAttributeDiv;
	private Div eachAttributeDiv;


	public AddSiteDialog() 
	{
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl,closeBtnDiv);

		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);

		generateFieldNameValuePair();
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		//	saveBtn.setEnabled(false);
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveData2();
			}
		});
		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});

	}
	protected void saveData2() 
	{

		try 
		{
			if((sitecodeField.getValue().length()<=0)|| (sitenameField.getValue().length()<=0) || (regionField.getValue().length()<=0)
					||(descriptionField.getValue().length()<=0)|| (addressField.getValue().length()<=0)
					||(latitudeField.getValue()==null)|| (longitudeField.getValue()==null))
			{
				if(sitecodeField.getValue().length()<=0)
				{
					sitecodeField.setInvalid(true);
					sitecodeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(sitenameField.getValue().length()<=0)
				{
					sitenameField.setInvalid(true);
					sitenameField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(regionField.getValue().length()<=0)
				{
					regionField.setInvalid(true);
					regionField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(descriptionField.getValue().length()<=0)
				{
					descriptionField.setInvalid(true);
					descriptionField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(latitudeField.getValue()==null)
				{
					latitudeField.setInvalid(true);
					latitudeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(longitudeField.getValue()==null)
				{
					longitudeField.setInvalid(true);
					longitudeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(addressField.getValue().length()<=0)
				{
					addressField.setInvalid(true);
					addressField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}

			}


			if((sitecodeField.getValue().length()>0)&& (sitenameField.getValue().length()>0) && (descriptionField.getValue().length()>0)
					&& (addressField.getValue().length()>0)&& (regionField.getValue().length()>0)
					&&(latitudeField.getValue()!=null)&& (longitudeField.getValue()!=null))
			{	

				JSONObject saveobjJson=new JSONObject();
				saveobjJson.put("SiteCode",sitecodeField.getValue());
				saveobjJson.put("SiteName",sitenameField.getValue());
				saveobjJson.put("Address",addressField.getValue());
				saveobjJson.put("Description",descriptionField.getValue());
				saveobjJson.put("Region",regionField.getValue());
				saveobjJson.put("Latitude",latitudeField.getValue().toString());
				saveobjJson.put("Longitude",longitudeField.getValue().toString());

				if(rfaiDateField.getValue()==null)
				{
					saveobjJson.put("RFAIDate","");
				}
				if(rfaiDateField.getValue()!=null)
				{
					LocalDate date=rfaiDateField.getValue();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
					String stringifiedDate =date.format(formatter);
					//saveobjJson.put("RFAIDate",CommonUtils.convertLocalDateToString(rfaiDateField.getValue()));
					saveobjJson.put("RFAIDate",stringifiedDate);
				}
				if(statusCombo.getValue()==null)
				{
					saveobjJson.put("Status","");
				}
				if(statusCombo.getValue()!=null && statusCombo.getValue().equalsIgnoreCase("Active"))
				{
					saveobjJson.put("Status","1");
				}
				if(statusCombo.getValue()!=null && statusCombo.getValue().equalsIgnoreCase("Pending"))
				{
					saveobjJson.put("Status","2");
				}
				
			//	System.out.println("saveobjJson="+saveobjJson);


				JSONObject otherinfoJson=new JSONObject();
				UIFileAttributeComponent fileAttributeComp;
				
				Iterator<String> itrKeys = updateddynamicSiteAttributesMap.keySet().iterator();
			//System.out.println("updateddynamicSiteAttributesMap="+updateddynamicSiteAttributesMap.toString());
				if(updateddynamicSiteAttributesMap!=null && updateddynamicSiteAttributesMap.size()>0)
				{	

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=updateddynamicSiteAttributesMap.get(key);

						if(value.size()>0)	//value obj
						{	
							String datatype=updateddynamicSiteAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=updateddynamicSiteAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":
								// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicSiteAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									otherinfoJson.put(key, ((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
							//	if (mandatory.equalsIgnoreCase("1")&&((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								if (mandatory.equalsIgnoreCase("1")&&((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()==null)	
								{
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
								{
									otherinfoJson.put(key, ((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;

								}
								if (((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
								{
									otherinfoJson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).toString().length()<=0)
								{
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
								}
								break;
								
							case "BOOLEAN"://AbhraC
								otherinfoJson.put(key, ((Checkbox) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString());
								break;
							case "MULTIPLE SELECTION":
								CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) updateddynamicSiteAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
									return;
								}
								if(!checkboxGroup.isEmpty()) {
									otherinfoJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
								}
								break;
							case "IMAGE FILE":
								fileAttributeComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									otherinfoJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "TEXT FILE":
								fileAttributeComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									otherinfoJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "CUSTOM FILE":
								fileAttributeComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									otherinfoJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;			
							}
						}	
					}
					saveobjJson.put("OtherInfo",otherinfoJson);
				//	System.out.println("otherinfoJson="+otherinfoJson);
				}	


				
			//	System.out.println("otherinfoJson="+otherinfoJson);

				JSONObject propertyotherinfojson=new JSONObject();


				Iterator<String> propertyKeys = dynamicPropertyAttributesMap.keySet().iterator();
				//System.out.println("dynamicPropertyAttributesMap="+dynamicPropertyAttributesMap.toString());
				if(dynamicPropertyAttributesMap!=null && dynamicPropertyAttributesMap.size()>0)
				{	

					while (propertyKeys.hasNext()) 
					{
						String key = propertyKeys.next();
						List<Object> value=dynamicPropertyAttributesMap.get(key);

						if(value.size()>0)	//value obj
						{	
							//System.out.println("dynamicPropertyAttributesMap="+dynamicPropertyAttributesMap.toString());
							String datatype=dynamicPropertyAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=dynamicPropertyAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":
								// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicPropertyAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((ComboBox<Object>)dynamicPropertyAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									propertyotherinfojson.put(key, ((ComboBox<Object>)dynamicPropertyAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									propertyotherinfojson.put(key, ((TextField) dynamicPropertyAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((TextField)dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									propertyotherinfojson.put(key, ((TextField)dynamicPropertyAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) dynamicPropertyAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;

								}
								if (((DatePicker) dynamicPropertyAttributesMap.get(key).get(1)).getValue()!=null)
								{
									propertyotherinfojson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) dynamicPropertyAttributesMap.get(key).get(1)).getValue()));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicPropertyAttributesMap.get(key).get(1)).toString().length()<=0)
								{
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicPropertyAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									propertyotherinfojson.put(key, ((TextField) dynamicPropertyAttributesMap.get(key).get(1)).getValue());
								}
								break;
								
							case "BOOLEAN"://AbhraC
								propertyotherinfojson.put(key, ((Checkbox) dynamicPropertyAttributesMap.get(key).get(1)).getValue().toString());
								break;
							case "MULTIPLE SELECTION":
								CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) dynamicPropertyAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
									return;
								}
								if(!checkboxGroup.isEmpty()) {
									propertyotherinfojson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
								}
								break;
							case "IMAGE FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicPropertyAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									propertyotherinfojson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "TEXT FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicPropertyAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									propertyotherinfojson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "CUSTOM FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicPropertyAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									propertyotherinfojson.put(key, fileAttributeComp.getFileJSON());
								}
								break;		
							}
						}	
					}
				}		

				saveobjJson.put("PropertyOtherInfo",propertyotherinfojson);
				
			//	System.out.println("PropertyOtherInfo="+propertyotherinfojson);
				System.out.println("saveobjJson="+saveobjJson);

				Form form =new Form();
				form.add("siteDetails",saveobjJson);
				
	//			System.out.println("form="+form.toString());

				String url=ApplicationConfiguration.getServiceEndpoint("CREATESITE");
				//System.out.println("url="+url);
				RestServiceHandler.createJSON_POST(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
				isSuccess=true;
				close();
			}	
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			isSuccess=true;
		}

	}
	
	public String getMultiSelectValue(Set<String> selectedItems) throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachVal = iterator.next();
			jsonArray.put(eachVal);
		}

		retVal.put("MultiSelectValue", jsonArray.toString());

		return retVal.toString();
	}


	private void generateFieldNameValuePair() 
	{
		try {	
			Div row0=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row1=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row2=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row3=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			row4=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row5=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");

			Div eachDataDiv0=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv7=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			eachDataDiv8=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv9=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv10=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");

			siteOrPropertyRadio = new RadioButtonGroup<String>();
			siteOrPropertyRadio.setItems("Site", "Property");
			siteOrPropertyRadio.addClassName(SCREENCD + "_SITE_OR_PROPERTY_RADIO_BUTTON");
			siteOrPropertyRadio.setValue("Site");

			sitecodeField= UIFieldFactory.createTextField("", true, SCREENCD,"SITE_CODE_FIELD");
			sitenameField= UIFieldFactory.createTextField("", true, SCREENCD,"SITE_NAME_FIELD");
			descriptionField= UIFieldFactory.createTextField("", true, SCREENCD,"DESC_FIELD");
			addressField= UIFieldFactory.createTextField("", true, SCREENCD,"ADDRESS_FIELD");
			regionField= UIFieldFactory.createTextField("", true, SCREENCD,"REGION_FIELD");

			latitudeField= UIFieldFactory.createNumberField(true, SCREENCD, "LATITUDE_FIELD");
			longitudeField=UIFieldFactory.createNumberField(true, SCREENCD, "LONGITUDE_FIELD");
			rfaiDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "RFAI_DATE_FIELD");

			ArrayList<String> statusList=new ArrayList<String>();
			statusList.clear();
			String status[] = { "Active", "Pending"};
			for (int i = 0; i < status.length; i++) {
				statusList.add(status[i]);
			}
			statusCombo = UIFieldFactory.createComboBox(statusList, false, SCREENCD, "STATUS_COMBO_FIELD");

			Div additionalAttrheaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_HEADER_DIV");
			Label additionalAttr = UIHtmlFieldFactory.createLabel(SCREENCD, "ADDITIONAL_ATTR");
			additionalAttrheaderDiv.add(additionalAttr);
			additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
			col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
			col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
			
			booleanAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BOOLEAN_ATTRIBUTE_DIV");
			multiSelectAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MULTI_SELECT_ATTRIBUTE_DIV");
			fileAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ATTRIBUTE_DIV");
			
			
			
			
			Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
			colRowDiv.add(col1Div,col2Div);
			containerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_CONTAINER_DIV");
		//	additionalAttrDiv.add(additionalAttrheaderDiv,containerDiv);
	//		additionalAttrDiv.add(additionalAttrheaderDiv,colRowDiv);
			additionalAttrDiv.add(additionalAttrheaderDiv,colRowDiv,booleanAttributeDiv, multiSelectAttributeDiv, fileAttributeDiv);

			eachDataDiv0.add(siteOrPropertyRadio);
			eachDataDiv1.add(sitecodeField);
			eachDataDiv2.add(sitenameField);
			eachDataDiv3.add(regionField);
			eachDataDiv4.add(descriptionField);
			eachDataDiv5.add(latitudeField);
			eachDataDiv6.add(longitudeField);
			eachDataDiv7.add(addressField);
			eachDataDiv9.add(rfaiDateField);
			eachDataDiv10.add(statusCombo);


			row0.add(eachDataDiv0);
			row1.add(eachDataDiv1,eachDataDiv2);
			row2.add(eachDataDiv3,eachDataDiv4);
			row3.add(eachDataDiv5,eachDataDiv6);
			row4.add(eachDataDiv7,eachDataDiv8);
			row5.add(eachDataDiv9,eachDataDiv10);
			bodyDiv.add(row0,row1,row2,row3,row5,row4,additionalAttrDiv);

			/***additional attr****/

			attributeMap=retrieveSiteLevelAttributes();
			siteOrPropertyChangeHandler();

			siteOrPropertyRadio.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<?> event) {
					row4.removeAll();
					eachDataDiv8.removeAll();
					col1Div.removeAll();
					col2Div.removeAll();
					row4.add(eachDataDiv7,eachDataDiv8);
					siteOrPropertyChangeHandler();
				}
			});


		}catch(Exception e)
		{
			e.printStackTrace();
		}	

	}

	private void siteOrPropertyChangeHandler() {
		boolean siteAttributesAdded = false;
		additionalAttrDiv.removeAll();////
		if (siteOrPropertyRadio.getValue().equals("Site")) {
			dynamicSiteAttributesMap = new HashMap<>();
			dynamicPropertyAttributesMap = new HashMap<>();
			updateddynamicSiteAttributesMap=new HashMap<>();
		//	populateAttributes2(attributeMap.get("SITE ATTRIBUTES"), true, siteAttributesAdded);//col wise
		//	populateAttributes(attributeMap.get("SITE ATTRIBUTES"), true, siteAttributesAdded);
			populateAttributes3(attributeMap.get("SITE ATTRIBUTES"), true, siteAttributesAdded);
			siteAttributesAdded = true;
		//	populateAttributes(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);
		//	populateAttributes2(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);
			populateAttributes3(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);//row wise
		} 
		else if (siteOrPropertyRadio.getValue().equals("Property")) {
			dynamicSiteAttributesMap = new HashMap<>();
			dynamicPropertyAttributesMap = new HashMap<>();
			updateddynamicSiteAttributesMap=new HashMap<>();
		//	populateAttributes(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);
	//		populateAttributes2(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);
			populateAttributes3(attributeMap.get("PROPERTY ATTRIBUTES"), false, siteAttributesAdded);
		}
	}
private void populateAttributes3(JSONArray mapvalueArr, boolean siteOrProperty, boolean siteAttributesAdded)
	{
		fileAttributeMap.clear();
		//Div fileAttribComp;
			UIFileAttributeComponent fileAttribComp = null;
		try {
			eachAttributeDiv = null;
	//		System.out.println("mapvalueArr====="+mapvalueArr);
			for(int i=0; i<mapvalueArr.length(); i++)
			{
				
				
				JSONObject js=mapvalueArr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				Iterator<String> keys = js.keys();
			
				String attrname=js.getString("AttributeName");
				String defaultval= "";
				if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
					defaultval=js.getString("DefaultValue");
				}
				String mandatoryFlag=js.getString("Mandatory").toString();
				String attributeDatatype=js.getString("AttributeDatatype");
				
				eachAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ATTRIBUTE_FLD_DIV");
				

				switch(attributeDatatype.toString())
				{
				case "5":
					String datatype="FLOV";
					List<String> choiceList=new ArrayList<String>();
					String str=js.getString("FLOV");
					String flovVal[]=str.split(",");
					choiceList.clear();
					for(String s:flovVal)
					{
						choiceList.add(s);
					}
					ComboBox<String> attributeComboBox = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "ATTRIBUTE_COMBO_FIELD");
					attributeComboBox.setLabel(attrname);
					//attributeComboBox.setInvalid(false);
					if(defaultval.length()>0)
					{
						attributeComboBox.setValue(defaultval);
					}
					//	attrrow.add(attributeComboBox);

					dataTypeList.add(datatype);
					dataTypeList.add(attributeComboBox);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					//	additionalAttrDiv.add(attributeComboBox);
					if(mandatoryFlag.equals("1"))
					{

						attributeComboBox.setRequired(true);
						attributeComboBox.setErrorMessage("");
						attributeComboBox.setRequiredIndicatorVisible(true);
					}
				//	detailsTabVL.add(attributeComboBox);
					eachAttributeDiv.add(attributeComboBox);
					break;
				case "1":
				/*	datatype="NUMERIC";
					TextField attributeNumberTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					//	numberField.getStyle().set("width", "48.2%");
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(defaultval);
					}
					//	additionalAttrDiv.add(numberField);
					// 	attrrow.add(numberField);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					attributeNumberTxtFld.setValueChangeMode(ValueChangeMode.EAGER);
					attributeNumberTxtFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
							if(!arg0.getValue().toString().matches("^\\w*$"))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
						}
					});
				//	detailsTabVL.add(attributeNumberTxtFld);
					eachAttributeDiv.add(attributeNumberTxtFld);*/
					datatype="NUMERIC";
					NumberField attributeNumberTxtFld = UIFieldFactory.createNumberField(false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(Double.parseDouble(defaultval));
					}
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					eachAttributeDiv.add(attributeNumberTxtFld);
					break;
				case "4":
					datatype="DATE";
					DatePicker attributeDateFld = UIFieldFactory.createDatePicker(false, SCREENCD, "ATTRIBUTE_DATE_FIELD");
					attributeDateFld.setLabel(attrname);
					//	attributeDateFld.getStyle().set("width", "48.2%");
					//	additionalAttrDiv.add(attributeDateFld);
					//	attrrow.add(attributeDateFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeDateFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeDateFld.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
					}
					if(mandatoryFlag=="1")
					{
						attributeDateFld.setRequired(true);
						attributeDateFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeDateFld);
					
					eachAttributeDiv.add(attributeDateFld);
					break; 
				case "3":
					datatype="FREEFLOW";
					TextField attributeFreeflowFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeFreeflowFld.setLabel(attrname);
					//	attributeFreeflowFld.getStyle().set("width", "48.2%");
					attributeFreeflowFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeFreeflowFld);
					//	attrrow.add(attributeFreeflowFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeFreeflowFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeFreeflowFld.setRequired(true);
						attributeFreeflowFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeFreeflowFld);
					eachAttributeDiv.add(attributeFreeflowFld);
					break;
				case "2":
					datatype="ALPHANUMERIC";
					TextField attributeAlphanumericFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeAlphanumericFld.setLabel(attrname);
					//	attributeAlphanumericFld.getStyle().set("width", "48.2%");
					attributeAlphanumericFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeAlphanumericFld);
					//	attrrow.add(attributeAlphanumericFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeAlphanumericFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeAlphanumericFld.setRequired(true);
						attributeAlphanumericFld.setRequiredIndicatorVisible(true);
					}
					attributeAlphanumericFld.setValueChangeMode(ValueChangeMode.EAGER);
					attributeAlphanumericFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
							{
								attributeAlphanumericFld.setValue(arg0.getOldValue().toString());
							}
						}
					});
					//detailsTabVL.add(attributeAlphanumericFld);
					eachAttributeDiv.add(attributeAlphanumericFld);
					break;
				case "6":
					datatype = "BOOLEAN";
					Checkbox booleanFld=UIFieldFactory.createCheckbox(false,false, SCREENCD, "VALUE");
					booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
					booleanFld.addClassName(SCREENCD + "_VALUE");
					booleanFld.setLabel(attrname);
					if(defaultval != null && defaultval.trim().toLowerCase().equals("true")) {
						booleanFld.setValue(true);
					} else {
						booleanFld.setValue(false);
					}
					
					dataTypeList.add(datatype);
					dataTypeList.add(booleanFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(booleanFld);
					eachAttributeDiv.add(booleanFld);
					dataTypeList.add(eachAttributeDiv);
					
					break;

				case "7":
					datatype = "MULTIPLE SELECTION";
					CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
					multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
					multiSelectFld.addClassName(SCREENCD + "_VALUE");
					multiSelectFld.setLabel(attrname);
					String possibleValues = js.getString("FLOV");
					renderMultiSelectField(multiSelectFld, possibleValues, defaultval);
										
					dataTypeList.add(datatype);
					dataTypeList.add(multiSelectFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(multiSelectFld);
					eachAttributeDiv.add(multiSelectFld);
					dataTypeList.add(eachAttributeDiv);
					
					break;
					
				case "8":
					datatype = "IMAGE FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 8);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					eachAttributeDiv.add(fileAttribComp);
				
					break;
				case "9":
					datatype = "TEXT FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 9);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					
					break;

				case "10":
					datatype = "CUSTOM FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 10);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					
					break;
				default:
					break;   
				}
				if(!siteAttributesAdded) {
					additionalAttrDiv.add(eachAttributeDiv);
				}
				
				if (siteOrProperty) {
					dynamicSiteAttributesMap.put(attrname,dataTypeList);
					updateddynamicSiteAttributesMap.put(attrname,dataTypeList);
				} else {
					dynamicPropertyAttributesMap.put(attrname,dataTypeList);
				}

			}
			
			attributeUIOrchestration();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}


	private void populateAttributes(JSONArray mapvaluearr, boolean siteOrProperty, boolean siteAttributesAdded)
	{
		try {
			//Div attrrow=null;

			for(int i=0;i<mapvaluearr.length();i++)
			{

				JSONObject js=mapvaluearr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				Iterator<String> keys = js.keys();
				Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");


				attrname=js.getString("AttributeName");
				String defaultval= "";
				if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
					defaultval=js.getString("DefaultValue");
				}
				mandatoryFlag=js.getString("Mandatory").toString();
				attributeDatatype=js.getString("AttributeDatatype");

				switch(attributeDatatype.toString()/*key.toUpperCase()*/)
				{
				case "5":
					String datatype="FLOV";
					List<String> choiceList=new ArrayList<String>();
					String str=js.getString("FLOV");
					String flovVal[]=str.split(",");
					choiceList.clear();
					for(String s:flovVal)
					{
						choiceList.add(s);
					}
					ComboBox<String> valueCombo = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "VALUE");
					valueCombo.setLabel(attrname);
					valueCombo.setInvalid(false);
					if(defaultval.length()>0)
					{
						valueCombo.setValue(defaultval);
					}
					//	attrrow.add(valueCombo);

					dataTypeList.add(datatype);
					dataTypeList.add(valueCombo);
					dataTypeList.add(mandatoryFlag);
					//	additionalAttrDiv.add(valueCombo);
					if(mandatoryFlag.equals("1"))
					{

						valueCombo.setRequired(true);
						valueCombo.setErrorMessage("");
						valueCombo.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(valueCombo);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(valueCombo);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(valueCombo);
							col2Div.add(eachDataDiv);
						}	
					}    	

					break;
				case "1":
					datatype="NUMERIC";
					TextField numberTxtField=UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					numberTxtField.setLabel(attrname);
					//	numberField.getStyle().set("width", "48.2%");
					if(defaultval!=null && defaultval.length()>0)
					{
						numberTxtField.setValue(defaultval);
					}
					//	additionalAttrDiv.add(numberField);
					// 	attrrow.add(numberField);
					dataTypeList.add(datatype);
					dataTypeList.add(numberTxtField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						numberTxtField.setRequiredIndicatorVisible(true);

					}
					numberTxtField.setValueChangeMode(ValueChangeMode.EAGER);
					numberTxtField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							{
								numberTxtField.setValue(arg0.getOldValue().toString());
							}
							if(!arg0.getValue().toString().matches("^\\w*$"))
							{
								numberTxtField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					if(i==0 && !siteAttributesAdded)
					{
						// 		attrrow.remove(numberField);
						row4.add(numberTxtField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(numberTxtField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(numberTxtField);
							col2Div.add(eachDataDiv);
						}	
					}    	
					break;
				case "4":
					datatype="DATE";
					DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
					ValueDateField.setLabel(attrname);
					//	ValueDateField.getStyle().set("width", "48.2%");
					//	additionalAttrDiv.add(ValueDateField);
					//	attrrow.add(ValueDateField);
					dataTypeList.add(datatype);
					dataTypeList.add(ValueDateField);
					dataTypeList.add(mandatoryFlag);
					if(defaultval!=null && defaultval.length()>0)
					{
						ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
					}
					if(mandatoryFlag=="1")
					{
						ValueDateField.setRequired(true);
						ValueDateField.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						//	attrrow.remove(ValueDateField);
						row4.add(ValueDateField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(ValueDateField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(ValueDateField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break; 
				case "3":
					datatype="FREEFLOW";
					TextField textField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
					textField.setLabel(attrname);
					//	textField.getStyle().set("width", "48.2%");
					textField.setValue(defaultval);
					//	additionalAttrDiv.add(textField);
					//	attrrow.add(textField);
					dataTypeList.add(datatype);
					dataTypeList.add(textField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						textField.setRequired(true);
						textField.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						// 		attrrow.remove(textField);
						row4.add(textField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(textField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(textField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break;
				case "2":
					datatype="ALPHANUMERIC";
					TextField alphanumericField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
					alphanumericField.setLabel(attrname);
					//	alphanumericField.getStyle().set("width", "48.2%");
					alphanumericField.setValue(defaultval);
					//	additionalAttrDiv.add(alphanumericField);
					//	attrrow.add(alphanumericField);
					dataTypeList.add(datatype);
					dataTypeList.add(alphanumericField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						alphanumericField.setRequired(true);
						alphanumericField.setRequiredIndicatorVisible(true);
					}
					alphanumericField.setValueChangeMode(ValueChangeMode.EAGER);
					alphanumericField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
							{
								alphanumericField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					if(i==0 && !siteAttributesAdded)
					{
						//		attrrow.remove(alphanumericField);
						row4.add(alphanumericField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(alphanumericField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(alphanumericField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break;
				default:
					break;   
				}
				if (siteOrProperty) {
					dynamicSiteAttributesMap.put(attrname,dataTypeList);
				} else {
					dynamicPropertyAttributesMap.put(attrname,dataTypeList);
				}

				//	}

				//	additionalAttrDiv.add(attrrow);
				//	c++;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	private void populateAttributes2(JSONArray mapvaluearr, boolean siteOrProperty, boolean siteAttributesAdded)
	{
		
		try {
			//Div attrrow=null;
			fileAttributeMap.clear();
			//Div fileAttribComp;
			UIFileAttributeComponent fileAttribComp = null;

			for(int i=0;i<mapvaluearr.length();i++)
			{

				JSONObject js=mapvaluearr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				Iterator<String> keys = js.keys();
				Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");


				attrname=js.getString("AttributeName");
				String defaultval= "";
				if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
					defaultval=js.getString("DefaultValue");
				}
				mandatoryFlag=js.getString("Mandatory").toString();
				attributeDatatype=js.getString("AttributeDatatype");

				switch(attributeDatatype.toString()/*key.toUpperCase()*/)
				{
				case "5":
					String datatype="FLOV";
					List<String> choiceList=new ArrayList<String>();
					String str=js.getString("FLOV");
					String flovVal[]=str.split(",");
					choiceList.clear();
					for(String s:flovVal)
					{
						choiceList.add(s);
					}
					ComboBox<String> valueCombo = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "VALUE");
					valueCombo.setLabel(attrname);
					valueCombo.setInvalid(false);
					if(defaultval.length()>0)
					{
						valueCombo.setValue(defaultval);
					}
					//	attrrow.add(valueCombo);

					dataTypeList.add(datatype);
					dataTypeList.add(valueCombo);
					dataTypeList.add(mandatoryFlag);
					//	additionalAttrDiv.add(valueCombo);
					if(mandatoryFlag.equals("1"))
					{

						valueCombo.setRequired(true);
						valueCombo.setErrorMessage("");
						valueCombo.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(valueCombo);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(valueCombo);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(valueCombo);
							col2Div.add(eachDataDiv);
						}	
					}    	

					break;
				case "1":
					datatype="NUMERIC";
					TextField numberTxtField=UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					numberTxtField.setLabel(attrname);
					//	numberField.getStyle().set("width", "48.2%");
					if(defaultval!=null && defaultval.length()>0)
					{
						numberTxtField.setValue(defaultval);
					}
					//	additionalAttrDiv.add(numberField);
					// 	attrrow.add(numberField);
					dataTypeList.add(datatype);
					dataTypeList.add(numberTxtField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						numberTxtField.setRequiredIndicatorVisible(true);

					}
					numberTxtField.setValueChangeMode(ValueChangeMode.EAGER);
					numberTxtField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							{
								numberTxtField.setValue(arg0.getOldValue().toString());
							}
							if(!arg0.getValue().toString().matches("^\\w*$"))
							{
								numberTxtField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					if(i==0 && !siteAttributesAdded)
					{
						// 		attrrow.remove(numberField);
					//	row4.add(numberTxtField);
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(numberTxtField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(numberTxtField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(numberTxtField);
							col2Div.add(eachDataDiv);
						}	
					}    	
					break;
				case "4":
					datatype="DATE";
					DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
					ValueDateField.setLabel(attrname);
					//	ValueDateField.getStyle().set("width", "48.2%");
					//	additionalAttrDiv.add(ValueDateField);
					//	attrrow.add(ValueDateField);
					dataTypeList.add(datatype);
					dataTypeList.add(ValueDateField);
					dataTypeList.add(mandatoryFlag);
					if(defaultval!=null && defaultval.length()>0)
					{
						ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
					}
					if(mandatoryFlag=="1")
					{
						ValueDateField.setRequired(true);
						ValueDateField.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						//	attrrow.remove(ValueDateField);
					//	row4.add(ValueDateField);
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(ValueDateField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(ValueDateField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(ValueDateField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break; 
				case "3":
					datatype="FREEFLOW";
					TextField textField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
					textField.setLabel(attrname);
					//	textField.getStyle().set("width", "48.2%");
					textField.setValue(defaultval);
					//	additionalAttrDiv.add(textField);
					//	attrrow.add(textField);
					dataTypeList.add(datatype);
					dataTypeList.add(textField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						textField.setRequired(true);
						textField.setRequiredIndicatorVisible(true);
					}
					if(i==0 && !siteAttributesAdded)
					{
						// 		attrrow.remove(textField);
				//		row4.add(textField);
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(textField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(textField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(textField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break;
				case "2":
					datatype="ALPHANUMERIC";
					TextField alphanumericField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
					alphanumericField.setLabel(attrname);
					//	alphanumericField.getStyle().set("width", "48.2%");
					alphanumericField.setValue(defaultval);
					//	additionalAttrDiv.add(alphanumericField);
					//	attrrow.add(alphanumericField);
					dataTypeList.add(datatype);
					dataTypeList.add(alphanumericField);
					dataTypeList.add(mandatoryFlag);
					if(mandatoryFlag.equals("1"))
					{
						alphanumericField.setRequired(true);
						alphanumericField.setRequiredIndicatorVisible(true);
					}
					alphanumericField.setValueChangeMode(ValueChangeMode.EAGER);
					alphanumericField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
							{
								alphanumericField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					if(i==0 && !siteAttributesAdded)
					{
						//		attrrow.remove(alphanumericField);
					//	row4.add(alphanumericField);
						eachDataDiv8.getStyle().set("width", "48.2%");
						eachDataDiv8.add(alphanumericField);
					}
					else
					{
						if(i%2!=0)
						{
							eachDataDiv.add(alphanumericField);
							col1Div.add(eachDataDiv);
						}	
						if(i%2==0)
						{
							eachDataDiv.add(alphanumericField);
							col2Div.add(eachDataDiv);
						}	
					}   

					break;
					
				case "6":
					datatype="BOOLEAN";
					Checkbox booleanFld=UIFieldFactory.createCheckbox(false,false, SCREENCD, "VALUE");
					booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
					booleanFld.setLabel(attrname);
					//	alphanumericField.getStyle().set("width", "48.2%");
					if(defaultval.trim().toLowerCase().equals("true")) {
						booleanFld.setValue(true);
					}
					
					dataTypeList.add(datatype);
					dataTypeList.add(booleanFld);
					dataTypeList.add(mandatoryFlag);

					if (i == 0 && !siteAttributesAdded) {
						row4.add(booleanFld);
					} else {
						if (i % 2 != 0) {
							eachDataDiv.add(booleanFld);
							col1Div.add(eachDataDiv);
						}
						if (i % 2 == 0) {
							eachDataDiv.add(booleanFld);
							col2Div.add(eachDataDiv);
						}
					}
					 
					break;
				
				case "7":
					datatype="MULTIPLE SELECTION";
					CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
					multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
					multiSelectFld.setLabel(attrname);
					String possibleValues = js.getString("FLOV");
					renderMultiSelectField(multiSelectFld, possibleValues, defaultval);
										
					dataTypeList.add(datatype);
					dataTypeList.add(multiSelectFld);
					dataTypeList.add(mandatoryFlag);

					if (i == 0 && !siteAttributesAdded) {
						row4.add(multiSelectFld);
					} else {
						if (i % 2 != 0) {
							eachDataDiv.add(multiSelectFld);
							col1Div.add(eachDataDiv);
						}
						if (i % 2 == 0) {
							eachDataDiv.add(multiSelectFld);
							col2Div.add(eachDataDiv);
						}
					}
					 
					break;
					
				case "8":
					datatype="IMAGE FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 8);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					if (i == 0 && !siteAttributesAdded) {
						row4.add(fileAttribComp);
					} else {
						if (i % 2 != 0) {
							eachDataDiv.add(fileAttribComp);
							col1Div.add(eachDataDiv);
						}
						if (i % 2 == 0) {
							eachDataDiv.add(fileAttribComp);
							col2Div.add(eachDataDiv);
						}
					}
					break;
					
				case "9":
					datatype="TEXT FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 9);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					if (i == 0 && !siteAttributesAdded) {
						row4.add(fileAttribComp);
					} else {
						if (i % 2 != 0) {
							eachDataDiv.add(fileAttribComp);
							col1Div.add(eachDataDiv);
						}
						if (i % 2 == 0) {
							eachDataDiv.add(fileAttribComp);
							col2Div.add(eachDataDiv);
						}
					}
					break;
					
				case "10":
					datatype="CUSTOM FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 10);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					if (i == 0 && !siteAttributesAdded) {
						row4.add(fileAttribComp);
					} else {
						if (i % 2 != 0) {
							eachDataDiv.add(fileAttribComp);
							col1Div.add(eachDataDiv);
						}
						if (i % 2 == 0) {
							eachDataDiv.add(fileAttribComp);
							col2Div.add(eachDataDiv);
						}
					}
					break;
				default:
					break;   
				}
				if (siteOrProperty) {
					dynamicSiteAttributesMap.put(attrname,dataTypeList);
					updateddynamicSiteAttributesMap.put(attrname,dataTypeList);
				} else {
					dynamicPropertyAttributesMap.put(attrname,dataTypeList);
				}

				//	}

				//	additionalAttrDiv.add(attrrow);
				//	c++;
			}
			
			attributeUIOrchestration();
	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected Div renderFileUploadComponent(String aname, int adatatype) {
		Div fileAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ATTRIB_DIV");
		Button fileAttributeBtn = UIFieldFactory.createButton(SCREENCD, "FILE_ATTRIB_BTN");
		fileAttributeBtn.setText(SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "FILE_ATTRIB_BTN"));
		
		fileAttributeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				String [] acceptedFileTypes = null;
				if(adatatype == 8) {
					acceptedFileTypes = ".png,.jpg,.jpeg,.gif,.bmp".split("[,]");
				} else if(adatatype == 9) {
					acceptedFileTypes = ".txt".split("[,]");
					//uploadDoc.setAcceptedFileTypes(".txt");
				} else if(adatatype == 10) {
					//uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif",".bmp",".xls",".xlsx");
					acceptedFileTypes = ".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.bmp,.xls,.xlsx".split("[,]");
				}

				FileTypeAttributeUploadDialog uploadDlg = new FileTypeAttributeUploadDialog(aname, "Landlord File Attribute", acceptedFileTypes);
				uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						FileTypeAttributeUploadDialog dlg = (FileTypeAttributeUploadDialog)event.getSource();
						if(!dlg.isOpened()) {
							if(dlg.isGetDocUploadStatus()) {
								JSONObject fileDetailJSON = dlg.getFileDetail();
								if(fileDetailJSON != null && fileDetailJSON.length() > 0) {
									fileAttributeMap.put(aname, fileDetailJSON);
								}
								else {
									fileAttributeMap.remove(aname);
								}
							}
							else {
								fileAttributeMap.remove(aname);
							}
						}
					}
				});
			}
		});
		
		Label fileAttributeLbl = UIHtmlFieldFactory.createLabel(aname, SCREENCD, "FILE_ATTRIB_LBL");
		fileAttributeDiv.add(fileAttributeLbl, fileAttributeBtn);
		return fileAttributeDiv;
	}
		
	protected void renderMultiSelectField(CheckboxGroup<String> multiSelectFld, String possibleValues, String defaultValue) {
		try {
			JSONObject json = new JSONObject(possibleValues);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));

			List<String> possibleValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				possibleValuesList.add(jsonArray.getString(i));
			}
			
			json = new JSONObject(defaultValue);

			jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));

			List<String> defaultValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				defaultValuesList.add(jsonArray.getString(i));
			}
			
			multiSelectFld.setItems(possibleValuesList);
			multiSelectFld.select(defaultValuesList);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	private void attributeUIOrchestration() {
		
		System.out.println("dynamicSiteAttributesMap="+dynamicSiteAttributesMap.toString());
		if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
			/*	if(key.equalsIgnoreCase("EB Meter Status")) {
					if(keyvalue.size()>0)	//value obj
					{	
						String datatype=keyvalue.get(0).toString().toUpperCase();
						switch(datatype)
						{
						case "FLOV":
							if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
								attributeVisibility(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(),key);
							}
							((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
								private static final long serialVersionUID = 1L;
		
								@Override
								public void valueChanged(ValueChangeEvent<?> event) {
									if (event.getValue() != null) {
										attributeVisibility(event.getValue().toString().trim(),key);
									}
								}
							});
							
							break;
						}
					}
				}*/
				if(key.equalsIgnoreCase("EB Chargeable") || key.equalsIgnoreCase("EB Meter Status")) {
					if(keyvalue.size()>0)	//value obj
					{	
						String datatype=keyvalue.get(0).toString().toUpperCase();
						switch(datatype)
						{
						case "FLOV":
							if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
								attributeVisibility2(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(),key);
							}
							((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
								private static final long serialVersionUID = 1L;
		
								@Override
								public void valueChanged(ValueChangeEvent<?> event) {
									if (event.getValue() != null) {
										attributeVisibility2(event.getValue().toString().trim(),key);
									}
								}
							});
							
							break;
						}
					}
				}

		
			}
			
		}		
		
	}
/*	protected void attributeVisibility(String combovalue, String keyName) {
		//	System.out.println(combovalue);
			if(combovalue.equalsIgnoreCase("SEB Meter")) {
			//	System.out.println("inside attributeVisibility3333="+combovalue);
				if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
				{	
					Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();
					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
			
						if(key.equalsIgnoreCase("Electricity Consumer No")&& keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("SEB Meter Serial Number") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("SD for Electricity EB Board") && keyName.equalsIgnoreCase("EB Meter Status")) {
						//else if(key.equalsIgnoreCase("SD for Electricity (EB Board)")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("Submeter Serial Number") && keyName.equalsIgnoreCase("EB Meter Status")) {//not visible
							if(keyvalue.size()>0) {
								//System.out.println("inside1");
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
								
							}
							
						}else if(key.equalsIgnoreCase("EB Meter Charges") && keyName.equalsIgnoreCase("EB Meter Status")) {
							//System.out.println("inside2");
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}//else if(key.equalsIgnoreCase("SD for Electricity (Realtor)")) {
						else if(key.equalsIgnoreCase("SD for Electricity Realtor") && keyName.equalsIgnoreCase("EB Meter Status")) {
							//System.out.println("inside3");
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}

				}
			}
		}else if(combovalue.equalsIgnoreCase("Sub Meter") || combovalue.equalsIgnoreCase("Prepaid Meter")) {
			//System.out.println("inside attributeVisibility222="+combovalue);
			if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
						
						if(key.equalsIgnoreCase("Submeter Serial Number") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");//set attr mandatory 
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("EB Meter Charges") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}//else if(key.equalsIgnoreCase("SD for Electricity (Realtor)")) {
						else if(key.equalsIgnoreCase("SD for Electricity Realtor") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed") && keyName.equalsIgnoreCase("EB Meter Status")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}
						else if(key.equalsIgnoreCase("Electricity Consumer No") && keyName.equalsIgnoreCase("EB Meter Status")) {
						//	System.out.println("inside1");
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}else if(key.equalsIgnoreCase("SEB Meter Serial Number") && keyName.equalsIgnoreCase("EB Meter Status")) {
						//	System.out.println("inside2");
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}//else if(key.equalsIgnoreCase("SD for Electricity (EB Board)")) {
						else if(key.equalsIgnoreCase("SD for Electricity EB Board") && keyName.equalsIgnoreCase("EB Meter Status")) {
						//	System.out.println("inside3");
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}
					}
				}
				
			}else if(combovalue.equalsIgnoreCase("Chargeable") && keyName.equalsIgnoreCase("EB Chargeable")){
				if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
				{	
					Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
						if(key.equalsIgnoreCase("Sanction Load")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");//set attr mandatory 
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}else if(key.equalsIgnoreCase("EB Invoice Frequency")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								mandatoryFields(datatype,keyvalue);
								keyvalue.set(2,"1");//set attr mandatory 
								updateddynamicSiteAttributesMap.put(key,keyvalue);
							}
							
						}
					}
				}
			}else if(combovalue.equalsIgnoreCase("FOC") && keyName.equalsIgnoreCase("EB Chargeable")){
				if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
				{	
					Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
						if(key.equalsIgnoreCase("Sanction Load")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}else if(key.equalsIgnoreCase("EB Invoice Frequency")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}
					}
				}
			}
			
		}*/
	protected void attributeVisibility2(String combovalue, String keyName) {
		
		 if(keyName.equalsIgnoreCase("EB Chargeable") && combovalue.equalsIgnoreCase("Chargeable")){
			if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
					if(key.equalsIgnoreCase("EB Meter Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("Sanction Load")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("EB Invoice Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("Additional EB Security Deposite")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("Electricity Unit Rate for Submeter")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("SD for Electricity EB Board")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}else if(key.equalsIgnoreCase("SD for Electricity Realtor")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed")) {
							if(keyvalue.size()>0) {
								String datatype=keyvalue.get(0).toString().toUpperCase();
								nonmandatoryFields(datatype,keyvalue);
								if(updateddynamicSiteAttributesMap.containsKey(key)) {
									updateddynamicSiteAttributesMap.remove(key);
								}
							}
							
						}
				}
			}
		}else if(keyName.equalsIgnoreCase("EB Meter Status") && combovalue.equalsIgnoreCase("SEB Meter")) {
		//	System.out.println("inside attributeVisibility3333="+combovalue);
			if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
		
					if(key.equalsIgnoreCase("Electricity Consumer No")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("SEB Meter Serial Number")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("SD for Electricity EB Board")) {
					//else if(key.equalsIgnoreCase("SD for Electricity (EB Board)")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("Submeter Serial Number")) {//not visible
						if(keyvalue.size()>0) {
							//System.out.println("inside1");
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
							
						}
						
					}else if(key.equalsIgnoreCase("EB Meter Charges")) {
						//System.out.println("inside2");
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}//else if(key.equalsIgnoreCase("SD for Electricity (Realtor)")) {
					else if(key.equalsIgnoreCase("SD for Electricity Realtor")) {
						//System.out.println("inside3");
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}

				}
			}
		}else if(keyName.equalsIgnoreCase("EB Meter Status") &&(combovalue.equalsIgnoreCase("Sub Meter") 
				|| combovalue.equalsIgnoreCase("Prepaid Meter"))) {
			//System.out.println("inside attributeVisibility222="+combovalue);
			if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
					
					if(key.equalsIgnoreCase("Submeter Serial Number")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");//set attr mandatory 
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("EB Meter Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}//else if(key.equalsIgnoreCase("SD for Electricity (Realtor)")) {
					else if(key.equalsIgnoreCase("SD for Electricity Realtor")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("Electricity Consumer No")) {
					//	System.out.println("inside1");
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("SEB Meter Serial Number")) {
					//	System.out.println("inside2");
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}//else if(key.equalsIgnoreCase("SD for Electricity (EB Board)")) {
					else if(key.equalsIgnoreCase("SD for Electricity EB Board")) {
					//	System.out.println("inside3");
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
				}
			}
			}
		 else if(keyName.equalsIgnoreCase("EB Chargeable") && combovalue.equalsIgnoreCase("FOC")){
			if(dynamicSiteAttributesMap!=null && dynamicSiteAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicSiteAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicSiteAttributesMap.get(key);
					if(key.equalsIgnoreCase("EB Meter Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
					else if(key.equalsIgnoreCase("Sanction Load")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("EB Invoice Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("Additional EB Security Deposite")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
					else if(key.equalsIgnoreCase("Electricity Unit Rate for Submeter")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("SD for Electricity EB Board")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("SD for Electricity Realtor")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("EB Meter Installation Charges Fixed")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
				}
			}
		}
		
	}
	private void nonmandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(false);
			((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(false);
			((NumberField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(false);
			((DatePicker)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
			
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		}

		
	}
	private void mandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(true);
			((ComboBox<Object>)keyvalue.get(1)).setRequired(true);
			((ComboBox<Object>)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(true);
//			((NumberField)keyvalue.get(1)).setRequired(true);
			((NumberField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((TextField)keyvalue.get(1)).setInvalid(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setRequired(true);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((TextField)keyvalue.get(1)).setInvalid(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(true);
			((DatePicker)keyvalue.get(1)).setRequired(true);
			((DatePicker)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((DatePicker)keyvalue.get(1)).setInvalid(true);
			((Div) keyvalue.get(3)).setVisible(true);
			
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setRequired(true);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
		//	((TextField)keyvalue.get(1)).setInvalid(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		}

		
	}
	private Map<String, JSONArray>   retrieveSiteLevelAttributes()
	{

		Map<String, JSONArray> attributeListMap= new LinkedHashMap<String, JSONArray>();
		String attributeType;

		String res = "",res1="";
		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");

			res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("siteattr="+res);
			
		//	res="[{\"AttributeId\":36,\"AttributeName\":\"EB Meter Status\",\"AttributeType\":7,\"AttributeDatatype\":5,\"Mandatory\":1,\"DefaultValue\":\"SEB Meter\",\"FLOV\":\"SEB Meter,Sub Meter,Prepaid Meter\"},{\"AttributeId\":37,\"AttributeName\":\"Electricity Consumer No\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":37,\"AttributeName\":\"SEB Meter Serial Number\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":37,\"AttributeName\":\"SD for Electricity (EB Board)\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":37,\"AttributeName\":\"Submeter Serial Number\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":37,\"AttributeName\":\"EB Meter Charges\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":37,\"AttributeName\":\"SD for Electricity (Realtor)\",\"AttributeType\":7,\"AttributeDatatype\":3,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"}]";

		} 
		catch (Exception e) {

			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			return null;

		}

		try {
			if (res != null) {
				JSONArray ja = new JSONArray(res);
				List<String> attributeNameListAccount = new ArrayList<String>();
				//	JSONObject eachjsobj=new JSONObject();
				JSONArray eachSiteAttrJsArr=new JSONArray();
				JSONArray eachPropertyAttrJsArr=new JSONArray();
				for (int i = 0; i < ja.length(); i++) {

					switch (ja.getJSONObject(i).getInt("AttributeType")) {
					case 7:
						//	attributeNameListAccount.add(ja.getJSONObject(i).get("AttributeName").toString());
						eachSiteAttrJsArr.put(ja.getJSONObject(i));
						break;
					case 9:
						eachPropertyAttrJsArr.put(ja.getJSONObject(i));
						break;
					default:
						break;
					}
				}
				attributeListMap.put("SITE ATTRIBUTES", eachSiteAttrJsArr);
				attributeListMap.put("PROPERTY ATTRIBUTES", eachPropertyAttrJsArr);
//				System.out.println("Map="+attributeListMap);
			}
		}catch(JSONException ex)
		{
			ex.printStackTrace();	
		}
		return attributeListMap;

	}
	public boolean isSuccess() {
		return isSuccess;
	}

}
