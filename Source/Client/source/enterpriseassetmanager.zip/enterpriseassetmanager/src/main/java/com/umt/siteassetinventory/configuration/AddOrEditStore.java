package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/add_edit_store-styles.css")
public class AddOrEditStore extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_STORE";

	private TextField storeNameFld, addrFld;
	private ComboBox<String> statusCombo;
	//private String siteCode;
	private long storeId;

	public AddOrEditStore(StoreMaster storeMaster) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		storeNameFld = UIFieldFactory.createTextField("", true, SCREENCD, "STORE_NAME_FIELD");
		addrFld = UIFieldFactory.createTextField("", true, SCREENCD, "ADDRESS_FIELD");

		statusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, 
				SCREENCD, "STATUS_COMBO");
		statusCombo.setValue("Active");
		statusCombo.setEnabled(false);
		
		AddOrEditStorePopup popup = new AddOrEditStorePopup("Add Store", true, this, storeMaster, SCREENCD);

		add(storeNameFld, addrFld, statusCombo);

	}

	public AddOrEditStore(StoreMaster storeMaster, StoreMasterDataBean 
			storeMasterDataBean, long storeId, String storeName, String address, 
			String status) {
		this.storeId = storeId;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		try {
			storeNameFld = UIFieldFactory.createTextField(storeName, true, SCREENCD, "STORE_NAME_FIELD");
			storeNameFld.setEnabled(false);
			addrFld = UIFieldFactory.createTextField(address, true, SCREENCD, "ADDRESS_FIELD");

			statusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, 
					SCREENCD, "STATUS_COMBO");
			statusCombo.setValue(status);
			AddOrEditStorePopup popup = new AddOrEditStorePopup("Edit Store", false, this, storeMaster, SCREENCD);

			add(storeNameFld, addrFld, statusCombo);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean validation() {
		storeNameFld.setInvalid(false);
		addrFld.setInvalid(false);
		statusCombo.setInvalid(false);

		if (storeNameFld.getValue()==null || storeNameFld.getValue().trim().length()==0) {
			storeNameFld.setInvalid(true);
			storeNameFld.setErrorMessage("Please enter "+storeNameFld.getLabel().toLowerCase());
			return false;
		}

		if (addrFld.getValue()==null || addrFld.getValue().toString().trim().length()==0) {
			addrFld.setInvalid(true);
			addrFld.setErrorMessage("Please enter "+addrFld.getLabel().toLowerCase());
			return false;
		}

		if (statusCombo.getValue()==null || statusCombo.getValue().trim().length()==0) {
			statusCombo.setInvalid(true);
			statusCombo.setErrorMessage("Please enter "+statusCombo.getLabel().toLowerCase());
			return false;
		}
		return true;
	}
	
	
	public long getStoreId() {
		return storeId;
	}

	public String getStoreName() {
		if (storeNameFld.getValue()==null)
			return "";
		else
			return storeNameFld.getValue();
	}

	public String getAddress() {
		if (addrFld.getValue()==null)
			return "";
		else
			return addrFld.getValue()+"";
	}

	public String getStatus() {
		if (statusCombo.getValue()==null)
			return "";
		else
			return statusCombo.getValue();
	}


}
