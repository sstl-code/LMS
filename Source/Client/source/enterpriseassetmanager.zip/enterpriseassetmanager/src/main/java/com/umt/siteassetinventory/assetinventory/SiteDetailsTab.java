package com.umt.siteassetinventory.assetinventory;

import com.vaadin.flow.component.html.Div;
public class SiteDetailsTab extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_DETAILS_TAB";
	public SiteDetailsTab() {
		// TODO Auto-generated constructor stub
	}
	public void setSiteCode(String selectedsiteCode) 
	{
	//	System.out.println(selectedsiteCode);	
	}

}
