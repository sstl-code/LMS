package com.umt.siteassetinventory.assets;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/asset_history-style.css")
public class AssetHistoryDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_HISTORY_DATA_BEAN";
	private String startDate, endDate, storeName, storeLocationId, status, remarks;
	private Div eachrowDiv;


	public AssetHistoryDataBean(String startDate, String endDate, String storeName, String storeLocationId, String status, String remarks) 
	{
		addClassName(SCREENCD + "_BEAN_MAIN_LAYOUT");
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.storeName = storeName;
		this.storeLocationId = storeLocationId;
		this.status = status;
		this.remarks = remarks;
		Div eachrowOuterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_OUTER_DIV");
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
	
		
		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
//		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");
//		Div eachdataDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV6");
		
		Label startDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "START_DATE_CAPTION");
		Label startDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "START_DATE_VAL");
		startDateVal.setText(startDate);
		eachdataDiv1.add(/*startDateCaption, */startDateVal);

		/*Label endDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "END_DATE_CAPTION");
		Label endDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "END_DATE_VAL");
		endDateVal.setText(endDate);
		eachdataDiv2.add(endDateCaption, endDateVal);*/

		Label storeNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STORE_NAME_CAPTION");
		Label storeNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STORE_NAME_VAL");
		storeNameVal.setText(storeName);
		eachdataDiv2.add(storeNameCaption, storeNameVal);

		/*Label storeLocationIdCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STORE_LOC_ID_CAPTION");
		Label storeLocationIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STORE_LOC_ID_VAL");
		storeLocationIdVal.setText(storeLocationId);
		eachdataDiv4.add(storeLocationIdCaption, storeLocationIdVal);*/

		Label statusCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_CAPTION");
		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VAL");
		statusVal.setText(status);
		eachdataDiv3.add(statusCaption, statusVal);
		
		Label remarksCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "REMARKS_CAPTION");
		Label remarksVal = UIHtmlFieldFactory.createLabel(SCREENCD, "REMARKS_VAL");
		remarksVal.setText(remarks);
		eachdataDiv4.add(remarksCaption, remarksVal);

		eachrowDiv.add(eachdataDiv2,eachdataDiv3,eachdataDiv4);
		Icon circle = VaadinIcon.CIRCLE.create();
		circle.addClassName("CIRCLE");
		eachrowOuterDiv.add(eachdataDiv1, eachrowDiv);
		add(circle, eachrowOuterDiv);

	}


}
