package com.umt.siteassetinventory.invoice;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

@CssImport("./styles/invoice-mangement.css")
public class UploadInvoiceDocument extends Dialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "UPLOAD_INVOICE_DOC_DLG";
	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private Button saveBtn,cancelBtn;
	private String base64EncodedFileContent = "";
	private TextField docnameTextfield;
	
	private UIUploadComponent uploadDocDiv;
	private String fileFormat="";

	private String fileName="";
	public boolean fileuploadStatus=false;
	private Div previewImgDiv;
	private Image fileImage;
	private TextField doctypeField;
	private TextField descField;
	private List<String> docList=new ArrayList<String>();
	private List<String> docList2=new ArrayList<String>();

	public UploadInvoiceDocument() {
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		
		saveBtn=UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		saveBtn.setEnabled(false);
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);
		
	//	populateDocumentTypeList();
	//	doctypeField = UIFieldFactory.createComboBox(docList,true, SCREENCD,"DOCTYPE_FIELD");
		doctypeField = UIFieldFactory.createTextField("invoice",true, SCREENCD,"DOCTYPE_FIELD");
		descField = UIFieldFactory.createTextField("", true, SCREENCD,"DESC_FIELD");
		doctypeField.setEnabled(false);
		
		
		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDocDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDocDiv.getUpload();

		uploadDoc.setAcceptedFileTypes(".pdf", ".doc", ".docx", ".txt", ".png", ".jpg", ".jpeg", ".gif");
		
		int maxfilesize=Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDoc.setMaxFileSize(maxfilesize*1000);

		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					fileName=event.getFileName();
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc")
							|| fileExtension.equalsIgnoreCase("docx") || fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx")
							|| fileExtension.equalsIgnoreCase("csv")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
						if (fileExtension.equalsIgnoreCase("xls")) {
							fileFormat = "application/vnd.ms-excel";
						} 
						if (fileExtension.equalsIgnoreCase("xlsx")) {
							fileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
						}
						saveBtn.setEnabled(true);

					}
					if (fileExtension.equalsIgnoreCase("jpg")  || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
					//	populatePreviewImg(base64EncodedFileContent);
						fileFormat = "image/"+fileExtension.toLowerCase();
						saveBtn.setEnabled(true);
					}

				} catch (Exception ex) {
					ex.printStackTrace();
					base64EncodedFileContent = "";
					fileuploadStatus=false;
				}

			}
		});

		uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {

				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
				event.getUpload().interruptUpload();
				saveBtn.setEnabled(false);
				fileuploadStatus=false;
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
				saveBtn.setEnabled(false);
				fileuploadStatus=false;
			}
		});
		
		uploadDoc.getElement().addEventListener("file-abort", event1 -> {
			base64EncodedFileContent="";
			saveBtn.setEnabled(false);
			fileuploadStatus=false;
		});

		VerticalLayout bodyLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "BODY_LAYOUT");
		bodyLayout.add(doctypeField,descField,uploadDocDiv);

		mainLayoutDiv.add(titleBar,bodyLayout,buttonBar);

		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				boolean isvalid=validateFields();
				if(!isvalid) {
					return;
				}else {
					fileuploadStatus=true;
					close();
				}
				

			}
		});

	}

	protected boolean validateFields() {
		boolean valid=true;
		if(doctypeField.getValue()==null || doctypeField.getValue().length()<=0) {
			doctypeField.setInvalid(true);
			doctypeField.setErrorMessage("Please Fill up this field");
			valid=false;
		}else if(descField.getValue()==null || descField.getValue().length()<=0) {
			descField.setInvalid(true);
			descField.setErrorMessage("Please Fill up this field");
			valid=false;
		}
		return valid;
	}

	private void populateDocumentTypeList() {
		try {
			docList=new ArrayList<String>();
			docList2.clear();
			String url = ApplicationConfiguration.getServiceEndpoint("GET_LANDLORD_DOCUMENT_TYPES");
			String res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			if(res!=null && res.trim().length()>0) {
				JSONObject js=new JSONObject(res);
				String types=js.getString("documenttypes");
				if(types!=null) {
					String str = types.replace("[", "").replace("]", "");
				//	System.out.println(str.replaceAll("\"", ""));
					String[] arrOfStr = str.replaceAll("\"", "").split(",");
			        for (String s : arrOfStr) {
			        	docList.add(s);
			        }
				}
				
			
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public String getFileName() {
		return fileName;
	}

	public String getFileContent() {
		return base64EncodedFileContent;
	}

	public String getFileType() {
		return doctypeField.getValue();
	}
	public String getFileDescription() {
		return descField.getValue();
	}

}
