package com.umt.siteassetinventory.audittrail;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.IFrame;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinServletRequest;

@Route(value = "audittrail", layout = MainView.class)
@CssImport("./styles/audit_trail-styles.css")
public class Audittrail extends VerticalLayout{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String SCREENCD = "AUDIT_TRAIL";


	public Audittrail() {

		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Audit Trail");
		String auditTrail_iframeSrc = VaadinServletRequest.getCurrent().getScheme() 
				+ "://" + VaadinServletRequest.getCurrent().getServerName() 
				+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
				+"/audittrail" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

		//String auditTrail_iframeSrc2="https://172.18.0.11:7004"+"/audittrail" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

		//System.out.println("auditTrail_iframeSrc= "+auditTrail_iframeSrc);
		IFrame iframe = new IFrame(auditTrail_iframeSrc);
		iframe.addClassName(SCREENCD + "_IFRAME");
		add(iframe);

	}
}
