package com.umt.siteassetinventory.utility;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

@CssImport("./styles/file_type_attribute_upload_dialog-styles.css")
public class FileTypeAttributeUploadDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "FILE_TYPE_ATTRIBUTE_UPLOAD_DIALOG";
	
	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private Button saveBtn;
	private Button cancelBtn;
	private String base64EncodedFileContent = "";
	private String attributeName = "";
	private String documentType = "";
	private String[] acceptedFileTypes;
	private boolean getDocUploadStatus = false;	
	private String fileFormat="";
	private UIUploadComponent uploadDiv;
	private boolean saveBtnClicked = false;
	private JSONObject fileDetailsJson;
	
	public FileTypeAttributeUploadDialog(String attributeName, String documentType, String[] acceptedFileTypes) {
		this.attributeName = attributeName;
		this.documentType = documentType;
		this.acceptedFileTypes = acceptedFileTypes;
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label titleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(titleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");

		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
	
		buttonBar.add(saveBtn,cancelBtn);

		Label docLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_LBL");

		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDiv.getUpload();
		uploadDiv.getStyle().set("margin-top", "0px");
		//uploadDoc.addClassName("DOCUMENT_UPLOAD");
		//uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif");
		uploadDoc.setAcceptedFileTypes(this.acceptedFileTypes);
		int maxfilesize = Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDoc.setMaxFileSize(maxfilesize*1000);
		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx")
							|| fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
						if (fileExtension.equalsIgnoreCase("xls")) {
							fileFormat = "application/vnd.ms-excel";
						} 
						if (fileExtension.equalsIgnoreCase("xlsx")) {
							fileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
						}
					}
					if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
						fileFormat = "image/"+fileExtension.toLowerCase();
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					base64EncodedFileContent = "";
				}
			}
		});
		

		uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
				event.getUpload().interruptUpload();
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
			}
		});
		
		uploadDoc.getElement().addEventListener("file-abort", event1 -> {
			base64EncodedFileContent="";
		});

		VerticalLayout lay = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "INFO_TAB");
		lay.add(docLbl,uploadDiv);

		mainLayoutDiv.add(titleBar,lay,buttonBar);

		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button/*Div*/>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button/*Div*/> event) {
				cancelBtnClicked();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button/*Div*/>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button/*Div*/> event) {
				if (validation()) {
					addDocument();
				}
			}
		});
	}

	private boolean validation()
	{
		return true;	
	}

	protected void addDocument() 
	{
		try 
		{
			if(base64EncodedFileContent==null || base64EncodedFileContent.trim().length()==0)
			{
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DOC_UPLOAD_ERROR", ApplicationConstants.DialogTypes.INFO);
				return;
			}
		
			fileDetailsJson = new JSONObject();
			fileDetailsJson.put("Name", uploadDiv.getFileName().trim());
			fileDetailsJson.put("Type", documentType);
			fileDetailsJson.put("Description", uploadDiv.getFileName().trim());
			fileDetailsJson.put("Content", base64EncodedFileContent);
			getDocUploadStatus = true;
			close();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(ex.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			getDocUploadStatus = false;
		}
	}
	
	public String getAttributeName() {
		return this.attributeName;
	}
	
	public void setAttribute(String attributeName) {
		this.attributeName = attributeName;
	}
	
	protected void cancelBtnClicked()
	{
		close();	
	}

	public boolean isGetDocUploadStatus() {
		return getDocUploadStatus;
	}
	
	public JSONObject getFileDetail() {
		return fileDetailsJson;
	}

	public void setGetDocUploadStatus(boolean getDocUploadStatus) {
		this.getDocUploadStatus = getDocUploadStatus;
	}

	public boolean isSaveBtnClicked() {
		return saveBtnClicked;
	}

	public void setSaveBtnClicked(boolean saveBtnClicked) {
		this.saveBtnClicked = saveBtnClicked;
	}

	public String getBase64EncodedFileContent() {
		return base64EncodedFileContent;
	}

	public void setBase64EncodedFileContent(String base64EncodedFileContent) {
		this.base64EncodedFileContent = base64EncodedFileContent;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
}
                                                                                                                                                                                            