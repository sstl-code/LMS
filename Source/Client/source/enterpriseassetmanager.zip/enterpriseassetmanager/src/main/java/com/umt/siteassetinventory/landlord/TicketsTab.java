package com.umt.siteassetinventory.landlord;

import java.net.URLEncoder;

import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.IFrame;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.server.VaadinServletRequest;

@CssImport("./styles/tickets_tab-styles.css")
public class TicketsTab extends VerticalLayout {

	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "TICKETS_TAB";

	private String landlordId = ""; 
	//private String instanceFilter = this.landlordId;
	private String templateFilter = "LandlordTroubleTicket";
	private boolean createFlag = true;
	
	protected VerticalLayout troubleticketTableVL;

	public String getLandlordId() {
		return landlordId;
	}

	public void setLandlordId(String landlordId) {
		this.landlordId = landlordId;
		populateScreen();
	}
	
	public TicketsTab() {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		troubleticketTableVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "WORKFLOW_TABLE_VL");
		

		//Button raiseTicketBtn = UIFieldFactory.createButton(SCREENCD, "RAISE_TICKET_BTN");
		add(/*raiseTicketBtn,*/troubleticketTableVL);

		/*raiseTicketBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

			}
		});*/


		//troubleticketTableVL.add();

	}
	
	private void populateScreen() {
		String instanceFilterParamEncoded = URLEncoder.encode("instanceFilter");
		String templateFilterParamEncoded = URLEncoder.encode("templateFilter");
		String createFlagParamEncoded = URLEncoder.encode("createFlag");
		String instanceFilterValEncoded = URLEncoder.encode(getLandlordId());
		String templateFilterValEncoded = URLEncoder.encode(templateFilter);
		String createFlagValEncoded = URLEncoder.encode(createFlag+"");
		String ticket_iframeSrc = VaadinServletRequest.getCurrent().getScheme() 
				+ "://" + VaadinServletRequest.getCurrent().getServerName() 
				+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
			    +"/workflow/#/tickets" + "?"+instanceFilterParamEncoded+
				"=" + "landlordid:"+ instanceFilterValEncoded +"&"+templateFilterParamEncoded+"=" + templateFilterValEncoded + "&" + 
				createFlagParamEncoded+"=" + createFlagValEncoded + "&data=LandlordId:" + instanceFilterValEncoded;
				
				//System.out.println("ticket_iframeSrc= "+ticket_iframeSrc);
				
				IFrame iframe = new IFrame(ticket_iframeSrc);
				iframe.addClassName(SCREENCD + "_IFRAME");
				troubleticketTableVL.add(iframe);
	}


}

