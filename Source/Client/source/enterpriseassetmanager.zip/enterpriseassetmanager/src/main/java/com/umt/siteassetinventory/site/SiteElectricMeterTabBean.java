package com.umt.siteassetinventory.site;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.component.dependency.CssImport;

@CssImport("./styles/electric-meter-tab-styles.css")
public class SiteElectricMeterTabBean extends Div{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ELECTRIC_METER_TAB_BEAN";
	private String storeserialno,serialNo;
	private String equipment_id;
	private String assetType;
	private String metercategory="",sebMeterAuthority="",sebMeterInstallationDate="",consumerNo="";
	private SiteElectricMeterTab siteElectricMeterTab;
	private JSONObject otherinfojs;
	private JSONArray arrayList;
	private ArrayList<String> atrri_title;
	private Map<String, String> attri_data;

	public SiteElectricMeterTabBean() {
		
	}

	public SiteElectricMeterTabBean(String storeserialno, String assetType, String assetName, String serialNo, String installationDate,
			String vendorName, String status, SiteElectricMeterTab siteElectricMeterTab,JSONObject otherinfojs) {
		//public SiteElectricMeterTabBean(String assetId, String metercategory, String assetName, String serialNo, String installationDate,
		//		String sebMeterAuthority, String status, SiteElectricMeterTab siteElectricMeterTab,
		//		String sebMeterInstallationDate,String consumerNo) {
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.siteElectricMeterTab = siteElectricMeterTab;
		this.storeserialno = storeserialno;
		this.serialNo=serialNo;
		//
		//
		//this.consumerNo=consumerNo;
		this.otherinfojs=otherinfojs;
	//	this.assetType=assetType;
	//	getEquipmentId();
	//	System.out.println("otherinfojs="+otherinfojs);
		getAttributesMaster();
		if(otherinfojs!=null && otherinfojs.length()>0) {
			try {
				if(otherinfojs.has("Meter Category")) {
					this.metercategory=otherinfojs.getString("Meter Category");
				}
				if(otherinfojs.has("SEB Meter Authority")) {
					this.sebMeterAuthority=otherinfojs.getString("SEB Meter Authority");
				}
				if(otherinfojs.has("Consumer No")) {
					this.consumerNo=otherinfojs.getString("Consumer No");	
				}
				if(otherinfojs.has("SEB Meter Installation Date")) {
					this.sebMeterInstallationDate=otherinfojs.getString("SEB Meter Installation Date");
				}else {
					this.sebMeterInstallationDate=null;
				}
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		Label assetIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_ID_LBL");
		Button editMeterButton = UIFieldFactory.createButton(SCREENCD, "VIEW_ASSET_BTN");
		Button removeAssetButton = UIFieldFactory.createButton(SCREENCD, "REMOVE_ASSET_BTN");
		assetIdLbl.setText("Meter ID: "+storeserialno);
		headerDiv.add(assetIdLbl, editMeterButton, removeAssetButton);

		Div col1 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN1");
		Div col2 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN2");
		Div col3 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN3");

		

/*		Div eachAssetDetailDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label meterNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_CAPTION");
		Label meterNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_VALUE");
		meterNameVal.setText(vendorName);
		eachAssetDetailDiv1.add(meterNameCaption, meterNameVal);*/
		Div eachAssetDetailDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label installationDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_CAPTION");
		Label installationDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_VALUE");
		installationDateVal.setText(installationDate);
		eachAssetDetailDiv1.add(installationDateCaption, installationDateVal);
	
		Div eachAssetDetailDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label meterCategoryCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_CAPTION");
		Label meterCategoryVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_VALUE");
		meterCategoryVal.setText(metercategory);
		eachAssetDetailDiv2.add(meterCategoryCaption, meterCategoryVal);

		Div eachAssetDetailDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label serialNoCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_CAPTION");
		Label serialNoVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_VALUE");
		serialNoVal.setText(serialNo);
		eachAssetDetailDiv3.add(serialNoCaption, serialNoVal);

/*		Div eachAssetDetailDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label installationDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_CAPTION");
		Label installationDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_VALUE");
		installationDateVal.setText(installationDate);
		eachAssetDetailDiv4.add(installationDateCaption, installationDateVal);*/
		
		Div eachAssetDetailDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		
		
		Div eachAssetDetailDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label sebMeterAuthorityCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_CAPTION");
		Label sebMeterAuthorityVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_VALUE");
		sebMeterAuthorityVal.setText(sebMeterAuthority);
		eachAssetDetailDiv5.add(sebMeterAuthorityCaption, sebMeterAuthorityVal);

		Div eachAssetDetailDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label statusCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_CAPTION");
		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VALUE");
		statusVal.setText(status);
		statusVal.getStyle().set("background-color", CommonUtils.getStatusColorCode(status));
		eachAssetDetailDiv6.add(statusCaption, statusVal);
		
		Div eachAssetDetailDiv7 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label SebMeterInstallationDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "SEB_METER_INSTALLATION_DATE_CAPTION");
		Label sebMeterInstallationDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SEB_METER_INSTALLATION_DATE_VALUE");
		try {
			if(sebMeterInstallationDate!=null) {		
			    sebMeterInstallationDateVal.setText(CommonUtils.convertDateToDifferentFormat(sebMeterInstallationDate,"dd/MM/yyyy","dd-MMM-yy"));
			}else {
				sebMeterInstallationDateVal.setText("");
			}
		}catch(Exception e) {
			e.printStackTrace();
		//	System.out.println(e.getMessage());
		}
		
		
		//sebMeterInstallationDateVal.setText(sebMeterInstallationDate);
	//	eachAssetDetailDiv7.add(SebMeterInstallationDateCaption,sebMeterInstallationDateVal);
		eachAssetDetailDiv4.add(SebMeterInstallationDateCaption,sebMeterInstallationDateVal);
		
		Div eachAssetDetailDiv8 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label consumerNoCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMER_NO_CAPTION");
		Label consumerNoVal = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMER_NO_VALUE");
		consumerNoVal.setText(consumerNo);
//		eachAssetDetailDiv8.add(consumerNoCaption, consumerNoVal);
		eachAssetDetailDiv7.add(consumerNoCaption, consumerNoVal);

		col1.add(eachAssetDetailDiv1, eachAssetDetailDiv4,eachAssetDetailDiv7);
		col2.add(eachAssetDetailDiv2, eachAssetDetailDiv5,eachAssetDetailDiv8);
		col3.add(eachAssetDetailDiv3, eachAssetDetailDiv6);
		containerDiv.add(col1, col2, col3);
		add(headerDiv, containerDiv);
		
		if(getSiteStatus().equalsIgnoreCase("Decommissioned")) {
			editMeterButton.setEnabled(false);
		}else {
			editMeterButton.setEnabled(true);
		}
		
		editMeterButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				editMeter(vendorName,metercategory,storeserialno,installationDate,sebMeterAuthority,status,sebMeterInstallationDate,consumerNo);	
			}
		});

		
//		removeAssetButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public void onComponentEvent(ClickEvent<Button> arg0) {
//				removeAsset();	
//			}
//		});
		
		
		removeAssetButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

				String title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "WARNING_DIALOG_TITLE");
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showWarningMessage(SCREENCD, "REMOVE_ROW_WARNING", title);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						Dialog srcDlg = event.getSource();
						if(!srcDlg.isOpened()) 
						{
							if(srcDlg.getId().isPresent() && srcDlg.getId().get().equals("9999"))
							{
								removeAsset();
								srcDlg.close();
							}
							if(srcDlg.getId().isPresent() && srcDlg.getId().get().equals("-9999"))
							{
								srcDlg.close();
							}
						}
						
					}
				});
			}
		});
		

	}
	
	protected void editMeter(String vendorName, String metercategory2, String storeserialno, String installationDate, String sebMeterAuthority2, String status, String sebMeterInstallationDate2, String consumerNo2) {
		EditElectricMeterDialog dlg =new EditElectricMeterDialog(vendorName,metercategory2,storeserialno,installationDate,
				sebMeterAuthority2,status,sebMeterInstallationDate2,consumerNo2,serialNo,siteElectricMeterTab,arrayList, attri_data);
		
		
//		EditElectricMeterDialog dlg =new EditElectricMeterDialog(vendorName,metercategory2,storeserialno,installationDate,
//				sebMeterAuthority2,status,sebMeterInstallationDate2,consumerNo2,serialNo,siteElectricMeterTab,arrayList, attri_data);
		
	}

	
	
	private void removeAsset()
	{
		String base_URL=ApplicationConfiguration.getServiceEndpoint("REMOVEASSETFROMSITE");
		try {

			Form formData = new Form();
			formData.add("SiteCode", siteElectricMeterTab.getSiteCode());
			formData.add("StoreSerialNo", storeserialno);
//			formData.add("StoreId", 9995);
//			formData.add("StatusId", 3);
//			formData.add("StoreLocId", viewSiteAssetsTab.getSiteCode());
			//System.out.println("input:: " + formData.toString());
			String response = RestServiceHandler.deleteJSON_DELETE(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("Return:" + response);
			//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "METER_REMOVE_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
			siteElectricMeterTab.refreshData();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	}
	
	private void getAttributesMaster() {
		//System.out.println("id" + id);
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTESFORASSETS");
		base_URL = base_URL + "?EquipmentTypeId="+ "1";
		try {
			String res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
		//	System.out.println("Response: " + res);
			
			arrayList = new JSONArray(res);
		//	System.out.println("arrayList: " + arrayList);
			
			atrri_title = new ArrayList<>();
			for(int i = 0; i<arrayList.length(); i++) {
				JSONObject json = arrayList.getJSONObject(i);
				
					atrri_title.add(json.getString("AttributeName"));
				
			}
			populateAttributes(storeserialno);
			//System.out.println("atrri_title: " + atrri_title);
//			System.out.println("arrayList: " + arrayList);
			//	System.out.println("attri_data: " + attri_data);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void populateAttributes(String storeserialno) throws Exception {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTSATTRIBUTES");
		base_URL = base_URL + "?StoreSerialNo=" + storeserialno;
		
		System.out.println("base_URL:::: " + base_URL);
		String res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
		
	//	System.out.println("Attr outPut: " + res);
		JSONObject json = new JSONObject(res);
		String otherInfo= json.getString("OtherInfo");
		JSONObject json_otherinfo = new JSONObject(otherInfo);
		Iterator<String> keys = json_otherinfo.keys();
		
		
		ArrayList<String> keyValue = new ArrayList<>();
		Map<String, String> attri_value_key = new LinkedHashMap<>();
		
		
		while(keys.hasNext()) {
			String key = keys.next();
			attri_value_key.put(key, json_otherinfo.getString(key));
		}
		
		attri_data = new LinkedHashMap<>();
		Set<String> key_set = attri_value_key.keySet();
		//System.out.println(atrri_title.size());
		for(int i = 0; i<atrri_title.size(); i++) {

			attri_data.put(atrri_title.get(i), "-");
	
		}
		
	//	System.out.println("attri_value_key:::"+attri_value_key);
		
		for(int i = 0; i<atrri_title.size(); i++) {
			for(String key : key_set) {
				if(atrri_title.get(i).equals(key) && attri_value_key.get(key)!=null && attri_value_key.get(key).trim().length()>0) {
					attri_data.replace(atrri_title.get(i), attri_value_key.get(key));	
				}
			}
		}

		
		
		
	}
	
	private String getSiteStatus() {
		String siteStatus="Active";
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEDETAILS");
			url=url+"?SiteCode="+siteElectricMeterTab.getSiteCode();
			String resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			if(resp.length()>0) {
				JSONObject js = new JSONObject(resp);
				if(js.length()>0) {
					siteStatus=js.getString("Status");
				}
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return siteStatus;
	}



}
