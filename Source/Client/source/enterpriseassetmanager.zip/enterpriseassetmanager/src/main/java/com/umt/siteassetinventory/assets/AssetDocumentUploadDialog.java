package com.umt.siteassetinventory.assets;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

@CssImport("./styles/asset_document_upload_dialog-styles.css")
public class AssetDocumentUploadDialog extends Dialog 
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_DOCUMENT_UPLOAD_DLG";

	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private Div bodyLayout;
	Button saveBtn;
	//	private Button saveBtn;
	//	private Button cancelBtn;
	private Button cancelBtn;
	private String base64EncodedFileContent = "";
	private ComboBox<String> documentTypeCombo;
	private TextField documentDescTextfield;
	private String assetId = "";
	private boolean getDocUploadStatus = false;	
	private String fileFormat="";
	private UIUploadComponent uploadDiv;
	private boolean saveBtnClicked = false;


	public AssetDocumentUploadDialog(String assetId) 
	{
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label titleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(titleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		bodyLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_LAYOUT");

		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");

		//		saveBtn =  UIHtmlFieldFactory.createDiv(SCREENCD, "SAVE_BTN_DIV");
		//		Label saveBtnLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAVE_BTN_LBL");
		//		saveBtn.add(saveBtnLbl);
		//
		//		cancelBtn =  UIHtmlFieldFactory.createDiv(SCREENCD, "CANCEL_BTN_DIV");
		//		Label cancelBtnLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CANCEL_BTN_LBL");
		//		cancelBtn.add(cancelBtnLbl);

		buttonBar.add(saveBtn,cancelBtn);
		List<String> documentTypes = CommonUtils.parseFLOV(SCREENCD, "DOCUMENT_TYPES_LIST", ',');
		//System.out.println("documentTypes="+documentTypes.toString());
		documentTypeCombo = UIFieldFactory.createComboBox(documentTypes, true,  SCREENCD, "DOC_TYPE_FIELD");
		documentTypeCombo.setPlaceholder("Enter Document Type");

		documentDescTextfield = UIFieldFactory.createTextField("", false,  SCREENCD, "DOC_DESC_FIELD");
		documentDescTextfield.setPlaceholder("Enter Document description");

		Label docLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_LBL");

		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDiv.getUpload();
		uploadDiv.getStyle().set("margin-top", "0px");
		//uploadDoc.addClassName("DOCUMENT_UPLOAD");
		uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif");
		int maxfilesize=Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDoc.setMaxFileSize(maxfilesize*1000);
		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
					}
					if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
						fileFormat = "image/"+fileExtension.toLowerCase();
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					base64EncodedFileContent = "";
				}

			}
		});

		/*uploadDoc.addFailedListener(e -> {
			base64EncodedFileContent = "";
		});*/

		uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
				event.getUpload().interruptUpload();
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
			}
		});


		VerticalLayout lay = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "INFO_TAB");
		lay.add(documentTypeCombo,documentDescTextfield,docLbl,uploadDiv);


		mainLayoutDiv.add(titleBar,lay,buttonBar);

		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button/*Div*/>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button/*Div*/> event) {
				cancelBtnClicked();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button/*Div*/>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button/*Div*/> event) {
				if (validation()) {
					addDocument(assetId);
				}
			}
		});

		documentTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				if (event.getValue()!=null && event.getValue().trim().length()>0) {
					documentTypeCombo.setInvalid(false);
				}
			}
		});

		documentDescTextfield.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				if (event.getValue()!=null && event.getValue().trim().length()>0) {
					documentDescTextfield.setInvalid(false);
				}
			}
		});
	}

	private boolean validation()
	{
		documentTypeCombo.setInvalid(false);
		documentDescTextfield.setInvalid(false);

		if(documentTypeCombo.getValue() == null || documentTypeCombo.getValue().trim().length() == 0) {
			documentTypeCombo.setInvalid(true);
			documentTypeCombo.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "DOC_TYPE_MANDATORY"));
			return false;
		}

		/*if(documentDescTextfield.getValue() == null || documentDescTextfield.getValue().trim().length() == 0) {
			documentDescTextfield.setInvalid(true);
			documentDescTextfield.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "DOC_DESC_MANDATORY"));
			return false;
		}*/

		return true;	
	}

	protected void addDocument(String assetId) 
	{
		try 
		{
			if(base64EncodedFileContent==null || base64EncodedFileContent.trim().length()==0)
			{
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DOC_UPLOAD_ERROR", ApplicationConstants.DialogTypes.INFO);
				return;
			}
			String docDesc = "";
			if (documentDescTextfield.getValue()!=null) {
				docDesc=documentDescTextfield.getValue().trim();
			}
			JSONObject fileDetailsJson = new JSONObject();
			fileDetailsJson.put("Name", uploadDiv.getFileName().trim());
			fileDetailsJson.put("Type", documentTypeCombo.getValue().trim());
			fileDetailsJson.put("Description", docDesc);
			fileDetailsJson.put("Content", base64EncodedFileContent);
			Form l_objInputForm = new Form();
			l_objInputForm.add("StoreSerialNo",assetId);
			l_objInputForm.add("FileDetails", fileDetailsJson);

			String base_URL = ApplicationConfiguration.getServiceEndpoint("UPLOADASSETDOCUMENT");
			//System.out.println(base_URL+" ::::::::: "+l_objInputForm.toString());
			RestServiceHandler.createJSON_POST(base_URL, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());

			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DOC_ADDITION_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
			getDocUploadStatus = true;
			close();

		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(ex.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			getDocUploadStatus = false;

		}

	}


	//	private List<AssetDocumentUploadBean> getDocumentName(String assetId)
	//	{
	//		textFieldlist= new ArrayList<>(); 
	//		textFieldlist.add(documentTypeCombo.getValue());
	//		assetDocumentUploadDatalist.clear();
	//		for(int i=0;i<textFieldlist.size();i++)
	//		{
	//			String getTextfield=textFieldlist.get(i);
	//			allDocuments =new AssetDocumentUploadBean(getTextfield,null,assetId);
	//			assetDocumentUploadDatalist.add(allDocuments);
	//		}
	//		return assetDocumentUploadDatalist;
	//
	//	}

	protected void cancelBtnClicked()
	{
		close();	
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}


	public boolean isGetDocUploadStatus() {
		return getDocUploadStatus;
	}

	public void setGetDocUploadStatus(boolean getDocUploadStatus) {
		this.getDocUploadStatus = getDocUploadStatus;
	}

	public boolean isSaveBtnClicked() {
		return saveBtnClicked;
	}

	public void setSaveBtnClicked(boolean saveBtnClicked) {
		this.saveBtnClicked = saveBtnClicked;
	}

	public String getBase64EncodedFileContent() {
		return base64EncodedFileContent;
	}

	public void setBase64EncodedFileContent(String base64EncodedFileContent) {
		this.base64EncodedFileContent = base64EncodedFileContent;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
}
