package com.umt.siteassetinventory.assetinventory;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tabs;

@CssImport("./styles/base-structure.css")
public class BaseStructucture extends Div 
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "BASE_STRUCTURE";
	protected Div rowDiv,col1Div,col2Div; 
	protected Div col1HeaderDiv,col2HeaderDiv,col1ValueDiv,col2ValueDiv;
	protected Tabs parentTabs;

	public BaseStructucture() 
	{
		rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		col1Div = UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_DIV");
		col2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_DIV");
		
		col1HeaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_HEADER_DIV");
		col1ValueDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_VALUE_DIV");
		col2HeaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_HEADER_DIV");
		col2ValueDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_VALUE_DIV");
		
		parentTabs = new Tabs();
		parentTabs.addClassName(SCREENCD + "_PARENT_TABS");
		col2HeaderDiv.add(parentTabs);
		
		col1Div.add(col1HeaderDiv,col1ValueDiv);
		col2Div.add(col2HeaderDiv,col2ValueDiv);
		
		
		
		rowDiv.add(col1Div,col2Div);
	}

}
