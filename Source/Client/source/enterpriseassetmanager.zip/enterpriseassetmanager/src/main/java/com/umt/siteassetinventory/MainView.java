package com.umt.siteassetinventory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Base64;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants.Menu;
import com.umt.siteassetinventory.application.ApplicationHeader;
import com.umt.siteassetinventory.application.VerticalMenuBar;
//import com.umt.siteassetinventory.assetinventory.ModuleBaseLayout;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.bean.CompanyProfileBean;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.HasElement;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLayout;
import com.vaadin.flow.server.InputStreamFactory;
import com.vaadin.flow.server.PWA;
import com.vaadin.flow.server.StreamResource;

@Route
@CssImport("./styles/main_view-styles.css")
@PWA(name = "siteassetinventory", shortName = "siteassetinventory", enableInstallPrompt = false, startPath = "assets")
public class MainView extends Div implements RouterLayout, BeforeEnterObserver, AfterNavigationObserver {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "MAINVIEW";
	private BaseStructure currentModule;
	private Div headerDiv;
	private Div bodyDiv;
	private Div contentDiv;
	private Div truebyllogodiv, partnerlogodiv;
	private Div navigationdiv;
	private Label navigationlbl, userEmailLbl, userLoginTimestampLbl;
	private boolean loadScreen = false;
	private com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon toggleMenuIcon;
	public Div toggleMenuIcondiv;
	private Image truebyllogo;
	private ApplicationHeader appHeader;
	private VerticalMenuBar vertical_menu_bar;

	public MainView() {
		headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		//		truebyllogodiv=UIHtmlFieldFactory.createDiv(SCREENCD, "TRUEBYL_LOGO_DIV");
		partnerlogodiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PARTNER_LOGO_DIV");

		appHeader = new ApplicationHeader();
		vertical_menu_bar = new VerticalMenuBar();

		navigationdiv = UIHtmlFieldFactory.createDiv(SCREENCD, "NAVIGATION_DIV");
		navigationlbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NAVIGATION_DIV_LBL");
		navigationdiv.add(navigationlbl, partnerlogodiv);
		//		headerDiv.add(truebyllogodiv);

		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		contentDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTENT_DIV");
		//		contentDiv.add(navigationdiv);
		bodyDiv.add(navigationdiv, contentDiv);
		add(vertical_menu_bar);
		//		showVerticalMenuBar(false);
		add(appHeader, bodyDiv);

		SiteAssetInventoryUIFramework.getFramework().setApplicationMainView(this);

		addClassName(SCREENCD + "_MAIN_LAYOUT");
	}

	@Override
	public void beforeEnter(BeforeEnterEvent event) {
		SiteAssetInventoryUIFramework.getFramework().setCurrentPath(event.getLocation().getPath());
		if (event.getLocation().getPath().equalsIgnoreCase("configuration")) {
			appHeader.getSearchInput().setEnabled(false);
			appHeader.getSearchInput().addClassName("HEADER_SEARCH_FIELD_DISABLED");
		} else {
			appHeader.getSearchInput().setEnabled(true);
			appHeader.getSearchInput().removeClassName("HEADER_SEARCH_FIELD_DISABLED");
		}
		SiteAssetInventoryUIFramework.getFramework().setCurrentPathParam(event.getLocation().getQueryParameters());

		if (!SiteAssetInventoryUIFramework.getFramework().isUserLoggedIn()) {
			setVisible(false);
			SessionManager.handleTokenExpiry();
		} else {
			if (event.getNavigationTarget().equals(this.getClass())) {
				//event.rerouteTo("assets");
				//event.rerouteTo("siteview");
				event.rerouteTo("landlordview");		
			}
		}
	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) {
		String pageTitle = ApplicationConfiguration.getConfigurationValue("APPLICATION_TITLE");
		UI.getCurrent().getPage().setTitle(pageTitle);

		if (!loadScreen) {
			initializeScreen();
		}
	}

	private void initializeScreen() {
		loadScreen = true;
	//	getPartnerLogo();
		
	truebyllogo = UIHtmlFieldFactory.createImage(SCREENCD, "TRUEBYL_LOGO");
		try {
			truebyllogo.setSrc(ApplicationConfiguration.getConfigurationValue("LOGO_URL_SELF"));
			partnerlogodiv.removeAll();
			partnerlogodiv.add(truebyllogo);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void showVerticalMenuBar(boolean show) { if (show) {
		vertical_menu_bar.addClassName("SHOW_VERTICAL_MENU_BAR");
		vertical_menu_bar.removeClassName("COLLAPSE_MENU");
		vertical_menu_bar.addBlackOverlayClass();

	} else { vertical_menu_bar.removeClassName("SHOW_VERTICAL_MENU_BAR");
	vertical_menu_bar.addClassName("COLLAPSE_MENU");
	vertical_menu_bar.removeClaseBlackOverlay(); } }


	private void getPartnerLogo() {
		try {
			CompanyProfileBean companyProfile = new CompanyProfileBean();

			String serviceGetCompanyLogoEndPoint = ApplicationConfiguration.getServiceEndpoint("GETCOMPANYLOGO");
			serviceGetCompanyLogoEndPoint = serviceGetCompanyLogoEndPoint + "?PartitionId="
					+ SiteAssetInventoryUIFramework.getFramework().getUserInfo().getPartnerCode();

			String response = RestServiceHandler.retriveJSON_GET(serviceGetCompanyLogoEndPoint,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(serviceGetCompanyLogoEndPoint+" response:::"+response);
			if (response.length() != 0) {

				companyProfile.setLogo(response);

				byte[] imageFileContent = Base64.getDecoder().decode(companyProfile.getLogo());
				StreamResource fileStreamResource = new StreamResource("Company_Logo", new InputStreamFactory() {
					private static final long serialVersionUID = 1L;

					@Override
					public InputStream createInputStream() {

						return new ByteArrayInputStream(imageFileContent);
					}
				});

				Image partnerLogoImg = new Image(fileStreamResource, "Company_logo");

				if (CommonUtils.getClientView())
					partnerLogoImg.addClassName(SCREENCD + "_PARTNER_LOGO_IMG_MOB_VIEW");
				else
					partnerLogoImg.addClassName(SCREENCD + "_PARTNER_LOGO_IMG");
				partnerlogodiv.removeAll();
				partnerlogodiv.add(partnerLogoImg);
			}
//			Image partnerLogoImg = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
//			
//			if (CommonUtils.getClientView())
//				partnerLogoImg.addClassName(SCREENCD + "_PARTNER_LOGO_IMG_MOB_VIEW");
//			else
//				partnerLogoImg.addClassName(SCREENCD + "_PARTNER_LOGO_IMG");
//			partnerlogodiv.removeAll();
//			partnerlogodiv.add(partnerLogoImg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void showRouterLayoutContent(HasElement content) {
		contentDiv.getElement().removeAllChildren();
		contentDiv.getElement().appendChild(content.getElement());
		if(content instanceof BaseStructure) {
			currentModule = (BaseStructure)content;
			//System.out.println("Module");

		}else {
			currentModule = null;
			//System.out.println("Null");

		}

	}

	public BaseStructure getCurrentModule() {
		return currentModule;
	}

	public void showNavigationBar(String headertxt) {
		navigationdiv.setVisible(true);
		navigationlbl.setText(headertxt);
	}

	public com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon getToggleMenuIcon() {
		return toggleMenuIcon;
	}

	public Div getNavigationdiv() {
		return navigationdiv;
	}

	public void updateMenuBar(Menu selectedMenu) {
		if (vertical_menu_bar != null) {
			vertical_menu_bar.updateMenuBar(selectedMenu);
		}
	}

	public Div getMainviewHeaderdiv() {
		return headerDiv;
	}

	public Image getTruebylLogo() {
		return truebyllogo;
	}
}
