package com.umt.siteassetinventory.configuration;

import java.util.Map;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/equipment_type_vendor_association_master-styles.css")
public class EquipmentTypeVendorAssociationMasterDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENT_TYPE_VENDOR_ASSOCIATION_MASTER_DATA_BEAN";
	//private long attributeId, equipmentTypeId;
	private String attributeId, equipmentType, vendor, inputFileFormat, serviceAgent, /*warrantyPeriod, */outputFileFormat;
	private EquipmentTypeVendorAssociationMaster parent;
	private Div eachrowDiv;
	//private Button editBtn, deactivateBtn;
	private Div editDiv;
	//private boolean selected = false;


	public EquipmentTypeVendorAssociationMasterDataBean(String vendor, String equipmentType, String inputFileFormat, String outputFileFormat, String serviceAgent, 
			/*String warrantyPeriod,*/ Map<Long, String> vendorMap, Map<Long, String> activeEquipmentTypeMap, 
			Map<Long, String> passiveEquipmentTypeMap, EquipmentTypeVendorAssociationMaster equipmentTypeVendorAssociationMaster, 
			boolean vendorOrOperator) {

		this.vendor = vendor;
		this.equipmentType = equipmentType;
		this.inputFileFormat = inputFileFormat;
		this.outputFileFormat = outputFileFormat;
		this.serviceAgent = serviceAgent;
		//		this.warrantyPeriod = warrantyPeriod;
		this.parent = equipmentTypeVendorAssociationMaster;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");
		//Div eachdataDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV6");


		Label vendorVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL1");
		vendorVal.setText(vendor);
		eachdataDiv1.add(vendorVal);

		Label equipmentTypeIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL2");
		equipmentTypeIdVal.setText(equipmentType);
		eachdataDiv2.add(equipmentTypeIdVal);

		Label inputFileFormatVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL3");
		inputFileFormatVal.setText(inputFileFormat);
		eachdataDiv3.add(inputFileFormatVal);

		Label outputFileFormatVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL4");
		outputFileFormatVal.setText(outputFileFormat);
		eachdataDiv4.add(outputFileFormatVal);

		Label serviceAgentVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL5");
		serviceAgentVal.setText(serviceAgent);
		eachdataDiv5.add(serviceAgentVal);

		//		Label warrantyPeriodVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL6");
		//		warrantyPeriodVal.setText(warrantyPeriod);
		//		eachdataDiv6.add(warrantyPeriodVal);

		editDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EDIT_DIV");
		Image editIcon = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
		//Icon editIcon = VaadinIcon.PENCIL.create();
		editDiv.add(editIcon);
		//editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
		//		deactivateBtn = UIFieldFactory.createButton(SCREENCD, "DEACTIVATE_BTN");

		eachrowDiv.add(eachdataDiv1,eachdataDiv2);
		if (vendorOrOperator) {
			eachrowDiv.add(eachdataDiv3,eachdataDiv4,eachdataDiv5);
		}
		else {
			eachdataDiv1.removeClassName(SCREENCD+"_EACH_DATA_DIV1");
			eachdataDiv2.removeClassName(SCREENCD+"_EACH_DATA_DIV2");
			
			eachdataDiv1.addClassName(SCREENCD+"_EACH_DATA_DIV_2FLDS");
			eachdataDiv2.addClassName(SCREENCD+"_EACH_DATA_DIV_2FLDS");
		}
		eachrowDiv.add(editDiv);
		add(eachrowDiv);

		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//selectedRowChangeHandler();
			}
		});

		editDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> arg0) {
				editDialog(false, vendorMap, activeEquipmentTypeMap, passiveEquipmentTypeMap, vendorOrOperator);
			}
		});
	}

	private void editDialog(boolean addOrEdit, Map<Long, String> vendorMap, Map<Long, String> activeEquipmentTypeMap, Map<Long, String> passiveEquipmentTypeMap, boolean vendorOrOperator)
	{
		//System.out.println("Working");
		AddOrEditEquipmentTypeVendorAssociation editEquipmentTypeVendorAssociation = new AddOrEditEquipmentTypeVendorAssociation
				(parent, this, vendor, equipmentType, inputFileFormat, outputFileFormat, serviceAgent, /*warrantyPeriod,*/ 
						vendorMap, activeEquipmentTypeMap, passiveEquipmentTypeMap, vendorOrOperator);

	}

	//	private void selectedRowChangeHandler()
	//	{
	//		selectDeselect(selected);
	//		parent.selectedRowChangeHandler(this);
	//	}

	//	protected void selectDeselect(boolean selectedOrDeselected)
	//	{
	//		if (selectedOrDeselected) {
	//			selected = false;
	//			eachrowDiv.removeClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
	//		}
	//		else
	//		{
	//			selected = true;
	//			eachrowDiv.addClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
	//		}
	//	}

	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	public String getVendor() {
		return vendor;
	}

	public String getEquipmentType() {
		return equipmentType;
	}

	public String getInputFileFormat() {
		return inputFileFormat;
	}

	public String getOutputFileFormat() {
		return outputFileFormat;
	}

	public String getServiceAgent() {
		return serviceAgent;
	}	

	//	public String getWarrantyPeriod() {
	//		return warrantyPeriod;
	//	}


	//	public boolean isSelected() {
	//		return selected;
	//	}

}
