package com.umt.siteassetinventory.site;

import java.net.URLEncoder;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;


@CssImport("./styles/site_landlord-style.css")
public class SiteLandLordTab extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_LANDLORD_TAB";
	private String siteCode;
	private Div btnDiv, infoDiv;
	private Button addLandlordBtn;
	private SiteView siteView;
	
	public SiteLandLordTab(String siteCode,SiteView siteView) {
		this.siteCode = siteCode;
		this.siteView = siteView;
		btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		addLandlordBtn = UIFieldFactory.createButton(SCREENCD, "ADD_LANDLORD_BTN");
		
		infoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "INFO_DIV");
		if(siteCode != null) {
			populateLandLordDetails(siteCode);
		}
		
		
		
		btnDiv.add(addLandlordBtn);
		
		add(btnDiv, infoDiv);
		
		addLandlordBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				AddLandLord addLandLord = new AddLandLord(siteCode, siteView);
				
			}
		});
		
		
		
		
		
		
	}
	public void populateLandLordDetails(String siteCode){
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETSITELANDLORDDETAILS");
		base_URL = base_URL + "?SiteCode=" + URLEncoder.encode(siteCode);
		
		try {
			String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("siteLandlord: " + outputResponse);
			JSONArray jsonArray = new JSONArray(outputResponse);
			
			for(int i = 0; i<jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				SiteLandLordBean bean = new SiteLandLordBean(
						jsonObject.getString("SiteCode"),
						jsonObject.getString("LandlordId"),
						jsonObject.getString("LandlordName"),
						jsonObject.getString("Address"),
						jsonObject.getString("Email"),
						jsonObject.getString("Status"),
						jsonObject.getString("ContactNo"),
						jsonObject.getString("PayoutAmount"),
						/*jsonObject.getString("PayoutFrequency"),*/
						siteView
						);
				infoDiv.add(bean);
				//System.out.println(jsonObject);
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
