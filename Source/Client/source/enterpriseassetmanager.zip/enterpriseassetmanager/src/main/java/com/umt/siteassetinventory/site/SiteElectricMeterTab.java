package com.umt.siteassetinventory.site;

import java.net.URLEncoder;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/electric-meter-tab-styles.css")
public class SiteElectricMeterTab extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ELECTRIC_METER_TAB";
	private String siteCode;
	private Div containerDiv;

	public SiteElectricMeterTab(String siteCode) {
		this.siteCode=siteCode;
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		Button addMeterButton = UIFieldFactory.createButton(SCREENCD, "ADD_METERS_BTN");
		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");	
		filterDiv.add(addMeterButton);
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		
		add(filterDiv,containerDiv);
		loadElectricMeters();
		
		if(siteCode==null || siteCode.length()<=0) {
			addMeterButton.setEnabled(false);
		}
		
		addMeterButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				openAddElectricDialog();
			}
		});
	}

	protected void openAddElectricDialog() {
		AddElectricMetersDialog dlg =new AddElectricMetersDialog(this);
		
	}

	private void loadElectricMeters() {
		containerDiv.removeAll();
		try {
			JSONArray allAssetsJA;
			JSONArray assetsJA = new JSONArray();
			String equipments = "";

			String equipmentId = "-1";
			 
			
			equipments = getEquipments("-1", equipmentId);
			
			allAssetsJA = new JSONArray(equipments);
			for (int i = 0; i < allAssetsJA.length(); i++) {
				JSONObject allAssetJson = allAssetsJA.getJSONObject(i);
				if (allAssetJson.getInt("ServiceType") == 0) {
					assetsJA.put(allAssetJson);
				}
			}

			/*if (assetsJA.length() == 0) {
				if (activeOrPassive) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "ACTIVE_NO_RECORD",
							ApplicationConstants.DialogTypes.INFO);
				} else {
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "PASSIVE_NO_RECORD",
							ApplicationConstants.DialogTypes.INFO);
				}
			}*/
			
			for (int i = 0; i < assetsJA.length(); i++) {
				JSONObject assetJson = assetsJA.getJSONObject(i);
				
				JSONObject otherInfo=getEquipmentAttributes(assetJson.getString("StoreSerialNo"));
				SiteElectricMeterTabBean bean = new SiteElectricMeterTabBean(assetJson.getString("StoreSerialNo"),
						assetJson.getString("EquipmentType"), assetJson.getString("Description"),
						assetJson.getString("EquipmentSerialNo"), assetJson.getString("CreationDate"),
						assetJson.getString("VendorName"), assetJson.getString("StatusCode"), this,otherInfo);
				
				/*SiteElectricMeterTabBean bean = new SiteElectricMeterTabBean(assetJson.getString("StoreSerialNo"),
						assetJson.getString("MeterCategory"), assetJson.getString("Description"),
						assetJson.getString("EquipmentSerialNo"), assetJson.getString("CreationDate"),
						assetJson.getString("SEBMeterAuthority"), assetJson.getString("StatusCode"),this,
						assetJson.getString("SEBMeterInstallationDate"),assetJson.getString("ConsumerNo"));*/
				containerDiv.add(bean);
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private JSONObject getEquipmentAttributes(String storeserialno) {
		try {
			
			JSONObject js = new JSONObject();
			JSONObject otherinfo=null;
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTSATTRIBUTES");
			url = url + "?StoreSerialNo=" + storeserialno;
			String resp = RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			if(resp!=null || !resp.equals("null") || !resp.equals("{}")) {
				js=new JSONObject(resp);
				if(js!=null && js.length()>0) {
					otherinfo = new JSONObject(js.getString("OtherInfo"));
				}
			}else {
				otherinfo=new JSONObject();
			}
				
		//	System.out.println(otherinfo);
			return otherinfo;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}	
	}

	private String getEquipments(String tenancyId, String equipmentTypeId)
	{
		try {
			String response1="";
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url = url + "?StoreSerialNo=-1&StoreId=9996&StatusId=-1&VendorId=" + tenancyId + "&EquipmentTypeId=" 
					+ equipmentTypeId + "&StoreLocId=" + URLEncoder.encode(siteCode) + "&EquipmentSerialNo=-1";
			
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			System.out.println("url ::::::: "+url);
			System.out.println("response ::::::: "+response);
			
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}


	public void setSiteCode(String selectedsiteCode) {
		this.siteCode = selectedsiteCode;
		
	}

	public String getSiteCode() {
		// TODO Auto-generated method stub
		return this.siteCode;
	}

	public void refreshData() {
		loadElectricMeters();
		
	}

}
