package com.umt.siteassetinventory.assetinventory;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/asset-operations-dialog.css")
public class AssetOperationsDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "ASSET_OPERATIONS_DIALOG";
	
	protected Div containerBody;
	protected Div header;
	protected Div buttons_div;
	protected Div mainLayout;
	protected Button saveBtn;
	protected Button closeBtn;
	protected Label headerTitle;
	
	public AssetOperationsDialog(String screenName, LinkedHashMap<String, String> dataMap) {
		header = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		headerTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_TITLE");
		headerTitle.setText(screenName);
		
		header.add(headerTitle);
		
		containerBody = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_BODY");
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");	
		buttons_div = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR_DIV");
		
		mainLayout.add(header, containerBody, buttons_div);
		
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		closeBtn = UIFieldFactory.createButton(SCREENCD, "CLOSE_BTN");
		
		saveBtn.setText("Save");
		closeBtn.setText("Close");
		
		buttons_div.add(saveBtn, closeBtn);
		
		Iterator<Entry<String, String>> iterator = dataMap.entrySet().iterator();
		int i = 0;
		Div rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		while(iterator.hasNext()) {
			Entry<String, String> eachEntry = iterator.next();
			if(i == 0 || i%2 == 0) {
				rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				containerBody.add(rowDiv);
			}
			
			TextField fld = UIFieldFactory.createTextField(eachEntry.getValue(), false, SCREENCD, "INPUT_FIELD");
			fld.setLabel(eachEntry.getKey());
			rowDiv.add(fld);
			i++;
		}
		
		closeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		
		add(mainLayout);
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		open();
	}

}
