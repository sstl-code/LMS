package com.umt.siteassetinventory.login;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.utility.CommonUtils;

@WebServlet("/authreq/*")
public class AuthRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String authURL = "";
		
		String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
		if(truebyl_domain != null && truebyl_domain.trim().length() > 0) {
			String validateURL = ApplicationConfiguration.getConfigurationValue("AUTHVALIDATE");
			authURL = truebyl_domain + validateURL.substring(1);
		} else {
			authURL = ApplicationConfiguration.getServiceEndpoint("AUTHVALIDATE");
		}
			
		String baseURL = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort()
				+ req.getContextPath();
		String targetURL = baseURL + "/authresp";
		targetURL = CommonUtils.getEncodedText(targetURL);
		String baseURL2 = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort();
		String signupURL = baseURL2 + ApplicationConfiguration.getConfigurationValue("SIGNUP_URL");
		signupURL = CommonUtils.getEncodedText(signupURL);
		authURL = authURL + "?wildcard=true&target=" + targetURL;
		if (ApplicationConfiguration.getConfigurationValue("SIGNUP_ENABLED").trim().equalsIgnoreCase("1")) {
			authURL = authURL+ "&signup=" + signupURL;
		} 
		OutputStream outputStream = null;
		try {
			resp.sendRedirect(authURL);
		} catch (Exception ex) {
			ex.getMessage();
		} 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
