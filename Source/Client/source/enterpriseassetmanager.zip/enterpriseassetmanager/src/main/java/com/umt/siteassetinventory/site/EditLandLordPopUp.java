package com.umt.siteassetinventory.site;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;

public class EditLandLordPopUp extends BaseDialogPopup {

	private static final long serialVersionUID = 1L;
	private EditLandlordDetails parent;
	private String siteCode, id;
	private SiteView siteView;

	public EditLandLordPopUp(String title, Component component, String sitecd, String id, SiteView siteView) {
		super(title, component);
		setWidth("500px");
		this.parent = (EditLandlordDetails) component;
		this.id = id;
		this.siteCode = sitecd;
		this.siteView = siteView;
		
		
		
	}

	@Override
	public void saveOperartion() {
		
		
		if(parent.getPayoutShare()==null) {
			parent.getPayoutField().setInvalid(true);
			parent.getPayoutField().setErrorMessage("Please fill up this field");
			return;
			
		}else {
			
			save_btn.setEnabled(false);
			parent.getPayoutField().setInvalid(false);
			String base_URL=ApplicationConfiguration.getServiceEndpoint("EDITLANDLORDTOSITE");
			
			Form formData = new Form();
			formData.add("SiteCode",siteCode);
			formData.add("LandlordId",id);
			
		//	formData.add("PayOutAmount",parent.getAmt());
			formData.add("PayOutAmount",parent.getPayoutShare());
			
	//		System.out.println("parent.getPayoutShare()=="+parent.getPayoutShare());
			
			//System.out.println(siteCode + " " + id + " " + parent.getFreqCode() + " " +  parent.getAmt());
			
			try {
				String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
				
				//System.out.println("res: " + response);
				siteView.addlandlordTab(siteCode);
				SiteAssetInventoryUIFramework.getFramework().showMessage("Successfully Edited.", ApplicationConstants.DialogTypes.INFO);
				closeDialog();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
				if(e.getMessage() != null) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
				}else {
					
				}
				e.printStackTrace();
			//	save_btn.setEnabled(true);
			}
			finally {
				save_btn.setEnabled(true);
			}
			
		}
		
		
	}

}
