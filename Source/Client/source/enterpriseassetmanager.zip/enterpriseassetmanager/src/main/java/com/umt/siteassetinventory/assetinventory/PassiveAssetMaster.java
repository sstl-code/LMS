package com.umt.siteassetinventory.assetinventory;

import java.util.ArrayList;
import java.util.List;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class PassiveAssetMaster extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "PASSIVE_ASSET_MASTER";
	private Div assetTypeSelectionDiv;
	private Div assetContainerDiv;
	private ComboBox<String> assetTypeCmb;
	private Label assetTypeLbl;
	private AssetTabularViewComponent assetTabularViewComponent;
	
	public PassiveAssetMaster() {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		List<String> assetTypeList = new ArrayList<String>();
		assetTypeList.add("Air Conditioner");
		assetTypeList.add("Battery");
		assetTypeList.add("Diesel Generator");
		assetTypeList.add("Grid");
		assetTypeList.add("Solar");
		assetTypeList.add("Rectifier");
		assetTypeCmb = UIFieldFactory.createComboBox(assetTypeList, true, SCREENCD, "ASSET_TYPE_CMB");
		assetTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_LBL");
		assetTypeSelectionDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ASSET_TYPE_SELECTION_DIV");
		assetTypeSelectionDiv.add(assetTypeLbl, assetTypeCmb);
		assetContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ASSET_CONTAINER_DIV");
		add(assetTypeSelectionDiv, assetContainerDiv);
		
		assetTypeCmb.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				onAssetTypeChange(event.getValue());
			}
		});
	}
	
	private void onAssetTypeChange(String assetType) {
		assetContainerDiv.removeAll();
		assetTabularViewComponent = null;
		if(assetType == null || assetType.trim().length() == 0) {
			return;
		}
		
		String fileName = "";
		
		if(assetType.trim().equalsIgnoreCase("Air Conditioner")) {
			assetTabularViewComponent = new AssetTabularViewComponent("AC_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("AC_PARENT_ASSET_CSV");
		} else if(assetType.trim().equalsIgnoreCase("Battery")) {
			assetTabularViewComponent = new AssetTabularViewComponent("BATTERY_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("BATTERY_PARENT_ASSET_CSV");
		} else if(assetType.trim().equalsIgnoreCase("Diesel Generator")) {
			assetTabularViewComponent = new AssetTabularViewComponent("DG_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("DG_PARENT_ASSET_CSV");
		} else if(assetType.trim().equalsIgnoreCase("Grid")) {
			assetTabularViewComponent = new AssetTabularViewComponent("GRID_POWER_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("GRID_POWER_PARENT_ASSET_CSV");
		} else if(assetType.trim().equalsIgnoreCase("Solar")) {
			assetTabularViewComponent = new AssetTabularViewComponent("SOLAR_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("SOLAR_PARENT_ASSET_CSV");
		} else if(assetType.trim().equalsIgnoreCase("Rectifier")) {
			assetTabularViewComponent = new AssetTabularViewComponent("RECTFIER_PARENT_ASSET", true, true, false, false, false);
			fileName = ApplicationConfiguration.getConfigurationValue("RECTIFIER_PARENT_ASSET_CSV");
		}		
		
		if(assetTabularViewComponent != null) {
			assetContainerDiv.add(assetTabularViewComponent);
			assetTabularViewComponent.loadData(fileName, "");
		}
	}
}
