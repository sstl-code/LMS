package com.umt.siteassetinventory.assetinventory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

@CssImport("./styles/doc_tab-styles.css")
public class DocumentsTab extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "DOCUMENTS_TAB";
	private Button addBtn;
	private VerticalLayout docContainerVL;
	private SiteMaster siteMaster;
	private SiteMaster parent;
	private DocumentsTab doctabobj;

	public DocumentsTab(SiteMaster siteMaster) {

		doctabobj=this;
		this.siteMaster = siteMaster;
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		Div docHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DOC_HEADER_DIV");
		Label headerLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
		Label headerLbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL2");

		Div headerDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV1");
		Div headerDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV2");
		Div headerDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV3");
		headerDiv1.add(headerLbl1);
		headerDiv2.add(headerLbl2);
		docHeaderDiv.add(headerDiv1, headerDiv2, headerDiv3);

		Div btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ADD_BTN_DIV");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");
		btnDiv.add(addBtn);

		docContainerVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DOC_CONTAINER_VL");

		add(btnDiv, docHeaderDiv, docContainerVL);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				createDocumentRow(siteMaster);
			}
		});

		// populateDocumentsRow(parent);
	}

	protected void createDocumentRow(SiteMaster siteMaster2) {
		AddDocumentDialog dlg = new AddDocumentDialog(doctabobj,siteMaster2);

		dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
				AddDocumentDialog srcDlg = (AddDocumentDialog) event.getSource();
				if (!srcDlg.isOpened() && (srcDlg.isGetDocUploadStatus() == true)) {

					Timestamp timestamp = new Timestamp(System.currentTimeMillis());
					String filename = srcDlg.getFileName();
					String fileconent = srcDlg.getFileContent();
					String sitecode = siteMaster2.getSelectedSiteCode();
					createAssetDocFolder(siteMaster2, filename, fileconent, (String.valueOf(timestamp.getTime())));

					populateDocumentsRow(siteMaster2, sitecode);

				}
			}

		});

	}

	protected void createAssetDocFolder(SiteMaster siteMaster2, String filename, String filecontent, String timestamp) {
		try {
			String SiteCode = siteMaster2.getSelectedSiteCode();
			if (SiteCode != null || SiteCode.trim().length() > 0) {

				String homeDirectory = System.getProperty("user.home");
				String assetDataFile = homeDirectory + File.separator + "AssetDocuments" + File.separator + SiteCode;
				// String assetDataFile2 = homeDirectory + File.separator + "AssetDocuments" +
				// File.separator + SiteCode+ File.separator + timestamp+ "_" + filename;

				File file = new File(assetDataFile);// <user.home>\AssetDocuments\SiteCode

				if (file.exists() && filename.trim().length() > 0) {
					// System.out.println("File Exists");
					String assetDataFile2 = homeDirectory + File.separator + "AssetDocuments" + File.separator
							+ SiteCode + File.separator + timestamp + "-" + filename;
					file = new File(assetDataFile2);// <user.home>\AssetDocuments\SiteCode\timestamp_filename
					file.createNewFile();

					writetoFiles(file.getName(), filecontent, assetDataFile2);
				}
				if (!file.exists() && filename.trim().length() > 0) {
					file.mkdirs();

					String assetDataFile2 = homeDirectory + File.separator + "AssetDocuments" + File.separator
							+ SiteCode + File.separator + timestamp + "-" + filename;
					file = new File(assetDataFile2);// <user.home>\AssetDocuments\SiteCode\timestamp_filename
					file.createNewFile();

					// System.out.println("File created: " + file.getName());
					// System.out.println("Absolute path: " + file.getAbsolutePath());
					writetoFiles(file.getName(), filecontent, assetDataFile2);

				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void writetoFiles(String filename, String filecontent, String assetDataFile2) {
		try {

			byte[] pdfFileContent = Base64.getDecoder().decode(filecontent);
			OutputStream stream = new FileOutputStream(assetDataFile2);
			stream.write(pdfFileContent);
			stream.close();
			// System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			// System.out.println("An error occurred.");
			e.printStackTrace();
		}

	}

	public void populateDocumentsRow(SiteMaster siteMaster2, String sitecode) {
		try {

			if (sitecode != null || sitecode.trim().length() > 0) {
				docContainerVL.removeAll();// if sitecode!=null
				String homeDirectory = System.getProperty("user.home");
				String assetDataFile = homeDirectory + File.separator + "AssetDocuments" + File.separator + sitecode;
				File file = new File(assetDataFile);
				File[] fileLists = file.listFiles();
				List<String> list1 = new ArrayList<>();
				list1.clear();
				if (fileLists != null) {
					for (int i = 0; i < fileLists.length; i++) {

						list1.add(fileLists[i].getName());
					}
				}
				if (list1.size() > 0) {
					for (int i = 0; i < list1.size(); i++) {
						String s = list1.get(i);
						try {
							int index = s.indexOf("-");
							String timestamp = s.substring(0, index);
							String filename = s.substring(index + 1);

							DocumentsTabBean beanobj = new DocumentsTabBean(sitecode, filename, timestamp);
							docContainerVL.add(beanobj.createdocumentRow());
						} catch (Exception e) {
							e.printStackTrace();
						}

					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setParent(SiteMaster parent) {
		this.parent = parent;

	}

	public Boolean validateForDuplicateFiles(String fileName, SiteMaster siteMaster2) 
	{
		Boolean flag=false;
		String sitecode=siteMaster2.getSelectedSiteCode();
		String homeDirectory = System.getProperty("user.home");
		String assetDataFile = homeDirectory + File.separator + "AssetDocuments" + File.separator + sitecode;
		File file = new File(assetDataFile);
		File[] fileLists = file.listFiles();
		List<String> list1 = new ArrayList<>();
		list1.clear();
		if (fileLists != null) {
			for (int i = 0; i < fileLists.length; i++) {

				list1.add(fileLists[i].getName());
			}
		}
		if (list1.size() > 0) 
		{
			for (int i = 0; i < list1.size(); i++) 
			{
				String s = list1.get(i);
				try 
				{
					int index = s.indexOf("-");
					String filename = s.substring(index + 1);
					if(fileName.equalsIgnoreCase(filename))
					{
						flag=true;
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		}
		return flag;
		
	}

}
