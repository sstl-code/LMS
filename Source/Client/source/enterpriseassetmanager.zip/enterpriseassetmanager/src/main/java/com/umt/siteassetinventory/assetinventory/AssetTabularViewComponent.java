package com.umt.siteassetinventory.assetinventory;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UploadDialog;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.ColumnTextAlign;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.function.ValueProvider;

public class AssetTabularViewComponent extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_TABULAR_VIEW_COMPONENT";
	private Div headerDiv;
	private TextField searchTextFld;
	private Div gridComponentDiv;
	private Grid<GridDynamicRow> grid;
	private GridDynamicRow selectedItem;
	private List<String> columnHeaders;
	private Div buttonBarDiv;
	private SiteMaster parent;
	private boolean allowEdit;
	private boolean allowAddition;
	private boolean allowExport;
	private boolean allowImport;
	private Button additionBtn;
	private Button editBtn;
	private Button exportBtn;
	private Button importBtn;
	private boolean displayAsList;
	private String selectedSiteCode;
	private HashMap<Div, String> dataRowMap = new HashMap<Div, String>();
	private ListDataProvider<GridDynamicRow> dataProvider = new ListDataProvider<GridDynamicRow>(
			new ArrayList<GridDynamicRow>());
	private List<Div> listViewRowReferences = new ArrayList<Div>();
	private List<GridDynamicRow> assetData = new ArrayList<GridDynamicRow>();

	public AssetTabularViewComponent(String screenName, boolean allowAddition, boolean allowEdit, boolean allowExport,
			boolean displayAsList, boolean allowImport) {
		headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		buttonBarDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR_DIV");
		searchTextFld = UIFieldFactory.createTextField("", false, SCREENCD, "SEARCH_TXT_FLD");
		gridComponentDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "GRID_COMPONENT_DIV");
		headerDiv.add(searchTextFld, buttonBarDiv);
		add(headerDiv, gridComponentDiv);
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		addClassName(screenName.toUpperCase() + "_MAIN_LAYOUT");

		this.allowAddition = allowAddition;
		this.allowEdit = allowEdit;
		this.allowExport = allowExport;
		this.allowImport = allowImport;
		this.displayAsList = displayAsList;

		if (allowAddition) {
			additionBtn = UIFieldFactory.createButton(SCREENCD, "ADD_NEW_BTN");
			additionBtn.setText("Add New");
			// buttonBarDiv.add(additionBtn);

			additionBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					addNew();
				}
			});
		}

		if (allowEdit) {
			editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
			editBtn.setText("Edit");
			buttonBarDiv.add(editBtn);

			editBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					edit();
				}
			});
		}

		if (allowExport) {
			exportBtn = UIFieldFactory.createButton(SCREENCD, "EXPORT_BTN");
			exportBtn.setText("Export");
			buttonBarDiv.add(exportBtn);
		}

		if (allowImport) {
			importBtn = UIFieldFactory.createButton(SCREENCD, "IMPORT_BTN");
			importBtn.setText("Import");
			buttonBarDiv.add(importBtn);

			importBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					upload();
				}
			});
		}

		searchTextFld.setValueChangeMode(ValueChangeMode.EAGER);
		searchTextFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				if (displayAsList) {
					filterList(event.getValue());
				} else {
					if (dataProvider != null) {
						dataProvider.refreshAll();
					}
				}
			}
		});
	}

	private void upload() {
		UploadDialog uploadDlg = new UploadDialog("Sites");
		uploadDlg.open();
	}

	private void filterList(String searchText) {

		for (int i = 0; i < assetData.size(); i++) {
			listViewRowReferences.get(i).setVisible(true);
			if (searchText == null || searchText.trim().length() == 0) {
				continue;
			}

			if (columnHeaders == null || columnHeaders.size() == 0) {
				continue;
			}

			GridDynamicRow t = assetData.get(i);
			boolean rowVisibility = false;
			for (int j = 0; j < columnHeaders.size() && j < 4; j++) {
				String cellValue = "";
				if (t.getValue(j) != null) {
					cellValue = t.getValue(j).toString();
				}

				if (cellValue.toLowerCase().contains(searchText.toLowerCase())) {
					rowVisibility = true;
					break;
				}
			}
			listViewRowReferences.get(i).setVisible(rowVisibility);

		}

	}

	public AssetTabularViewComponent(String screenName, SiteMaster parent, boolean allowAddition, boolean allowEdit,
			boolean allowExport, boolean displayAsList, boolean allowImport) {
		this(screenName, allowAddition, allowEdit, allowExport, displayAsList, allowImport);
		this.parent = parent;
	}

	private void addNew() {
		if (columnHeaders.size() <= 0) {
			return;
		}

		LinkedHashMap<String, String> dataMap = new LinkedHashMap<String, String>();
		for (int i = 0; i < columnHeaders.size(); i++) {
			dataMap.put(columnHeaders.get(i), "");
		}

		new AssetOperationsDialog("Add New", dataMap);
	}

	private void edit() {
		if (columnHeaders.size() <= 0) {
			return;
		}

		LinkedHashMap<String, String> dataMap = new LinkedHashMap<String, String>();
		for (int i = 0; i < columnHeaders.size(); i++) {
			if (selectedItem != null) {
				dataMap.put(columnHeaders.get(i), (String) selectedItem.getValue(i));
			} else {
				dataMap.put(columnHeaders.get(i), "");
			}
		}

		new AssetOperationsDialog("Edit", dataMap);
	}

	private void populateInList(List<String> columnHeaders, List<GridDynamicRow> gridData) {
		this.columnHeaders = columnHeaders;
		this.assetData = gridData;
		listViewRowReferences.clear();
		gridComponentDiv.removeAll();
		dataRowMap.clear();

		Div listHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "LIST_HEADER_DIV");

		for (int i = 0; i < columnHeaders.size() && i < 4; i++) {
			Div headerLblDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_LBL_DIV_" + (i + 1));
			Label headerLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL");
			headerLblDiv.add(headerLbl);
			headerLbl.setText(columnHeaders.get(i));
			listHeaderDiv.add(headerLblDiv);
		}

		gridComponentDiv.add(listHeaderDiv);
		Div defaultDiv = null;
		for (int i = 0; i < gridData.size(); i++) {
			if (i == 0) {
				selectedItem = gridData.get(i);
			}

			Div dataRow = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_ROW");
			listViewRowReferences.add(dataRow);
			GridDynamicRow eachRowData = gridData.get(i);
			for (int j = 0; j < columnHeaders.size() && j < 4; j++) {
				Div dataCellDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_CELL_DIV_" + (j + 1));
				Label dataCellLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATA_CELL_LBL");
				dataCellDiv.add(dataCellLbl);
				dataCellLbl.setText((String) eachRowData.getValue(j));
				dataRow.add(dataCellDiv);

				if (j == 0) {
					dataRowMap.put(dataRow, (String) eachRowData.getValue(j));
					if (defaultDiv == null) {
						defaultDiv = dataRow;
					}

					if (i == 0) {
						selectedSiteCode = (String) eachRowData.getValue(j);
					}
				}
			}

			dataRow.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					listSelectionChangeHandler(event.getSource());
				}
			});

			if (defaultDiv != null) {
				listSelectionChangeHandler(defaultDiv);
			}
			gridComponentDiv.add(dataRow);
		}
	}

	private void listSelectionChangeHandler(Div selectedDiv) {
		selectedSiteCode = dataRowMap.get(selectedDiv);

		Iterator<Div> iterator = dataRowMap.keySet().iterator();
		while (iterator.hasNext()) {
			Div eachDiv = iterator.next();
			if (!eachDiv.equals(selectedDiv)) {
				eachDiv.removeClassName("ASSET_TABULAR_VIEW_COMPONENT_DATA_ROW_SELECTED");
			}
		}

		selectedDiv.addClassName("ASSET_TABULAR_VIEW_COMPONENT_DATA_ROW_SELECTED");

		if (parent != null) {
			parent.siteSelectionChangeHandler();
		}
	}
	
	public void setSelectedSite(String siteCode) {
		if(dataRowMap == null || dataRowMap.isEmpty()) {
			return;
		}
		
		try {
		Iterator<Entry<Div, String>> iterator = dataRowMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<Div, String> eachEntry = iterator.next();
			
			if(eachEntry.getValue().trim().equalsIgnoreCase(siteCode)) {
				listSelectionChangeHandler(eachEntry.getKey());
			}
		}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public String getSelectedSiteCode() {
		return selectedSiteCode;
	}

	private void populateInGrid(List<String> columnHeaders, List<GridDynamicRow> gridData) {
		this.columnHeaders = columnHeaders;
		grid = new Grid<>(GridDynamicRow.class);

		int eachColumnWidth = 10;
		if (columnHeaders.size() > 0) {
			eachColumnWidth = 100 / columnHeaders.size();
		}

		for (int i = 0; i < columnHeaders.size(); i++) {
			grid.addColumn(new GridDynamicValueProvider(i)).setHeader(columnHeaders.get(i)).setResizable(true)
					.setSortable(true).setTextAlign(ColumnTextAlign.CENTER).setWidth("15%");

		}

		if (gridData.size() > 0) {
			selectedItem = gridData.get(0);
		}

		dataProvider = new ListDataProvider<GridDynamicRow>(gridData);
		dataProvider.addFilter(new SerializablePredicate<AssetTabularViewComponent.GridDynamicRow>() {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean test(GridDynamicRow t) {
				String searchText = searchTextFld.getValue();

				if (searchText == null || searchText.trim().length() == 0) {
					return true;
				}

				if (columnHeaders == null || columnHeaders.size() == 0) {
					return true;
				}

				for (int i = 0; i < columnHeaders.size(); i++) {
					String cellValue = "";
					if (t.getValue(i) != null) {
						cellValue = t.getValue(i).toString();
					}

					if (cellValue.toLowerCase().contains(searchText.toLowerCase())) {
						return true;
					}
				}

				return false;
			}
		});
		grid.setDataProvider(dataProvider);
		gridComponentDiv.removeAll();
		gridComponentDiv.add(grid);
		grid.addThemeName("CELL_WHITESPACE_NOWRAP_THEME");
	}

	public void populateComponent(List<String> columnHeaders, List<GridDynamicRow> gridData) {
		if (displayAsList) {
			populateInList(columnHeaders, gridData);
		} else {
			populateInGrid(columnHeaders, gridData);
		}

	}

	public void setGridHeight(String height) {
		grid.setHeight(height);
	}

	public void loadData(String fileName, String siteCode) {
		//System.out.println("Selected Site Code -> " + siteCode);
		String homeDirectory = System.getProperty("user.home");
		String assetDataFile = homeDirectory + File.separator + "AssetInventory" + File.separator + fileName;
		List<String> csvHeader = new ArrayList<String>();
		List<GridDynamicRow> csvRowWiseData = new ArrayList<GridDynamicRow>();
		try {
			CSVParser csvParser = new CSVParser(new FileReader(assetDataFile), CSVFormat.DEFAULT);
			String currentLine = null;
			boolean lookUpHeader = true;
			Iterator<CSVRecord> iterator = csvParser.iterator();
			while (iterator.hasNext()) {
				CSVRecord eachRecord = iterator.next();

				if (eachRecord == null || eachRecord.size() <= 0) {
					continue;
				}

				if (lookUpHeader) {
					for (int i = 0; i < eachRecord.size(); i++) {
						csvHeader.add(eachRecord.get(i));
					}
					lookUpHeader = false;
				} else {
					GridDynamicRow row = new GridDynamicRow();
					boolean validRecord = true;
					for (int i = 0; i < eachRecord.size(); i++) {
						if (siteCode != null && siteCode.trim().length() > 0) {
							if (i == 0) {
								if (!siteCode.equals(eachRecord.get(i))) {
									validRecord = false;
									break;
								}
							}
						}

						if (validRecord) {
							row.addValue(eachRecord.get(i));
						}
						// row.addValue(eachRecord.get(i));
					}
					if (validRecord) {
						csvRowWiseData.add(row);
					}
				}
			}

			if (csvHeader.size() > 0) {
				populateComponent(csvHeader, csvRowWiseData);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public class GridDynamicRow {

		private List<Object> values = new ArrayList<>();

		public void addValue(String value) {
			values.add(value);
		}

		public Object getValue(int columnIndex) {
			return values.get(columnIndex);
		}
	}

	public class GridDynamicValueProvider implements ValueProvider<GridDynamicRow, Object> {
		private static final long serialVersionUID = 1L;
		private int columnIndex;

		public GridDynamicValueProvider(int columnIndex) {
			this.columnIndex = columnIndex;
		}

		@Override
		public Object apply(GridDynamicRow dynamicRow) {
			return dynamicRow.getValue(columnIndex);
		}
	}
}
