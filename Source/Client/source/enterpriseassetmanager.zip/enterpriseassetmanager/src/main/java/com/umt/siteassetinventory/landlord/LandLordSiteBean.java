package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.server.VaadinServletRequest;

public class LandLordSiteBean extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_SITE_TAB_BEAN";
	private Button viewBtn;
	private Label siteCodeLbl, siteNameLbl, addressLbl;
	private Label siteCodeVal, siteNameVal, addressVal;
	private String siteCode;
	
	public LandLordSiteBean(String siteCode,String siteName, String siteAddress ) {
		addClassName(SCREENCD +"_MAIN_LAYOUT");
		this.siteCode = siteCode;
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div idDiv =  UIHtmlFieldFactory.createDiv(SCREENCD, "ID_DIV");
		siteCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_CODE_LBL");
		siteCodeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_CODE_V_LBL");
		siteCodeVal.setText(siteCode);
		idDiv.add(siteCodeLbl, siteCodeVal);
		
		Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		viewBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
		buttonDiv.add(viewBtn);
		headerDiv.add(idDiv, buttonDiv);
		
		Div bodyInfoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_INFO_DIV");
		Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_NAME_LBL");
		addressLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_ADDRESS_LBL");
		
		siteNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_NAME_V_LBL");
		addressVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_ADDRESS_V_LBL");
		
		siteNameVal.setText(siteName);
		addressVal.setText(siteAddress);
		
		row_1.add(siteNameLbl, siteNameVal);
		row_2.add(addressLbl, addressVal);
		
		bodyInfoDiv.add(row_1,row_2);
		
		add(headerDiv, bodyInfoDiv);
		
		viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
			/*	String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() + "/"
						+ "siteassetinventory/landlordview?LandlordId="+id;*/
				String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() 
						+VaadinServletRequest.getCurrent().getContextPath()
						+ "/siteview?siteCode="+siteCode;
				UI.getCurrent().getPage().open(url);
				
			}
		});
	}
}