package com.umt.siteassetinventory.framework.bean;

import java.io.Serializable;

public class CompanyProfileBean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String companyName = "";
	
	private String companyAddress = "";
	
	private String contactPerson = "";
	
	private String contactNo = "";
	
	private String country = "";
	
	private String currency = "";
	
	private String timeZone = "";
	
	private String logo = "";
	
	private String partnerEmail = "";
	
	private String tenantId = "";
	
	private String clientId = "";
	
	private String clientSecret = "";
	
	private boolean azureAuthenticationEnabled = false;
	
	public String getPartnerEmail() {
		return partnerEmail;
	}

	public void setPartnerEmail(String partnerEmail) {
		this.partnerEmail = partnerEmail;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}
	
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public boolean isAzureAuthenticationEnabled() {
		return azureAuthenticationEnabled;
	}

	public void setAzureAuthenticationEnabled(boolean azureAuthenticationEnabled) {
		this.azureAuthenticationEnabled = azureAuthenticationEnabled;
	}
}
