package com.umt.siteassetinventory.application;

import java.util.Iterator;
import java.util.stream.Stream;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConstants.Menu;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.server.VaadinServletRequest;

@CssImport("./styles/vertical_menu_bar-styles.css")
public class VerticalMenuBar extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "VERTICAL_MENU_BAR";
	private Div menuHeader, loginDetailsDiv, blackOverlay;
	private Image companyLogo;
	private Label userEmailLbl, userLoginTimestampLbl;
	private MenuItems menuHome, menuSiteView, menuAssetView, menuLandlordView, menuConfiguration, menuUserManagement,
	menuAuditTrail, menuReport, menuDefault, menuLogout,menuGalaxyView,menuInvoiceManagement,myTasks,changePw;
	private Div menuList;
	private Image homeIcon, siteViewIcon, assetsIcon, landLordIcon, configurationIcon, userManagementIcon, auditTrailIcon, reportIcon, 
	defaultIcon, logoutIcon,invoiceIcon,myTasksIcon,changePwIcon;
	private Image homeIconActive, siteViewIconActive, landLordIconActive, assetsIconActive, configurationIconActive, userManagementIconActive, 
	auditTrailIconActive, reportIconActive, defaultIconActive,invoiceIconActive,myTasksIconActive,changePwIconActive;

	public VerticalMenuBar() {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		loginDetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "LOGIN_DETAILS_DIV");
		userEmailLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LOGGED_IN_USER_EMAIL_LBL");
		blackOverlay = UIHtmlFieldFactory.createDiv(SCREENCD, "BLACK_OVERLAY_DIV");
		userLoginTimestampLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "USER_LOGIN_TIMESTAMP_LBL");
		loginDetailsDiv.add(userEmailLbl, userLoginTimestampLbl);
		menuHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "MENU_HEADER_DIV");
		companyLogo = UIHtmlFieldFactory.createImage(SCREENCD, "TRUEBYL_LOGO");
		try {
			companyLogo.setSrc(ApplicationConfiguration.getConfigurationValue("LOGO_URL"));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		menuList = UIHtmlFieldFactory.createDiv(SCREENCD, "MENU_LIST_DIV");

		homeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "HOME_ICON");
		siteViewIcon = UIHtmlFieldFactory.createImage(SCREENCD, "SITEVIEW_ICON");
		assetsIcon = UIHtmlFieldFactory.createImage(SCREENCD, "ASSETS_ICON");
		landLordIcon = UIHtmlFieldFactory.createImage(SCREENCD, "LANDLORD_ICON");
		configurationIcon = UIHtmlFieldFactory.createImage(SCREENCD, "CONFIG_ICON");
		userManagementIcon = UIHtmlFieldFactory.createImage(SCREENCD, "USERMANAGEMENT_ICON");
		auditTrailIcon = UIHtmlFieldFactory.createImage(SCREENCD, "AUDITTRAIL_ICON");
		reportIcon = UIHtmlFieldFactory.createImage(SCREENCD, "REPORT_ICON");
		defaultIcon = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_ICON");
		logoutIcon = UIHtmlFieldFactory.createImage(SCREENCD, "LOGOUT_ICON");
		myTasksIcon=UIHtmlFieldFactory.createImage(SCREENCD, "MYTASK_ICON");
		changePwIcon=UIHtmlFieldFactory.createImage(SCREENCD, "CHANGEPW");

		homeIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "HOME_ICON_ACTIVE");
		siteViewIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "SITEVIEW_ACTIVE");
		assetsIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "ASSETS_ACTIVE");
		landLordIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "LANDLORD_ACTIVE");
		configurationIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "CONFIG_ACTIVE");
		userManagementIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "USERMANAGEMENT_ACTIVE");
		auditTrailIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "AUDITTRAIL_ACTIVE");
		reportIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "REPORT_ACTIVE");
		defaultIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_ACTIVE");
		
	//	invoiceIcon = UIHtmlFieldFactory.createImage(SCREENCD, "ASSETS_ICON");
	//	invoiceIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "ASSETS_ACTIVE");
		invoiceIcon = UIHtmlFieldFactory.createImage(SCREENCD, "INVOICE_ICON");
		invoiceIconActive = UIHtmlFieldFactory.createImage(SCREENCD, "INVOICE_ACTIVE");
		myTasksIconActive=UIHtmlFieldFactory.createImage(SCREENCD, "MYTASK_ACTIVE");
		changePwIconActive=UIHtmlFieldFactory.createImage(SCREENCD, "CHANGEPW_ACTIVE");

		menuSiteView = new MenuItems(siteViewIcon, siteViewIconActive, "Site", Menu.SiteView, "siteview", null, false,
				false);
		menuAssetView = new MenuItems(assetsIcon, assetsIconActive, "Asset", Menu.AssetView, "assetsview", null, false,
				false);
		menuLandlordView = new MenuItems(landLordIcon, landLordIconActive, "Landlord", Menu.LandlordView, "landlordview", null, 
				false, false);
		menuConfiguration = new MenuItems(configurationIcon, configurationIconActive, "Configuration", Menu.Configuration,
				"configuration", null, false, false);
		menuUserManagement = new MenuItems(userManagementIcon, userManagementIconActive, "User Management", Menu.UserManagement,
				"usermanagement", null, false, false);
		
		menuGalaxyView=new MenuItems(assetsIcon, assetsIconActive, "Galaxy", Menu.GalaxyView, "galaxyview", null, false,
					false);
		
		menuInvoiceManagement=new MenuItems(invoiceIcon, invoiceIconActive, "Invoice Management", Menu.InvoiceManagement, "invoicemanagement", null, false,
				false);
		
		
		myTasks=new MenuItems(myTasksIcon, myTasksIconActive, "My Tasks", Menu.MyTasks, "", null, false,
				false);
		
		changePw=new MenuItems(changePwIcon, changePwIconActive, "Change Password", Menu.ChangePw, "changepassword", null, false,
				false);
		//JSONArray dynamicMenuJA = new JSONArray();
		menuList.add(menuSiteView, /*menuAssetView,*/ menuLandlordView, menuConfiguration, menuUserManagement,menuGalaxyView,
				menuInvoiceManagement,myTasks);
		try {
			JSONArray dynamicMenuJA = new JSONArray(ApplicationConfiguration.getConfigurationValue("DYNAMIC_MENU_LIST"));
			for (int i = 0; i < dynamicMenuJA.length(); i++) {
				JSONObject dynamicMenuJson = dynamicMenuJA.getJSONObject(i);
				String menuCaption = "";
				if (dynamicMenuJson.has("menu-caption")) {
					menuCaption = dynamicMenuJson.getString("menu-caption");
				}
				switch (menuCaption.toUpperCase()) {
				case "AUDIT TRAIL":
					menuAuditTrail = new MenuItems(auditTrailIcon, auditTrailIconActive, dynamicMenuJson.getString("menu-caption"), Menu.AuditTrail,
							"dynamicpage", null, false, false);
					menuList.add(menuAuditTrail);
					break;
				case "REPORT":
					menuReport = new MenuItems(reportIcon, reportIconActive, dynamicMenuJson.getString("menu-caption"), Menu.Report,
							"dynamicpage", null, false, false);
					menuList.add(menuReport);
					break;
				default:
					menuDefault = new MenuItems(defaultIcon, defaultIconActive, dynamicMenuJson.getString("menu-caption"), Menu.Default,
							"dynamicpage", null, false, false);
					menuList.add(menuDefault);
					break;
				}
				
			}
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		menuLogout = new MenuItems(logoutIcon, logoutIcon, "Log out", Menu.NullValue, "", null, false, false);

		menuList.add(changePw,menuLogout);

		menuHeader.add(companyLogo, loginDetailsDiv);

		add(menuHeader, menuList, blackOverlay);

		try {
			if (SiteAssetInventoryUIFramework.getFramework().isUserLoggedIn()) {
				userEmailLbl.setText(SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());
				String loggedInDateTimeTxt = userLoginTimestampLbl.getText();
				loggedInDateTimeTxt = loggedInDateTimeTxt.replaceAll("@@LOGIN_DATE_TIME@@",
						CommonUtils.getDisplayDateTime(
								SiteAssetInventoryUIFramework.getFramework().getUserInfo().getLoginDateTime()));
				userLoginTimestampLbl.setText(loggedInDateTimeTxt);

				menuLogout.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Div> event) {
						CommonUtils.logout(SiteAssetInventoryUIFramework.getFramework().getToken());
						SessionManager.handleTokenExpiry();
					}
				});
				
				myTasks.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Div> event) {
						String url = VaadinServletRequest.getCurrent().getScheme() 
								+ "://" + VaadinServletRequest.getCurrent().getServerName() 
								+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
								+ "/workflow";
						
						System.out.println("url="+url);
						UI.getCurrent().getPage().open(url);
					}
				});

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (SiteAssetInventoryUIFramework.getFramework().getOpenMenubar() == true) {
			blackOverlay.addClassName("REMOVE_CLASS");
		}

		blackOverlay.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {

				SiteAssetInventoryUIFramework.getFramework().showVerticalMenuBar(false);

			}
		});

	}

	public void addBlackOverlayClass() {
		blackOverlay.addClassNames("REMOVE_CLASS");
	}

	public void removeClaseBlackOverlay() {
		blackOverlay.removeClassName("REMOVE_CLASS");
	}

	public void updateMenuBar(Menu selectedMenu) {
		Stream<Component> childComponent = menuList.getChildren();
		if (childComponent == null) {
			return;
		}

		Iterator<Component> componentIterator = childComponent.iterator();
		while (componentIterator.hasNext()) {
			Component eachComponent = componentIterator.next();
			if (eachComponent instanceof MenuItems) {
				MenuItems menu = (MenuItems) eachComponent;
				menu.setSelected(false);

				if (selectedMenu == menu.getMenu()) {
					menu.setSelected(true);

					// System.out.println("menu " + menu.getMenu() );
				}
			}
		}

		// SiteAssetInventoryUIFramework.getFramework().showVerticalMenuBar(false);
	}

}
