package com.umt.siteassetinventory.framework.componentfactory.baselayout;

import com.umt.siteassetinventory.assets.AssetsView;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.landlord.LandlordView;
import com.umt.siteassetinventory.site.SiteView;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tabs;

@CssImport("./styles/base-structure.css")
public class BaseStructure extends Div 
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "BASE_STRUCTURE";
	protected Div rowDiv,col1Div,col2Div; 
	protected Div col1HeaderDiv,col2HeaderDiv,col1ValueDiv,col2ValueDiv,col2HeaderDiv1;
	protected Tabs parentTabs;
	protected String searchcriteria2;
	protected BaseStructure baseStructureobj;
	protected SiteView siteview;
	protected AssetsView assetview;
	protected LandlordView landlordview;

	public BaseStructure() 
	{
		baseStructureobj=this;
		rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		col1Div = UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_DIV");
		col2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_DIV");
		
		col1HeaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_HEADER_DIV");
		col1ValueDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL1_VALUE_DIV");
		col2HeaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_HEADER_DIV");
		col2HeaderDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_HEADER_DIV1");
		col2ValueDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "COL2_VALUE_DIV");
		
		parentTabs = new Tabs();
		parentTabs.addClassName(SCREENCD + "_PARENT_TABS");
		col2HeaderDiv.add(parentTabs);
		
		col1Div.add(col1HeaderDiv,col1ValueDiv);
		col2Div.add(col2HeaderDiv1,col2HeaderDiv,col2ValueDiv);
		
		
		
		rowDiv.add(col1Div,col2Div);
	}
	
	public void searchRecords(String searchCriteria) 
	{
	try {	
		//System.out.println("searchCriteria:: " + searchCriteria);
		this.searchcriteria2=searchCriteria;
	
		if(siteview!=null )
		{
			siteview.populateSiteDetailRow2(searchcriteria2);
		}
		if(assetview!=null)
		{
			assetview.populateAssetsDetailRow2(searchcriteria2);
		}
		if(landlordview!=null)
		{
			landlordview.populateLandlordDetailRow2(searchcriteria2);
		}
		
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		
		
	}
	protected void getSiteViewobj(SiteView siteview2)
	{
		siteview=siteview2;
	}
	protected void getAssetsViewobj(AssetsView assetview2) {
		assetview=assetview2;
		
	}
	protected void getLandlordViewobj(LandlordView landlordview2) {
		landlordview=landlordview2;
		
	}
	

}
