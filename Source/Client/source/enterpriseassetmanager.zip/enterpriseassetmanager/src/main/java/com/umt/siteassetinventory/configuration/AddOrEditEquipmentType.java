package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/add_edit_equipment_type-styles.css")
public class AddOrEditEquipmentType extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_EQUIPMENT_TYPE";

	private TextField equipmentTypeFld, equipmentTypeNameFld, descFld;
	private ComboBox<String> serviceTypeCombo;
	//private String siteCode;
	private long equipmentTypeId;

	public AddOrEditEquipmentType(EquipmentTypeMaster equipmentTypeMaster) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		equipmentTypeFld = UIFieldFactory.createTextField("", true, SCREENCD, "EQUIPMENT_TYPE_FIELD");
		equipmentTypeNameFld = UIFieldFactory.createTextField("", true, SCREENCD, "EQUIPMENT_TYPE_NAME_FIELD");
		descFld = UIFieldFactory.createTextField("", true, SCREENCD, "DESC_FIELD");

		serviceTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "SERVICE_TYPE_LIST", ','), true, 
				SCREENCD, "SERVICE_TYPE_COMBO");
		
		AddOrEditEquipmentTypePopup popup = new AddOrEditEquipmentTypePopup("Add Equipment Type", true, this, equipmentTypeMaster, SCREENCD);

		add(equipmentTypeFld, equipmentTypeNameFld, descFld, serviceTypeCombo);

	}

	public AddOrEditEquipmentType(EquipmentTypeMaster equipmentTypeMaster, EquipmentTypeMasterDataBean 
			equipmentTypeMasterDataBean, long equipmentTypeId, String equipmentType, String equipmentTypeName, String desc, 
			String serviceType) {
		this.equipmentTypeId = equipmentTypeId;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		try {
			equipmentTypeFld = UIFieldFactory.createTextField(equipmentType, true, SCREENCD, "EQUIPMENT_TYPE_FIELD");
			equipmentTypeFld.setEnabled(false);
			equipmentTypeNameFld = UIFieldFactory.createTextField(equipmentTypeName, true, SCREENCD, "EQUIPMENT_TYPE_NAME_FIELD");
			descFld = UIFieldFactory.createTextField(desc, true, SCREENCD, "DESC_FIELD");

			serviceTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "SERVICE_TYPE_LIST", ','), true, 
					SCREENCD, "SERVICE_TYPE_COMBO");
			serviceTypeCombo.setValue(CommonUtils.getServiceTypeCd(Integer.parseInt(serviceType)));
			serviceTypeCombo.setEnabled(false);
			AddOrEditEquipmentTypePopup popup = new AddOrEditEquipmentTypePopup("Edit EquipmentType", false, this, equipmentTypeMaster, SCREENCD);

			add(equipmentTypeFld, equipmentTypeNameFld, descFld, serviceTypeCombo);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean validation() {
		equipmentTypeFld.setInvalid(false);
		equipmentTypeNameFld.setInvalid(false);
		descFld.setInvalid(false);
		serviceTypeCombo.setInvalid(false);

		if (equipmentTypeFld.getValue()==null || equipmentTypeFld.getValue().trim().length()==0) {
			equipmentTypeFld.setInvalid(true);
			equipmentTypeFld.setErrorMessage("Please enter "+equipmentTypeFld.getLabel().toLowerCase());
			return false;
		}
		
		if (equipmentTypeNameFld.getValue()==null || equipmentTypeNameFld.getValue().trim().length()==0) {
			equipmentTypeNameFld.setInvalid(true);
			equipmentTypeNameFld.setErrorMessage("Please enter "+equipmentTypeNameFld.getLabel().toLowerCase());
			return false;
		}

		if (descFld.getValue()==null || descFld.getValue().toString().trim().length()==0) {
			descFld.setInvalid(true);
			descFld.setErrorMessage("Please enter "+descFld.getLabel().toLowerCase());
			return false;
		}

		if (serviceTypeCombo.getValue()==null || serviceTypeCombo.getValue().trim().length()==0) {
			serviceTypeCombo.setInvalid(true);
			serviceTypeCombo.setErrorMessage("Please enter "+serviceTypeCombo.getLabel().toLowerCase());
			return false;
		}
		return true;
	}
	
	
	public long getEquipmentTypeId() {
		return equipmentTypeId;
	}
	
	public String getEquipmentType() {
		if (equipmentTypeFld.getValue()==null)
			return "";
		else
			return equipmentTypeFld.getValue();
	}

	public String getEquipmentTypeName() {
		if (equipmentTypeNameFld.getValue()==null)
			return "";
		else
			return equipmentTypeNameFld.getValue();
	}

	public String getDesc() {
		if (descFld.getValue()==null)
			return "";
		else
			return descFld.getValue()+"";
	}

	public String getServiceType() {
		if (serviceTypeCombo.getValue()==null)
			return "";
		else
			return serviceTypeCombo.getValue();
	}


}
