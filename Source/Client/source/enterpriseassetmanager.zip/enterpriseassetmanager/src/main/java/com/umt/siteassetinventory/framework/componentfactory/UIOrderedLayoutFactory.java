package com.umt.siteassetinventory.framework.componentfactory;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.resourcemanager.ResourceUtil;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;

public class UIOrderedLayoutFactory  
{
	public static VerticalLayout createVerticalLayout(String screencd, String componentcd)
	{
		VerticalLayout layout = new VerticalLayout();
		layout.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return layout;
	}
	
	public static HorizontalLayout createHorizontalLayout(String screencd, String componentcd)
	{
		HorizontalLayout layout = new HorizontalLayout();
		layout.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return layout;
	}
	
	public static FlexLayout createFlexLayout(String screencd, String componentcd)
	{
		FlexLayout layout = new FlexLayout();
		layout.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return layout;
	}

	public static Tab createTab(String screencd, String componentcd)
	{
		
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		Tab tab = new Tab(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		tab.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return tab;
	}
}
