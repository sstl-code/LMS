package com.umt.siteassetinventory.landlord;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.EventsTab;
import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap.CustomGoogleMapMarkerClickListener;
import com.umt.siteassetinventory.site.SiteListMapViewDialog;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.router.Route;

@Route(value = "landlordview", layout = MainView.class)
@CssImport("./styles/landlord-view.css")
public class LandlordView extends BaseStructure implements AfterNavigationObserver,HasUrlParameter<String>{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_VIEW";
	private LandlordView parent;
	private Tab detailsTab,attributesTab,sitesTab,paymentsTab,propertyTab,documentTab,TicketsTab,invoicesTab,eventsTab;
	private LandlordDocumentsTab landlordDocumentsTabVL;
	private Button addAssetsBtn;
	private Button viewMapBtn,applyBtn,clearMapBtn;
	private TextField applyRadiusField;
	private Checkbox mapViewChk;
	private Div landLordListContainerDiv;
	public String route="",searchCriteria,selectedLandlordId;
	private List<LandlordViewDataBean> landlordbeanList=new ArrayList<LandlordViewDataBean>();
	private String paramLandlordId;
	private Map<String, List<String>> parameterMap;
	public String landlordlistresponse;
	private Div detailsTabHolder, attributesTabHolder, siteTabHolder, paymentHolder, documentHolder,ticketHolder,invoicesHolder,eventsTabHolder;
	private String searchcriteria2="";
	private LandlordListMapView  mapView;
	private Div mapviewDiv1,mapviewDiv;
	public boolean isMapVisible=false;
	private String maplandlordId1;

	private LandlordDetailsTab detail_tab;
	private LandLordAttributesTab attribute_tab;

	private String str1,str2;
	private JSONArray sortedjsArr;
	//private LandlordDocumentsTab landlordDocumentsTabVL;
	private TicketsTab landlordTicketsTabVL;
	private LandLordSiteTab landlordSitesTabVL;
	private LandlordPaymentsTab paymentsTabVL;
	private EventsTab eventsTabVL;
	private Label col2Lbl1,col2Lbl2;
	private String col2Lbl1Str,col2Lbl2Str;

	private Div idiv1,idiv2;
	private Div idiv3,idiv4;
	private Div idiv5,idiv6;
	private Icon caret_down1,caret_down2,caret_down3;
	private Icon caret_up1,caret_up2,caret_up3;
	private String sortedListResponse;

	private CustomGoogleMap googleMapComponent;
	private JSONArray markerJSONArray = new JSONArray();
	private String lat,longi;
	private ComboBox<String> radiusUnitCombo;

	private Div noRecordDiv,noRecordDiv2;
	private Div recordcontainerDiv;
	private LocalDate date1,date2;
	
	private LandlordInvoicesTab invoicesTabVL;
	
	private int id1,id2;

	public LandlordView() 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		parent=this;
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Landlord View");

		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAIL_TAB_LBL"));
		attributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ATTR_TAB_LBL"));
		sitesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "SITE_TAB_LBL"));
		paymentsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PAYMENT_TAB_LBL"));
		propertyTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PROPERTY_TAB_LBL"));
		documentTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DOCUMENTS_TAB_LBL"));
		TicketsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TICKETS_TAB_LBL"));
		invoicesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "INVOICES_TAB_LBL"));
		eventsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EVENTS_LBL"));

		parentTabs.add(detailsTab,attributesTab,sitesTab,paymentsTab,invoicesTab,/*propertyTab,*/documentTab,TicketsTab,eventsTab);
		detailsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_TAB_DIV");
		attributesTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTES_TAB_DIV");
		siteTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "SITES_TAB_DIV");
		paymentHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "PAYMENT_TAB_DIV");
		documentHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DOC_TAB_DIV"); 
		ticketHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "TICKET_TAB_DIV");
		invoicesHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "INVOICES_TAB_DIV");
		eventsTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "EVENTS_TAB_DIV");
		noRecordDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "LANDLORD_LIST_CONTAINER_DIV");
		recordcontainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RECORD_DIV");
		recordcontainerDiv.setVisible(true);

		add(rowDiv);

		landlordDocumentsTabVL = new LandlordDocumentsTab();
		paymentsTabVL=new LandlordPaymentsTab();
		landlordTicketsTabVL = new TicketsTab();

		createHeader();
		refreshData();

		landlordDocumentsTabVL.setVisible(false);
		landlordTicketsTabVL.setVisible(false);
		parentTabs.setSelectedTab(detailsTab);
		paymentsTabVL.setVisible(false);
		detailsTabHolder.setVisible(true);
		ticketHolder.setVisible(false);
		noRecordDiv2.setVisible(false);
		siteTabHolder.setVisible(false);
		addDetailsLandlord(selectedLandlordId);

		recordcontainerDiv.add(detailsTabHolder, attributesTabHolder, siteTabHolder, paymentHolder,invoicesHolder,documentHolder,ticketHolder,eventsTabHolder);
		col2ValueDiv.add(/*detailsTabHolder, attributesTabHolder, paymentHolder, documentHolder,ticketHolder*/recordcontainerDiv,noRecordDiv2);

		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) 
				{

					detailsTabHolder.setVisible(true);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(false);
					addDetailsLandlord(selectedLandlordId);
					ticketHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(attributesTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(true);
					siteTabHolder.setVisible(false);
					ticketHolder.setVisible(false);

					addAttributes(selectedLandlordId);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(sitesTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(true);
					ticketHolder.setVisible(false);

					addSites(selectedLandlordId);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(paymentsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(true);
					documentHolder.setVisible(false);
					//paymentsTabVL.setLandlordId(getLandlordId());
					addPayment(selectedLandlordId);
					

					landlordTicketsTabVL.setVisible(false);
					ticketHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if (event.getSelectedTab().equals(invoicesTab)) {
					invoicesHolder.setVisible(true);
					addInvoices(selectedLandlordId);
					
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(false);
					
					documentHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(false);
					ticketHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if (event.getSelectedTab().equals(documentTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(true);
					landlordTicketsTabVL.setVisible(false);
					ticketHolder.setVisible(false);

					addDocument();
					eventsTabHolder.setVisible(false);

				} else if (event.getSelectedTab().equals(TicketsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(true);
					ticketHolder.setVisible(true);
					//	col2ValueDiv.removeAll();
					//	col2ValueDiv.add(landlordTicketsTabVL);
					//landlordTicketsTabVL.setLandlordId(getLandlordId());
					//	landlordTicketsTabVL.displayWorkflows();

					addTickets();
					eventsTabHolder.setVisible(false);
				} else if (event.getSelectedTab().equals(eventsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					siteTabHolder.setVisible(false);
					paymentHolder.setVisible(false);
					invoicesHolder.setVisible(false);
					documentHolder.setVisible(false);
					landlordTicketsTabVL.setVisible(false);
					ticketHolder.setVisible(false);

					addEvents();
					eventsTabHolder.setVisible(true);

				}

			}
		});
	}


	public void refreshData()
	{

		//	populateLandlordDetailRow(searchcriteria2);
		populateLandlordDetailRow2(searchcriteria2);
		generateMarkerData(landlordlistresponse);
	}

	public void addDetailsLandlord(String landlordId) {
		//System.out.println(landlordId);
		detailsTabHolder.removeAll();
		detail_tab = new LandlordDetailsTab(landlordId, this);
		detailsTabHolder.add(detail_tab);

	}
	public void addAttributes(String landlordId) {
		attributesTabHolder.removeAll();
		attribute_tab = new LandLordAttributesTab(landlordId, this);
		attributesTabHolder.add(attribute_tab);
	}
	public void addSites(String landlordId) {
		siteTabHolder.removeAll();
		landlordSitesTabVL = new LandLordSiteTab(landlordId);
		siteTabHolder.add(landlordSitesTabVL);
	}
	public void addPayment(String selectedLandlordId2) {
		paymentHolder.removeAll();
		paymentsTabVL=new LandlordPaymentsTab();
		paymentHolder.add(paymentsTabVL.populatePayments(selectedLandlordId2));

	}
	public void addInvoices(String selectedLandlordId2) {
		String landlordname=col2Lbl1Str;
		invoicesHolder.removeAll();
		invoicesTabVL=new LandlordInvoicesTab(selectedLandlordId2,landlordname,this);
		invoicesHolder.add(invoicesTabVL);
		
	}
	public void addDocument() {
		documentHolder.removeAll();
		landlordDocumentsTabVL = new LandlordDocumentsTab();
		documentHolder.add(landlordDocumentsTabVL);
		landlordDocumentsTabVL.loadLandlordDocumentScreen(getLandlordId());
	}
	public void addTickets() {

		ticketHolder.removeAll();
		landlordTicketsTabVL = new TicketsTab();
		landlordTicketsTabVL.setLandlordId(getLandlordId());
		//landlordTicketsTabVL.displayWorkflows();
		ticketHolder.add(landlordTicketsTabVL);
	}
	public void addEvents() {

		eventsTabHolder.removeAll();
		eventsTabVL=new EventsTab("LandlordId:"+getLandlordId(), "Landlord");
		eventsTabVL.populateData();
		eventsTabHolder.add(eventsTabVL);
	}

	private void createHeader()
	{
		/*	mapView=new LandlordListMapView(this);
		mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");

		mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
		mapviewDiv.add(mapView);
		mapviewDiv1.add(mapviewDiv);
		mapView.setVisible(false);
		mapviewDiv1.setVisible(false);*/
		landLordListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "LANDLORD_LIST_CONTAINER_DIV");
		noRecordDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "LANDLORD_LIST_CONTAINER_DIV");
		noRecordDiv.setVisible(false);

		lat=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
		longi=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");

		mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");
		mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
		mapviewDiv1.add(mapviewDiv);
		mapviewDiv1.setVisible(false);

		Div eachDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");


		Label headerLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
		eachDiv1.add(headerLbl1);

		Image viewmapImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_MAP_IMAGE");
		eachDiv2.add(viewmapImg);

		addAssetsBtn = UIFieldFactory.createButton(SCREENCD, "ADD_ASSETS_BTN");
		eachDiv3.add(addAssetsBtn);

		col1HeaderDiv.add(eachDiv1,/*eachDiv2,*/eachDiv3);

		Div headerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_HEADER_DIV");

		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV4");

		idiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up1=VaadinIcon.CARET_UP.create();
		caret_up1.addClassName("CARET_UP");
		idiv1.add(caret_up1);
		idiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down1=VaadinIcon.CARET_DOWN.create();
		caret_down1.addClassName("CARET_DOWN");
		idiv2.add(caret_down1);
		Div IconDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv1.add(idiv1,idiv2);


		idiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up2=VaadinIcon.CARET_UP.create();
		caret_up2.addClassName("CARET_UP");
		idiv3.add(caret_up2);
		idiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down2=VaadinIcon.CARET_DOWN.create();
		caret_down2.addClassName("CARET_DOWN");
		idiv4.add(caret_down2);
		Div IconDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv2.add(idiv3,idiv4);

		idiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up3=VaadinIcon.CARET_UP.create();
		caret_up3.addClassName("CARET_UP");
		idiv5.add(caret_up3);
		idiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down3=VaadinIcon.CARET_DOWN.create();
		caret_down3.addClassName("CARET_DOWN");
		idiv6.add(caret_down3);
		Div IconDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv3.add(idiv5,idiv6);

		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachdataDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachdataDiv2.add(lbl2,IconDiv1);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachdataDiv3.add(lbl3,IconDiv2);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachdataDiv4.add(lbl4,IconDiv3);
		headerDiv.add(/*eachdataDiv1,*/eachdataDiv2,eachdataDiv3,eachdataDiv4);

		Div searchListDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_DIV");
		Div searchListRowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV1");
		Div searchListRowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV2");

		viewMapBtn= UIFieldFactory.createButton(SCREENCD, "VIEW_MAP_BTN");
		applyBtn= UIFieldFactory.createButton(SCREENCD, "APPLY_BTN");
		clearMapBtn= UIFieldFactory.createButton(SCREENCD, "CLOSE_BTN");
		applyRadiusField= UIFieldFactory.createTextField("", false, SCREENCD,"APPLY_RADIUS_FIELD");
		applyRadiusField.setPlaceholder("Type radius");
		mapViewChk = UIFieldFactory.createCheckbox(false, false, SCREENCD, "MAP_VIEW");
		mapViewChk.setEnabled(false);

		ArrayList<String> unitList=new ArrayList<String>();
		unitList.clear();
		String units[] = { "m","km","miles"};
		for (int i = 0; i < units.length; i++) {
			unitList.add(units[i]);
		}
		radiusUnitCombo = UIFieldFactory.createComboBox(unitList, false, SCREENCD, "UNIT_COMBO_FIELD");
		radiusUnitCombo.setPlaceholder("units");
		radiusUnitCombo.setEnabled(false);

		Div radiusDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RADIUS_DIV");
		radiusDiv.add(applyRadiusField,radiusUnitCombo);

		searchListRowDiv1.add(mapViewChk,viewMapBtn);
		searchListRowDiv2.add(/*locationimgDiv,applyRadiusField*/radiusDiv,applyBtn,clearMapBtn);
		searchListRowDiv2.setVisible(false);

		searchListDiv.add(searchListRowDiv1,searchListRowDiv2);

		//	landLordListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "LANDLORD_LIST_CONTAINER_DIV");
		col1ValueDiv.add(searchListDiv,mapviewDiv1,headerDiv,landLordListContainerDiv,noRecordDiv);

		applyRadiusField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) 
			{
				if (applyRadiusField.getValue() == null || applyRadiusField.getValue().trim().length() <= 0) 
				{
					radiusUnitCombo.setEnabled(false);
				}
				if (applyRadiusField.getValue().trim().length() > 0) 
				{
					radiusUnitCombo.setEnabled(true);
				}
			}
		});



		viewMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				/*	System.out.println("selectedsiteCode1="+selectedLandlordId);
				mapView.setVisible(true);
				mapView.populateLandlordDetails(landlordlistresponse);
				mapView.setSelectedSite(selectedLandlordId);
				mapviewDiv.setVisible(true);
				mapviewDiv1.setVisible(true);
				isMapVisible=true;
				searchListDiv.setVisible(true);
				landLordListContainerDiv.setVisible(false);
				headerDiv.setVisible(false);
				searchListRowDiv2.setVisible(true);
				headerLbl1.removeAll();
				headerLbl1.setText("Landlord List-Map View");*/

				try {

					mapviewDiv.setVisible(true);
					mapviewDiv1.setVisible(true);
					isMapVisible=true;
					searchListDiv.setVisible(true);
					landLordListContainerDiv.setVisible(false);
					headerDiv.setVisible(false);
					searchListRowDiv2.setVisible(true);
					headerLbl1.removeAll();
					headerLbl1.setText("Landlord List-Map View");
					mapViewChk.setEnabled(false);
					applyRadiusField.clear();
					radiusUnitCombo.clear();
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					if (googleMapComponent == null) {
						googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 3,"landlordlistmap");
						mapviewDiv.removeAll();
						mapviewDiv.add(googleMapComponent);

						googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onMapMarkerClick(String eventData) {
								//System.out.println("Event Data -->>" + eventData);
								try {
									JSONObject eventDataJSON = new JSONObject(eventData);
									String uniqueId = eventDataJSON.getString("event.detail").split("_")[0];
									selectedRowChangeHandler(uniqueId);
									selectLandlordViewNode(uniqueId);
									selectedLandlordId = uniqueId;
									addDetailsLandlord(uniqueId);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});
					}
					googleMapComponent.setVisible(true);
					googleMapComponent.clearMapMarker();
					generateMarkerData(landlordlistresponse);
					googleMapComponent.populateMarker(markerJSONArray);
					googleMapComponent.openInfoWindow2(selectedLandlordId);

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}		

		});
		clearMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				/*	mapView.setVisible(false);
				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				isMapVisible=false;
				searchListDiv.setVisible(true);
				landLordListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Landlord List");*/

				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				searchListDiv.setVisible(true);
				isMapVisible=false;
				//	landLordListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Landlord List");
				mapViewChk.setEnabled(false);
				mapViewChk.setValue(false);
				applyRadiusField.clear();
				radiusUnitCombo.clear();
				if(landlordlistresponse!=null || !landlordlistresponse.equalsIgnoreCase("[]"))
				{
					landLordListContainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
				}
				if(landlordlistresponse==null || landlordlistresponse.equalsIgnoreCase("[]"))
				{
					landLordListContainerDiv.setVisible(false);
					noRecordDiv.setVisible(true);
					noRecordDiv2.setVisible(true);
					//		col2HeaderDiv1.removeAll();
				}
			}
		});
		addAssetsBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) 
			{

				AddLandlordDialog dlg= new AddLandlordDialog();
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AddLandlordDialog srcDlg = (AddLandlordDialog)event.getSource();
						if(!srcDlg.isOpened()&& (srcDlg.isSuccess()==true)) 
						{
							populateLandlordDetailRow2(searchcriteria2);
						}
					}

				});
			}
		});

		applyBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				try 
				{
					if(applyRadiusField.getValue().toString().length()<=0)
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide radius", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if (radiusUnitCombo.getValue() == null) 
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide units", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if(applyRadiusField.getValue().toString().length()<=0 && radiusUnitCombo.getValue() == null)
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide both radius and units", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if(applyRadiusField.getValue().toString().length()>0)
					{
						String radius=calcRadius(applyRadiusField.getValue(),radiusUnitCombo.getValue());
						googleMapComponent.applyGeoFence(Double.parseDouble(radius));
						mapViewChk.setValue(true);
						mapViewChk.setEnabled(true);
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		mapViewChk.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) 
			{
				if(event.getValue().equals(false))
				{
					googleMapComponent.clearGeoFence();
					mapViewChk.setEnabled(false);
				}

			}
		});

		eachDiv2.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) 
			{

				SiteListMapViewDialog dlg= new SiteListMapViewDialog(null,selectedLandlordId,null,parent,"Landlord_view");
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						SiteListMapViewDialog srcDlg = (SiteListMapViewDialog)event.getSource();
						if(!srcDlg.isOpened()) 
						{

						}
					}

				});
			}
		});

		idiv1.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByName("descending");

				caret_up1.getStyle().set("color", "#0000ff87");
				caret_down1.getStyle().set("color", "#8080809e");

				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");
			}
		});
		idiv2.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByName("ascending");

				caret_down1.getStyle().set("color", "#0000ff87");
				caret_up1.getStyle().set("color", "#8080809e");

				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");
			}
		});

/*		idiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByRegion("descending");

				caret_up2.getStyle().set("color", "#0000ff87");
				caret_down2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});
		idiv4.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByRegion("ascending");

				caret_down2.getStyle().set("color", "#0000ff87");
				caret_up2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});
*/		
		
		idiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByLandlordId("descending");

				caret_up2.getStyle().set("color", "#0000ff87");
				caret_down2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});
		idiv4.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByLandlordId("ascending");

				caret_down2.getStyle().set("color", "#0000ff87");
				caret_up2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});

		idiv5.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//sortByRegistrationDate("descending");
				sortByPanNo("descending");

				caret_up3.getStyle().set("color", "#0000ff87");
				caret_down3.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");

			}
		});
		idiv6.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
			//	sortByRegistrationDate("ascending");
				sortByPanNo("ascending");

				caret_down3.getStyle().set("color", "#0000ff87");
				caret_up3.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");

			}
		});


	}
	protected String calcRadius(String rad, String unit) {

		String val="";
		switch(unit)
		{
		case "m":
			val=rad;
			break;
		case "km":
			double d=Double.parseDouble(rad)*1000;
			val=String.valueOf(d);
			break;
		case "miles":
			double v=Double.parseDouble(rad)*1609.34;
			val=String.valueOf(v);
			break;
		}
		return val;
	}

	public void populateLandlordDetailRow(String searchcriteria2) 
	{
		//System.out.println("searchcriteria2="+searchcriteria2);
		try 
		{
			String res1="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCH_LANDLORD");
			url=url+"?searchText="+searchcriteria2;
			//		System.out.println("url1="+url);
			res1 = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//		System.out.println("landlord_search_res:::"+res1);

			landlordlistresponse=res1;

			landLordListContainerDiv.removeAll();
			landlordbeanList.clear();

			if(res1!=null && res1.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res1);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								jsarr.getJSONObject(i).getString("LandlordId"),
								jsarr.getJSONObject(i).getString("Name"),
								jsarr.getJSONObject(i).getString("Region"),
								jsarr.getJSONObject(i).getString("RegistrationDate"),
								jsarr.getJSONObject(i).getString("PAN"),
								this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);
						if(i==0 /*&& paramLandlordId==null*/)
						{
							selectedLandlordId=jsarr.getJSONObject(i).getString("LandlordId");
							beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
							maplandlordId1=jsarr.getJSONObject(i).getString("LandlordId");
						}

					}
				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}


	private void selectLandlordViewNode(String paramLandlordId2) {
		for(int i = 0; i < landlordbeanList.size(); i++) {
			landlordbeanList.get(i).selectAssetViewBeanNode(paramLandlordId2);
		}

	}

	public List<LandlordViewDataBean> getLandlordBeanList() {

		return landlordbeanList;
	}
	public void deselectOtherRows(LandlordViewDataBean child2) 
	{
		for (int i = 0; i < landlordbeanList.size(); i++) 
		{
			landlordbeanList.get(i).deselectEachDiv(child2);
		}


	}
	public void selectedRowChangeHandler(String landlordid) 
	{
		parentTabs.setSelectedTab(detailsTab);
		selectedLandlordId=landlordid;


		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) 
				{

				} else if(event.getSelectedTab().equals(attributesTab)) {

				}
			}
		});
	}
	public void populateLandlordDetailRow1(String paramLandlordId) 
	{
		try 
		{
			String res1="",res="",panNo="";

			String url = ApplicationConfiguration.getServiceEndpoint("GET_LANDLORD_DETAILS");
			url=url+"?LandlordId="+paramLandlordId;
			//		System.out.println("url1="+url);
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" landlord_param_res:::"+res);
			res1="["+res+"]";

			landlordlistresponse=res1;
			generateMarkerData(landlordlistresponse);

			landLordListContainerDiv.removeAll();
			landlordbeanList.clear();

			if(res1!=null && res1.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res1);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						String otherinfo=jsarr.getJSONObject(i).getString("OtherInfo");
						if(otherinfo!=null  && otherinfo.length()>0) {
							JSONObject otherinfojs=new JSONObject(otherinfo);
							if(otherinfojs!=null && otherinfojs.length()>0) {
								if(otherinfojs.has("PAN")) {
									panNo=otherinfojs.getString("PAN");
								}
							}
						}
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								jsarr.getJSONObject(i).getString("Landlordid"),
								jsarr.getJSONObject(i).getString("LandlordName"),
								jsarr.getJSONObject(i).getString("Region"),
								jsarr.getJSONObject(i).getString("RegistrationDate"),
								panNo,//jsarr.getJSONObject(i).getString("PAN"),
								this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);


					}
				}
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			UI.getCurrent().navigate("landlordview");
		}

	}
	public String getLandlordId()
	{
		return selectedLandlordId;
	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) 
	{
		route=event.getLocation().getPathWithQueryParameters();
		if(route.equalsIgnoreCase("landlordview") || route.contains("landlordview?LandlordId="))
		{
			this.searchCriteria=searchcriteria2;
			getLandlordViewobj(parent);
		}

	}

	@Override
	public void setParameter(BeforeEvent event, @OptionalParameter String parameter) {
		try
		{
			Location location = event.getLocation();
			QueryParameters queryParameters = location.getQueryParameters();
			parameterMap = queryParameters.getParameters();
			List<String> paramValue = parameterMap.get("LandlordId");
			if(parameterMap.size()>0)
			{
				if(paramValue != null && paramValue.size() > 0)
				{
					paramLandlordId = paramValue.get(0);
				}
				//	System.out.println("paramsiteCode::"+paramAssetId);
				if(paramLandlordId!=null)
				{
					populateLandlordDetailRow1(paramLandlordId);
					selectLandlordViewNode(paramLandlordId);
					selectedLandlordId=paramLandlordId;
					addDetailsLandlord(selectedLandlordId);
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			UI.getCurrent().navigate("landlordview");
		}

	}

	private void populateMapview(String landlordlistresponse2) 
	{
		mapView.populateLandlordDetails(landlordlistresponse2);
		mapView.setSelectedSite(maplandlordId1);
		mapviewDiv.setVisible(true);
		mapviewDiv1.setVisible(true);

	}
	private void refreshGoogleMapview(String landlordlistresponse2) 
	{
		try
		{

			mapviewDiv.setVisible(true);
			mapviewDiv1.setVisible(true);
			lat=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
			longi=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			googleMapComponent.clearMapMarker();
			if (googleMapComponent == null) {
				googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 3,"landlordlistmap");
				mapviewDiv.removeAll();
				mapviewDiv.add(googleMapComponent);

				googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onMapMarkerClick(String eventData) {
						//	System.out.println("Event Data -->>" + eventData);
						try {
							JSONObject eventDataJSON = new JSONObject(eventData);
							String uniqueId = eventDataJSON.getString("event.detail");
							selectedRowChangeHandler(uniqueId);
							selectLandlordViewNode(uniqueId);
							selectedLandlordId = uniqueId;
							addDetailsLandlord(uniqueId);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
			}
			googleMapComponent.setVisible(true);
			generateMarkerData(landlordlistresponse2);
			googleMapComponent.populateMarker(markerJSONArray);
			//	googleMapComponent.openInfoWindow(mapsitecode1);
			googleMapComponent.openInfoWindow2(selectedLandlordId);
		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	public void addMapMarkerClickHandler(String caption) 
	{
		try
		{
			//System.out.println("LandlordmapmarkerClicked::"+caption);
			selectedRowChangeHandler(caption);
			selectLandlordViewNode(caption);
			selectedLandlordId=caption;
			//	addDetailsTab(caption);
			addDetailsLandlord(caption);

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	public void populateLandlordDetailRow2(String searchcriteria2) 
	{
		//System.out.println("searchcriteria2="+searchcriteria2);
		try 
		{
			String res1="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCH_LANDLORD");
			//	url=url+"?searchText="+searchcriteria2;
			url=url+"?searchText="+CommonUtils.getEncodedText(searchcriteria2).replaceAll("\\+","%20");
			//	System.out.println("url1="+url);
			res1 = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//	System.out.println("landlord_search_res:::"+res1);

			landlordlistresponse=res1;
			sortedListResponse=res1;

			landLordListContainerDiv.removeAll();
			landlordbeanList.clear();

			if(landlordlistresponse==null || landlordlistresponse.equals("[]"))
			{
				noRecordDiv.setVisible(true);
				noRecordDiv2.setVisible(true);
				landLordListContainerDiv.setVisible(false);
				//detailsTabHolder.setVisible(false);
				//col2ValueDiv.removeAll();
				recordcontainerDiv.setVisible(false);
				landlordbeanList.clear();
				noRecordDiv.removeAll();
				noRecordDiv2.removeAll();
				Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_REC_LBL");
				noRecordDiv.add(lbl);
			}

			caret_down1.getStyle().set("color", "#8080809e");
			caret_down2.getStyle().set("color", "#8080809e");
			caret_down3.getStyle().set("color", "#8080809e");
			caret_up1.getStyle().set("color", "#8080809e");
			caret_up2.getStyle().set("color", "#8080809e");
			caret_up3.getStyle().set("color", "#8080809e");

			/*	if(res1!=null && res1.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res1);
				if(jsonArray.length()>0 && !landlordlistresponse.equals("[]"))
				{
					landLordListContainerDiv.setVisible(true);
					recordcontainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					detailsTabHolder.setVisible(true);
					parentTabs.setSelectedTab(detailsTab);
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject object1, JSONObject object2) {
							try {
								str1 = object1.getString("PAN");
								str2 = object2.getString("PAN");
								final Pattern p = Pattern.compile("^\\d+");
								 Matcher m = p.matcher(str1);
							        Integer number1 = null;
							        if (!m.find()) {
							            return str1.compareTo(str2);
							        }
							        else {
							            Integer number2 = null;
							            number1 = Integer.parseInt(m.group());
							            m = p.matcher(str2);
							            if (!m.find()) {
							                return str1.compareTo(str2);
							            }
							            else {
							                number2 = Integer.parseInt(m.group());
							                int comparison = number1.compareTo(number2);
							                if (comparison != 0) {
							                    return comparison;
							                }
							                else {
							                    return str1.compareTo(str2);
							                }
							            }
							        }

							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

						Collections.reverse(jsonsList);//descending order
						sortedjsArr=new JSONArray(jsonsList);
				}

			}*/

			col2HeaderDiv1.removeAll();
			sortedjsArr=new JSONArray();
			
			if(res1!=null && res1.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res1);
				System.out.println("jsonArray.length():::"+jsonArray.length());
				
				if(jsonArray.length()>0 && !landlordlistresponse.equals("[]"))
				{
					landLordListContainerDiv.setVisible(true);
					recordcontainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					detailsTabHolder.setVisible(true);
					parentTabs.setSelectedTab(detailsTab);
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("PAN");
								str2 = jo2.getString("PAN");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						//	return date1.compareTo(date2);
						}
					});

					Collections.reverse(jsonsList);//descending order
					sortedjsArr=new JSONArray(jsonsList);
					//	System.out.println("Sorted JSON Array with dates: " + sortedjsArr);

				}
			}


				if(sortedjsArr.length()>0)
				{
					
					if(sortedjsArr.length()>=50 && searchcriteria2.length()<=0 ) {//if more than 50 records & no search string provided
						landLordListContainerDiv.removeAll();
						landlordbeanList.clear();
						
						for(int i=0;i<sortedjsArr.length();i++)
						{
							LandlordViewDataBean beanobj=new LandlordViewDataBean(
									sortedjsArr.getJSONObject(i).getString("LandlordId"),
									sortedjsArr.getJSONObject(i).getString("Name"),
									sortedjsArr.getJSONObject(i).getString("Region"),
									sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
									sortedjsArr.getJSONObject(i).getString("PAN"),
									this);



							landLordListContainerDiv.add(beanobj);
							landlordbeanList.add(beanobj);
							if(i==0 /*&& paramLandlordId==null*/)
							{
								selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
								beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
								maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
								String name=sortedjsArr.getJSONObject(i).getString("Name");
								addDetailsLandlord(selectedLandlordId);
								sendLandlordName(name,selectedLandlordId);
							}

						}
						
						Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
						morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
						
						System.out.println("searchcriteria2.length()=="+searchcriteria2.length());
						if(sortedjsArr.length()>=50 && searchcriteria2.length()<=0) {
							landLordListContainerDiv.add(morerecordLbl);
							morerecordLbl.setVisible(true);
						}
					} else if((sortedjsArr.length()<50 && searchcriteria2.length()<=0)|| searchcriteria2.length()>0) {
						//if less than 50 records & no search string provided || if search string is provided
						
						landLordListContainerDiv.removeAll();
						landlordbeanList.clear();
						
						for(int i=0;i<sortedjsArr.length();i++)
						{
							LandlordViewDataBean beanobj=new LandlordViewDataBean(
									sortedjsArr.getJSONObject(i).getString("LandlordId"),
									sortedjsArr.getJSONObject(i).getString("Name"),
									sortedjsArr.getJSONObject(i).getString("Region"),
									sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
									sortedjsArr.getJSONObject(i).getString("PAN"),
									this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);
						if(i==0 /*&& paramLandlordId==null*/)
						{
							selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
							beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
							maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
							String name=sortedjsArr.getJSONObject(i).getString("Name");
							addDetailsLandlord(selectedLandlordId);
							sendLandlordName(name,selectedLandlordId);
						}

						}
						
					}else {	
						
					}
				}
				if(isMapVisible==true)
				{
					//populateMapview(landlordlistresponse);
					refreshGoogleMapview(landlordlistresponse);
					landLordListContainerDiv.setVisible(false);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);

				}
			//}	

		}catch(Exception e)
		{
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			//	parentTabs.setEnabled(false);
			}
		}

	}

	public void sendLandlordName(String name, String landlordId) 
	{
		col2Lbl1Str=name;
		col2Lbl2Str=landlordId;

		col2Lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL1");
		col2Lbl1.setText(col2Lbl1Str+" (");
		col2Lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL2");
		col2Lbl2.setText(" Landlord Id# "+col2Lbl2Str+")");

		col2HeaderDiv1.removeAll();
		col2HeaderDiv1.add(col2Lbl1,col2Lbl2);

	}

	protected void sortByName(String orderBy) 
	{
		try
		{
			String res="";

			res=sortedListResponse;
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("Name").toUpperCase();
								str2 = jo2.getString("Name").toUpperCase();
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				//System.out.println("sortedjsArr.length():::"+sortedjsArr.length());
				if(sortedjsArr.length()>=50) {
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



					landLordListContainerDiv.add(beanobj);
					landlordbeanList.add(beanobj);
					if(i==0 && paramLandlordId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
						addDetailsLandlord(selectedLandlordId);
						beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
						maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
						String name=sortedjsArr.getJSONObject(i).getString("Name");

						sendLandlordName(name,selectedLandlordId);
					}

					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						landLordListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
				}else if(sortedjsArr.length()<50) {
					
					landLordListContainerDiv.removeAll();
					landlordbeanList.clear();
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);
						if(i==0 && paramLandlordId==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
							addDetailsLandlord(selectedLandlordId);
							beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
							maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
							String name=sortedjsArr.getJSONObject(i).getString("Name");

							sendLandlordName(name,selectedLandlordId);
						}

					}
				}else {}
				

			}

			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}



		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}
	protected void sortByRegion(String orderBy) 
	{
		try
		{
			String res="";

			res=sortedListResponse;
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("Region");
								str2 = jo2.getString("Region");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					LandlordViewDataBean beanobj=new LandlordViewDataBean(
							sortedjsArr.getJSONObject(i).getString("LandlordId"),
							sortedjsArr.getJSONObject(i).getString("Name"),
							sortedjsArr.getJSONObject(i).getString("Region"),
							sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
							sortedjsArr.getJSONObject(i).getString("PAN"),
							this);



					landLordListContainerDiv.add(beanobj);
					landlordbeanList.add(beanobj);
					if(i==0 && paramLandlordId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
						addDetailsLandlord(selectedLandlordId);
						beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
						maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
						String name=sortedjsArr.getJSONObject(i).getString("Name");

						sendLandlordName(name,selectedLandlordId);
					}


				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	
	protected void sortByLandlordId(String orderBy) 
	{
		try
		{
			String res="";

			res=sortedListResponse;
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}
			
					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								
								id1 = Integer.parseInt(jo1.getString("LandlordId"));
								id2 = Integer.parseInt(jo2.getString("LandlordId"));
							} catch(JSONException e) {
								e.printStackTrace();
							}

							Integer x = new Integer(id1);
					        Integer y = new Integer(id2);
							return x.compareTo(y);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				if(sortedjsArr.length()>=50) {
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



					landLordListContainerDiv.add(beanobj);
					landlordbeanList.add(beanobj);
					if(i==0 && paramLandlordId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
						addDetailsLandlord(selectedLandlordId);
						beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
						maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
						String name=sortedjsArr.getJSONObject(i).getString("Name");

						sendLandlordName(name,selectedLandlordId);
					}


					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						landLordListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
				}else if(sortedjsArr.length()<50) {
					landLordListContainerDiv.removeAll();
					landlordbeanList.clear();
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);
						if(i==0 && paramLandlordId==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
							addDetailsLandlord(selectedLandlordId);
							beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
							maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
							String name=sortedjsArr.getJSONObject(i).getString("Name");

							sendLandlordName(name,selectedLandlordId);
						}


					}
				}else {}
			}
			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	
	protected void sortByPanNo(String orderBy) {
		try
		{
			String res="";

			res=sortedListResponse;
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();
			
			
	/*		res="[\r\n" + 
					"  {\r\n" + 
					"    \"LandlordId\": \"1\",\r\n" + 
					"    \"Name\": \"Test Landlord\",\r\n" + 
					"    \"ContactNo\": \"123456\",\r\n" + 
					"    \"Address\": \"123 Shakespeare Sarani\",\r\n" + 
					"    \"Email\": \"test@nomail.com\",\r\n" + 
					"    \"Region\": \"Kolkata\",\r\n" + 
					"    \"RegistrationDate\": \"06-Feb-2023\",\r\n" + 
					"    \"SiteDetails\": [\r\n" + 
					"      \r\n" + 
					"    ],\r\n" + 
					"    \"PAN\": \"ZGKLA5287H\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"LandlordId\": \"2\",\r\n" + 
					"    \"Name\": \"Poulomi Sur\",\r\n" + 
					"    \"ContactNo\": \"9890909889\",\r\n" + 
					"    \"Address\": \"Kolkata\",\r\n" + 
					"    \"Email\": \"poulomi.sur@ushamartintech.com\",\r\n" + 
					"    \"Region\": \"Kolkata\",\r\n" + 
					"    \"RegistrationDate\": \"06-Feb-2023\",\r\n" + 
					"    \"SiteDetails\": [\r\n" + 
					"      \r\n" + 
					"    ],\r\n" + 
					"    \"PAN\": \"NLXBC1905E\"\r\n" + 
					"  }\r\n" + 
					"]";
			
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();*/
			
			
			/*	if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject object1, JSONObject object2) {
							try {
								str1 = object1.getString("PAN");
								str2 = object2.getString("PAN");
								final Pattern p = Pattern.compile("^\\d+");
								 Matcher m = p.matcher(str1);
							        Integer number1 = null;
							        if (!m.find()) {
							            return str1.compareTo(str2);
							        }
							        else {
							            Integer number2 = null;
							            number1 = Integer.parseInt(m.group());
							            m = p.matcher(str2);
							            if (!m.find()) {
							                return str1.compareTo(str2);
							            }
							            else {
							                number2 = Integer.parseInt(m.group());
							                int comparison = number1.compareTo(number2);
							                if (comparison != 0) {
							                    return comparison;
							                }
							                else {
							                    return str1.compareTo(str2);
							                }
							            }
							        }

							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}*/
			
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0 && !landlordlistresponse.equals("[]"))
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("PAN");
								str2 = jo2.getString("PAN");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});


						
						if(orderBy.equalsIgnoreCase("descending"))
						{
							Collections.reverse(jsonsList);
							sortedjsArr=new JSONArray(jsonsList);
						}
						if(orderBy.equalsIgnoreCase("ascending"))
						{
							sortedjsArr=new JSONArray(jsonsList);
						}
				//		System.out.println("Sorted JSON Array with PAN: " + sortedjsArr);
				}
			}
			
			if(sortedjsArr.length()>0)
			{
				if(sortedjsArr.length()>=50) {
					
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



					landLordListContainerDiv.add(beanobj);
					landlordbeanList.add(beanobj);
					if(i==0 && paramLandlordId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
						addDetailsLandlord(selectedLandlordId);
						beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
						maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
						String name=sortedjsArr.getJSONObject(i).getString("Name");

						sendLandlordName(name,selectedLandlordId);
					}

					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						landLordListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
					
				}else if(sortedjsArr.length()<50) {
					landlordbeanList.clear();
					landLordListContainerDiv.removeAll();
					for(int i=0;i<sortedjsArr.length();i++)
					{
						LandlordViewDataBean beanobj=new LandlordViewDataBean(
								sortedjsArr.getJSONObject(i).getString("LandlordId"),
								sortedjsArr.getJSONObject(i).getString("Name"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
								sortedjsArr.getJSONObject(i).getString("PAN"),
								this);



						landLordListContainerDiv.add(beanobj);
						landlordbeanList.add(beanobj);
						if(i==0 && paramLandlordId==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
							addDetailsLandlord(selectedLandlordId);
							beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
							maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
							String name=sortedjsArr.getJSONObject(i).getString("Name");

							sendLandlordName(name,selectedLandlordId);
						}

					}
					
				}else {
					
				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	protected void sortByRegistrationDate(String orderBy) {
		try
		{
			String res="";

			res=sortedListResponse;
			landlordlistresponse=res;

			landlordbeanList.clear();
			landLordListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("RegistrationDate");
								str2 = jo2.getString("RegistrationDate");

								date1=CommonUtils.convertStringToLocalDate(str1,"dd-MMM-yyyy");
								date2=CommonUtils.convertStringToLocalDate(str2,"dd-MMM-yyyy");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							//return str1.compareTo(str2);
							return date1.compareTo(date2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					LandlordViewDataBean beanobj=new LandlordViewDataBean(
							sortedjsArr.getJSONObject(i).getString("LandlordId"),
							sortedjsArr.getJSONObject(i).getString("Name"),
							sortedjsArr.getJSONObject(i).getString("Region"),
							sortedjsArr.getJSONObject(i).getString("RegistrationDate"),
							sortedjsArr.getJSONObject(i).getString("PAN"),
							this);



					landLordListContainerDiv.add(beanobj);
					landlordbeanList.add(beanobj);
					if(i==0 && paramLandlordId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedLandlordId=sortedjsArr.getJSONObject(i).getString("LandlordId");
						addDetailsLandlord(selectedLandlordId);
						beanobj.getEachRowDiv().addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
						maplandlordId1=sortedjsArr.getJSONObject(i).getString("LandlordId");
						String name=sortedjsArr.getJSONObject(i).getString("Name");

						sendLandlordName(name,selectedLandlordId);
					}

				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(landlordlistresponse);
				refreshGoogleMapview(landlordlistresponse);
				landLordListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private void generateMarkerData(String landlordlistresponse2) {
		try 
		{
			String siteDetails="";
			String title="",uniqueId="",region="",addr="",name="";
			JSONObject jsobj=null;

			markerJSONArray = new JSONArray();
			JSONArray jsarr=null;
			if(landlordlistresponse2 == null) {
				landlordlistresponse2 = "[]";
			}
			JSONArray js=new JSONArray(landlordlistresponse2);
			for(int i=0;i<js.length();i++ )
			{
				siteDetails=js.getJSONObject(i).getString("SiteDetails");
				//System.out.println("SiteDetails:: "+siteDetails.toString());
				if(siteDetails == null) {
					siteDetails = "[]";
				}
				jsarr=new JSONArray(siteDetails);
				if(jsarr.length()>0)
				{

					jsobj=new JSONObject();
					if(js.getJSONObject(i).has("LandlordId"))
					{
						title=js.getJSONObject(i).getString("LandlordId");
						//uniqueId=js.getJSONObject(i).getString("LandlordId");
						name=js.getJSONObject(i).getString("Name");
					}
					if(js.getJSONObject(i).has("Landlordid"))
					{
						title=js.getJSONObject(i).getString("Landlordid");
						//uniqueId=js.getJSONObject(i).getString("Landlordid");
						name=js.getJSONObject(i).getString("LandlordName");
					}
					//title=js.getJSONObject(i).getString("LandlordId");
					//uniqueId=js.getJSONObject(i).getString("LandlordId");
					region=js.getJSONObject(i).getString("Region");
					addr=js.getJSONObject(i).getString("Address");
					//	name=js.getJSONObject(i).getString("Name");


					jsobj.put("title",title /*js.getJSONObject(i).get("LandlordId")*/);
					String landlordId = "";
					if (js.getJSONObject(i).has("LandlordId")) {
						landlordId = js.getJSONObject(i).get("LandlordId")+"";
					} else if (js.getJSONObject(i).has("Landlordid")) {
						landlordId = js.getJSONObject(i).get("Landlordid")+"";
					}

					//jsobj.put("uniqueId",uniqueId /*js.getJSONObject(i).get("LandlordId")*/);
					//	jsobj.put("lat", js.getJSONObject(j).get("Lattitude"));
					//	jsobj.put("lng", js.getJSONObject(j).get("Longitude"));
					jsobj.put("Region", js.getJSONObject(i).get("Region"));
					jsobj.put("Address", js.getJSONObject(i).get("Address"));
					jsobj.put("Name", name/*js.getJSONObject(i).get("Name")*/);

					if(jsarr.length()==1)
					{
						if (jsarr.getJSONObject(0).has("SiteCode")) {
							jsobj.put("uniqueId", landlordId+"_"+jsarr.getJSONObject(0).get("SiteCode"));
						} else if (jsarr.getJSONObject(0).has("Sitecode")) {
							jsobj.put("uniqueId", landlordId+"_"+jsarr.getJSONObject(0).get("Sitecode"));
						}

						jsobj.put("lat", jsarr.getJSONObject(0).get("Lattitude"));
						jsobj.put("lng", jsarr.getJSONObject(0).get("Longitude"));

					}
					if(jsarr.length()>1)
					{
						for(int j=0;j<jsarr.length();j++)
						{
							jsobj=new JSONObject();

							jsobj.put("title", title);
							if (jsarr.getJSONObject(j).has("SiteCode")) {
								jsobj.put("uniqueId", landlordId+"_"+jsarr.getJSONObject(j).get("SiteCode"));
							} else if (jsarr.getJSONObject(j).has("Sitecode")) {
								jsobj.put("uniqueId", landlordId+"_"+jsarr.getJSONObject(j).get("Sitecode"));
							}

							jsobj.put("lat", jsarr.getJSONObject(j).get("Lattitude"));
							jsobj.put("lng", jsarr.getJSONObject(j).get("Longitude"));
							jsobj.put("Region", region);
							jsobj.put("Address", addr);
							jsobj.put("Name", name);

							markerJSONArray.put(jsobj);
						}
					}
					markerJSONArray.put(jsobj);
				}

				//markerJSONArray.put(jsobj);



			}
			//System.out.println("markerJSONArray3="+markerJSONArray);

			for(int i = 0; i < markerJSONArray.length(); i++) {
				JSONObject eachItem = markerJSONArray.getJSONObject(i);

				String contentString1 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId").split("_")[1] + "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" + eachItem.getString("Address") + "</small></div></body></html>";


				//	String contentString3 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("Name") + "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+"</span><br><em>" + eachItem.getString("Address")+ "</small></div></body></html>";

				//	String contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng")+ "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+
				//			"</span><br><em>" + eachItem.getString("Address")+ "</span><br><em>Name :" + eachItem.getString("Name")+"</small></div></body></html>";


				eachItem.put("contentString", contentString1);
			}


		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void generateMarkerData2(String landlordlistresponse2) {
		try 
		{


			markerJSONArray = new JSONArray();
			if(landlordlistresponse2 == null) {
				landlordlistresponse2 = "[]";
			}
			JSONArray js=new JSONArray(landlordlistresponse2);
			for(int i=0;i<js.length();i++ )
			{
				String lat=js.getJSONObject(i).getString("Lattitude");
				String longi=js.getJSONObject(i).getString("Longitude");
				if(lat.trim().length()>0 && longi.trim().length()>0)
				{
					JSONObject jsobj=new JSONObject();
					jsobj.put("title", js.getJSONObject(i).get("LandlordId"));
					jsobj.put("uniqueId", js.getJSONObject(i).get("LandlordId"));
					jsobj.put("lat", js.getJSONObject(i).get("Lattitude"));
					jsobj.put("lng", js.getJSONObject(i).get("Longitude"));
					jsobj.put("Region", js.getJSONObject(i).get("Region"));
					jsobj.put("Address", js.getJSONObject(i).get("Address"));
					jsobj.put("Name", js.getJSONObject(i).get("Name"));

					markerJSONArray.put(jsobj);
				}
			}

			//System.out.println("markerJSONArray3="+markerJSONArray);

			for(int i = 0; i < markerJSONArray.length(); i++) {
				JSONObject eachItem = markerJSONArray.getJSONObject(i);

				String contentString1 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("Name") + "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+"</span><br><em>" + eachItem.getString("Address")+ "</small></div></body></html>";

				String contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng")+ "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+
						"</span><br><em>" + eachItem.getString("Address")+ "</span><br><em>Name :" + eachItem.getString("Name")+"</small></div></body></html>";


				eachItem.put("contentString", contentString1);
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
