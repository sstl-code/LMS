package com.umt.siteassetinventory.assets;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/change_assets_details_params-styles.css")
public class ChangeAssetDetailsParams extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "CHANGE_ASSET_DTL_PARAMS";

	private ComboBox<String> storeCombo, statusCombo, vendorCombo;
	private TextField remarksTxtfld, siteCodeTxtfld;
	private AssetDetailsTab assetDetailsTab;
	private Map<String, String> storeNameIdMap;
	private Map<String, String> storeStatusNameIdMap;
	private Map<String, String> equipmentNameIdMap;
	private Map<String, String> vendorNameIdMap;
	private int changeParam;


	public ChangeAssetDetailsParams(AssetDetailsTab assetDetailsTab, int changeParam) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.assetDetailsTab = assetDetailsTab;
		this.changeParam = changeParam;
		storeCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "STORE_COMBO");
		statusCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "STATUS_COMBO");
		remarksTxtfld = UIFieldFactory.createTextField("", false, SCREENCD, "REMARKS_FLD");
		siteCodeTxtfld = UIFieldFactory.createTextField("", false, SCREENCD, "SITE_CODE_FLD");
		vendorCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "VENDOR_COMBO");
		String title = "";
		if (changeParam==1) {
			title = "Assign Asset";
		}
		else if (changeParam==2) {
			title = "Return Asset";
		}
		if (changeParam==3) {
			title = "Change Status";
		}
		ChangeAssetDetailsParamsPopup popup = new ChangeAssetDetailsParamsPopup(title, changeParam, this, assetDetailsTab, SCREENCD);

		if (changeParam==1 || changeParam==2) {
			add(storeCombo);
			loadStores();
			loadEquipmentNameIdMap();
			loadVendors();
			vendorCombo.setValue(assetDetailsTab.getVendorName());
			vendorCombo.setEnabled(false);
		} 
		else
		{
			statusCombo.removeClassName(SCREENCD+"_STATUS_COMBO");
			statusCombo.addClassName(SCREENCD+"_2FLD");
			remarksTxtfld.removeClassName(SCREENCD+"_REMARKS_FLD");
			remarksTxtfld.addClassName(SCREENCD+"_2FLD_REMARKS");
		}
		loadStatuses(assetDetailsTab.getStoreid());
		statusCombo.setValue(assetDetailsTab.getStatuscode());
		add(statusCombo, remarksTxtfld);
		if(storeCombo.getValue().equalsIgnoreCase("SITE"))
		{
			addComponentAtIndex(2, siteCodeTxtfld);
		}
		if(storeCombo.getValue().equalsIgnoreCase("VENDOR"))
		{
			addComponentAtIndex(1, vendorCombo);
		}

		storeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event)
			{ 
				if (event.getValue()!=null && storeCombo.getValue().trim().length()>0) {
					statusCombo.setEnabled(true);
					loadStatuses(storeNameIdMap.get(storeCombo.getValue()));
					if(event.getValue().toString().equalsIgnoreCase("SITE"))
					{
						addComponentAtIndex(2, siteCodeTxtfld);
					}
					else
					{
						remove(siteCodeTxtfld);
					}
					if(event.getValue().toString().equalsIgnoreCase("VENDOR"))
					{
						addComponentAtIndex(1, vendorCombo);
					}
					else
					{
						remove(vendorCombo);
					}
				}
				else
				{
					statusCombo.clear();
					statusCombo.setEnabled(false);
					remove(siteCodeTxtfld);
					remove(vendorCombo);
				}

			}
		});

	}

	private void loadStores()
	{
		storeNameIdMap = new HashedMap<>();
		String stores = getStore();
		try {
			JSONArray storesJA = new JSONArray(stores);
			for (int i = 0; i < storesJA.length(); i++) {
				JSONObject storeJson = storesJA.getJSONObject(i);
				storeNameIdMap.put(storeJson.getString("StoreName"), storeJson.getLong("StoreId")+"");
			}
			storeCombo.setItems(storeNameIdMap.keySet().stream());
			storeCombo.setValue(assetDetailsTab.getStorename());

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private void loadStatuses(String storeId)
	{
		storeStatusNameIdMap = new HashedMap<>();
		String storeStatuses = getStoreStatus(storeId);
		try {
			JSONArray storeStatusesJA = new JSONArray(storeStatuses);
			for (int i = 0; i < storeStatusesJA.length(); i++) {
				JSONObject storeStatusJson = storeStatusesJA.getJSONObject(i);
				storeStatusNameIdMap.put(storeStatusJson.getString("StatusCode"), storeStatusJson.getLong("StatusId")+"");
			}
			statusCombo.setItems(storeStatusNameIdMap.keySet().stream());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private void loadVendors()
	{
		vendorNameIdMap = new HashedMap<>();
		String vendors = getEquipmentTypeVendor();
		try {
			JSONArray  vendorsJA = new JSONArray(vendors);	
			for (int i = 0; i < vendorsJA.length(); i++) {
				JSONObject vendorJson = vendorsJA.getJSONObject(i);
				vendorNameIdMap.put(vendorJson.getString("VendorName"), vendorJson.getString("VendorId"));
			}
			vendorCombo.setItems(vendorNameIdMap.keySet().stream());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void loadEquipmentNameIdMap()
	{
		try {
			String equipmentTypes = getEquipmentType();
			JSONArray  equipmentTypesJA = new JSONArray(equipmentTypes);
			equipmentNameIdMap = new HashedMap<>();
			for (int i = 0; i < equipmentTypesJA.length(); i++) {
				JSONObject equipmentTypeJson = equipmentTypesJA.getJSONObject(i);
				equipmentNameIdMap.put(equipmentTypeJson.getString("EquipmentType"), equipmentTypeJson.getString("EquipmentTypeId"));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	private String getStore()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETSTORE");
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getStoreStatus(String storeId)
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETSTORESTATUS");
			url = url + "?StoreId="+ storeId;
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getEquipmentTypeVendor()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPEVENDOR");
			url = url + "?EquipmentTypeId=" + equipmentNameIdMap.get(assetDetailsTab.getEquipmentType());
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getEquipmentType()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPE");
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	public boolean validation() {
		storeCombo.setInvalid(false);
		statusCombo.setInvalid(false);

		if(changeParam==1 || changeParam==2)
		{
			if (storeCombo.getValue()==null || storeCombo.getValue().trim().length()==0) {
				storeCombo.setInvalid(true);
				storeCombo.setErrorMessage("Please enter "+storeCombo.getLabel().toLowerCase());
				return false;
			}
		}
		if (statusCombo.getValue()==null || statusCombo.getValue().trim().length()==0) {
			statusCombo.setInvalid(true);
			statusCombo.setErrorMessage("Please enter "+statusCombo.getLabel().toLowerCase());
			return false;
		}
		return true;
	}

	public String getStoreId()
	{		
		return storeNameIdMap.get(storeCombo.getValue());
	}

	public String getStoreLocId()
	{
		if (siteCodeTxtfld.getValue()==null && vendorCombo.getValue()==null) {
			return "";
		}
		if(storeCombo.getValue().equalsIgnoreCase("SITE"))
		{
			return siteCodeTxtfld.getValue();
		}
		else 
			if(storeCombo.getValue().equalsIgnoreCase("VENDOR"))
			{
				return vendorNameIdMap.get(vendorCombo.getValue());
			}
		return "";
	}

	public String getStatusId()
	{
		return storeStatusNameIdMap.get(statusCombo.getValue());
	}

	public String getRemarks()
	{
		if (remarksTxtfld.getValue()==null) {
			return "";
		} 
		return remarksTxtfld.getValue();
	}
}
