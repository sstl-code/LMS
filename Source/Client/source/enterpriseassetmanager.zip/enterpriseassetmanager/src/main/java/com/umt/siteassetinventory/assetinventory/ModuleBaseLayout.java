package com.umt.siteassetinventory.assetinventory;

import com.vaadin.flow.component.html.Div;

public abstract class ModuleBaseLayout extends Div{

	private static final long serialVersionUID = 1L;
	
	public abstract void searchRecords(String searchCriteria);

}
