package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/equipment_type_master-styles.css")
public class EquipmentTypeMaster extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENT_TYPE_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<EquipmentTypeMasterDataBean> equipmentTypeMasterDataBeanList;
	private ConfigView parent;
	//private Label lbl1, lbl2, lbl3, lbl4, lbl5;
	//private String siteCode;

	public EquipmentTypeMaster(ConfigView parent) {
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;
		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		filterFld.setPlaceholder("Filter EquipmentTypes");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");

//		for (int i = 0; i < fieldCounts; i++) {
//			Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV");
//			Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL");
//			eachrowDiv.add(lbl);
//			tableHeaderDiv.add(eachrowDiv);
//		}
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5);

		filterDiv.add(filterFld , addBtn);
		
		//AddSiteAssetPopup popup = new AddSiteAssetPopup("Add " + assetParam + " Asset", this, siteAssetsTab, SCREENCD);

		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				addDialog(true);
			}
		});
		
		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				try {
				equipmentTypeMasterDataBeanList.stream().filter(new Predicate<EquipmentTypeMasterDataBean>() {

					@Override
					public boolean test(EquipmentTypeMasterDataBean t) {
						String filterTxt = filterFld.getValue();
						if (filterTxt == null || filterTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if (StringUtils.containsIgnoreCase(t.getEquipmentTypeId()+"", filterTxt)
								|| StringUtils.containsIgnoreCase(t.getEquipmentType(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getEquipmentTypeName(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getDesc(), filterTxt)
								|| StringUtils.containsIgnoreCase(CommonUtils.getServiceTypeCd(Integer.parseInt(t.getServiceType())), filterTxt)) {
							t.setVisible(true);
							return true;
						}
						t.setVisible(false);
						return false;
					}
				}).collect(Collectors.toList());
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		filterFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		populateData();
	}
	
	protected void populateData() {
		tableContainerDiv.removeAll();
		equipmentTypeMasterDataBeanList = new ArrayList<>();
		parent.activeEquipmentTypeMap = new HashMap<>();
		parent.passiveEquipmentTypeMap = new HashMap<>();
		String response = getEquipmentType();
//				"[{\"EquipmentTypeId\":1,\"EquipmentType\":\"Battery\",\"EquipmentTypeName\":\"Exide Industries\",\"Description\":\"Battery 24V\","
//				+ "\"ServiceType\":\"Active\"},{\"EquipmentTypeId\":2,\"EquipmentType\":\"Dish Antenna\",\"EquipmentTypeName\":\"Airtel\",\"Description\":"
//				+ "\"Dish _Antenna_02 added\",\"ServiceType\":\"Passive\"}]";
		try {
			JSONArray ja = new JSONArray(response);
			for (int i = 0; i < ja.length(); i++) {
				JSONObject jo = ja.getJSONObject(i);
				String equipmentType = "";
				String equipmentTypeName = "";
				String desc = "";
				String serviceType = "";
				if (jo.getString("EquipmentType")!=null) {
					equipmentType = jo.getString("EquipmentType");
				} 
				if (jo.getString("EquipmentTypeName")!=null) {
					equipmentTypeName = jo.getString("EquipmentTypeName");
				} 
				if (jo.getString("Description")!=null) {
					desc = jo.getString("Description");
				} 
				if (jo.getString("ServiceType")!=null) {
					serviceType = jo.getString("ServiceType");
				} 
				if (Integer.parseInt(serviceType)==1) {
					parent.activeEquipmentTypeMap.put(jo.getLong("EquipmentTypeId"), equipmentType);
				} else if (Integer.parseInt(serviceType)==0) {
					parent.passiveEquipmentTypeMap.put(jo.getLong("EquipmentTypeId"), equipmentType);
				}
				
				EquipmentTypeMasterDataBean bean = new EquipmentTypeMasterDataBean(jo.getLong("EquipmentTypeId"), equipmentType, 
						equipmentTypeName, desc, serviceType, this);
				
				equipmentTypeMasterDataBeanList.add(bean);
				tableContainerDiv.add(bean);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void addDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddOrEditEquipmentType addEquipmentType = new AddOrEditEquipmentType(this);
	}
	
//	public void selectedRowChangeHandler(ConfigBaseDataBean selectedBean) 
//	{
//		for (ConfigBaseDataBean equipmentTypeMasterDataBean : equipmentTypeMasterDataBeanList) {
//			if (!equipmentTypeMasterDataBean.equals(selectedBean)) {
//				equipmentTypeMasterDataBean.selectDeselect(true);
//			}
//		}
//	}

	private String getEquipmentType()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPE");
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

}
