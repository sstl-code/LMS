package com.umt.siteassetinventory.assetinventory;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dependency.JsModule;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.Orientation;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "assets", layout = MainView.class)
@PageTitle("Site Asset Inventory")
@JsModule("./styles/shared_style.js")
@CssImport("./styles/site-master.css")
public class SiteMaster extends Div implements AfterNavigationObserver {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_INVENTORY";
	private Label screenTitle;
	private Div masterContainerDiv;
	private Div childContainerDiv;
	private Div siteMasterTabComponent;
	private PassiveAssetMaster passiveAssetMasterTabComponent;
	private Tabs parentTabs;
	private Tab siteMasterTab;
	private Tab assetMasterTab;
	private Tabs childTabs;
	private Tab detailTab;
	private Tab landAgreementTab;
	private Tab acParentAssetTab;
	private Tab batteryParentAssetTab;
	private Tab dgParentAssetTab;
	private Tab dgOperatorDataTab;
	private Tab gridPowerParentAssetTab;
	private Tab gridPowerOperatorDataTab;
	private Tab solarParentAssetTab;
	private Tab solarOperatorDataTab;
	private Tab rectifierParentAssetTab;
	private Tab rectifierOperatorDataTab;
	private Tab tenancyDataTab;
	private Tab documentsTab;

	private AssetTabularViewComponent siteMasterComponent;
	private AssetDetailComponent siteDetailTabComponent;
	private AssetDetailComponent landAgreementTabComponent;
	private AssetTabularViewComponent acParentAssetTabComponent;
	private AssetTabularViewComponent batteryParentAssetTabComponent;
	private AssetTabularViewComponent dgParentAssetTabComponent;
	private AssetTabularViewComponent dgOperatorDataTabComponent;
	private AssetTabularViewComponent gridPowerParentAssetTabComponent;
	private AssetTabularViewComponent gridPowerOperatorDataTabComponent;
	private AssetTabularViewComponent solarParentAssetTabComponent;
	private AssetTabularViewComponent solarOperatorDataTabComponent;
	private AssetTabularViewComponent rectifierParentAssetTabComponent;
	private AssetTabularViewComponent rectifierOperatorDataTabComponent;
	private TenancyDetails tenancyDataTabComponent;
	private DocumentsTab documentsTabComponent;
	private AccountWorkflow ticketTabComponent;
	
	private Div siteLevelPassiveAssetComponent;
	private Div siteLevelPassiveAssetTypeTabDiv;
	private Label siteLevelPassiveAssetTypeLbl;
	private Tabs siteLevelPassiveAssetTabs;
	private Tab siteLevelPassiveAssetTab;
	private Tab siteLevelTicketTab;
	private SiteMaster parent;
	private Tabs siteViewTabs;
	private SitesMapView siteMapViewComponent;
	private Tab siteListViewTab;
	private Tab siteMapViewTab;
	private Checkbox toggleSiteMapView;	

	public SiteMaster() {
		parent=this;
		screenTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE");
		masterContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MASTER_CONTAINER_DIV");
		childContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CHILD_CONTAINER_DIV");

		childTabs = new Tabs();
		detailTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "SITE_DETAIL_TAB_LBL"));
		landAgreementTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "LAND_AGREEMENT_TAB_LBL"));
		acParentAssetTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "AC_PARENT_ASSET_TAB_LBL"));
		acParentAssetTab.addClassName(SCREENCD + "AC_TAB");
		batteryParentAssetTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "BATTERY_PARENT_ASSET_TAB_LBL"));
		batteryParentAssetTab.addClassName(SCREENCD + "_BATTERY_TAB");
		dgParentAssetTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DG_PARENT_ASSET_TAB_LBL"));
		dgParentAssetTab.addClassName(SCREENCD + "_DG_TAB");
		dgOperatorDataTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DG_OPERATOR_DATA_TAB_LBL"));
		gridPowerParentAssetTab = new Tab(
				SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "GRID_POWER_PARENT_ASSET_TAB_LBL"));
		gridPowerParentAssetTab.addClassName(SCREENCD + "_GRID_TAB");
		gridPowerOperatorDataTab = new Tab(
				SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "GRID_POWER_OPERATOR_DATA_TAB_LBL"));
		solarParentAssetTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "SOLAR_PARENT_ASSET_TAB_LBL"));
		solarParentAssetTab.addClassName(SCREENCD + "_SOLAR_TAB");
		solarOperatorDataTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "SOLAR_OPERATOR_DATA_TAB_LBL"));
		rectifierParentAssetTab = new Tab(
				SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "RECTIFIER_PARENT_ASSET_TAB_LBL"));
		rectifierParentAssetTab.addClassName(SCREENCD + "_RECTIFIER_TAB");
		rectifierOperatorDataTab = new Tab(
				SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "RECTIFIER_OPERATOR_DATA_TAB_LBL"));
		tenancyDataTab = new Tab(
				SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TENANCY_DATA_TAB_LBL"));
		
		siteLevelPassiveAssetComponent = UIHtmlFieldFactory.createDiv(SCREENCD,
				"SITE_LEVEL_PASSIVE_ASSET_COMPONENT");
		siteLevelPassiveAssetTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PASSIVE_ASSET_TAB_LBL"));
		siteLevelPassiveAssetTabs = new Tabs();
		siteLevelPassiveAssetTabs.addClassName(SCREENCD + "_PASSIVE_ASSET_TABS");

		siteLevelPassiveAssetTabs.add(acParentAssetTab, batteryParentAssetTab, dgParentAssetTab,
				gridPowerParentAssetTab, solarParentAssetTab, rectifierParentAssetTab);
		
		documentsTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DOCUMENTS_TAB_LBL"));
		siteLevelTicketTab = new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TICKETS_TAB_LBL"));
				
		
		childTabs.add(detailTab, landAgreementTab, tenancyDataTab, siteLevelPassiveAssetTab,siteLevelTicketTab, documentsTab);

		siteMasterComponent = new AssetTabularViewComponent("SITE_MASTER", this, true, false, true, true, true);
		siteDetailTabComponent = new AssetDetailComponent("SITE_DETAIL", false, true, false);
		landAgreementTabComponent = new AssetDetailComponent("LAND_AGREEMENT", true, true, false);
		acParentAssetTabComponent = new AssetTabularViewComponent("AC_PARENT_ASSET", true, true, false, false, false);
		batteryParentAssetTabComponent = new AssetTabularViewComponent("BATTERY_PARENT_ASSET", true, true, false, false, false);
		dgParentAssetTabComponent = new AssetTabularViewComponent("DG_PARENT_ASSET", true, true, false, false, false);
		dgOperatorDataTabComponent = new AssetTabularViewComponent("DG_OPERATOR_DATA", true, true, false, false, false);
		gridPowerParentAssetTabComponent = new AssetTabularViewComponent("GRID_POWER_PARENT_ASSET", true, true, false, false, false);
		gridPowerOperatorDataTabComponent = new AssetTabularViewComponent("GRID_POWER_OPERATOR_DATA", true, true, false, false, false);
		solarParentAssetTabComponent = new AssetTabularViewComponent("SOLAR_PARENT_ASSET", true, true, false, false, false);
		solarOperatorDataTabComponent = new AssetTabularViewComponent("SOLAR_OPERATOR_DATA", true, true, false, false, false);
		rectifierParentAssetTabComponent = new AssetTabularViewComponent("RECTFIER_PARENT_ASSET", true, true, false, false, false);
		rectifierOperatorDataTabComponent = new AssetTabularViewComponent("RECTIFIER_OPERATOR_DATA", true, true, false, false, false);
		tenancyDataTabComponent = new TenancyDetails(this);
		ticketTabComponent = new AccountWorkflow(this);
		documentsTabComponent = new DocumentsTab(this);

		siteViewTabs = new Tabs();
		siteViewTabs.addClassName(SCREENCD + "SITE_VIEW_TABS");
		siteMapViewComponent = new SitesMapView(this);
		siteListViewTab = new Tab("List View");
		siteMapViewTab = new Tab("Map View");
		
		siteViewTabs.add(siteListViewTab, siteMapViewTab);

		childTabs.setSelectedTab(detailTab);
		siteDetailTabComponent.setVisible(true);
		siteDetailTabComponent.loadData(ApplicationConfiguration.getConfigurationValue("SITE_DETAIL_CSV"), "");
		landAgreementTabComponent.setVisible(false);
		
		acParentAssetTabComponent.setVisible(false);
		batteryParentAssetTabComponent.setVisible(false);
		dgParentAssetTabComponent.setVisible(false);
		dgOperatorDataTabComponent.setVisible(false);
		gridPowerParentAssetTabComponent.setVisible(false);
		gridPowerOperatorDataTabComponent.setVisible(false);
		solarParentAssetTabComponent.setVisible(false);
		solarOperatorDataTabComponent.setVisible(false);
		rectifierParentAssetTabComponent.setVisible(false);
		rectifierOperatorDataTabComponent.setVisible(false);
		
		tenancyDataTabComponent.setVisible(false);
		siteLevelPassiveAssetComponent.setVisible(false);
		documentsTabComponent.setVisible(false);
		ticketTabComponent.setVisible(false);

		childTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if (event.getSelectedTab().equals(detailTab)) {
					siteDetailTabComponent.setVisible(true);
					siteDetailTabComponent.loadData(ApplicationConfiguration.getConfigurationValue("SITE_DETAIL_CSV"), siteMasterComponent.getSelectedSiteCode());
					landAgreementTabComponent.setVisible(false);
					siteLevelPassiveAssetComponent.setVisible(false);
					tenancyDataTabComponent.setVisible(false);
					documentsTabComponent.setVisible(false);
					ticketTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(landAgreementTab)) {
					siteDetailTabComponent.setVisible(false);
					landAgreementTabComponent.setVisible(true);
					landAgreementTabComponent.loadData(ApplicationConfiguration.getConfigurationValue("LAND_AGREEMENT_CSV"), siteMasterComponent.getSelectedSiteCode());
					tenancyDataTabComponent.setVisible(false);
					siteLevelPassiveAssetComponent.setVisible(false);
					documentsTabComponent.setVisible(false);
					ticketTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(tenancyDataTab)) {
					siteDetailTabComponent.setVisible(false);
					landAgreementTabComponent.setVisible(false);
					tenancyDataTabComponent.setVisible(true);
					tenancyDataTabComponent.loadData();
					siteLevelPassiveAssetComponent.setVisible(false);
					documentsTabComponent.setVisible(false);
					ticketTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(siteLevelPassiveAssetTab)) {
					siteDetailTabComponent.setVisible(false);
					landAgreementTabComponent.setVisible(false);
					tenancyDataTabComponent.setVisible(false);
					siteLevelPassiveAssetComponent.setVisible(true);
					//Issue resolve for Passive Assets not being shown properly
					siteSelectionChangeHandler();
					documentsTabComponent.setVisible(false);
					ticketTabComponent.setVisible(false);
				}
				else if (event.getSelectedTab().equals(documentsTab)) {
					siteDetailTabComponent.setVisible(false);
					landAgreementTabComponent.setVisible(false);
					tenancyDataTabComponent.setVisible(false);
					siteLevelPassiveAssetComponent.setVisible(false);
					ticketTabComponent.setVisible(false);
					documentsTabComponent.setVisible(true);
					documentsTabComponent.setParent(parent);
					documentsTabComponent.populateDocumentsRow(parent,siteMasterComponent.getSelectedSiteCode());
				}
				else if (event.getSelectedTab().equals(siteLevelTicketTab)) {
					siteDetailTabComponent.setVisible(false);
					landAgreementTabComponent.setVisible(false);
					tenancyDataTabComponent.setVisible(false);
					siteLevelPassiveAssetComponent.setVisible(false);
					documentsTabComponent.setVisible(false);
					ticketTabComponent.setVisible(true);
					ticketTabComponent.setSiteCode(getSelectedSiteCode());
					ticketTabComponent.displayWorkflows();
				}
			}
		});
		
		//site level passive assets
		siteLevelPassiveAssetTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if (event.getSelectedTab().equals(acParentAssetTab)) {
					acParentAssetTabComponent.setVisible(true);
					acParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("AC_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
					batteryParentAssetTabComponent.setVisible(false);
					dgParentAssetTabComponent.setVisible(false);
					gridPowerParentAssetTabComponent.setVisible(false);
					solarParentAssetTabComponent.setVisible(false);
					rectifierParentAssetTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(batteryParentAssetTab)) {
					acParentAssetTabComponent.setVisible(false);
					batteryParentAssetTabComponent.setVisible(true);
					batteryParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("BATTERY_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
					dgParentAssetTabComponent.setVisible(false);
					gridPowerParentAssetTabComponent.setVisible(false);
					solarParentAssetTabComponent.setVisible(false);
					rectifierParentAssetTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(dgParentAssetTab)) {
					acParentAssetTabComponent.setVisible(false);
					batteryParentAssetTabComponent.setVisible(false);
					dgParentAssetTabComponent.setVisible(true);
					dgParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("DG_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
					gridPowerParentAssetTabComponent.setVisible(false);
					solarParentAssetTabComponent.setVisible(false);
					rectifierParentAssetTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(gridPowerParentAssetTab)) {
					acParentAssetTabComponent.setVisible(false);
					batteryParentAssetTabComponent.setVisible(false);
					dgParentAssetTabComponent.setVisible(false);
					gridPowerParentAssetTabComponent.setVisible(true);
					gridPowerParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("GRID_POWER_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
					solarParentAssetTabComponent.setVisible(false);
					rectifierParentAssetTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(solarParentAssetTab)) {
					acParentAssetTabComponent.setVisible(false);
					batteryParentAssetTabComponent.setVisible(false);
					dgParentAssetTabComponent.setVisible(false);
					gridPowerParentAssetTabComponent.setVisible(false);
					solarParentAssetTabComponent.setVisible(true);
					solarParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("SOLAR_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
					rectifierParentAssetTabComponent.setVisible(false);
				} else if (event.getSelectedTab().equals(rectifierParentAssetTab)) {
					acParentAssetTabComponent.setVisible(false);
					batteryParentAssetTabComponent.setVisible(false);
					dgParentAssetTabComponent.setVisible(false);
					gridPowerParentAssetTabComponent.setVisible(false);
					solarParentAssetTabComponent.setVisible(false);
					rectifierParentAssetTabComponent.setVisible(true);
					rectifierParentAssetTabComponent
							.loadData(ApplicationConfiguration.getConfigurationValue("RECTIFIER_PARENT_ASSET_CSV"), siteMasterComponent.getSelectedSiteCode());
				} 
			}
		});
		
		siteMasterComponent.loadData(ApplicationConfiguration.getConfigurationValue("SITE_MASTER_CSV"), "");
		
		siteMapViewComponent.loadData(ApplicationConfiguration.getConfigurationValue("SITE_MASTER_CSV"), "");		
				
		masterContainerDiv.add(/* siteViewTabs, */siteMasterComponent, siteMapViewComponent);
		
		siteMapViewComponent.setVisible(false);
		//siteListViewTab.setSelected(true);
		
		childContainerDiv.add(childTabs, siteDetailTabComponent, landAgreementTabComponent, tenancyDataTabComponent,
				siteLevelPassiveAssetComponent, ticketTabComponent, documentsTabComponent);
		
		siteLevelPassiveAssetTypeTabDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LEVEL_PASSIVE_ASSET_TYPE_TAB_DIV");
		siteLevelPassiveAssetTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITE_LEVEL_PASSIVE_ASSET_TYPE_TAB_LBL");
		siteLevelPassiveAssetTypeTabDiv.add(siteLevelPassiveAssetTypeLbl, siteLevelPassiveAssetTabs);
		
		siteLevelPassiveAssetComponent.add(siteLevelPassiveAssetTypeTabDiv, acParentAssetTabComponent,
				batteryParentAssetTabComponent, dgParentAssetTabComponent, gridPowerParentAssetTabComponent,
				solarParentAssetTabComponent, rectifierParentAssetTabComponent);
		siteLevelPassiveAssetTabs.setOrientation(Orientation.VERTICAL);
		
		siteMasterTabComponent = UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_MASTER_TAB_COMPONENT");
		passiveAssetMasterTabComponent = new PassiveAssetMaster();
		siteLevelPassiveAssetTabs.setSelectedTab(acParentAssetTab);
		acParentAssetTabComponent.setVisible(true);
		acParentAssetTabComponent.loadData(
				ApplicationConfiguration.getConfigurationValue("AC_PARENT_ASSET_CSV"),
				siteMasterComponent.getSelectedSiteCode());
		parentTabs = new Tabs();
		parentTabs.addClassName(SCREENCD + "_PARENT_TABS");
		siteMasterTab = new Tab("Site View");
		assetMasterTab = new Tab("Asset View");
		parentTabs.add(siteMasterTab, assetMasterTab);
		
		//add(screenTitle, masterContainerDiv, childContainerDiv);
		
		siteMasterTabComponent.add(masterContainerDiv, childContainerDiv);
		
		Div parentTabsContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PARENT_TABS_CONTAINER_DIV");
		toggleSiteMapView = UIFieldFactory.createCheckbox(false, true, SCREENCD, "TOGGLE_SITE_MAP_VIEW");
		parentTabsContainerDiv.add(parentTabs, toggleSiteMapView);
		add(parentTabsContainerDiv, siteMasterTabComponent, passiveAssetMasterTabComponent);
		
		passiveAssetMasterTabComponent.setVisible(false);
		
		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(siteMasterTab)) {
					siteMasterTabComponent.setVisible(true);
					toggleSiteMapView.setVisible(true);
					passiveAssetMasterTabComponent.setVisible(false);
				} else if(event.getSelectedTab().equals(assetMasterTab)) {
					siteMasterTabComponent.setVisible(false);
					toggleSiteMapView.setVisible(false);
					passiveAssetMasterTabComponent.setVisible(true);
				}
			}
		});
		
		toggleSiteMapView.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Boolean>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Boolean> event) {
				if (event.getValue()) {
					siteMapViewComponent.setVisible(true);
					siteMasterComponent.setVisible(false);
					siteMapViewComponent.setSelectedSite(siteMasterComponent.getSelectedSiteCode());
				} else {
					siteMapViewComponent.setVisible(false);
					siteMapViewComponent.closeMarkerInfoWindow();
					siteMasterComponent.setVisible(true);
				}
			}
		});
					
		addClassName(SCREENCD + "_MAIN_LAYOUT");
	}
	
	public void setSelectedSite(String siteCode) {
		siteMasterComponent.setSelectedSite(siteCode);
	}
	
	public String getSelectedSiteCode() {
		return siteMasterComponent.getSelectedSiteCode();
	}
	
	public void siteSelectionChangeHandler() {
		
		/*if(siteViewTabs.getSelectedTab().equals(siteListViewTab)) {
			
		} else if (siteViewTabs.getSelectedTab().equals(siteMapViewTab)) {*/
			
		//}
		
		if (childTabs.getSelectedTab().equals(detailTab)) {
			siteDetailTabComponent.loadData(ApplicationConfiguration.getConfigurationValue("SITE_DETAIL_CSV"),
					siteMasterComponent.getSelectedSiteCode());
		} else if (childTabs.getSelectedTab().equals(landAgreementTab)) {
			landAgreementTabComponent.loadData(ApplicationConfiguration.getConfigurationValue("LAND_AGREEMENT_CSV"),
					siteMasterComponent.getSelectedSiteCode());
		} else if (childTabs.getSelectedTab().equals(tenancyDataTab)) {
			tenancyDataTabComponent.loadData();
		} else if (childTabs.getSelectedTab().equals(siteLevelPassiveAssetTab)) {
			if (siteLevelPassiveAssetTabs.getSelectedTab().equals(acParentAssetTab)) {
				acParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("AC_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(batteryParentAssetTab)) {
				batteryParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("BATTERY_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(dgParentAssetTab)) {
				dgParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("DG_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(dgOperatorDataTab)) {
				dgOperatorDataTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("DG_OPERATOR_DATA_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(gridPowerParentAssetTab)) {
				gridPowerParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("GRID_POWER_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(gridPowerOperatorDataTab)) {
				gridPowerOperatorDataTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("GRID_POWER_OPERATOR_DATA_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(solarParentAssetTab)) {
				solarParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("SOLAR_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(solarOperatorDataTab)) {
				solarOperatorDataTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("SOLAR_OPERATOR_DATA_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(rectifierParentAssetTab)) {
				rectifierParentAssetTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("RECTIFIER_PARENT_ASSET_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			} else if (siteLevelPassiveAssetTabs.getSelectedTab().equals(rectifierOperatorDataTab)) {
				rectifierOperatorDataTabComponent.loadData(
						ApplicationConfiguration.getConfigurationValue("RECTIFIER_OPERATOR_DATA_CSV"),
						siteMasterComponent.getSelectedSiteCode());
			}
		}
		else if (childTabs.getSelectedTab().equals(siteLevelTicketTab)) {
			ticketTabComponent.setSiteCode(getSelectedSiteCode());
			ticketTabComponent.displayWorkflows();
		}
		else if (childTabs.getSelectedTab().equals(documentsTab))
		{
			documentsTabComponent.setParent(parent);
			documentsTabComponent.populateDocumentsRow(parent,siteMasterComponent.getSelectedSiteCode());
		}
	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) {
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Site Asset Inventory");
		SiteAssetInventoryUIFramework.getFramework().setCurrentPath(event.getLocation().getPathWithQueryParameters());
	}
}
