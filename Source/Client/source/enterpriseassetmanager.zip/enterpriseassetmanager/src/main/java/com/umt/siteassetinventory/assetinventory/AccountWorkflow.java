package com.umt.siteassetinventory.assetinventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

@CssImport("./styles/account_workflow-styles.css")
public class AccountWorkflow extends VerticalLayout {

	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "ACCOUNT_WORKFLOW";

	protected VerticalLayout troubleticketTableVL;

	protected Div troubleticketListVL;

	private String siteCode = ""; 

	private JSONArray allWorkflows;

	private JSONArray troubleTickets;

	private JSONArray workflowDtl;

	private WorkflowDetails workflowDetails;

	private List<String> troubleTicketNameList;

	private HashMap<String, JSONObject> troubleTicketNameDetailMap;


	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public AccountWorkflow(SiteMaster parent) {
		this.siteCode = parent.getSelectedSiteCode();
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		troubleticketTableVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "WORKFLOW_TABLE_VL");
		troubleticketListVL = UIHtmlFieldFactory.createDiv(SCREENCD, "WORKFLOW_LIST_VL");

		Button raiseTicketBtn = UIFieldFactory.createButton(SCREENCD, "RAISE_TICKET_BTN");
		add(raiseTicketBtn,troubleticketTableVL);

		raiseTicketBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				RaiseTicketDialog raiseTktDlg = new RaiseTicketDialog(siteCode, troubleTicketNameList, troubleTicketNameDetailMap);
				raiseTktDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						// TODO Auto-generated method stub
						if(!event.isOpened()) {
							RaiseTicketDialog dlg = (RaiseTicketDialog)event.getSource();
							if(dlg.isNewTicketCreated()) {
								displayWorkflows();
							}
						}
					}
				});
			}
		});

		Div workflowHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "WORKFLOW_HEADER_DIV");

		Div headerDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV_1");
		Div headerDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV_2");
		Div headerDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV_3");
		Div headerDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV_4");
		Label idLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ID_LBL");
		headerDiv1.add(idLbl);
		Label nameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NAME_LBL");
		headerDiv2.add(nameLbl);
		Label statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		headerDiv3.add(statusLbl);

		workflowHeaderDiv.add(headerDiv1, headerDiv2, headerDiv3, headerDiv4);
		nameLbl.setText("Incident Name");
		troubleticketTableVL.add(workflowHeaderDiv,troubleticketListVL);

	}

	protected void displayWorkflows()
	{
		troubleTickets = new JSONArray();
		troubleTicketNameList = new ArrayList<String>();
		troubleTicketNameDetailMap = new HashMap<>();

		allWorkflows = retrieveSiteWorkOrders();
		workflowDtl = workflows();

		for (int i = 0; i < workflowDtl.length(); i++) {
			try {
				JSONObject eachWorkflowDtl = workflowDtl.getJSONObject(i);
				JSONObject properties = eachWorkflowDtl.getJSONObject("properties");
				if (properties.has("AssetTroubleTicket") && properties.getString("AssetTroubleTicket")!=null && properties.getString("AssetTroubleTicket").trim().equalsIgnoreCase("true")) {
					troubleTicketNameList.add(eachWorkflowDtl.getString("workflow"));
					troubleTicketNameDetailMap.put(eachWorkflowDtl.getString("workflow"), eachWorkflowDtl);
				}
				////System.out.println("Workflow dtl  "+eachWorkflowDtl.getString("workflow"));
				for (int j = 0; j < allWorkflows.length(); j++) {
					JSONObject eachWorkflow = allWorkflows.getJSONObject(j);
					////System.out.println("Workflow  "+eachWorkflow.getString("Workflow"));
					if (eachWorkflowDtl.getString("workflow").equalsIgnoreCase(eachWorkflow.getString("Workflow")))
					{
						////System.out.println(eachWorkflowDtl.getString("workflow")+"=="+eachWorkflow.getString("Workflow"));
						if (properties.has("AssetTroubleTicket") && properties.getString("AssetTroubleTicket")!=null && properties.getString("AssetTroubleTicket").trim().equalsIgnoreCase("true")) 
						{
							troubleTickets.put(eachWorkflow);
						}
					}
				} 
			}
			catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//workflows = retrieveAccountWorkflows();
		//////System.out.println("workflows="+workflows.toString());
		//System.out.println("troubleTickets="+troubleTickets.toString());
		populateWorkflows();
	}

	protected void populateWorkflows() {
		JSONArray data = new JSONArray();	
		troubleticketListVL.removeAll();
		data = troubleTickets;
		////System.out.println("data="+data.toString());
		for(int i = 0; i < data.length(); i++) {
			try {
				JSONObject eachWorkflow = data.getJSONObject(i);
				createWorkflowRow(eachWorkflow);
			}
			catch (Exception ex) {
				ex.printStackTrace();
			}			
		}
	}

	protected JSONArray retrieveFieldForceOrders() {
		JSONArray retVal = new JSONArray();
		String fieldforceEndpoint = ApplicationConfiguration.getServiceEndpoint("GETFIELDFORCEORDERS");
		//System.out.println(fieldforceEndpoint);
		try {
			String fieldforceDetails = RestServiceHandler.retriveJSON_GET(fieldforceEndpoint, SiteAssetInventoryUIFramework.getFramework().getToken());
			retVal = new JSONArray(fieldforceDetails);
			//System.out.println(fieldforceEndpoint+":::"+retVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retVal;
	}
	
	protected JSONArray retrieveSiteWorkOrders() {
		JSONArray retVal = new JSONArray();
		String workflowEndpoint = ApplicationConfiguration.getServiceEndpoint("GETSITEWORKORDERS");
		workflowEndpoint = workflowEndpoint + "?SiteCode=" + this.siteCode;
		//////System.out.println(workflowEndpoint);
		try {
			String workflowDetails = RestServiceHandler.retriveJSON_GET(workflowEndpoint, SiteAssetInventoryUIFramework.getFramework().getToken());
			retVal = new JSONArray(workflowDetails);
			//System.out.println(workflowEndpoint+":::"+retVal);
		} catch (Exception e) {
			//e.printStackTrace();
			e.printStackTrace();
		}
		return retVal;
	}

	protected JSONArray workflows() {
		JSONArray retVal = new JSONArray();
		String workflowEndpoint = ApplicationConfiguration.getServiceEndpoint("WORKFLOWS");
		try {
			String workflowDetails = RestServiceHandler.retriveJSON_GET(workflowEndpoint, SiteAssetInventoryUIFramework.getFramework().getToken());
			retVal = new JSONArray(workflowDetails);
			//System.out.println(workflowEndpoint+":::"+retVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retVal;
	}

	private void createWorkflowRow(JSONObject eachWorkflow) {
		Div eachWorkflowHL = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_WORKFLOW_HL");
		try {
			int status = eachWorkflow.getInt("Status");
			String instanceId = eachWorkflow.getString("instanceid");
			//System.out.println(workflowOrTroubleticket+"eachWorkflow="+eachWorkflow.toString());

			Div valueDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV_1");
			Div valueDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV_2");
			Div valueDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV_3");
			Div valueDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV_4");
			Label idValue = UIHtmlFieldFactory.createLabel(instanceId, SCREENCD, "ID_VALUE");
			valueDiv1.add(idValue);
			Label nameValue = UIHtmlFieldFactory.createLabel(eachWorkflow.getString("Workflow"), SCREENCD, "NAME_VALUE");
			valueDiv2.add(nameValue);

			Label statusValue = UIHtmlFieldFactory.createLabel(CommonUtils.getWorkflowStatusName(status), SCREENCD, "STATUS_VALUE");
			valueDiv3.add(statusValue);

			Button viewBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
			valueDiv4.add(viewBtn);

			/*if (status==2) {
				viewBtn.setEnabled(false);
			}*/

			eachWorkflowHL.add(valueDiv1, valueDiv2,valueDiv3,valueDiv4);
			troubleticketListVL.add(eachWorkflowHL);

			viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() 
			{
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) 
				{

					try
					{
						String strJsonWorkflow = "";
						if (status==1) {
							String ServiceEndpoint = ApplicationConfiguration.getServiceEndpoint("GET_WORKFLOWSDETAILS");
							//System.out.println("ServiceEndpoint>>>>"+ServiceEndpoint+instanceId);
							strJsonWorkflow = RestServiceHandler.retriveJSON_GET(ServiceEndpoint+instanceId, SiteAssetInventoryUIFramework.getFramework().getToken());
							//System.out.println("ServiceEndpoint>>>>"+ServiceEndpoint+" ? "+instanceId+" ::::: "+strJsonWorkflow);
						}
						else {
							JSONObject wfmDataJson = new JSONObject(eachWorkflow.getString("WFMData"));
							//System.out.println("WFMData:::"+instanceId+" ::::: "+wfmDataJson);
							JSONObject resultJson = new JSONObject(wfmDataJson.getString("result"));
							strJsonWorkflow = resultJson.getString("instance");
							//System.out.println("Workflow:::"+instanceId+" ::::: "+strJsonWorkflow);
						}
						workflowDetails = new WorkflowDetails(strJsonWorkflow, siteCode, status);
					}
					catch (Exception ex) 
					{
						ex.printStackTrace();
						String msg = SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "ERRORMSG_FOR_INSTANCEID");
						msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
						Dialog dialog = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.ERROR);
					}


				}

			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

