package com.umt.siteassetinventory.site;

import com.umt.siteassetinventory.assets.AssetListMapView;
import com.umt.siteassetinventory.assets.AssetsView;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.landlord.LandlordListMapView;
import com.umt.siteassetinventory.landlord.LandlordView;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/site-view.css")
public class SiteListMapViewDialog extends Dialog{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "VIEW_SITE_MAP_DLG";
	private Div titleBar;
	private Div buttonBar,row1Div;
	private Div bodyDiv,bodyDiv1;
	private Div mainLayout,closeBtnDiv;
	private Button cancelBtn;
	private TextField radiusField;
	
	public SiteListMapViewDialog(SiteView parent, String selectedSitecode, AssetsView parent2,LandlordView parent3, String dialogType)
	{
		//System.out.println("dlgselectedSitecode="+selectedSitecode);
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV1");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl,closeBtnDiv);
		
		Div closeIconDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_ICON_DIV");
		Icon closeIcon = VaadinIcon.CLOSE_SMALL.create();
		closeIcon.addClassName(SCREENCD+"_CLOSE_ICON");
		closeIconDiv.add(closeIcon);
		
		row1Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW1_DIV");
		radiusField= UIFieldFactory.createTextField("", true, SCREENCD,"RADIUS_FIELD");
		radiusField.setPlaceholder("Type radius");
		row1Div.add(radiusField,closeIconDiv);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
	//	buttonBar.add(cancelBtn);
		
		if(dialogType.equalsIgnoreCase("Site_view"))
		{
			SiteListMapView mapview=new SiteListMapView(parent);
		//	mapview.populateSiteDetails();
			mapview.populateSiteDetails1(parent.sitelistresponse);
			mapview.setSelectedSite(selectedSitecode);
			bodyDiv1.add(mapview);
		}
		if(dialogType.equalsIgnoreCase("Asset_view"))
		{
			AssetListMapView mapview=new AssetListMapView(parent2);
			mapview.populateAssetDetails(parent2.assetlistresponse);
			mapview.setSelectedSite(selectedSitecode);
			bodyDiv1.add(mapview);
		}
		if(dialogType.equalsIgnoreCase("Landlord_view"))
		{
			LandlordListMapView mapview=new LandlordListMapView(parent3);
			mapview.populateLandlordDetails(parent3.landlordlistresponse);
			mapview.setSelectedSite(selectedSitecode);
			bodyDiv1.add(mapview);
		}
		
		bodyDiv.add(bodyDiv1);
		
		
		mainLayout.add(row1Div,bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();
		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		
		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});
		closeIconDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				radiusField.clear();
			}
		});
	}

}
