package com.umt.siteassetinventory.application;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/base_dialog_popup-style.css")
public abstract class BaseDialogPopup extends Dialog{
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "BASE_DESIGN_DIALOG";
	private Button cancel_btn;
	public Button save_btn;
	private Image closeIcon;
	public Div footer;
	public Button saveAsDraft_btn,clearDraft_btn;
	

	public BaseDialogPopup(String title, Component component) {
		
		Div header = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Label headerTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_TITILE_LBL");
		headerTitle.setText(title);
		closeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_ICON");
		header.add(headerTitle, closeIcon);
		
		Div body = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		body.add(component);
		
		footer = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_DIV"); 
		save_btn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancel_btn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		saveAsDraft_btn = UIFieldFactory.createButton(SCREENCD, "SAVE_DRAFT_BTN");
		saveAsDraft_btn.setVisible(false);
		clearDraft_btn = UIFieldFactory.createButton(SCREENCD, "CLEAR_DRAFT_BTN");
		clearDraft_btn.setVisible(false);
		
		footer.add(saveAsDraft_btn,clearDraft_btn,save_btn, cancel_btn);
		
		
		add(header, body, footer);
		setWidth("890px");
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnOutsideClick(false);
		open();
		
		
		closeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Image> event) {
			close();
				
			}
		});
		cancel_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
				
			}
		});
		
		save_btn.setDisableOnClick(true);
		save_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveOperartion();
				
			}
		});


	}

	public abstract void saveOperartion();
	
	
	public void setButtonText(String name) {
		save_btn.setText(name);
	}
	public void setButtonEnable(Boolean enable) {
		save_btn.setEnabled(enable);
	}
	
	
	
	public void closeDialog() {
		close();
	}
	
	
	

}
