package com.umt.siteassetinventory.site;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.LocalStorage;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;


public class AddSiteAgreementPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddSiteAgreement addSiteAgreement;
	private String screencd;
	private boolean dataSaved;
	private SiteAgreementsTab viewSiteAgreementsTab;
	private boolean addOrEdit, noChange = true;
	private String KEY_NAME = "ADD_AGREEMENT_FORMVALUE";


	public AddSiteAgreementPopup(String title, boolean addOrEdit, Component component, SiteAgreementsTab siteAgreementsTab, String screencd) {

		super(title, component);
		setWidth("800px");
		this.addSiteAgreement = (AddSiteAgreement) component;
		this.viewSiteAgreementsTab = siteAgreementsTab;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
		
		
		if (addOrEdit) {//add
			saveAsDraft_btn.setVisible(true);
			clearDraft_btn.setVisible(true);
			saveAsDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					saveAsDraft();
				}
			});

			clearDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					clearDraft();
				}
			});
		}
	}
	
	private void saveAsDraft() {
		try {
			JSONObject formvalue=new JSONObject();
			
			JSONObject agreementDetailsJson = new JSONObject();
			addSiteAgreement.getFormValues();
		
			agreementDetailsJson.put("Name", addSiteAgreement.getAgreementName());
			agreementDetailsJson.put("AgreementDate", addSiteAgreement.getAgreementDate());
			agreementDetailsJson.put("StartDate", addSiteAgreement.getStartDate());
			agreementDetailsJson.put("EndDate", addSiteAgreement.getEndDate());
			agreementDetailsJson.put("Type", addSiteAgreement.getAgreementType());
			
			JSONObject fileDetailsJson = new JSONObject();
			fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
			fileDetailsJson.put("Type", "Agreements");
			fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
		//	fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
			fileDetailsJson.put("Content", "");
			agreementDetailsJson.put("FileDetails", fileDetailsJson);
			
			formvalue.put("SiteCode", viewSiteAgreementsTab.getSiteCode());
			formvalue.put("AgreementDetails", agreementDetailsJson);
			formvalue.put("AgreementAttribute", addSiteAgreement.getTempAgreementAttributesJson());
			
			CommonUtils.insertDraftData("2", formvalue.toString(), "Agreement data saved as draft");
			System.out.println("saveAsDraft Agreement::::::::::"+formvalue);
			
		/*	LocalStorage.setItem(KEY_NAME,formvalue.toString());
			LocalStorage.showStoredValue(KEY_NAME);
			SiteAssetInventoryUIFramework.getFramework().showMessage("Agreement saved as draft", ApplicationConstants.DialogTypes.INFO);
		*/
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	private void clearDraft() {
	//	LocalStorage.removeItem(KEY_NAME);
	//	LocalStorage.showStoredValue(KEY_NAME);
		CommonUtils.resetDraftData("2", "Agreement data reset successfully");
		addSiteAgreement.resetFormValue();
	}
	


/*	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addSiteAgreement.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDSITEAGREEMENT");
					JSONObject agreementDetailsJson = new JSONObject();
					agreementDetailsJson.put("Name", addSiteAgreement.getAgreementName());
					agreementDetailsJson.put("AgreementDate", addSiteAgreement.getAgreementDate());
					agreementDetailsJson.put("StartDate", addSiteAgreement.getStartDate());
					agreementDetailsJson.put("EndDate", addSiteAgreement.getEndDate());
					//agreementDetailsJson.put("AgreementType", addSiteAgreement.getAgreementType());
					agreementDetailsJson.put("Type", addSiteAgreement.getAgreementType());
					JSONObject fileDetailsJson = new JSONObject();
					fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
					fileDetailsJson.put("Type", "Agreements");
					fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
					fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
					agreementDetailsJson.put("FileDetails", fileDetailsJson);
					//					agreementDetailsJson.put("PaymentFrequency", CommonUtils.getPaymentFrequency(addSiteAgreement.getPaymentFrequency())+"");
					//					agreementDetailsJson.put("PaymentAmount", addSiteAgreement.getPaymentAmt());
					//					agreementDetailsJson.put("PaymentUnit", CommonUtils.getEscalationOrPaymentUnit(addSiteAgreement.getPaymentType()));
					//					agreementDetailsJson.put("PaymentMode", CommonUtils.getPaymentMode(addSiteAgreement.getPaymentMode()));
					//					agreementDetailsJson.put("EscalationFrequency", CommonUtils.getEscalationFrequency(addSiteAgreement.getEscalationFrequency()));
					//					agreementDetailsJson.put("EscalationUnit", CommonUtils.getEscalationOrPaymentUnit(addSiteAgreement.getEscalationType()));
					//					agreementDetailsJson.put("EscalationAmount", addSiteAgreement.getEscalationAmt());

					Form formData = new Form();
					formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
					formData.add("agreementDetails", agreementDetailsJson);
					
					System.out.println("formData1:: " + formData);
				//	System.out.println(" agreementDetails1:: " + agreementDetailsJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					addSiteAgreement.enableDetailsTab(response);
					//closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "AGREEMENT_SAVE_SUCCESSFUL");
					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);	
					addOrEdit = false;
					noChange = false;
				}
				else
				{
					if (!addSiteAgreement.getAgreementName().equals(addSiteAgreement.getExistingAgreementName()) || 
							!addSiteAgreement.getAgreementDocDesc().equals(addSiteAgreement.getExistingFileDesc()) || 
							addSiteAgreement.getAgreementFileName().trim().length()>0) {
						String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATESITEAGREEMENT");
						JSONObject agreementDetailsJson = new JSONObject();
						agreementDetailsJson.put("AgreementId", addSiteAgreement.getAgreementId());
						agreementDetailsJson.put("Name", addSiteAgreement.getAgreementName());
						agreementDetailsJson.put("AgreementDate", addSiteAgreement.getAgreementDate());
						agreementDetailsJson.put("StartDate", addSiteAgreement.getStartDate());
						agreementDetailsJson.put("EndDate", addSiteAgreement.getEndDate());
					//	agreementDetailsJson.put("AgreementType", addSiteAgreement.getAgreementType());
						agreementDetailsJson.put("Type", addSiteAgreement.getAgreementType());
						if (addSiteAgreement.getAgreementFileName().trim().length()>0) {
							JSONObject fileDetailsJson = new JSONObject();
							fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
							fileDetailsJson.put("Type", "Agreements");
							fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
							fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
							agreementDetailsJson.put("FileDetails", fileDetailsJson);
						}
						Form formData = new Form();
						formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
						formData.add("agreementDetails", agreementDetailsJson);

						//System.out.println(base_URL+" input:: " + formData.toString());
						String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
						//System.out.println("Update:" + response);
						//closeDialog();
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "AGREEMENT_UPDATE_SUCCESSFUL");
						noChange = false;
					}

					//					agreementDetailsJson.put("PaymentFrequency", CommonUtils.getPaymentFrequency(addSiteAgreement.getPaymentFrequency())+"");
					//					agreementDetailsJson.put("PaymentAmount", addSiteAgreement.getPaymentAmt());
					//					agreementDetailsJson.put("PaymentUnit", CommonUtils.getEscalationOrPaymentUnit(addSiteAgreement.getPaymentType()));
					//					agreementDetailsJson.put("PaymentMode", CommonUtils.getPaymentMode(addSiteAgreement.getPaymentMode()));
					//					agreementDetailsJson.put("EscalationFrequency", CommonUtils.getEscalationFrequency(addSiteAgreement.getEscalationFrequency()));
					//					agreementDetailsJson.put("EscalationUnit", CommonUtils.getEscalationOrPaymentUnit(addSiteAgreement.getEscalationType()));
					//					agreementDetailsJson.put("EscalationAmount", addSiteAgreement.getEscalationAmt());


					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);	
				}
				if (addSiteAgreement.isDetailsTabEnabled() && !addSiteAgreement.getAgreementAttributesJson().toString().
						equals(addSiteAgreement.getExistingAgreementAttributesJson().toString())) {
					if (addSiteAgreement.getAgreementAttributesJson()!=null && addSiteAgreement.getAgreementAttributesJson().length()>0) {
						String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEAGREEMENTATTRIBUTES");
						Form formData = new Form();
						formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
						formData.add("AgreementId", addSiteAgreement.getAgreementId());
						formData.add("AgreementAttributes", addSiteAgreement.getAgreementAttributesJson());

						//System.out.println(base_URL+" input:: " + formData.toString());
						String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
						if (noChange) {
							SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "AGREEMENT_ATTRIBUTE_UPDATE_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
							noChange = false;
						}	
						
			//			System.out.println("click3");
					}				
				}
				if (msg.trim().length()>0) {
					Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;


						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							if(!event.isOpened()) {
								dataSaved = true;

								//close();	
							}
						}
					});
				}
				if (noChange)
				{
					SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "NO_DATA_CHANGED", ApplicationConstants.DialogTypes.INFO);
				}
				else {
					closeDialog();				
					viewSiteAgreementsTab.refreshData();
				}
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}*/
	
	@Override
	public void saveOperartion() {//new implemnted 21/04/2023
	String msg= "";
		try {
			if (addSiteAgreement.validation2()) {
				if (addOrEdit) {//add
				
			//		save_btn.setEnabled(false);
					JSONObject agreementDetailsJson = new JSONObject();
					agreementDetailsJson.put("Name", addSiteAgreement.getAgreementName());
					agreementDetailsJson.put("AgreementDate", addSiteAgreement.getAgreementDate());
					agreementDetailsJson.put("StartDate", addSiteAgreement.getStartDate());
					agreementDetailsJson.put("EndDate", addSiteAgreement.getEndDate());
					agreementDetailsJson.put("Type", addSiteAgreement.getAgreementType());
					JSONObject fileDetailsJson = new JSONObject();
					fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
					fileDetailsJson.put("Type", "Agreements");
					fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
					fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
					agreementDetailsJson.put("FileDetails", fileDetailsJson);
					
					Form formData = new Form();
					formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
					formData.add("agreementDetails", agreementDetailsJson);
					formData.add("AgreementAttribute", addSiteAgreement.getAgreementAttributesJson());
					
					System.out.println("agreementDetails==="+agreementDetailsJson);
					System.out.println("AgreementAttribute==="+addSiteAgreement.getAgreementAttributesJson());
					System.out.println("SiteCode==="+viewSiteAgreementsTab.getSiteCode());
					
		//			System.out.println("formData==="+formData.toString());
					
					String base_URL=ApplicationConfiguration.getServiceEndpoint("CREATE_UPDATE_SITE_AGREEMENT");
					RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "AGREEMENT_SAVE_SUCCESSFUL");
					CommonUtils.resetDraftData("2", "none");
					addOrEdit = false;
					noChange = false;
					
				}
				else
				{
			//		save_btn.setEnabled(false);
					boolean isupdatesiteagreementDoc=false;
					if (!addSiteAgreement.getAgreementName().equals(addSiteAgreement.getExistingAgreementName()) || 
							!addSiteAgreement.getAgreementDocDesc().equals(addSiteAgreement.getExistingFileDesc()) || 
							addSiteAgreement.getAgreementFileName().trim().length()>0) {
						System.out.println("click3");
						isupdatesiteagreementDoc=true;
						String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATESITEAGREEMENT");
						JSONObject agreementDetailsJson = new JSONObject();
						agreementDetailsJson.put("AgreementId", addSiteAgreement.getAgreementId());
						agreementDetailsJson.put("Name", addSiteAgreement.getAgreementName());
						agreementDetailsJson.put("AgreementDate", addSiteAgreement.getAgreementDate());
						agreementDetailsJson.put("StartDate", addSiteAgreement.getStartDate());
						agreementDetailsJson.put("EndDate", addSiteAgreement.getEndDate());
					//	agreementDetailsJson.put("AgreementType", addSiteAgreement.getAgreementType());
						agreementDetailsJson.put("Type", addSiteAgreement.getAgreementType());
//						if (addSiteAgreement.getAgreementFileContent().trim().length()<=0){
//							SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload document",DialogTypes.INFO);
//						}
						
						if (addSiteAgreement.getAgreementFileName().trim().length()>0) {//if uploaded doc
							JSONObject fileDetailsJson = new JSONObject();
							fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
							fileDetailsJson.put("Type", "Agreements");
							fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
							fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
							agreementDetailsJson.put("FileDetails", fileDetailsJson);
						}
//						JSONObject fileDetailsJson = new JSONObject();
//						fileDetailsJson.put("Name","");
//						fileDetailsJson.put("Type", "Agreements");
//						fileDetailsJson.put("Description", addSiteAgreement.getAgreementDocDesc());
//						fileDetailsJson.put("Content","");
//						
//						if(addSiteAgreement.getAgreementFileName().trim().length()>0) {
//							fileDetailsJson.put("Name", addSiteAgreement.getAgreementFileName());
//							fileDetailsJson.put("Content", addSiteAgreement.getBase64EncodedFileContent());
//						}
						
				//		agreementDetailsJson.put("FileDetails", fileDetailsJson);
						Form formData = new Form();
						formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
						formData.add("agreementDetails", agreementDetailsJson);
						formData.add("AgreementAttributes", addSiteAgreement.getAgreementAttributesJson());

				//		System.out.println(base_URL+" input:: " + formData.toString());
				//		System.out.println(base_URL+" input:: " + formData.toString());
						String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "AGREEMENT_UPDATE_SUCCESSFUL");
						CommonUtils.resetDraftData("2", "none");
						noChange = false;
						
					}
					
					if (isupdatesiteagreementDoc||
							(addSiteAgreement.isDetailsTabEnabled() && !addSiteAgreement.getAgreementAttributesJson().toString().
							equals(addSiteAgreement.getExistingAgreementAttributesJson().toString())
							)
					) 
					{
						if (addSiteAgreement.getAgreementAttributesJson()!=null && addSiteAgreement.getAgreementAttributesJson().length()>0) {
				
							System.out.println("click4");
							save_btn.setEnabled(false);
							String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEAGREEMENTATTRIBUTES");
							Form formData = new Form();
							formData.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
							formData.add("AgreementId", addSiteAgreement.getAgreementId());
							formData.add("AgreementAttributes", addSiteAgreement.getAgreementAttributesJson());

							//System.out.println(base_URL+" input:: " + formData.toString());
					//		System.out.println("formData:: " + formData.toString());
							String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
							if (noChange) {
							//	SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "AGREEMENT_ATTRIBUTE_UPDATE_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
								msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "AGREEMENT_ATTRIBUTE_UPDATE_SUCCESSFUL");
								CommonUtils.resetDraftData("2", "none");
								noChange = false;
							}	
						}				
					}
				}
				
				if (msg.trim().length()>0) {
					Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;


						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							if(!event.isOpened()) {
								dataSaved = true;

								closeDialog();				
								viewSiteAgreementsTab.refreshData();
								CommonUtils.resetDraftData("2", "none");
							}
						}
					});
				}
				
//				if (noChange)
//				{
//					SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "NO_DATA_CHANGED", ApplicationConstants.DialogTypes.INFO);
//				}
//				else {
//					closeDialog();				
//					viewSiteAgreementsTab.refreshData();
//				}
			}
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		//	save_btn.setEnabled(true);
		}
		finally {
			save_btn.setEnabled(true);
		}
	}
	
}
