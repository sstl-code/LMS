package com.umt.siteassetinventory;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/events_tab-styles.css")
public class EventsTab extends Div  {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EVENTS_TAB";
	private Div tableContainerBodyDiv, tableContainerDiv, detailsContainerBodyDiv, detailsContainerDiv;
	private String searchString, engineName;
	private List<Div> tableRowList = new ArrayList<>();
	private Label eventDetailLbl;
	private int slNo;

	public EventsTab(String searchString, String engineName) {
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.searchString=searchString;
		this.engineName=engineName;

		Label slNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SL_NO_LBL");
		Label eventIDLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_ID_LBL");
		Label eventTimeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_TIME_LBL");


		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");
		tableContainerBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_BODY_DIV");
		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");

		tableHeaderDiv.add(slNoLbl,eventIDLbl,eventTimeLbl);
		//populateData();

		tableContainerDiv.add(tableHeaderDiv,tableContainerBodyDiv);

		Div detailsHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_HEADER_DIV");
		eventDetailLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_DETAIL_LBL");
		detailsContainerBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_CONTAINER_BODY_DIV");
		detailsContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_CONTAINER_DIV");

		detailsHeaderDiv.add(eventDetailLbl);

		detailsContainerDiv.add(detailsHeaderDiv,detailsContainerBodyDiv);
		add(tableContainerDiv, detailsContainerDiv);
	}

	public void populateData() {
		try {
			tableContainerBodyDiv.removeAll();

			String resp = getAuditTrailRecords();

			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr = new JSONArray(resp);
				if(jsarr.length()>0) {
					slNo = jsarr.length();
					for(int i=0; i<jsarr.length(); i++) {
						Div tableRowDiv=createRows(slNo, jsarr.getJSONObject(i).getString("Activity"),
								jsarr.getJSONObject(i).getString("RecordDate"), jsarr.getJSONObject(i).getString("UserId"), 
								jsarr.getJSONObject(i).getString("Activity"), jsarr.getJSONObject(i).getString("ActivityParams"));
						tableContainerBodyDiv.add(tableRowDiv);
						slNo--;
					}
				}
			} 
			else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				tableContainerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				tableContainerBodyDiv.add(norecLbl);
			}

		}catch(Exception e) {
			e.printStackTrace();
		}

	}

	private String getAuditTrailRecords() {

		String resp="";
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETAUDITTRAILRECORDS");
			url=url+"?UserId=&StartDate=&EndDate=&Activity=&EngineName="+engineName+"&SearchString="+searchString;

			//System.out.println("url="+url);

			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
//			resp = "[{\"UserId\":\"abhra.chandra@ushamartintech.com\",\"Engine\":\"Landlord\",\"Activity\":\"updateLandlordEvent\",\"EventId\":"
//					+ "\"9404240a-c144-4577-be2c-ab588e05c481\",\"ActivityParams\":\"{\\\"LandlordId\\\":59,\\\"Name\\\":\\\"Kanchanben A Parmar\\\",\\\"Address\\\""
//					+ ":{\\\"Line1\\\":\\\"16/1GIbrahimpurRd.\\\",\\\"Line2\\\":\\\"Jadavpur\\\",\\\"PostalCode\\\":\\\"700102\\\",\\\"PoliceStation\\\":{\\\"Name\\\""
//					+ ":\\\"Regent Park\\\",\\\"Region\\\":\\\"South\\\",\\\"Email\\\":\\\"abc@xyz.com\\\"}},\\\"ContactNo\\\":\\\"9377430953\\\",\\\"Region\\\":"
//					+ "\\\"Ahmedabad\\\",\\\"Photo\\\":\\\"\\\",\\\"Email\\\":\\\"abc@xyz.com\\\"} \",\"RecordDate\":\"21-Apr-2023 09:30:02\"},"
//					+ "{\"UserId\":\"abhra.chandra@ushamartintech.com\",\"Engine\":\"Landlord\",\"Activity\":\"uploadFileEvent\",\"EventId\":"
//					+ "\"742012fb-60aa-4725-ac83-2b3d09dd2256\",\"ActivityParams\":\"{\\\"LandlordId\\\":59,\\\"Name\\\":\\\"Kanchanben A Parmar\\\",\\\"Address\\\":"
//					+ "{\\\"Line1\\\":\\\"16/1GIbrahimpurRd.\\\",\\\"Line2\\\":\\\"Jadavpur\\\",\\\"PostalCode\\\":\\\"700102\\\",\\\"PoliceStation\\\":{\\\"Name\\\":"
//					+ "{\\\"ID\\\":\\\"PORP\\\",\\\"Region\\\":\\\"South Region\\\",\\\"SP\\\":\\\"abc\\\"},\\\"Region\\\":\\\"South\\\",\\\"Email\\\":"
//					+ "\\\"abc@xyz.com\\\"}},\\\"ContactNo\\\":\\\"9377430953\\\",\\\"Region\\\":\\\"Ahmedabad\\\",\\\"Photo\\\":\\\"\\\",\\\"Email\\\":"
//					+ "\\\"abc@xyz.com\\\"}\",\"RecordDate\":\"13-Apr-2023 11:53:21\"},{\"UserId\":\"abhra.chandra@ushamartintech.com\","
//					+ "\"Engine\":\"Landlord\",\"Activity\":\"uploadFileEvent\",\"EventId\":\"0c524ec8-2d35-4d8b-ac43-c47b54c5c8b4\",\"ActivityParams\":"
//					+ "\"{\\\"LandlordId\\\":\\\"104\\\",\\\"FileUID\\\":\\\"f4f67ba7-b7fb-4849-9af3-4d95adc34e59\\\",\\\"Description\\\":\\\"PAN.jpg\\\","
//					+ "\\\"Type\\\":\\\"PAN Document\\\",\\\"Name\\\":\\\"PAN.jpg\\\"}\",\"RecordDate\":\"13-Apr-2023 11:53:21\"},{\"UserId\":"
//					+ "\"abhra.chandra@ushamartintech.com\",\"Engine\":\"Landlord\",\"Activity\":\"uploadFileEvent\",\"EventId\":\"fde2502f-0547-402f-99d3-0864ef5a3f13\","
//					+ "\"ActivityParams\":\"{\\\"LandlordId\\\":\\\"23\\\",\\\"FileUID\\\":\\\"8736884f-3cad-4e51-a593-aad67d9107fa\\\",\\\"Description\\\":"
//					+ "\\\"\\\",\\\"Type\\\":\\\"GST.png\\\",\\\"Name\\\":\\\"STIPL&DEL&139\\\"}\",\"RecordDate\":\"19-Mar-2023 07:56:20\"}]";
//			System.out.println("resp= "+resp);

		} catch(Exception e) {
			e.printStackTrace();
		}
		return resp;
	}

	private Div createRows(int slNo, String eventID, String eventTime, String userName, String eventName, String details) {

		Div tableRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_ROW_DIV");
		Label slNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN","SL_NO_LBL");
		Label eventIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "EVENT_ID_LBL");
		Label eventTimeLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "EVENT_TIME_LBL");

		slNoLbl.setText(slNo+"");
		eventIdLbl.setText(eventID);
		eventTimeLbl.setText(eventTime);

		tableRowDiv.add(slNoLbl,eventIdLbl,eventTimeLbl);
		tableRowList.add(tableRowDiv);

		tableRowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				for (Div otherDiv : tableRowList) {
					otherDiv.removeClassName(SCREENCD+"_TABLE_ROW_DIV_SELECTED");
				}
				tableRowDiv.addClassName(SCREENCD+"_TABLE_ROW_DIV_SELECTED");
				showEventDetails(eventID, eventTime, userName, eventName, details);
			}
		});

		return tableRowDiv;
	}

	private void showEventDetails(String eventID, String eventTime, String userName, String eventName, String activityParams) {
		try {
			detailsContainerBodyDiv.removeAll();
	//		String eventData="";

			eventDetailLbl.setText("Event Details: "+eventName);
			Div engineDataDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Label engineCaptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ENGINE_CAPTION_LBL");
			Label engineLbl = UIHtmlFieldFactory.createLabel(engineName, SCREENCD, "DATA_LBL");
			engineDataDiv.add(engineCaptionLbl, engineLbl);

			Div eventTimeDataDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Label eventTimeCaptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_TIME_CAPTION_LBL");
			Label eventTimeLbl = UIHtmlFieldFactory.createLabel(eventTime, SCREENCD, "DATA_LBL");
			eventTimeDataDiv.add(eventTimeCaptionLbl, eventTimeLbl);

			Div eventIDDataDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Label eventIDCaptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_ID_CAPTION_LBL");
			Label eventIDLbl = UIHtmlFieldFactory.createLabel(eventID, SCREENCD, "DATA_LBL");
			eventIDDataDiv.add(eventIDCaptionLbl, eventIDLbl);

			Div userNameDataDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Label userNameCaptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "USER_NAME_CAPTION_LBL");
			Label userNameLbl = UIHtmlFieldFactory.createLabel(userName, SCREENCD, "DATA_LBL");
			userNameDataDiv.add(userNameCaptionLbl, userNameLbl);

			Div eventDataDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EVENT_DATA_DIV");
			Label eventDataCaptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_DATA_CAPTION_LBL");
			Div eventDetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EVENT_DETAILS_DIV");
			eventDataDiv.add(eventDataCaptionLbl,eventDetailsDiv);

			JSONObject activityParamsJson = new JSONObject(activityParams);
//			Iterator<String> eventDataKeys = activityParamsJson.keys();
//			while (eventDataKeys.hasNext()) {
//				String eventDataKey = eventDataKeys.next();
//				eventData += eventDataKey+": "+activityParamsJson.get(eventDataKey)+"<br>";
//			}

			//TextArea eventDataTextArea = UIFieldFactory.createTextArea(eventData, true, SCREENCD, "EVENT_DATA_TEXT_AREA");
			//eventDataTextArea.setEnabled(false);

			eventDetailsDiv.getElement().setProperty("innerHTML", getJSONKeyValuePair(activityParamsJson, ""));

			detailsContainerBodyDiv.add(engineDataDiv, eventTimeDataDiv, eventIDDataDiv, userNameDataDiv, eventDataDiv);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getJSONKeyValuePair(JSONObject inputJson, String space) {
		String output = "";
		try {
			Iterator<String> eventDataKeys = inputJson.keys();
			while (eventDataKeys.hasNext()) {
				String eventDataKey = eventDataKeys.next();
				if((inputJson.get(eventDataKey)+"").startsWith("{") || (inputJson.get(eventDataKey)+"").startsWith("\"{")) {
					JSONObject keyJson = new JSONObject(inputJson.get(eventDataKey)+"");
					String keyValPair = getJSONKeyValuePair(keyJson, space+"&emsp;");
					output += space+eventDataKey+": "+"<br>"+keyValPair;
				}
				else if((inputJson.get(eventDataKey)+"").startsWith("[") || (inputJson.get(eventDataKey)+"").startsWith("\"[")) {
					JSONArray keyJA = new JSONArray(inputJson.get(eventDataKey)+"");
					for (int i = 0; i < keyJA.length(); i++) {
						JSONObject keyJson = keyJA.getJSONObject(i);
						String keyValPair = getJSONKeyValuePair(keyJson, space+"&emsp;");
						output += space+eventDataKey+": "+"<br>"+keyValPair+"<br>";
					}	
				}
				else {
					output += space+eventDataKey+": "+inputJson.get(eventDataKey)+"<br>";
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}
}

