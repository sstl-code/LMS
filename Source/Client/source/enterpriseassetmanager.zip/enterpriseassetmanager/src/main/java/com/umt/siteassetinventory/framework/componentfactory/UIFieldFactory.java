package com.umt.siteassetinventory.framework.componentfactory;

import java.time.LocalDate;
import java.util.List;

import org.vaadin.gatanaso.MultiselectComboBox;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.resourcemanager.ResourceUtil;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.textfield.EmailField;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.timepicker.TimePicker;
import com.vaadin.flow.router.RouterLink;

public class UIFieldFactory {
	public static TextField createTextField(String initialvalue, boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		TextField txtfld = new TextField(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), initialvalue,
				ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		txtfld.setRequired(mandatory);
		txtfld.setRequiredIndicatorVisible(mandatory);
		txtfld.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		
		String txtfldInputPattern = ApplicationConfiguration.getConfigurationValue("TEXT_FIELD_INPUT_PATTERN");
		if(txtfldInputPattern != null && txtfldInputPattern.trim().length() > 0) {
			txtfld.setPattern(txtfldInputPattern);
			txtfld.setPreventInvalidInput(true);
		}
				
		return txtfld;
	}
	
	public static NumberField createNumberField(boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		NumberField numfld = new NumberField(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), 
				ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		numfld.setRequiredIndicatorVisible(mandatory);
		numfld.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		
		return numfld;
	}


	public static EmailField createEmailField(String initialvalue, boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		EmailField email = new EmailField(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		email.setRequiredIndicatorVisible(mandatory);
		email.setValue(initialvalue);
		email.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return email;
	}

	public static PasswordField createPasswordField(boolean mandatory, String screencd, String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		PasswordField password = new PasswordField(ResourceUtil.getConfiguredValueAt(configuredvalues, 0),
				ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		password.setRequired(mandatory);
		password.setRequiredIndicatorVisible(mandatory);
		password.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return password;
	}

	public static Button createButton(String screencd, String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
		Button button = new Button(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		button.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return button;
	}

	public static Checkbox createCheckbox(boolean initialvalue, boolean mandatory, String screencd, String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
		Checkbox chkbx = new Checkbox(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), initialvalue);
		chkbx.setRequiredIndicatorVisible(mandatory);
		chkbx.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return chkbx;
	}

	public static RouterLink createRouterLink(Class<? extends Component> navigationTarget, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
		RouterLink link = new RouterLink(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), navigationTarget);
		link.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return link;
	}
	
	public static TextArea createTextArea(String initialvalue, boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		TextArea txtArea = new TextArea(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), initialvalue,
				ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		txtArea.setRequired(mandatory);
		txtArea.setRequiredIndicatorVisible(mandatory);
		txtArea.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		
		return txtArea;
	}
	
	public static <T> ComboBox<T> createComboBox(List<T> items, boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		ComboBox<T> comboBox = new ComboBox<T>();
		comboBox.setLabel(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		comboBox.setPlaceholder(ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		comboBox.setRequired(mandatory);
		comboBox.setRequiredIndicatorVisible(mandatory);
		comboBox.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		comboBox.setItems(items);
		return comboBox;
	}
	
/*	public static DatePicker createDatePicker(boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		DatePicker datePicker = new DatePicker(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		datePicker.setRequired(mandatory);
		datePicker.setRequiredIndicatorVisible(mandatory);
		datePicker.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		datePicker.setPlaceholder(ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		return datePicker;
	}
*/
	
	public static DatePicker createDatePicker(boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

	//	DatePicker datePicker = new DatePicker(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		DatePicker datePicker = new CustomDatePicker();
		datePicker.setLabel(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		((CustomDatePicker)datePicker).setPattern("dd-MMM-yyyy");
		datePicker.setRequired(mandatory);
		datePicker.setRequiredIndicatorVisible(mandatory);
		datePicker.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		datePicker.setPlaceholder(ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		return datePicker;
	}
	public static TimePicker createTimePicker(boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		TimePicker timePicker = new TimePicker(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		timePicker.setRequired(mandatory);
		timePicker.setRequiredIndicatorVisible(mandatory);
		timePicker.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		timePicker.setPlaceholder(ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		return timePicker;
	}	
	
    public static Button createIconButton(String screencd, String componentcd,Icon icon) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
		Button button = new Button(ResourceUtil.getConfiguredValueAt(configuredvalues, 0),icon);
		button.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return button;
	}
	
	public static TextField createTextField(String initialvalue, boolean mandatory, String screencd,
			String componentcd,String caption) {

		TextField txtfld = new TextField(caption, initialvalue,
				"");
		txtfld.setRequired(mandatory);
		txtfld.setRequiredIndicatorVisible(mandatory);
		txtfld.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return txtfld;
	}
	public static DatePicker createDatePicker(LocalDate initialDate, boolean mandatory, String screencd,
			String componentcd,String caption) {

		DatePicker datePicker = new DatePicker(caption, initialDate);
		datePicker.setRequired(mandatory);
		datePicker.setRequiredIndicatorVisible(mandatory);
		datePicker.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return datePicker;
	}
	
	public static <T> MultiselectComboBox<T> createMultiselectComboBox(List<T> items, boolean mandatory, String screencd,
			String componentcd) {
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
	
		MultiselectComboBox<T> multiselectComboBox = new MultiselectComboBox();
		multiselectComboBox.setLabel(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		multiselectComboBox.setPlaceholder(ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		multiselectComboBox.setRequired(mandatory);
		multiselectComboBox.setRequiredIndicatorVisible(mandatory);
		multiselectComboBox.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		multiselectComboBox.setItems(items);
			
		
		return multiselectComboBox;
	}

		
}
