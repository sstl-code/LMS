package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;

@CssImport("./styles/site-agreements-styles.css")
public class SiteAgreementsTab extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_AGREEMENTS_TAB";
	private String siteCode;
	private Div containerDiv;
	private List<SiteAgreementDetailBean> siteAgreementDetailBeanList = new ArrayList<>();
	private SiteView siteViewParent;
	private boolean mapViewBtnClicked=false;
	private String selectedSiteLatitude,selectedSiteLongitude;
	private Div agreementAttributeDiv;
	public Button backButton,viewRentReferenceButton, addAgreementButton;

	public SiteAgreementsTab(SiteView siteViewParent, boolean mapViewBtnClicked, String selectedSiteLatitude,
			String selectedSiteLongitude) {
		this.siteViewParent = siteViewParent;
		this.mapViewBtnClicked = mapViewBtnClicked;
		this.selectedSiteLatitude=selectedSiteLatitude;
		this.selectedSiteLongitude=selectedSiteLongitude;
	//	System.out.println("this.mapViewBtnClicked=" + this.mapViewBtnClicked);

		addClassName(SCREENCD + "_MAIN_LAYOUT");
		viewRentReferenceButton = UIFieldFactory.createButton(SCREENCD, "VIEW_RENT_REFERENCE_BTN");
		addAgreementButton = UIFieldFactory.createButton(SCREENCD, "ADD_AGREEMENT_BTN");
		backButton= UIFieldFactory.createButton(SCREENCD, "BACK_BTN");
		backButton.setVisible(false);

		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		headerDiv.add(viewRentReferenceButton, addAgreementButton,backButton);
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		agreementAttributeDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "AGREEMENT_ATTRIBUTE_DIV");
		agreementAttributeDiv.setVisible(false);
		add(headerDiv, containerDiv,agreementAttributeDiv);

		addAgreementButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				// TODO Auto-generated method stub
				openAddDialog(true);
			}
		});
		
		viewRentReferenceButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				openRentReferenceDialog();
			}
		});
		
		backButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				 
				viewRentReferenceButton.setVisible(true);
				addAgreementButton.setVisible(true);
				agreementAttributeDiv.setVisible(false);
				containerDiv.setVisible(true);
				backButton.setVisible(false);
			}
		});
		
		
	}

	protected void openRentReferenceDialog() {
		RentReferenceDialog dlg=new RentReferenceDialog(siteCode,selectedSiteLatitude,selectedSiteLongitude);
		
		dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
//				if(!event.getSource().isOpened() && mapViewBtnClicked==true) {
//					siteViewParent.populateGMap(mapViewBtnClicked);
//				}
				if(!event.getSource().isOpened()) {
				//	System.out.println("this.mapViewBtnClicked On Dlg Close=" + mapViewBtnClicked);
					siteViewParent.populateGMap(mapViewBtnClicked);
				}
				
			}
		});
		
	}

	private void openAddDialog(boolean addOrEdit)
	{
		AddSiteAgreement addSiteAgreement = new AddSiteAgreement(this,getSiteCode());
	//	addSiteAgreement.setSiteCode(getSiteCode());
		addSiteAgreement.setSiteCode2(getSiteCode());
	}


	private String getSiteAgreements()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEAGREEMENTS");
			url = url + "?SiteCode=" + URLEncoder.encode(getSiteCode());
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private void loadAgreements()
	{
		containerDiv.removeAll();
		siteAgreementDetailBeanList.clear();
		try {
			String agreements = getSiteAgreements();
			//			String agreements = "[{\"SiteCode\":\"ep.ID884478EK\",\"Name\":\"Rent Agreement\",\"AgreementDate\":\"25-Mar-2022\","
			//					+ "\"StartDate\":\"01-Apr-2022\",\"EndDate\":\"01-Apr-2022\",\"PaymentFrequency\":1,"
			//					+ "\"PaymentAmount\":150000.55,\"AgreementId\":1,\"PaymentMode\":0,\"EscalationFrequency\":1,"
			//					+ "\"EscalationUnit\":1,\"EscalationAmount\":12.25,\"PaymentUnit\":1}]";
			JSONArray agreementsJA = new JSONArray(agreements);
			if (agreementsJA.length()==0) {

				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NO_RECORD", ApplicationConstants.DialogTypes.INFO);
			}
			for (int i = 0; i < agreementsJA.length(); i++) {
				JSONObject agreementJson = agreementsJA.getJSONObject(i);
				String fileName = "";
				String fileDesc = "";
				String fileUrl = "";
				if (agreementJson.has("FileDetails") && agreementJson.getString("FileDetails").trim().length()>0) {
					JSONArray fileDetailsJA = new JSONArray(agreementJson.getString("FileDetails"));
					if(fileDetailsJA.length()>0)
					{
						JSONObject fileDetailsJson = fileDetailsJA.getJSONObject(0);
						if (fileDetailsJson.has("filename") && fileDetailsJson.getString("filename").trim().length()>0) {
							fileName = fileDetailsJson.getString("filename");
						}
						if (fileDetailsJson.has("attributes") && fileDetailsJson.getString("attributes").trim().length()>0) {
							JSONObject fileAttributesJson = new JSONObject(fileDetailsJson.getString("attributes"));
							if (fileAttributesJson.has("description") && fileAttributesJson.getString("description").trim().length()>0) {
								fileDesc = fileAttributesJson.getString("description");
							}
						}
						if (fileDetailsJson.has("url") && fileDetailsJson.getString("url").trim().length()>0) {
							fileUrl = fileDetailsJson.getString("url");
						}
					}
					
				}
				SiteAgreementDetailBean bean = new SiteAgreementDetailBean(agreementJson.getLong("AgreementId"), agreementJson.getString("Name"), 
						agreementJson.getString("AgreementDate"), agreementJson.getString("StartDate"), agreementJson.getString("EndDate"), fileName, fileDesc, fileUrl,
						/*agreementJson.getInt("PaymentFrequency"), agreementJson.getDouble("PaymentAmount"), agreementJson.getInt("PaymentUnit"),
						agreementJson.getInt("PaymentMode"), agreementJson.getInt("EscalationFrequency"), agreementJson.getInt("EscalationUnit"), 
						agreementJson.getDouble("EscalationAmount"),*/agreementJson.getString("Status"),agreementJson.getString("AgreementType"),siteCode,
						this);
				containerDiv.add(bean);
				siteAgreementDetailBeanList.add(bean);
			}

		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void removeAgreementrow(SiteAgreementDetailBean siteAgreementDetailBean) {
		containerDiv.remove(siteAgreementDetailBean);
		siteAgreementDetailBeanList.remove(siteAgreementDetailBean);
		loadAgreements();
	}

	public void setSiteCode(String selectedsiteCode) 
	{
		//System.out.println("selectedsiteCode="+selectedsiteCode);
		this.siteCode = selectedsiteCode;
		refreshData();
	}

	public void refreshData()
	{
		loadAgreements();
	}

	public String getSiteCode() 
	{
		return siteCode;
	}
	public Div getagreementAttributeDiv()
	{
		return agreementAttributeDiv;
	}
	public Div getContainerDiv()
	{
		return containerDiv;
	}

}
