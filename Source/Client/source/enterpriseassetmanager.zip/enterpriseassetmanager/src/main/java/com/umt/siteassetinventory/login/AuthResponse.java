package com.umt.siteassetinventory.login;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.ruleengine.manager.RuleManager;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.bean.UserInfoBean;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;

@WebServlet("/authresp/*")
public class AuthResponse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String truebyl_token = "";
			String idp_refresh_token = "";
			Cookie cookie = SessionManager.getCookieByName("truebyl_token", req);
			String userPartition = "";
			if(cookie != null && cookie.getValue() != null && cookie.getValue().trim().length() > 0) {
				truebyl_token = cookie.getValue();
				userPartition = getUserPartition(truebyl_token);
				if(userPartition == null) {
					displayError("User not registered in the system.", resp);
					return;
				}
			} else {
				truebyl_token = req.getParameter("truebyl_token");
				userPartition = getUserPartition(truebyl_token);
				if(userPartition == null) {
					displayError("User not registered in the system.", resp);
					return;
				}
				idp_refresh_token = req.getParameter("idp_refresh_token");
				if (truebyl_token != null && truebyl_token.trim().length() > 0) {
					SessionManager.addCookieByName("truebyl_token", truebyl_token, -1, resp);
				}
				if (idp_refresh_token != null && idp_refresh_token.trim().length() > 0) {
					SessionManager.addCookieByName("idp_refresh_token", idp_refresh_token, -1, resp);
				}
			}

			String baseURL = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort()
			+ req.getContextPath();

			storeUserInfoInCookie(truebyl_token, userPartition, req, resp);
			resp.sendRedirect(baseURL);

		} catch (Exception ex) {
			ex.printStackTrace();
			displayError("User login failed.", resp);
		}		
	}

	private String getUserPartition(String token) throws Exception {
		String userPartition = CommonUtils.getUserPartition(token);
		if(userPartition == null || userPartition.trim().length() == 0 || userPartition.trim().equalsIgnoreCase(RuleManager.DEF_PART)) {
			CommonUtils.logout(token);
			userPartition = null;
		}

		return userPartition;
	}

	public void displayError(String errorMsg, HttpServletResponse resp) {
		OutputStream outputStream = null;
		try {
			outputStream = resp.getOutputStream();
			resp.setContentType("text/html");
			outputStream.write(errorMsg.getBytes());
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (outputStream != null) {
				try {
					outputStream.flush();
					outputStream.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	private void storeUserInfoInCookie(String token, String userPartition, HttpServletRequest req, HttpServletResponse resp) throws ServletException {
		if (token == null || token.trim().length() == 0) {
			throw new ServletException("Token not available.");
		}

		UserInfoBean userInfo = new UserInfoBean();
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("TOKENDATA");
			String response = RestServiceHandler.retriveJSON_GET(url, token);
			JSONObject token_data_JSON = new JSONObject(response);

			//JWTClaimsSet claimSet = CommonUtils.getTokenClaimsSet(token);
			userInfo.setEmailId(token_data_JSON.getString("sub"));
			String issuer = token_data_JSON.getString("iss");
			if (issuer.toUpperCase().equals("LOCAL")) {
				userInfo.setLoginMedia("SELF");
				setUserType(userInfo, token);
			} else if (issuer.toUpperCase().equals("MICROSOFT")) {
				userInfo.setLoginMedia("AZUREAD");
				//userInfo.setUserType("0");
				setUserType(userInfo, token);
			} else if (issuer.toUpperCase().equals("GOOGLE")) {
				userInfo.setLoginMedia("GOOGLE");
				//userInfo.setUserType("0");
				setUserType(userInfo, token);
			}
			long iat = token_data_JSON.getLong("iat");
			//System.out.println("iat="+iat);
			//Instant inst = Instant.ofEpochSecond(iat);
			LocalDateTime ldt = Instant.ofEpochMilli(iat).atZone(ZoneId.systemDefault()).toLocalDateTime();
			//System.out.println(ldt);
			Date in = new Date();
			Date out = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
			//System.out.println(out);
			userInfo.setLoginDateTime(out);
			//String partition = CommonUtils.getUserPartition(token);
			userInfo.setPartnerCode(userPartition);
			SessionManager.storeUserInfoInCookie(userInfo, -1, req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setUserType(UserInfoBean userInfo, String token) {
		userInfo.setUserType("0");
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("LISTWORKGROUPS");
			url = url + "?username=" + URLEncoder.encode(userInfo.getEmailId());
			String response = RestServiceHandler.retriveJSON_GET(url, token, false);
			JSONArray workgroupsArray = new JSONArray(response);
			for(int i = 0; i < workgroupsArray.length(); i++) {
				JSONObject eachJSON = workgroupsArray.getJSONObject(i);
				String wgName = eachJSON.getString("name");
				if(wgName != null && wgName.trim().equalsIgnoreCase("administrator")) {
					userInfo.setUserType("1");
					break;
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
