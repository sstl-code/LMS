package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class SiteDetailsTab extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_DETAILS_TAB";
	private Label siteCode, siteName, siteDes, siteAddress, siteReg, sitelat, siteLong, siteRateing, siteStatus, startdate, stopdate;
	private Label siteCodeV, siteNameV, siteDesV, siteAddressV, siteRegV, sitelatV, siteLongV, siteRateingV, siteStatusV, startdateV, stopdateV;
	private Button editBtn, decommissionBtn; 
	private Div btnDiv, infoDiv;
//	private String siteCode_v="-", siteName_v="-", siteDes_v="-", siteAdress_v="-", siteReg_v="-", siteLat_v="-", siteLong_v="-", siteRating_v="-", siteStatus_v="-", 
//			startDate_v="-", stopDate_v="-";
	
	private String siteCode_v="", siteName_v="", siteDes_v="", siteAdress_v="", siteReg_v="", siteLat_v="", siteLong_v="", siteRating_v="", siteStatus_v="", 
			startDate_v="", stopDate_v="";
	
	private Dialog demmissionDialog, decomissionDateDialog;
	private SiteView siteView;
	private String sitecd;
	private String lat_long;
	
	private Button viewBtn;
	
	
	public SiteDetailsTab(String sitecd, SiteView siteView) {
		this.sitecd=sitecd;
		btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
		decommissionBtn = UIFieldFactory.createButton(SCREENCD, "DECOMMISSION_BTN"); 
		viewBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
		btnDiv.add(viewBtn,editBtn, decommissionBtn);
		this.siteView = siteView;
		viewBtn.setVisible(false);
		
		
		
		
		infoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "INFO_DIV");
		
		Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_7 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_8 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_9 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_10 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_11 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_12 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		row_4.addClassName("ADDRESS_DIV_WIDTH");
		
		
		siteCode =  UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_LBL");
		siteName =  UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		siteDes = UIHtmlFieldFactory.createLabel(SCREENCD, "DES_LBL");
		siteAddress = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEADDRESS_LBL");
		siteReg = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEREG_LBL");
		sitelat = UIHtmlFieldFactory.createLabel(SCREENCD, "SITELAT_LBL");
		siteLong = UIHtmlFieldFactory.createLabel(SCREENCD, "SITELONG_LBL");
		siteRateing = UIHtmlFieldFactory.createLabel(SCREENCD, "SITERATING_LBL"); 
		siteStatus = UIHtmlFieldFactory.createLabel(SCREENCD, "SITESTATUS_LBL"); 
		startdate = UIHtmlFieldFactory.createLabel(SCREENCD, "STRATDATE_LBL");
		stopdate = UIHtmlFieldFactory.createLabel(SCREENCD, "STOPDATE_LBL");
		
		siteCodeV =  UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_V_LBL");
		siteNameV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_V_LBL");
		siteDesV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEDES_V_LBL");
		siteAddressV=  UIHtmlFieldFactory.createLabel(SCREENCD, "SITEADDRESS_V_LBL");
		siteRegV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEREG_V_LBL");
		sitelatV= UIHtmlFieldFactory.createLabel(SCREENCD, "SITELAT_V_LBL"); 
		siteLongV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITELONG_V_LBL");  
		siteRateingV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITERATING_V_LBL"); 
		siteStatusV = UIHtmlFieldFactory.createLabel(SCREENCD, "SITESTATUS_V_LBL");
		startdateV = UIHtmlFieldFactory.createLabel(SCREENCD, "STARTDATE_V_LBL"); 
		stopdateV= UIHtmlFieldFactory.createLabel(SCREENCD, "STOPDATE_V_LBL"); 
		
		
		
//		siteCodeV.setText("-");
//		siteNameV.setText("-");
//		siteDesV.setText("-");
//		siteAddressV.setText("-");
//		siteRegV.setText("-");
//		sitelatV.setText("-");
//		siteLongV.setText("-");
//		siteRateingV.setText("-");
//		siteStatusV.setText("-");
//		startdateV.setText("-");
//		stopdateV.setText("-");
		
		
		row_1.add(siteCode, siteCodeV);
		row_2.add(siteName, siteNameV);
		row_3.add(siteDes, siteDesV);
		row_4.add(siteAddress, siteAddressV);
		row_5.add(siteReg, siteRegV);
		row_6.add(sitelat, sitelatV);
		
		
		row_9.add(siteStatus, siteStatusV);
		row_10.add(startdate, startdateV);
		row_11.add(stopdate, stopdateV);
		
		//System.out.println("site: " + siteCode_v);
		
		if(sitecd != null) {
			decommissionBtn.setEnabled(true);
			editBtn.setEnabled(true);
			populateSiteDetails(sitecd);
		}else {
			decommissionBtn.setEnabled(false);
			editBtn.setEnabled(false);
		}
		
		if(siteStatusV.getText().equals("Decommissioned")) {
			decommissionBtn.setEnabled(false);
			
		}/*else {
			decommissionBtn.setEnabled(true);
		}*/
		
		
		infoDiv.add(row_1, row_2,row_4, row_3, row_5, row_6, row_9, row_10, row_11, row_12);
		
		add(btnDiv, infoDiv);
		
		editBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;
			
			

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				
				try {
					EditSiteDetails editDetails = new EditSiteDetails(siteView,sitecd, siteName_v, siteDes_v, siteAdress_v, siteReg_v, siteLat_v, siteLong_v, siteStatus_v, startDate_v, stopDate_v);
				}catch(Exception e) {
					e.printStackTrace();
				}
				

				
			}
		});
		
		decommissionBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				decommisionConfirmation(sitecd);
				
			}
		});
		
		viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				viewActivePassiveAssets(sitecd);
				
			}
		});

		
		
		
	}
	protected void viewActivePassiveAssets(String sitecd2) {
		
		ViewActivePassiveAssetDialog dlg=new ViewActivePassiveAssetDialog(sitecd2);
		
	}
	protected Dialog deCommissionDateDialog(String sidecode) {
		decomissionDateDialog = new Dialog();
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIALOG_DIV");
		Label headerTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_TITLE_LBL");
		headerDiv.add(headerTitle);
		Div bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
		
		bodyDiv.add(ValueDateField);
		
		 Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_DIV");
		 Button decommision_btn = UIFieldFactory.createButton(SCREENCD, "DECOMMISON_CONFIRMATION_BTN");
		 Button cancel_btn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		 buttonDiv.add(decommision_btn, cancel_btn);
		
		 
		 decomissionDateDialog.add(headerDiv, bodyDiv, buttonDiv);
		 
		 decommision_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				LocalDate now = LocalDate.now();
		//		String currentDate=CommonUtils.convertLocalDateToString(now);
				
				Date date1 = null,date2 = null;
				try {
					if(ValueDateField.getValue()!=null) {
						date1 = new SimpleDateFormat("dd-MMM-yyyy").parse(CommonUtils.convertDateToDifferentFormat(CommonUtils.convertLocalDateToString(ValueDateField.getValue()),"dd/MM/yyyy","dd-MMM-yyyy"));
						//date2 = new SimpleDateFormat("dd-MM-yyyy").parse(CommonUtils.convertDateToDifferentFormat(startDate_v,"dd/MM/yyyy","dd-MM-yyyy"));
						date2=CommonUtils.convertStringToDate(startDate_v,"dd-MMM-yyyy");
					}
					
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				if(ValueDateField.getValue()==null) {
					ValueDateField.setInvalid(true);
					ValueDateField.setErrorMessage("Please provide a valid date");
					return;
				}else if(ValueDateField.getValue()!=null && date1.before(date2)){
					
					ValueDateField.setInvalid(true);
					ValueDateField.setErrorMessage("Decommission date cannot be lesser than site creation date");
					return;
					
				}else {
					
					ValueDateField.setInvalid(false);
					ValueDateField.setErrorMessage("");
					
					String defaultval = CommonUtils.convertLocalDateToString(ValueDateField.getValue());
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
					
					//System.out.println(ValueDateField.getValue().format(formatter));
					
//					LocalDate changeFormat =  CommonUtils.convertStringToLocalDate(defaultval,"dd-MMM-yyyy");
					String base_URL=ApplicationConfiguration.getServiceEndpoint("DECOMMISSIONSITE");
					
					Form formData = new Form();
					formData.add("SiteCode",sidecode);
					formData.add("DecommissionDate",ValueDateField.getValue().format(formatter));
					//System.out.println(base_URL+" ::: "+ formData.toString());
					
					try {
						String response = RestServiceHandler.deleteJSON_DELETE(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
//						siteView.addlandlordTab(sidecode);
						SiteAssetInventoryUIFramework.getFramework().showMessage("Decommission Successfully!", ApplicationConstants.DialogTypes.INFO);
						demmissionDialog.close();
						decomissionDateDialog.close();
						siteView.addDetailsTab(sitecd);
//						remove_btn.setEnabled(false);
					} catch (Exception e) {
						e.printStackTrace();
						if(e.getMessage().contains("AppException-Access Violation")) {
							SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
						}else {
							SiteAssetInventoryUIFramework.getFramework().showMessage("Site is not in active status", ApplicationConstants.DialogTypes.ERROR);
						}
					}

					
				}
				
			
				
				
				
				
				
			}
		});
		 cancel_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				decomissionDateDialog.close();
				
			}
		});
		
		 decomissionDateDialog.open();
		return decomissionDateDialog;
	}
	
    protected Dialog decommisionConfirmation(String sidecode) {
    	demmissionDialog = new Dialog();
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIALOG_DIV");
		Label headerTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_TITLE_LBL");
		headerDiv.add(headerTitle);
		Div bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		 FontAwesome.Solid.Icon icon = FontAwesome.Solid.INFO_CIRCLE.create();
		 icon.addClassName("INFO_ICON");
		 Label infoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMOVE_CONFIRMATION_INFO");
		 bodyDiv.add(icon, infoLbl);
		
		 Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_DIV");
		 Button yes_btn = UIFieldFactory.createButton(SCREENCD, "YES_BTN");
		 Button no_btn = UIFieldFactory.createButton(SCREENCD, "NO_BTN");
		 buttonDiv.add(yes_btn, no_btn);
		 
		 
		 demmissionDialog.add(headerDiv, bodyDiv, buttonDiv);
		 
		 yes_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				deCommissionDateDialog(sidecode);
				demmissionDialog.close();
				
			}
		});
		 
		 no_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				demmissionDialog.close();
				
			}
		});
		
		 demmissionDialog.open();
		return demmissionDialog;
		
	}
//	private JSONObject populateUpdateJson() throws JSONException {
//		
//		
//		
//		
//		
//		
//	} 
	public void populateSiteDetails(String siteCode) {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETSITEDETAILS");
		base_URL = base_URL + "?SiteCode=" + URLEncoder.encode(siteCode);
		
		try {
			String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(outputResponse);
			JSONObject jsonobj = new JSONObject(outputResponse);

			if (jsonobj.getString("SiteCode")!=null && jsonobj.getString("SiteCode").trim().length()>0) {
				siteCode_v = jsonobj.getString("SiteCode");
			}
			if (jsonobj.getString("SiteName")!=null && jsonobj.getString("SiteName").trim().length()>0) {
				siteName_v = jsonobj.getString("SiteName");
			}
			if (jsonobj.getString("Description")!=null && jsonobj.getString("Description").trim().length()>0) {
				siteDes_v = jsonobj.getString("Description");
			}
			if (jsonobj.getString("Address")!=null && jsonobj.getString("Address").trim().length()>0) {
				siteAdress_v = jsonobj.getString("Address");
			}
			if (jsonobj.getString("Region")!=null && jsonobj.getString("Region").trim().length()>0) {
				siteReg_v = jsonobj.getString("Region");
			}
			if (jsonobj.getString("Lattitude")!=null && jsonobj.getString("Lattitude").trim().length()>0) {
				siteLat_v = jsonobj.getString("Lattitude");
			}
			if (jsonobj.getString("Longitude")!=null && jsonobj.getString("Longitude").trim().length()>0) {
				siteLong_v = jsonobj.getString("Longitude");
			}
			if (jsonobj.getString("Status")!=null && jsonobj.getString("Status").trim().length()>0) {
				siteStatus_v = jsonobj.getString("Status");
			}
			if (jsonobj.getString("Startdate")!=null && jsonobj.getString("Startdate").trim().length()>0) {
				startDate_v = jsonobj.getString("Startdate");
			}
			if (jsonobj.getString("Stopdate")!=null && jsonobj.getString("Stopdate").trim().length()>0) {
				stopDate_v = jsonobj.getString("Stopdate");
			}
			
//			siteRating_v = jsonobj.getString("SiteRating");
			
			
			
			
			lat_long = siteLat_v + " / " + siteLong_v;
		
				siteCodeV.setText(siteCode_v);
			
				
			
			
			siteNameV.setText(siteName_v);
			siteDesV.setText(siteDes_v);
			siteAddressV.setText(siteAdress_v);
			siteRegV.setText(siteReg_v);
			sitelatV.setText(lat_long);
			
			
			siteStatusV.setText(siteStatus_v);
			startdateV.setText(startDate_v);
			stopdateV.setText(stopDate_v);
			
				stopdateV.setText(stopDate_v);
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public void setSiteCode(String selectedsiteCode) 
	{
	
		siteCode_v = selectedsiteCode;
		
	}

}
