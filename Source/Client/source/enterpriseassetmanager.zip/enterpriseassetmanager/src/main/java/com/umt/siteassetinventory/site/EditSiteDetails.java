package com.umt.siteassetinventory.site;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/editSite_details-style.css")
public class EditSiteDetails extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_DETAILS_EDIT";
	
	private TextField siteCode, siteName, siteDes, siteAddress, siteReg, siteRate, siteStatus, siteStartdate, siteStopdate;
	private NumberField siteLat, siteLongi;
	
	
	
	
	public EditSiteDetails(SiteView siteView, String sitecd, String siteNm, String des, String address, String reg, String lat, String longi, String status, String startDate, String stopDate) {
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		
		Div spaceDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SPACE_DIV");
		
		siteCode = UIFieldFactory.createTextField(sitecd, false, SCREENCD, "EDIT_FIELD_1");
		siteCode.setEnabled(false);
		siteName = UIFieldFactory.createTextField(siteNm, false, SCREENCD, "EDIT_FIELD_2");
		siteName.setRequiredIndicatorVisible(true);
		siteName.setEnabled(false);
		siteDes = UIFieldFactory.createTextField(des, false, SCREENCD, "EDIT_FIELD_3");
		siteAddress = UIFieldFactory.createTextField(address, false, SCREENCD, "EDIT_FIELD_4");
		siteAddress.setRequiredIndicatorVisible(true);
		siteReg = UIFieldFactory.createTextField(reg, false, SCREENCD, "EDIT_FIELD_5");
		siteReg.setRequiredIndicatorVisible(true);
		siteReg.setEnabled(false);
		
		siteLat = UIFieldFactory.createNumberField( false, SCREENCD, "EDIT_FIELD_6");
		siteLat.setValue(Double.parseDouble(lat));
		siteLat.setEnabled(false);
		siteLat.setRequiredIndicatorVisible(true);
		siteLongi = UIFieldFactory.createNumberField( false, SCREENCD, "EDIT_FIELD_7");
		siteLongi.setValue(Double.parseDouble(longi));
		siteLongi.setRequiredIndicatorVisible(true);
		siteLongi.setEnabled(false);
		
//		siteRate = UIFieldFactory.createTextField(rate, false, SCREENCD, "EDIT_FIELD_8");
//		siteRate.setEnabled(false);
		siteStatus = UIFieldFactory.createTextField(status, false, SCREENCD, "EDIT_FIELD_9");
		siteStatus.setEnabled(false);
		siteStartdate = UIFieldFactory.createTextField(startDate, false, SCREENCD, "EDIT_FIELD_10");
		siteStartdate.setEnabled(false);
		siteStopdate = UIFieldFactory.createTextField(stopDate, false, SCREENCD, "EDIT_FIELD_11");
		siteStopdate.setEnabled(false);
		
		
		
		add(siteCode, siteName,siteAddress, siteDes,  siteReg, siteLat, siteLongi, siteStatus, siteStartdate, siteStopdate, spaceDiv);
		
		try {
			EditSiteDetailsPopup popup = new EditSiteDetailsPopup("Edit Details", this, sitecd, siteView, SCREENCD);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
	
	public String getSiteName() {
		return siteName.getValue();
	}
	public String getSiteAddress() {
		return siteAddress.getValue();
	}
	public String getSiteDescription() {
		return siteDes.getValue();
	}
	public String getSiteRegion() {
		return siteReg.getValue();
	}
	public String getSiteLatitude() {
		Double lat = siteLat.getValue();
		return String.valueOf(lat);
	}
	public String getSiteLongitute() {
		Double longi = siteLongi.getValue();
		return String.valueOf(longi);
	}
	
	

}
