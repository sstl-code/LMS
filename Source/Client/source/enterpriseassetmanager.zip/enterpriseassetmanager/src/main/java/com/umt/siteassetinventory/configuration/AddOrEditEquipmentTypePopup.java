package com.umt.siteassetinventory.configuration;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditEquipmentTypePopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditEquipmentType addOrEditEquipmentType;
	private String screencd;
	private boolean dataSaved;
	private EquipmentTypeMaster viewEquipmentTypeMaster;
	private boolean addOrEdit;


	public AddOrEditEquipmentTypePopup(String title, boolean addOrEdit, Component component, EquipmentTypeMaster master, String screencd) {

		super(title, component);
		setWidth("500px");
		//System.out.println(title);
		this.addOrEditEquipmentType = (AddOrEditEquipmentType) component;
		this.viewEquipmentTypeMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditEquipmentType.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDEQUIPMENTTYPE");
					JSONObject equipmentTypeInfoJson = new JSONObject();
					equipmentTypeInfoJson.put("EquipmentType", addOrEditEquipmentType.getEquipmentType());
					equipmentTypeInfoJson.put("EquipmentName", addOrEditEquipmentType.getEquipmentTypeName());
					equipmentTypeInfoJson.put("Description", addOrEditEquipmentType.getDesc());
					equipmentTypeInfoJson.put("ServiceType", CommonUtils.getServiceType(addOrEditEquipmentType.getServiceType()));

					Form formData = new Form();
					formData.add("EquipmetTypeInfo", equipmentTypeInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_SAVE_SUCCESSFUL");	
				}
				else
				{
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEEQUIPMENTTYPE");
					
					Form formData = new Form();
					formData.add("EquipmentType", addOrEditEquipmentType.getEquipmentType());
					formData.add("EquipmentTypeName", addOrEditEquipmentType.getEquipmentTypeName());
					formData.add("Description", addOrEditEquipmentType.getDesc());
					formData.add("ServiceType", CommonUtils.getServiceType(addOrEditEquipmentType.getServiceType()));

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_UPDATE_SUCCESSFUL");	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewEquipmentTypeMaster.populateData();
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
