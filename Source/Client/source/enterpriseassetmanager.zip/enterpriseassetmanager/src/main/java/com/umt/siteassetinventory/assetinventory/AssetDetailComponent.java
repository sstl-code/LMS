package com.umt.siteassetinventory.assetinventory;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class AssetDetailComponent extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_DETAIL_COMPONENT";
	private Div buttonBarDiv;
	private List<String> columnHeaders;
	private GridDynamicRow selectedDynamicRow;
	private boolean allowEdit;
	private boolean allowAddition;
	private boolean allowExport;
	private Button additionBtn;
	private Button editBtn;
	private Button exportBtn;
	
	public AssetDetailComponent(String screenName,  boolean allowAddition, boolean allowEdit, boolean allowExport) {
		buttonBarDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR_DIV");
		add(buttonBarDiv);
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		addClassName(screenName.toUpperCase() + "_MAIN_LAYOUT");
		
		this.allowAddition = allowAddition;
		this.allowEdit = allowEdit;
		this.allowExport = allowExport;
		
		if(allowAddition) {
			additionBtn = UIFieldFactory.createButton(SCREENCD, "ADD_NEW_BTN");
			additionBtn.setText("Add New");
			//buttonBarDiv.add(additionBtn);
			
			additionBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					addNew();
				}
			});
		}
		
		if(allowEdit) {
			editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
			editBtn.setText("Edit");
			buttonBarDiv.add(editBtn);
			
			editBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					edit();
				}
			});
		}
		
		if(allowExport) {
			exportBtn = UIFieldFactory.createButton(SCREENCD, "EXPORT_BTN");
			exportBtn.setText("Export");
			buttonBarDiv.add(exportBtn);
		}
	}
	
	private void addNew() {
		if(columnHeaders.size() <= 0) {
			return;
		}
		
		LinkedHashMap<String, String> dataMap = new LinkedHashMap<String, String>();
		for(int i = 0; i < columnHeaders.size(); i++) {
			dataMap.put(columnHeaders.get(i), "");
		}
		
		AssetOperationsDialog dlg = new AssetOperationsDialog("Add New", dataMap);
	}

	private void edit() {
		if(columnHeaders.size() <= 0) {
			return;
		}
		
		LinkedHashMap<String, String> dataMap = new LinkedHashMap<String, String>();
		for(int i = 0; i < columnHeaders.size(); i++) {
			if(selectedDynamicRow != null) {
				dataMap.put(columnHeaders.get(i), (String)selectedDynamicRow.getValue(i));
			} else {
				dataMap.put(columnHeaders.get(i), "");
			}
		}
		
		AssetOperationsDialog dlg = new AssetOperationsDialog("Edit", dataMap);
	}
	
	public void populateComponent(List<String> columnHeaders, List<GridDynamicRow> gridData) {
		removeAll();
		add(buttonBarDiv);
		
		this.columnHeaders = columnHeaders;
		
		if(gridData.size() > 0) {
			selectedDynamicRow = gridData.get(0);
		}
		else {
			return;
		}
		
		Div row = null;
		for(int i = 0; i < columnHeaders.size(); i++) {
			Div column = null;
			if(i == 0 || i % 3 == 0) {
				row = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_ROW");
				add(row);
				column = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN1");
				
			} else if (i % 3 == 1) {
				column = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN2");
			} else if (i % 3 == 2) {
				column = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN3");
			}
			
			Label detailCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "CAPTION");
			detailCaption.setText(columnHeaders.get(i));
			
			Label detailValue = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE");
			detailValue.setText((String) selectedDynamicRow.getValue(i));
			if(column != null) {
				column.add(detailCaption, detailValue);
			}
			
			if(row != null) {
				row.add(column);
			}
		}
		
	}
	
	public void loadData(String fileName, String siteCode) {
		String homeDirectory = System.getProperty("user.home");
		String assetDataFile = homeDirectory + File.separator + "AssetInventory" + File.separator
				+ fileName;
		List<String> csvHeader = new ArrayList<String>();
		List<GridDynamicRow> csvRowWiseData = new ArrayList<GridDynamicRow>();
		try {
			CSVParser csvParser = new CSVParser(new FileReader(assetDataFile), CSVFormat.DEFAULT);
			String currentLine = null;
			boolean lookUpHeader = true;
			Iterator<CSVRecord> iterator = csvParser.iterator();
			while(iterator.hasNext())
			{
				CSVRecord eachRecord = iterator.next();
				
				if(eachRecord == null || eachRecord.size() <= 0) {
					continue;
				}
								
				if(lookUpHeader) {
					for (int i = 0; i < eachRecord.size(); i++) {
						csvHeader.add(eachRecord.get(i));
					}
					lookUpHeader = false;
				} else {
					GridDynamicRow row = new GridDynamicRow();
					boolean validRecord = true;
					for (int i = 0; i < eachRecord.size(); i++) {
						if(siteCode != null && siteCode.trim().length() > 0) {
							if(i == 0) {
								if(!siteCode.equals(eachRecord.get(i))) {
									validRecord = false;
									break;
								}
							}
						} 
						
						if(validRecord) {
							row.addValue(eachRecord.get(i));
						}
					}
					if(validRecord) {
						csvRowWiseData.add(row);
					}
				}
			}
			
			if(csvHeader.size() > 0) {
				populateComponent(csvHeader, csvRowWiseData);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public class GridDynamicRow {

	    private List<Object> values = new ArrayList<>();

	    public void addValue(String value) {
	        values.add(value);
	    }

	    public Object getValue(int columnIndex) {
	        return values.get(columnIndex);
	    }
	}

}
