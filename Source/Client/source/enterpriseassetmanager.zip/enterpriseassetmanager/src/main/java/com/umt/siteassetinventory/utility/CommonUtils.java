package com.umt.siteassetinventory.utility;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.SiteAssetInventoryUIMain;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.server.VaadinServletService;

public class CommonUtils {

	public static String getXMLTagValue(String inputXML, String xmlTag) {
		if (inputXML == null || xmlTag == null) {
			return "";
		}
		xmlTag = xmlTag.trim();
		inputXML = inputXML.trim();
		if (inputXML.equals("") || xmlTag.equals("")) {
			return "";
		}

		String l_str = "";

		int l_iIndex = inputXML.indexOf("<" + xmlTag + ">");

		if (l_iIndex >= 0) {
			int l_iIndex1 = inputXML.indexOf("</" + xmlTag + ">", l_iIndex);
			if (l_iIndex1 >= l_iIndex) {
				l_iIndex = inputXML.indexOf(">", l_iIndex + xmlTag.length()) + 1;
				l_iIndex1 = inputXML.indexOf("</" + xmlTag + '>', l_iIndex);
				l_str = inputXML.substring(l_iIndex, l_iIndex1);
			}
		}
		return l_str.trim();
	}

	public static String getDisplayDate(Date date, String targetSimpleDateFormatPattern) {
		try {
			DateFormat l_objDateFormatter = new SimpleDateFormat(targetSimpleDateFormatPattern);
			return l_objDateFormatter.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "";
		}
	}

	public static Date convertStringToDate(String stringifiedDate, String sourceSimpleDateFormatPattern)
			throws ParseException {
		Date date = new SimpleDateFormat(sourceSimpleDateFormatPattern).parse(stringifiedDate);
		return date;
	}

	public static String convertLocalTimeToString(LocalTime time) {
		String stringifiedTime = "";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		stringifiedTime = time.format(formatter);
		return stringifiedTime;
	}

	public static String convertLocalDateToString(LocalDate date) {
		String stringifiedDate = "";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		stringifiedDate = date.format(formatter);
		return stringifiedDate;
	}

	public static String convertLocalDateToString(LocalDate date, String dateFormatPattern) {
		String stringifiedDate = "";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormatPattern);
		stringifiedDate = date.format(formatter);
		return stringifiedDate;
	}

	public static Date convertLocalDateToDate(LocalDate localDate) {
		return java.util.Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}

	public static LocalDate convertStringToLocalDate(String stringifiedDate, String sourceFormat) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(sourceFormat);
		LocalDate localDate = LocalDate.parse(stringifiedDate, formatter);
		return localDate;
	}

	public static LocalDate convertDateToLocalDate(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	public static String getDateValue(String inputDate) {
		String retVal = inputDate;
		try {
			retVal = getDisplayDate(convertStringToDate(inputDate, "dd-MMM-yyyy hh:mm:ss"), "dd-MMM-yyyy");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return retVal;
	}

	public static List<String> parseFLOV(String screencd, String componentcd, char separator) {
		List<String> retVal = new ArrayList<String>();
		String strVal = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		if (strVal == null || strVal.trim().length() == 0) {
			return retVal;
		}
		String[] parsedValueArray = strVal.split("[" + separator + "]");
		if (parsedValueArray == null || parsedValueArray.length == 0) {
			return retVal;
		}
		for (int i = 0; i < parsedValueArray.length; i++) {
			if (parsedValueArray[i] != null && parsedValueArray[i].trim().length() > 0) {
				retVal.add(parsedValueArray[i]);
			}
		}
		return retVal;
	}

	public static String getDisplayDateTime(Date datetime) {
		DateFormat l_objDateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
		return l_objDateFormatter.format(datetime);
	}

	public static String rightPad(String value, int size, char padChar) {
		String retVal = value;
		try {
			Double dVal = Double.parseDouble(value);
			int intPart = dVal.intValue();
			int intPartLength = (intPart + "").length();
			if (value.indexOf(".") != -1) {
				retVal = StringUtils.rightPad(value, size + intPartLength + 1, '0');
			} else {
				retVal = StringUtils.rightPad(value, size + intPartLength, '0');
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			retVal = value;
		}
		return retVal;
	}

	public static String roundValue(String value, int decimalPlaces) {
		String retVal = "0";
		try {
			Double dVal = Double.parseDouble(value);
			BigDecimal bd = new BigDecimal(dVal).setScale(decimalPlaces, RoundingMode.HALF_UP);
			retVal = bd.toString();
		} catch (Exception ex) {
			ex.printStackTrace();
			retVal = value;
		}
		return retVal;
	}

	public static String roundValue(double value, int decimalPlaces) {
		String retVal = "0";
		try {
			Double dVal = value;
			BigDecimal bd = new BigDecimal(dVal).setScale(decimalPlaces, RoundingMode.HALF_UP);
			retVal = bd.toString();
		} catch (Exception ex) {
			ex.printStackTrace();
			retVal = value + "";
		}
		return retVal;
	}

	public static QueryParameters getQueryParameters(String urlParameters) {
		if (urlParameters == null || urlParameters.trim().length() == 0) {
			return null;
		}

		String[] urlParams = urlParameters.split("[&]");
		HashMap<String, String> paramMap = new HashMap<String, String>();
		if (urlParams != null && urlParams.length > 0) {
			for (int i = 0; i < urlParams.length; i++) {
				String eachParam = urlParams[i];
				String[] eachParamPart = eachParam.split("[=]");
				paramMap.put(eachParamPart[0], eachParamPart[1]);
			}
		}
		QueryParameters queryParam = QueryParameters.simple(paramMap);
		return queryParam;
	}

	public static String getErrorMessage(String inputMsg) {
		if (inputMsg == null || inputMsg.trim().length() == 0) {
			return "";
		}

		String originalMessage = inputMsg.trim();
		originalMessage = originalMessage.replaceAll("&lt;", "<");
		originalMessage = originalMessage.replaceAll("&gt;", ">");

		String errorMessage = originalMessage.trim();

		if (originalMessage != null && originalMessage.trim().length() > 0) {
			int startIndex = originalMessage.indexOf("<<<");
			int endIndex = originalMessage.indexOf(">>>");
			if (startIndex != -1 && endIndex != -1) {
				try {
					errorMessage = originalMessage.substring(startIndex + 3, endIndex);
					if (errorMessage == null || errorMessage.trim().length() == 0) {
						errorMessage = originalMessage.trim();
					} else {
						errorMessage = errorMessage.trim();
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					errorMessage = originalMessage.trim();
				}
			}
		}
		return errorMessage;
	}

	public static String getEncodedText(String plainText) {
		try {
			return URLEncoder.encode(plainText, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return plainText;
		}
	}

	public static void logout() {
		HttpServletRequest request = VaadinServletRequest.getCurrent().getHttpServletRequest();
		String loginURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
		+ "/partnerportal/login?mode=" + "towerlogin";
		UI.getCurrent().getPage().setLocation(loginURL);
	}

	public static String convertTimeStamp(Long timestamp) {
		Date date = new Date(timestamp);
		DateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");

		return dateFormatter.format(date).toString();

	}

	public static String calculateEndDate(Long startTimestamp, Long maxdurationInhrs) {
		Date date = new Date(startTimestamp);

		Long s = date.getTime() + TimeUnit.HOURS.toMillis(maxdurationInhrs);// adds n number of hrs
		String enddate = convertTimeStamp(s);

		return enddate;

	}

	// Check The Number is Integer or Not
	public static boolean isIntger(String p_strInput) {
		String expression = "\\d+";
		Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(p_strInput);
		return matcher.matches();
	}

	// Check The Number is Float or Not
	public static boolean isFloat(String p_strInput) {
		String regex = "[+-]?[0-9]+(\\.[0-9]+)?([Ee][+-]?[0-9]+)?";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(p_strInput);
		return m.find() && m.group().equals(p_strInput);
	}

	public static Boolean getClientView() {
		return SiteAssetInventoryUIFramework.getFramework().isMobileView();
	}

	public static String getWorkflowStatusName(int status) {
		String statusName = "";
		if (status == 1) {
			statusName = "Open";
		} else if (status == 2) {
			statusName = "Close";
		}
		else if(status == 3) {
			statusName = "Cancelled";
		}
		else if(status == 4) {
			statusName = "Removed";
		}
		return statusName;
	}

	public static void logout(String token) {
		if(token == null || token.trim().length() == 0) {
			return;
		}

		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("LOGOUT");
			Form l_objInputForm = new Form();
			try {
				RestServiceHandler.createJSON_POST(base_URL, l_objInputForm, token, false);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			HttpServletResponse response = (HttpServletResponse) VaadinResponse.getCurrent();
			SessionManager.clearUserInfoInCookie(response);
			HttpServletRequest l_objContext = VaadinServletService.getCurrentServletRequest();
			String logoutURL = l_objContext.getScheme() + "://" + l_objContext.getServerName() + ":"
					+ l_objContext.getServerPort() + l_objContext.getContextPath()/* + "/app/" */;
			String otherSessionlogoutURL = l_objContext.getScheme() + "://" + l_objContext.getServerName() + ":"
					+ l_objContext.getServerPort() + l_objContext.getContextPath() + "/authreq";
			logoutURL = logoutURL + "/logout";
			// String logoutURL = l_objContext.getRequestURL()+"applicationLogout.html";
			UI uiCurrentInstance = UI.getCurrent();
			UI.getCurrent().getPage().setLocation(logoutURL);

			Collection<UI> sessionUIs = UI.getCurrent().getSession().getUIs();
			Iterator<UI> iterator = sessionUIs.iterator();
			while (iterator.hasNext()) {
				UI eachUI = iterator.next();
				if (uiCurrentInstance == eachUI) {
					continue;
				}
				if (eachUI instanceof SiteAssetInventoryUIMain) {
					try {
						eachUI.getPage().setLocation(otherSessionlogoutURL);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//		LogOut logout = new LogOut(token);
		//		HttpServletRequest request = VaadinServletRequest.getCurrent().getHttpServletRequest();
		//		String logoutURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
		//		+ request.getContextPath() + "/app/logout.html";
		//		System.out.println(logoutURL);
		//		UI.getCurrent().getPage().setLocation(logoutURL);


	}

	public static String getUserPartition(String token) throws Exception {
		String output = "";
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETUSERPARTITION");
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(url);
			ClientResponse response = null;
			if (token == null || token.trim().length() == 0) {
				throw new Exception("Please provide token to get user partition.");
			} else {
				response = webResource.accept("text/plain").header("Authorization", "Bearer " + token)
						.get(ClientResponse.class);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
					throw new Exception ("Failed to retrieve user partition. Error Detail: " + output);
				} catch (Exception ex) {
					throw new Exception ("Failed to retrieve user partition.");
				}
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			throw e;
		}
		return output;
	}

	public static String getCustomerStatusNameAccountLevel(int status) {
		String statusName = "";
		if(status == 1) {
			statusName = "Pending";
		}
		else if(status == 2) {
			statusName = "Active";
		}
		else if(status == 3) {
			statusName = "Suspended";
		}
		else if(status == 4) {
			statusName = "Deallocated";
		}

		return statusName;
	}

	public static String getStatusColorCode(String status)
	{
		String statusColorCode = "#FFFFFF";

		if(status.toUpperCase().equals("RETURNED") || status.toUpperCase().equals("DEFECTIVE"))
		{
			statusColorCode = "brown";
		}
		else if(status.toUpperCase().equals("ACTIVE"))
		{
			statusColorCode = "#09c318";
		}
		else if(status.toUpperCase().equals("DEACTIVE") || status.toUpperCase().equals("BLOCKED") || status.toUpperCase().equals("SUSPENDED"))
		{
			statusColorCode = "red";
		}
		else if(status.toUpperCase().equals("AVAILABLE") || status.toUpperCase().equals("ASSIGNED"))
		{
			statusColorCode = "blue";
		}
		else {
			statusColorCode = "orange";
		}
		return statusColorCode;				
	}

	public static String getStatusCd(int status) {
		String statusCd = "";
		if(status == 0) {
			statusCd = "Inactive";
		}
		else if(status == 1) {
			statusCd = "Active";
		}
		return statusCd;
	}

	public static String getPaymentFrequencyCd(int paymentFrequency) {
		String paymentFrequencyCd = "";
		if (paymentFrequency == 1) {
			paymentFrequencyCd = "Weekly";
		} 
		else if (paymentFrequency == 2) {
			paymentFrequencyCd = "Fortnightly";
		}
		else if(paymentFrequency == 3) {
			paymentFrequencyCd = "Monthly";
		}
		else if(paymentFrequency == 4) {
			paymentFrequencyCd = "Quarterly";
		}
		else if(paymentFrequency == 5) {
			paymentFrequencyCd = "Bi-Yearly";
		}
		else if(paymentFrequency == 6) {
			paymentFrequencyCd = "Yearly";
		}
		return paymentFrequencyCd;
	}

	public static String getEscalationFrequencyCd(int escalationFrequency) {
		String escalationFrequencyCd = "";
		if(escalationFrequency == 1) {
			escalationFrequencyCd = "Quarterly";
		}
		else if(escalationFrequency == 2) {
			escalationFrequencyCd = "Half-Yearly";
		}
		else if(escalationFrequency == 3) {
			escalationFrequencyCd = "Yearly";
		}
		return escalationFrequencyCd;
	}

	public static String getEscalationOrPaymentUnitCd(int escalationOrPaymentUnit) {
		String escalationOrPaymentUnitCd = "";
		if(escalationOrPaymentUnit == 1) {
			escalationOrPaymentUnitCd = "Fixed";
		}
		else if(escalationOrPaymentUnit == 2) {
			escalationOrPaymentUnitCd = "%";
		}
		return escalationOrPaymentUnitCd;
	}

	public static String getPaymentModeCd(int paymentMode) {
		String paymentModeCd = "";
		if(paymentMode == 1) {
			paymentModeCd = "Advance-Paid";
		}
		else if(paymentMode == 2) {
			paymentModeCd = "Post-Paid";
		}
		return paymentModeCd;
	}

	public static String getServiceTypeCd(int serviceType) {
		String serviceTypeCd = "";
		if(serviceType == 0) {
			serviceTypeCd = "Passive";
		}
		else if(serviceType == 1) {
			serviceTypeCd = "Active";
		}
		return serviceTypeCd;
	}

	public static String getAttributeTypeCd(int type) {
		String typeCd = "";
		if (type == 7) {
			typeCd = "Site";
		} 
		else if (type == 8) {
			typeCd = "Landlord";
		}
		else if (type == 9) {
			typeCd = "Property";
		}
		else if (type == 10) {
			typeCd = "Agreement";
		}
		return typeCd;
	}

	public static String getAttributeDataTypeCd(int dataType) {
		String dataTypeCd = "";
		if (dataType == 1) {
			dataTypeCd = "Numeric";
		} 
		else if (dataType == 2) {
			dataTypeCd = "AlphaNumeric";
		}
		else if(dataType == 3) {
			dataTypeCd = "Freeflow";
		}
		else if(dataType == 4) {
			dataTypeCd = "Date";
		}
		else if(dataType == 5) {
			dataTypeCd = "Fixed List of Values";
		}
		else if(dataType == 6) {
			dataTypeCd = "Boolean";
		}
		else if(dataType == 7) {
			dataTypeCd = "Multiple Selection";
		}
		else if(dataType == 8) {
			dataTypeCd = "Image File";
		}
		else if(dataType == 9) {
			dataTypeCd = "Text File";
		}
		else if(dataType == 10) {
			dataTypeCd = "Custom File";
		}
		return dataTypeCd;
	}

	public static String getStatus(String statusCd) {
		String status = "";
		switch (statusCd.trim().toUpperCase()) {
		case "ACTIVE":
			status = "1";
			break;
		case "INACTIVE":
			status = "0";
			break;	
		default:
			status = "";
			break;
		}	
		return status;
	}

	public static String getPaymentFrequency(String paymentFrequencyCd) {
		String paymentFrequency = "";

		switch (paymentFrequencyCd.trim().toUpperCase()) {
		case "WEEKLY":
			paymentFrequency = "1";
			break;
		case "FORTNIGHTLY":
			paymentFrequency = "2";
			break;
		case "MONTHLY":
			paymentFrequency = "3";
			break;
		case "QUARTERLY":
			paymentFrequency = "4";
			break;
		case "BI-YEARLY":
			paymentFrequency = "5";
			break;
		case "YEARLY":
			paymentFrequency = "6";
			break;	
		default:
			paymentFrequency = "";
			break;
		}		
		return paymentFrequency;
	}

	public static String getEscalationFrequency(String escalationFrequencyCd) {
		String escalationFrequency = "";
		switch (escalationFrequencyCd.trim().toUpperCase()) {
		case "QUARTERLY":
			escalationFrequency = "1";
			break;
		case "HALF-YEARLY":
			escalationFrequency = "2";
			break;
		case "YEARLY":
			escalationFrequency = "3";
			break;	
		default:
			escalationFrequency = "";
			break;
		}	
		return escalationFrequency;
	}

	public static String getEscalationOrPaymentUnit(String escalationOrPaymentUnitCd) {
		String escalationOrPaymentUnit = "";
		switch (escalationOrPaymentUnitCd.trim().toUpperCase()) {
		case "FIXED":
			escalationOrPaymentUnit = "1";
			break;
		case "%":
			escalationOrPaymentUnit = "2";
			break;	
		default:
			escalationOrPaymentUnit = "";
			break;
		}	
		return escalationOrPaymentUnit;
	}

	public static String getPaymentMode(String paymentModeCd) {
		String paymentMode = "";
		switch (paymentModeCd.trim().toUpperCase()) {
		case "ADVANCE-PAID":
			paymentMode = "1";
			break;
		case "POST-PAID":
			paymentMode = "2";
			break;	
		default:
			paymentMode = "2";
			break;
		}	
		return paymentMode;
	}

	public static String getServiceType(String serviceTypeCd) {
		String serviceType = "";
		switch (serviceTypeCd.trim().toUpperCase()) {
		case "ACTIVE":
			serviceType = "1";
			break;
		case "PASSIVE":
			serviceType = "0";
			break;	
		default:
			serviceType = "";
			break;
		}	
		return serviceType;
	}

	public static int getAttributeType(String typeCd) {
		int type = 0;

		switch (typeCd.trim().toUpperCase()) {
		case "SITE":
			type = 7;
			break;
		case "LANDLORD":
			type = 8;
			break;
		case "PROPERTY":
			type = 9;
			break;
		case "AGREEMENT":
			type = 10;
			break;
		}		
		return type;
	}

	public static int getAttributeDataType(String dataTypeCd) {
		int dataType = 0;

		switch (dataTypeCd.trim().toUpperCase()) {
		case "NUMERIC":
			dataType = 1;
			break;
		case "ALPHANUMERIC":
			dataType = 2;
			break;
		case "FREEFLOW":
			dataType = 3;
			break;
		case "DATE":
			dataType = 4;
			break;
		case "FIXED LIST OF VALUES":
			dataType = 5;
			break;
		case "BOOLEAN":
			dataType = 6;
			break;
		case "MULTIPLE SELECTION":
			dataType = 7;
			break;
		case "IMAGE FILE":
			dataType = 8;
			break;
		case "TEXT FILE":
			dataType = 9;
			break;
		case "CUSTOM FILE":
			dataType = 10;
			break;
		default:
			dataType = 0;
			break;
		}		
		return dataType;
	}
	
	public static String getLandlordInvoiceStatusCd(int landlordInvoiceStatus) {
		String landlordInvoiceStatusCd = "";
		if (landlordInvoiceStatus == 0) {
			landlordInvoiceStatusCd = "To be processed";
		} 
		else if (landlordInvoiceStatus == 1) {
			landlordInvoiceStatusCd = "Hold by EMG";
		} 
		else if (landlordInvoiceStatus == 2) {
			landlordInvoiceStatusCd = "Rejected by EMG";
		}
		else if(landlordInvoiceStatus == 3) {
			landlordInvoiceStatusCd = "Approved by EMG";
		}
		else if(landlordInvoiceStatus == 4) {
			landlordInvoiceStatusCd = "Rejected by Finance";
		}
		else if(landlordInvoiceStatus == 5) {
			landlordInvoiceStatusCd = "Approved by Finance";
		}
		else if(landlordInvoiceStatus == 6) {
			landlordInvoiceStatusCd = "Sent to SAP";
		}
		else if(landlordInvoiceStatus == 7) {
			landlordInvoiceStatusCd = "Payment Record Received";
		}
		return landlordInvoiceStatusCd;
	}
	
	public static String getLandlordInvoiceBillingTypeCd(int landlordInvoiceBillingType) {
		String landlordInvoiceBillingTypeCd = "";
		if (landlordInvoiceBillingType == 1) {
			landlordInvoiceBillingTypeCd = "Agreement based";
		} 
		else if (landlordInvoiceBillingType == 2) {
			landlordInvoiceBillingTypeCd = "Invoice based";
		}
		else if(landlordInvoiceBillingType == 3) {
			landlordInvoiceBillingTypeCd = "NFA based";
		}
		else if(landlordInvoiceBillingType == 4) {
			landlordInvoiceBillingTypeCd = "Galaxy Based";
		}
		return landlordInvoiceBillingTypeCd;
	}
	
	public static String getLandlordInvoiceTypeValueCd(int landlordInvoiceTypeValue) {
		String landlordInvoiceTypeValueCd = "";
		if (landlordInvoiceTypeValue == 1) {
			landlordInvoiceTypeValueCd = "Rent";
		} 
		else if (landlordInvoiceTypeValue == 2) {
			landlordInvoiceTypeValueCd = "Maintenance";
		}
		else if(landlordInvoiceTypeValue == 3) {
			landlordInvoiceTypeValueCd = "Escalation";
		}
		else if(landlordInvoiceTypeValue == 4) {
			landlordInvoiceTypeValueCd = "Rent+Space Charges+Conservancy Fee";
		}
		else if(landlordInvoiceTypeValue == 5) {
			landlordInvoiceTypeValueCd = "Space Charges & Conservancy Fee";
		}
		else if(landlordInvoiceTypeValue == 6) {
			landlordInvoiceTypeValueCd = "Space Charges";
		}
		else if(landlordInvoiceTypeValue == 7) {
			landlordInvoiceTypeValueCd = "Waiver";
		}
		else if (landlordInvoiceTypeValue == 8) {
			landlordInvoiceTypeValueCd = "Debit Note";
		}
		else if(landlordInvoiceTypeValue == 9) {
			landlordInvoiceTypeValueCd = "Credit Note";
		}	
		else if(landlordInvoiceTypeValue == 10) {
			landlordInvoiceTypeValueCd = "Interest Charges";
		}	
		else if(landlordInvoiceTypeValue == 11) {
			landlordInvoiceTypeValueCd = "NFA";
		}
		else if(landlordInvoiceTypeValue == 12) {
			landlordInvoiceTypeValueCd = "SD-License Fee";
		}
		else if(landlordInvoiceTypeValue == 13) {
			landlordInvoiceTypeValueCd = "Others";
		}
		
		else if (landlordInvoiceTypeValue == 14) {
			landlordInvoiceTypeValueCd = "Advance";
		}
		else if(landlordInvoiceTypeValue == 15) {
			landlordInvoiceTypeValueCd = "SD-EB";
		}
		else if(landlordInvoiceTypeValue == 16) {
			landlordInvoiceTypeValueCd = "EB-Advance";
		}
		else if(landlordInvoiceTypeValue == 17) {
			landlordInvoiceTypeValueCd = "EB";
		}
		else if(landlordInvoiceTypeValue == 18) {
			landlordInvoiceTypeValueCd = "FCU";
		}
		else if(landlordInvoiceTypeValue == 19) {
			landlordInvoiceTypeValueCd = "DG";
		}
		else if (landlordInvoiceTypeValue == 20) {
			landlordInvoiceTypeValueCd = "EB+FCU";
		}
		else if(landlordInvoiceTypeValue == 21) {
			landlordInvoiceTypeValueCd = "EB+DG";
		}	
		else if(landlordInvoiceTypeValue == 22) {
			landlordInvoiceTypeValueCd = "EB Fixed Charges";
		}
		return landlordInvoiceTypeValueCd;
	}
	
	public static String convertDateToDifferentFormat(String dateToConvert,String inputformat,String expectedFormat) {
		String date2="";
		try {
			if(dateToConvert!=null) {		
				SimpleDateFormat format1 = new SimpleDateFormat(inputformat);//inputformat=dd/MM/yyyy
			    SimpleDateFormat format2 = new SimpleDateFormat(expectedFormat);//expectedFormat=dd-MMM-yy
			    Date date = format1.parse(dateToConvert);
			    date2=format2.format(date);
			    
			}else {
				date2="";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return date2;
	}
	public static boolean isEmailAddress(String p_strEmail)
	{
		String  expression="^[\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
		CharSequence inputStr = p_strEmail;   
		Pattern pattern = Pattern.compile(expression,Pattern.CASE_INSENSITIVE);  
		Matcher matcher = pattern.matcher(inputStr);  
		return matcher.matches();
	}
	
	public static void insertDraftData(String Type,String DraftData,String successMsg)
	{
		try {
			
			Form formData = new Form();
			formData.add("UserId",SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());
			formData.add("Type",Type);
			formData.add("DraftData",DraftData);
			
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("INSERT_DRAFT_DATA");
			RestServiceHandler.createJSON_POST(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(successMsg, ApplicationConstants.DialogTypes.INFO);
			
		}catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
	}
	
	public static void resetDraftData(String Type,String successMsg)
	{
		try {
			
			Form formData = new Form();
			formData.add("UserId",SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());
			formData.add("Type",Type);
		
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("RESET_DRAFT_DATA");
			RestServiceHandler.deleteJSON_DELETE(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			if(!successMsg.equalsIgnoreCase("none")) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(successMsg, ApplicationConstants.DialogTypes.INFO);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
	}
	public static String getDraftData(String Type)
	{
		String resp=null;
		try {
			
			String url = ApplicationConfiguration.getServiceEndpoint("GET_DRAFT_DATA");
			url=url+"?UserId="+SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId()+"&Type="+Type;
			resp=RestServiceHandler.retrieveTEXT_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			if(resp.length()<=0 || resp==null ) {
				resp=null;
			}
			
			
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		return resp;
	}
}
