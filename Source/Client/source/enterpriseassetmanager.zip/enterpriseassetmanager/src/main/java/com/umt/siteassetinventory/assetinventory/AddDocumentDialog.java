package com.umt.siteassetinventory.assetinventory;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.umt.siteassetinventory.application.ApplicationConstants;

@CssImport("./styles/doc_tab-styles.css")
public class AddDocumentDialog extends Dialog{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_DOCUMENTS_DIALOG";
	private String fileFormat="";
	private String base64EncodedFileContent = "";
	private UIUploadComponent uploadDocDiv;
	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private VerticalLayout bodyLayout;
	private Button saveBtn;
	private Button cancelBtn;
	private boolean fileuploadStatus=false;
	private String fileName="";
	public AddDocumentDialog(DocumentsTab doctabobj, SiteMaster siteMaster2) 
	{
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);
		
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		
		saveBtn.setEnabled(false);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		buttonBar.add(saveBtn,cancelBtn);
		
		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDocDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDocDiv.getUpload();
		uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif",".bmp",".xls",".xlxs");
		int maxfilesize=Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDoc.setMaxFileSize(maxfilesize*1000);
		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					fileName=event.getFileName();
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
						if (fileExtension.equalsIgnoreCase("xls")) {
							fileFormat = "application/vnd.ms-excel";
						} 
						if (fileExtension.equalsIgnoreCase("xlsx")) {
							fileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
						}
						saveBtn.setEnabled(true);
					}
					if (fileExtension.equalsIgnoreCase("jpg")  || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
						fileFormat = "image/"+fileExtension.toLowerCase();
						saveBtn.setEnabled(true);
					}
				} catch (Exception ex) {
				
					base64EncodedFileContent = "";
				}

			}
		});

		uploadDoc.addFailedListener(e -> {
			base64EncodedFileContent = "";
		});
		
		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
			}
		});
		
		bodyLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "BODY_LAYOUT");
		bodyLayout.add(uploadDocDiv);
		mainLayoutDiv.add(titleBar,bodyLayout,buttonBar);
		
		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveBtnClicked(doctabobj,siteMaster2);

			}
		});
	}
	protected void saveBtnClicked(DocumentsTab doctabobj, SiteMaster siteMaster2)
	{
		Boolean isduplicate=doctabobj.validateForDuplicateFiles(fileName,siteMaster2);
	//	System.out.println("isduplicate="+isduplicate);
		if(isduplicate==false)
		{
			fileuploadStatus=true;
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"DOC_SAVED",ApplicationConstants.DialogTypes.INFO);
			close();
		}
		if(isduplicate==true)
		{
			fileuploadStatus=false;
			//SiteAssetInventoryUIFramework.getFramework().showMessage("Document Already exists",ApplicationConstants.DialogTypes.INFO);
			//close();
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"DOC_EXISTS", DialogTypes.ERROR);
		}
	}
	
	public boolean isGetDocUploadStatus() {
		return fileuploadStatus;
	}
	public String getFileName() {
		return fileName;
	}
	public String getFileContent() {
		return base64EncodedFileContent;
	}


}
