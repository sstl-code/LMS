package com.umt.siteassetinventory.utility;

import java.io.Serializable;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class AESEncryptionUtility implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Cipher getCipher()
    {
    	try
		{
    		return Cipher.getInstance("AES/CBC/PKCS5Padding");
		}
    	catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
    }
    
    private IvParameterSpec getIvParameterSpec(String p_strAESKey)
    {
    	return  new IvParameterSpec(p_strAESKey.getBytes());
    }
    
    private SecretKeySpec getSecretKeySpec(String p_strAESKey)
    {
    	return  new SecretKeySpec(p_strAESKey.getBytes(), "AES"); 
    }
    
	public String encrypt(String p_strInput,String p_strAESKey)
    {
		try
		{	
			Cipher l_objCipher = this.getCipher();
			l_objCipher.init(Cipher.ENCRYPT_MODE, this.getSecretKeySpec(p_strAESKey),this.getIvParameterSpec(p_strAESKey));
			byte[] l_byteEncrypted = l_objCipher.doFinal(p_strInput.getBytes());
			String l_strEncrypt = this.convertByteArrayToHexString(l_byteEncrypted);									
			return l_strEncrypt;
		}		  
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}		
    }

    public  String decrypt(String p_strInput, String p_strAESKey)
    {
    	try
		{	
    		Cipher l_objCipher = this.getCipher();
			byte[] l_byteHexString = this.convertHexStringToByteArray(p_strInput);
			l_objCipher.init(Cipher.DECRYPT_MODE,  this.getSecretKeySpec(p_strAESKey),this.getIvParameterSpec(p_strAESKey));
			byte[] l_byteDecrypted = l_objCipher.doFinal(l_byteHexString);							
			return new String(l_byteDecrypted);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}		
    }
    
    private  String convertByteArrayToHexString (byte buf[]) 
    {
         StringBuffer strbuf = new StringBuffer(buf.length * 2);
         int l_StrBufferLength = buf.length;
         
         for (int i = 0; i < l_StrBufferLength; i++) 
         {
	         if(((int)buf[i] & 0xff) < 0x10)
	        	 strbuf.append("0");
	         
	         strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
         }
         return strbuf.toString();
    }
    
    private  byte[] convertHexStringToByteArray(String p_strHexText) 
	{		
		String l_strByte = null;
		byte[] l_bytRawToByte = null;
		
		if(p_strHexText != null && p_strHexText.length() > 0) 
		{
			int l_intNumBytes = p_strHexText.length()/2;
		
			l_bytRawToByte = new byte[l_intNumBytes];
			int l_iOffset = 0;			
			for(int i = 0; i < l_intNumBytes; i++) 
			{
				l_strByte = p_strHexText.substring(l_iOffset, l_iOffset+2);
				l_iOffset += 2;
				l_bytRawToByte[i] = (byte) (Integer.parseInt(l_strByte, 16) & 0x000000FF);
			}			
		}
		return l_bytRawToByte;
	}
}
