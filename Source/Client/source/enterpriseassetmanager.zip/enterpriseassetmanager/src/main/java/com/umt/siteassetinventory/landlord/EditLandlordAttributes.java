package com.umt.siteassetinventory.landlord;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.FileTypeAttributeUploadDialog;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasEnabled;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;


@CssImport("./styles/landlord_attributes_edit-style.css")
public class EditLandlordAttributes extends Div {
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_ATTRIBUTES_EDIT";
	private  Map<String, String> values;
	private JSONArray json_array;
	private ComboBox<String> flov;
	//private NumberField numberField;
	private TextField textField;
	private Div bodyLayout;
	private Map<String, List<Object>> save_data;
	private Map<String, JSONObject> fileAttributeMap = new HashMap<String, JSONObject>();
	private Map<String, List<Object>> updated_save_data;
	private String partitionid = "";

	public EditLandlordAttributes(JSONArray json_array, Map<String, String> values, String landlordID, LandlordView landLordView) {
		this.json_array=json_array;
		this.values=values;
	    
		bodyLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		
		try {
			partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			populateRows(json_array, values);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		add(bodyLayout);
		
//		EditLandlordAttributesPopUp edit = new EditLandlordAttributesPopUp("Edit Landlord Attributes", this, landlordID, save_data, landLordView, fileAttributeMap);
		EditLandlordAttributesPopUp edit = new EditLandlordAttributesPopUp("Edit Landlord Attributes", this, landlordID, updated_save_data, landLordView, fileAttributeMap);
		
	}

	private void populateRows(JSONArray json_array, Map<String, String> values) throws JSONException {
		Div row = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
		Set<String> key_set = values.keySet();
		save_data = new HashMap<>();
		updated_save_data=new HashMap<>();
		String attri_values = null;
		String data_type = null;
		String mandetory = null;
		for (int i = 0; i < json_array.length(); i++) {
			JSONObject json = json_array.getJSONObject(i);
			List<Object> dataTypeList = new ArrayList<>();

			if (json.getString("AttributeType").equals("8")) {

				for (String key : key_set) {

					if (json.getString("AttributeName").equals(key)) {
						// System.out.println("Test: " +key+ " " + values.get(key));
						attri_values = values.get(key);

						break;
					}

				}
				String defaultval = "";
				if (json.has("DefaultValue") && json.getString("DefaultValue") != null
						&& json.getString("DefaultValue").trim().length() > 0) {
					defaultval = json.getString("DefaultValue");
				}
				if (json.getString("AttributeDatatype").equals("5")) {
					data_type = "FLOV";
					mandetory = json.getString("Mandatory");
					List<String> choiceList = new ArrayList<String>();
					String str = json.getString("FLOV");
					String flovVal[] = str.split(",");
					choiceList.clear();
					for (String s : flovVal) {
						choiceList.add(s);
					}
					ComboBox<String> flov = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "FLOV");
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						flov.setValue(defaultval);
					} else {
						flov.setValue(attri_values);
					}

					flov.setLabel(json.getString("AttributeName"));
					if (json.getString("Mandatory").equals("1")) {
						flov.setRequiredIndicatorVisible(true);
						
						
						flov.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
							
							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<String> event) {
								String value = event.getValue();
								if (value != null) {
									flov.setInvalid(false);
									flov.setErrorMessage("");
								}else {
									flov.setInvalid(true);
									flov.focus();
									flov.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
								}

							}
						});
					}
					dataTypeList.add(data_type);
					dataTypeList.add(flov);
					dataTypeList.add(mandetory);
					bodyLayout.add(flov);

				} else if (json.getString("AttributeDatatype").equals("4")) {
					mandetory = json.getString("Mandatory");
					data_type = "DATE_PICKER";
					DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
					ValueDateField.setLabel(json.getString("AttributeName"));
					if (attri_values != null && !attri_values.equals("") && !attri_values.equals("-")) {
						defaultval = attri_values;
					}

					if (defaultval.length() > 0) {
						ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval, "dd/MM/yyyy"));
					}
					if (json.getString("Mandatory").equals("1")) {
						ValueDateField.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(ValueDateField);
					dataTypeList.add(mandetory);
					bodyLayout.add(ValueDateField);
				} else if (json.getString("AttributeDatatype").equals("3")) {
					mandetory = json.getString("Mandatory");
					data_type = "FREEFLOW";
					TextField freeFlow = UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					freeFlow.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						freeFlow.setValue(defaultval);
					} else {
						freeFlow.setValue(attri_values);
					}

					if (json.getString("Mandatory").equals("1")) {
						freeFlow.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(freeFlow);
					dataTypeList.add(mandetory);
					bodyLayout.add(freeFlow);
					
					if(json.getString("AttributeName").equalsIgnoreCase("PIN")) {
						validatePINField(freeFlow);
					}
				} else if (json.getString("AttributeDatatype").equals("2")) {
					mandetory = json.getString("Mandatory");
					data_type = "ALPHANUMERIC";
					TextField textField = UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					textField.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						textField.setValue(defaultval);
					} else {
						textField.setValue(attri_values);
					}

					if (json.getString("Mandatory").equals("1")) {
						textField.setRequiredIndicatorVisible(true);
					}
					textField.setValueChangeMode(ValueChangeMode.EAGER);
					textField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if (!arg0.getValue().toString().matches("^\\w*$")
									|| arg0.getValue().toString().contains("_")) {
								textField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					dataTypeList.add(data_type);
					dataTypeList.add(textField);
					dataTypeList.add(mandetory);
					bodyLayout.add(textField);
					
					if(json.getString("AttributeName").equalsIgnoreCase("PAN")) {
						validatePANField(textField);
					}
				} else if (json.getString("AttributeDatatype").equals("1")) {
				/*	mandetory = json.getString("Mandatory");
					data_type = "NUMERIC";
					TextField numberTextField = UIFieldFactory.createTextField("", false, SCREENCD, "NUMBERFIELD");
					numberTextField.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						if (defaultval.trim().length() > 0) {
							numberTextField.setValue(defaultval);
						}
					} else {
						numberTextField.setValue(attri_values);
					}

					if (json.getString("Mandatory").equals("1")) {
						numberTextField.setInvalid(false);
						numberTextField.setRequiredIndicatorVisible(true);
					}
					numberTextField.setValueChangeMode(ValueChangeMode.EAGER);
					numberTextField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if (!arg0.getValue().toString().matches("[0-9]+")
									&& !arg0.getValue().toString().matches("")) {
								numberTextField.setValue(arg0.getOldValue().toString());
							}
							if (!arg0.getValue().toString().matches("^\\w*$")) {
								numberTextField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					dataTypeList.add(data_type);
					dataTypeList.add(numberTextField);
					dataTypeList.add(mandetory);
					bodyLayout.add(numberTextField);*/
					mandetory = json.getString("Mandatory");
					data_type = "NUMERIC";
					NumberField numberTextField = UIFieldFactory.createNumberField(false, SCREENCD, "NUMBERFIELD");
					numberTextField.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						if (defaultval.trim().length() > 0) {
							numberTextField.setValue(Double.parseDouble(defaultval));
						}
					} else {
						numberTextField.setValue(Double.parseDouble(attri_values));
					}

					if (json.getString("Mandatory").equals("1")) {
						numberTextField.setInvalid(false);
						numberTextField.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(numberTextField);
					dataTypeList.add(mandetory);
					bodyLayout.add(numberTextField);
				} else if (json.getString("AttributeDatatype").equals("6")) {
					data_type = "BOOLEAN";
					mandetory = json.getString("Mandatory");
					Checkbox booleanFld = UIFieldFactory.createCheckbox(false, false, SCREENCD, "VALUE");
					booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
					booleanFld.addClassName(SCREENCD + "_VALUE");
					booleanFld.setLabel(json.getString("AttributeName"));

					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						if (defaultval != null && defaultval.trim().toLowerCase().equals("true")) {
							booleanFld.setValue(true);
						}
					} else {
						if (attri_values.trim().toLowerCase().equals("true")) {
							booleanFld.setValue(true);
						} else {
							booleanFld.setValue(false);
						}
					}

					dataTypeList.add(data_type);
					dataTypeList.add(booleanFld);
					dataTypeList.add(mandetory);
					bodyLayout.add(booleanFld);
				} else if (json.getString("AttributeDatatype").equals("7")) {
					data_type = "MULTIPLE SELECTION";
					mandetory = json.getString("Mandatory");
					CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
					multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
					multiSelectFld.addClassName(SCREENCD + "_VALUE");
					multiSelectFld.setLabel(json.getString("AttributeName"));
					String possibleValues = json.getString("FLOV");
					renderMultiSelectField(multiSelectFld, possibleValues, defaultval, attri_values);

					dataTypeList.add(data_type);
					dataTypeList.add(multiSelectFld);
					dataTypeList.add(mandetory);
					bodyLayout.add(multiSelectFld);
				} else if (json.getString("AttributeDatatype").equals("8")) {
					data_type = "IMAGE FILE";
					mandetory = json.getString("Mandatory");
					//Div fileAttribComp = renderFileUploadComponent(json.getString("AttributeName"), 8);
					UIFileAttributeComponent fileAttribComp = new UIFileAttributeComponent(json.getString("AttributeName"), 8, mandetory, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(data_type);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandetory);
					if(attri_values!=null && attri_values.trim().length() > 0 && !attri_values.equals("-")) {
						//fileAttributeMap.put(json.getString("AttributeName"), new JSONObject(attri_values));
						setFileAttributeValue(fileAttribComp, attri_values);
					}
					bodyLayout.add(fileAttribComp);
				} else if (json.getString("AttributeDatatype").equals("9")) {
					data_type = "TEXT FILE";
					mandetory = json.getString("Mandatory");
					//Div fileAttribComp = renderFileUploadComponent(json.getString("AttributeName"), 9);
					UIFileAttributeComponent fileAttribComp = new UIFileAttributeComponent(json.getString("AttributeName"), 9, mandetory, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(data_type);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandetory);
					if(attri_values!=null && attri_values.trim().length() > 0 && !attri_values.equals("-")) {
						//fileAttributeMap.put(json.getString("AttributeName"), new JSONObject(attri_values));
						setFileAttributeValue(fileAttribComp, attri_values);
					}
					bodyLayout.add(fileAttribComp);
				} else if (json.getString("AttributeDatatype").equals("10")) {
					data_type = "CUSTOM FILE";
					mandetory = json.getString("Mandatory");
					//Div fileAttribComp = renderFileUploadComponent(json.getString("AttributeName"), 10);
					UIFileAttributeComponent fileAttribComp = new UIFileAttributeComponent(json.getString("AttributeName"), 10, mandetory, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(data_type);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandetory);
					if(attri_values!=null && attri_values.trim().length() > 0 && !attri_values.equals("-")) {
						//fileAttributeMap.put(json.getString("AttributeName"), new JSONObject(attri_values));
						setFileAttributeValue(fileAttribComp, attri_values);
					}
					bodyLayout.add(fileAttribComp);
				}

				save_data.put(json.getString("AttributeName"), dataTypeList);
				updated_save_data.put(json.getString("AttributeName"), dataTypeList);
				if(json.getString("AttributeName").equalsIgnoreCase("SAP Vendor Code")) {
					((HasEnabled) dataTypeList.get(1)).setEnabled(false);
				}

			}
		}
		attributeUIOrchestration();
	}
	
	private void validatePANField(TextField attributeAlphanumericFld) {
		attributeAlphanumericFld.setValueChangeMode(ValueChangeMode.EAGER);
		attributeAlphanumericFld.setPattern("([a-zA-Z0-9]{0,10})");//allows  10digit
		attributeAlphanumericFld.setPreventInvalidInput(true);
		
		attributeAlphanumericFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0) {
					 if(attributeAlphanumericFld.getValue().length()!=10) {
						attributeAlphanumericFld.setInvalid(true);
						attributeAlphanumericFld.setErrorMessage("PAN No must be 10 alphanumeric.");
					}
					else {
						attributeAlphanumericFld.setInvalid(false);
						attributeAlphanumericFld.setErrorMessage("");
					}
					 attributeAlphanumericFld.setValue(event.getValue().toUpperCase());
				}


			}
		});
		
	}
	
	private void validatePINField(TextField attributeFreeflowFld) {
		attributeFreeflowFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		attributeFreeflowFld.setPattern("([0-9]{0,6})");//allows  6digit only 
		attributeFreeflowFld.setPreventInvalidInput(true);
		
		attributeFreeflowFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0) {
					 if(attributeFreeflowFld.getValue().length()!=6) {
						 attributeFreeflowFld.setInvalid(true);
						 attributeFreeflowFld.setErrorMessage("PIN must be 6 digits.");
					}
					else {
						attributeFreeflowFld.setInvalid(false);
						attributeFreeflowFld.setErrorMessage("");
					}

				}


			}
		});
			

		
	}
	
	protected String getFileURL(String fileId) {
		String retVal = "";
		try {
			String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
			if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
				retVal = truebyl_domain + "RuleServer/files/" + partitionid + "/Landlord/" + fileId + "/stream";
			}
			else
			{
				retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/Landlord/" 
						       + fileId + "/stream";
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
				       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/Landlord/" 
				       + fileId + "/stream";	
		}
		return retVal;
	}
	
	private void setFileAttributeValue(UIFileAttributeComponent fileAttributeComponent, String fileAttributeValue) {
		if(fileAttributeValue == null || fileAttributeValue.trim().length() == 0) {
			return;
		}
		
		try {
			JSONObject fileDetailJSON = new JSONObject(fileAttributeValue);
			fileAttributeComponent.setFileDetail(fileDetailJSON);
			String href = getFileURL(fileDetailJSON.getString("UUID"));
			fileAttributeComponent.setFileLink(fileDetailJSON.getString("Name"), href); 
			//fileAttributeMap.put(attributeName, new );
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	private void attributeUIOrchestration() {
		
	//		System.out.println("save_dataMap="+save_data.toString());
			if(save_data!=null && save_data.size()>0)
			{	
				Iterator<String> itrKeys = save_data.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=save_data.get(key);
					if(key.equalsIgnoreCase("PAN Status") || key.equalsIgnoreCase("MSME Status") || key.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0)	//value obj
						{	
							String datatype=keyvalue.get(0).toString().toUpperCase();
							switch(datatype)
							{
							case "FLOV":
								if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
									attributeVisibility(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(), key);
								}
								((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
									private static final long serialVersionUID = 1L;
			
									@Override
									public void valueChanged(ValueChangeEvent<?> event) {
										if (event.getValue() != null) {
											attributeVisibility(event.getValue().toString().trim(),key);
										}
									}
								});
								
								break;
							}
						}
					}
					if(key.equalsIgnoreCase("Additional Bank Required")) {
						if(keyvalue.size()>0)	//value obj
						{	
							String datatype=keyvalue.get(0).toString().toUpperCase();
							switch(datatype)
							{
							case "FLOV":
								if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
									attributeVisibility(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(), key);
								}
								((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
									private static final long serialVersionUID = 1L;
			
									@Override
									public void valueChanged(ValueChangeEvent<?> event) {
										if (event.getValue() != null) {
											attributeVisibility(event.getValue().toString().trim(),key);
										}
									}
								});
								
								break;
							}
						}
					}

			
				}
				
			}		
			
		}
	protected void attributeVisibility(String combovalue, String keyName) {
		if(combovalue.equalsIgnoreCase("Available")) {
			if(save_data!=null && save_data.size()>0)
			{	
				Iterator<String> itrKeys = save_data.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=save_data.get(key);
					
					if(key.equalsIgnoreCase("PAN") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("PAN Document") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("GST RC Document") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("GST Number") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updated_save_data.put(key,keyvalue);
						}
						
					}
					
				}
			}
		}else if(combovalue.equalsIgnoreCase("Not Available")) {
			if(save_data!=null && save_data.size()>0)
			{	
				Iterator<String> itrKeys = save_data.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=save_data.get(key);
					
					if(key.equalsIgnoreCase("PAN") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("PAN Document") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}
					else if(key.equalsIgnoreCase("GST RC Document") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}
					else if(key.equalsIgnoreCase("GST Number") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updated_save_data.containsKey(key)) {
								updated_save_data.remove(key);
							}
						}
						
					}
					

				}
			}
			
		}else if(combovalue.equalsIgnoreCase("Yes")){
			Iterator<String> itrKeys = save_data.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=save_data.get(key);
			if(key.equalsIgnoreCase("Beneficiary Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("Bank Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}
			else if(key.equalsIgnoreCase("Bank Account Number EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("IFSC Code EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}/*else if(key.equalsIgnoreCase("Cancelled Cheque Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}*/
			else if(key.trim().equalsIgnoreCase("Cancelled Cheque EB Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updated_save_data.put(key,keyvalue);
				}
				
			}
			}
			
		}else if(combovalue.equalsIgnoreCase("No")){
			Iterator<String> itrKeys = save_data.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=save_data.get(key);
			if(key.equalsIgnoreCase("Beneficiary Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}else if(key.equalsIgnoreCase("Bank Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}
			else if(key.equalsIgnoreCase("Bank Account Number EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}else if(key.equalsIgnoreCase("IFSC Code EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}/*else if(key.equalsIgnoreCase("Cancelled Cheque Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}*/
			else if(key.trim().equalsIgnoreCase("Cancelled Cheque EB Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updated_save_data.containsKey(key)) {
						updated_save_data.remove(key);
					}
				}
				
			}
			}
			
		}
		else {
			
		}
		
	}
	
	private void nonmandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(false);
			((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(false);
			((NumberField)keyvalue.get(1)).setInvalid(false);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(false);
			((DatePicker)keyvalue.get(1)).setInvalid(false);
			
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			break;
		
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(false);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(false);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			break;
		}

		
	}
	private void mandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(true);
			((ComboBox<Object>)keyvalue.get(1)).setRequired(true);
			((ComboBox<Object>)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
			
			((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<?> event) {
					if (event.getValue() == null) {
					
						((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
						((ComboBox<Object>)keyvalue.get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
						
					}else {
						((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
						((ComboBox<Object>)keyvalue.get(1)).setErrorMessage("");
					}
				}
			});
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(true);
	//		((NumberField)keyvalue.get(1)).setRequired(true);
			((NumberField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((TextField)keyvalue.get(1)).setInvalid(true);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setRequired(true);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((TextField)keyvalue.get(1)).setInvalid(true);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(true);
			((DatePicker)keyvalue.get(1)).setRequired(true);
			((DatePicker)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//((DatePicker)keyvalue.get(1)).setInvalid(true);
			
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setRequired(true);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
		//	((TextField)keyvalue.get(1)).setInvalid(true);
			break;
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(true);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(true);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			break;
		}
	}

		
	

	
	protected Div renderFileUploadComponent(String aname, int adatatype) {
		Div fileAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ATTRIB_DIV");
		Button fileAttributeBtn = UIFieldFactory.createButton(SCREENCD, "FILE_ATTRIB_BTN");
		fileAttributeBtn.setText(SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "FILE_ATTRIB_BTN"));
		
		fileAttributeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				String [] acceptedFileTypes = null;
				if(adatatype == 8) {
					acceptedFileTypes = ".png,.jpg,.jpeg,.gif,.bmp".split("[,]");
				} else if(adatatype == 9) {
					acceptedFileTypes = ".txt".split("[,]");
					//uploadDoc.setAcceptedFileTypes(".txt");
				} else if(adatatype == 10) {
					//uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif",".bmp",".xls",".xlsx");
					acceptedFileTypes = ".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.bmp,.xls,.xlsx".split("[,]");
				}

				FileTypeAttributeUploadDialog uploadDlg = new FileTypeAttributeUploadDialog(aname, "Landlord File Attribute", acceptedFileTypes);
				uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						FileTypeAttributeUploadDialog dlg = (FileTypeAttributeUploadDialog)event.getSource();
						if(!dlg.isOpened()) {
							if(dlg.isGetDocUploadStatus()) {
								JSONObject fileDetailJSON = dlg.getFileDetail();
								if(fileDetailJSON != null && fileDetailJSON.length() > 0) {
									fileAttributeMap.put(aname, fileDetailJSON);
								}
								else {
									fileAttributeMap.remove(aname);
								}
							}
							else {
								fileAttributeMap.remove(aname);
							}
						}
					}
				});
			}
		});
		
		Label fileAttributeLbl = UIHtmlFieldFactory.createLabel(aname, SCREENCD, "FILE_ATTRIB_LBL");
		fileAttributeDiv.add(fileAttributeLbl, fileAttributeBtn);
		return fileAttributeDiv;
	}
	
	protected void renderMultiSelectField(CheckboxGroup<String> multiSelectFld, String possibleValues, String defaultValue, String attributeValue) {
		try {
			JSONObject json = new JSONObject(possibleValues);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));

			List<String> possibleValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				possibleValuesList.add(jsonArray.getString(i));
			}
			
			json = new JSONObject(defaultValue);

			jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));

			List<String> defaultValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				defaultValuesList.add(jsonArray.getString(i));
			}
			
			multiSelectFld.setItems(possibleValuesList);
			
			if(attributeValue==null || attributeValue.equals("-") || attributeValue.equals("")) {
				multiSelectFld.select(defaultValuesList);
			} else {
				json = new JSONObject(attributeValue);
				jsonArray = new JSONArray(json.getString("MultiSelectValue"));
				List<String> attributeValuesList = new ArrayList<String>();
				for (int i = 0; i < jsonArray.length(); i++) {
					attributeValuesList.add(jsonArray.getString(i));
				}
				multiSelectFld.select(attributeValuesList);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
