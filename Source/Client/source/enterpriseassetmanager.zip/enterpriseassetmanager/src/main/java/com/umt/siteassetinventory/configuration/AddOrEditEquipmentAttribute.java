package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.listbox.ListBox;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/add_edit_equipment_attribute-styles.css")
public class AddOrEditEquipmentAttribute extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_EQUIPMENT_ATTRIBUTE";

	private TextField attributeNameFld, flovFld, defaultValueTxtFld;
	protected DatePicker defaultValueDateFld;
	private ComboBox<String> equipmentTypeCombo, equipmentCombo, attributeDataTypeCombo, defaultValueCombo;
	private Checkbox mandatoryChkBox;
	//private String siteCode;
	private long attributeId;
	private Map<Long, String> activeEquipmentTypeMap, passiveEquipmentTypeMap;
	private RadioButtonGroup<String> defaultValueBoolFld;
	private ListBox<String> listOfValuesMultiSelectFld;
	private ArrayList<String> multiSelectValueArrayList = new ArrayList<String>();
	private ListDataProvider<String> multiSelectValueDataProvider;
	private Button addMultiSelectValueBtn, removeMultiSelectValueBtn;
	private TextField multiSelectValueTxtFld;
	private Div multiSelectValueInputDiv;
	private Label multipleSelectionDefaultValueLbl;
	private CheckboxGroup<String> defaultValueMultiSelectFld;

	public AddOrEditEquipmentAttribute(EquipmentAttributeMaster attributeMaster, Map<Long, String> activeEquipmentTypeMap, 
			Map<Long, String> passiveEquipmentTypeMap) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.activeEquipmentTypeMap = activeEquipmentTypeMap;
		this.passiveEquipmentTypeMap = passiveEquipmentTypeMap;
		attributeNameFld = UIFieldFactory.createTextField("", true, SCREENCD, "ATTRIBUTE_NAME_FIELD");
		equipmentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV("ADD_EDIT_EQUIPMENT_TYPE", "SERVICE_TYPE_LIST", ','),
				true, SCREENCD, "EQUIPMENT_TYPE_COMBO");
		equipmentTypeCombo.setValue("Active");
		equipmentCombo = UIFieldFactory.createComboBox(new ArrayList<String>(),true, SCREENCD, "EQUIPMENT_COMBO");
		List<String> listOfValues = new ArrayList<String>();
		//System.out.println("equipmentTypeMap size="+equipmentTypeMap.size()+" equipmentTypeMap="+equipmentTypeMap.toString());
		activeEquipmentTypeMap.forEach((k,v) -> {
			//System.out.println("key="+k);
			listOfValues.add(activeEquipmentTypeMap.get(k));
		});
		equipmentCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
		flovFld = UIFieldFactory.createTextField("", false, SCREENCD, "FLOV_FIELD");

		defaultValueTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "DEFAULT_VALUE_TXT_FIELD");
		defaultValueDateFld = UIFieldFactory.createDatePicker(false, SCREENCD, "DEFAULT_VALUE_DATE_FIELD");
		defaultValueCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), false, SCREENCD,
				"DEFAULT_VALUE_COMBO");
		mandatoryChkBox = UIFieldFactory.createCheckbox(false, true, SCREENCD, "MANDATORY_CHKBOX");

		attributeDataTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ATTRIBUTE_DATA_TYPE_LIST", ','), true, 
				SCREENCD, "ATTRIBUTE_DATA_TYPE_COMBO");
		
		defaultValueBoolFld = new RadioButtonGroup<String>();
		defaultValueBoolFld.setItems("True", "False");
		defaultValueBoolFld.addClassName(SCREENCD + "_DEFAULT_VALUE_BOOL_FLD");
		defaultValueBoolFld.setLabel(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DEFAULT_VALUE_BOOL_FLD"));
		defaultValueBoolFld.setValue("False");
		
		listOfValuesMultiSelectFld = new ListBox<String>();
		multiSelectValueDataProvider = new ListDataProvider<String>(multiSelectValueArrayList);
		listOfValuesMultiSelectFld.setDataProvider(multiSelectValueDataProvider);
		listOfValuesMultiSelectFld.setId(SCREENCD + "_LIST_OF_VALUE_MULTI_SELECT_FLD");
		//listOfValuesMultiSelectFld.
		addMultiSelectValueBtn = UIFieldFactory.createButton(SCREENCD, "ADD_MULTI_SELECT_VALUE_BTN");
		removeMultiSelectValueBtn = UIFieldFactory.createButton(SCREENCD, "REMOVE_MULTI_SELECT_VALUE_BTN");
		multiSelectValueTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "MULTI_SELECT_VALUE_TXT_FLD");
		multiSelectValueInputDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MULTI_SELECT_VALUE_INPUT_DIV");
		multiSelectValueInputDiv.add(multiSelectValueTxtFld, addMultiSelectValueBtn, removeMultiSelectValueBtn);
		defaultValueMultiSelectFld = new CheckboxGroup<String>();
		defaultValueMultiSelectFld.addClassName(SCREENCD + "_DEFAULT_VALUE_MULTI_SELECT_FLD");
		defaultValueMultiSelectFld.setLabel(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DEFAULT_VALUE_MULTI_SELECT_FLD"));
		
		AddOrEditEquipmentAttributePopup popup = new AddOrEditEquipmentAttributePopup("Add Equipment Attribute", true, this, attributeMaster, SCREENCD);
		
		Label multipleSelectionPossibleValuesLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MULTI_SELECT_POSSIBLE_VALUES_LBL");
		multipleSelectionDefaultValueLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MULTI_SELECT_DEFAULT_VALUES_LBL");
		
		add(equipmentTypeCombo, equipmentCombo, attributeNameFld, attributeDataTypeCombo, mandatoryChkBox, flovFld,
				multipleSelectionPossibleValuesLbl, multiSelectValueInputDiv, listOfValuesMultiSelectFld,
				defaultValueTxtFld, defaultValueCombo, defaultValueDateFld, defaultValueBoolFld,
				multipleSelectionDefaultValueLbl, defaultValueMultiSelectFld);

		attributeDataTypeChangeHandler();
		flovChangeHandler();

		equipmentTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				equipmentTypeChangeHandler();
			}
		});

		attributeDataTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				attributeDataTypeChangeHandler();
			}
		});

		flovFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				flovChangeHandler();
			}
		});
		
		addMultiSelectValueBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				addMultiSelectionOption();
			}
		});
		
		removeMultiSelectValueBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				removeMultiSelectOption();
			}
		});

		defaultValueTxtFld.setValueChangeMode(ValueChangeMode.EAGER);
		defaultValueTxtFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> arg0) {

				if (attributeDataTypeCombo.getValue()!=null) {
					if (attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("Numeric")) {
						if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
						{
							defaultValueTxtFld.setValue(arg0.getOldValue().toString());
						}
					}
					if (attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("Numeric") || attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("AlphaNumeric")) {
						if (! ((String) defaultValueTxtFld.getValue()).matches("^\\w*$") || ((String) defaultValueTxtFld.getValue()).contains("_")) {
							defaultValueTxtFld.setValue(arg0.getOldValue().toString());
						}
					}
				}
			}
		});
	}

	public AddOrEditEquipmentAttribute(EquipmentAttributeMaster attributeMaster, EquipmentAttributeMasterDataBean 
			attributeMasterDataBean, long attributeId, String attributeName, String equipmentType, String dataType, 
			boolean mandatory, String defaultValue, String flov, Map<Long, String> activeEquipmentTypeMap, 
			Map<Long, String> passiveEquipmentTypeMap) {

		this.attributeId = attributeId;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.activeEquipmentTypeMap = activeEquipmentTypeMap;
		this.passiveEquipmentTypeMap = passiveEquipmentTypeMap;
		try {
			attributeNameFld = UIFieldFactory.createTextField(attributeName, true, SCREENCD, "ATTRIBUTE_NAME_FIELD");
			attributeNameFld.setEnabled(false);
			equipmentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV("ADD_EDIT_EQUIPMENT_TYPE", "SERVICE_TYPE_LIST", ','),
					true, SCREENCD, "EQUIPMENT_TYPE_COMBO");
			activeEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				if(activeEquipmentTypeMap.get(k).equals(equipmentType))
				{
					equipmentTypeCombo.setValue("Active");
				}
			});
			passiveEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				if(passiveEquipmentTypeMap.get(k).equals(equipmentType))
				{
					equipmentTypeCombo.setValue("Passive");
				}
			});
			equipmentTypeCombo.setEnabled(false);
			equipmentCombo = UIFieldFactory.createComboBox(new ArrayList<String>(),true, SCREENCD, "EQUIPMENT_COMBO");
			List<String> listOfValues = new ArrayList<String>();
			activeEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				listOfValues.add(activeEquipmentTypeMap.get(k));
			});
			equipmentCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
			equipmentCombo.setValue(equipmentType);
			equipmentCombo.setEnabled(false);
			attributeDataTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ATTRIBUTE_DATA_TYPE_LIST", ','), true, 
					SCREENCD, "ATTRIBUTE_DATA_TYPE_COMBO");
			attributeDataTypeCombo.setValue(dataType);
			attributeDataTypeCombo.setEnabled(false);
			flovFld = UIFieldFactory.createTextField(flov, false, SCREENCD, "FLOV_FIELD");

			defaultValueTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "DEFAULT_VALUE_TXT_FIELD");
			defaultValueDateFld = UIFieldFactory.createDatePicker(false, SCREENCD, "DEFAULT_VALUE_DATE_FIELD");
			defaultValueCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), false, SCREENCD,
					"DEFAULT_VALUE_COMBO");
			mandatoryChkBox = UIFieldFactory.createCheckbox(mandatory, true, SCREENCD, "MANDATORY_CHKBOX");
			mandatoryChkBox.setEnabled(false);
			
			defaultValueBoolFld = new RadioButtonGroup<String>();
			defaultValueBoolFld.setItems("True", "False");
			defaultValueBoolFld.addClassName(SCREENCD + "_DEFAULT_VALUE_BOOL_FLD");
			defaultValueBoolFld.setLabel(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DEFAULT_VALUE_BOOL_FLD"));
			defaultValueBoolFld.setValue("False");
			
			listOfValuesMultiSelectFld = new ListBox<String>();
			multiSelectValueDataProvider = new ListDataProvider<String>(multiSelectValueArrayList);
			listOfValuesMultiSelectFld.setDataProvider(multiSelectValueDataProvider);
			listOfValuesMultiSelectFld.setId(SCREENCD + "_LIST_OF_VALUE_MULTI_SELECT_FLD");
			addMultiSelectValueBtn = UIFieldFactory.createButton(SCREENCD, "ADD_MULTI_SELECT_VALUE_BTN");
			removeMultiSelectValueBtn = UIFieldFactory.createButton(SCREENCD, "REMOVE_MULTI_SELECT_VALUE_BTN");
			multiSelectValueTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "MULTI_SELECT_VALUE_TXT_FLD");
			multiSelectValueInputDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MULTI_SELECT_VALUE_INPUT_DIV");
			multiSelectValueInputDiv.add(multiSelectValueTxtFld, addMultiSelectValueBtn, removeMultiSelectValueBtn);
			defaultValueMultiSelectFld = new CheckboxGroup<String>();
			defaultValueMultiSelectFld.addClassName(SCREENCD + "_DEFAULT_VALUE_MULTI_SELECT_FLD");
			defaultValueMultiSelectFld.setLabel(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DEFAULT_VALUE_MULTI_SELECT_FLD"));
			
			Label multipleSelectionPossibleValuesLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MULTI_SELECT_POSSIBLE_VALUES_LBL");
			multipleSelectionDefaultValueLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MULTI_SELECT_DEFAULT_VALUES_LBL");
			
			attributeDataTypeChangeHandler();
			
			if (dataType.equalsIgnoreCase("Fixed List of Values")) {
				flovFld.setValue(flov);
			} else {
				flovFld.setValue("");
			}
			
			flovChangeHandler();
			
			if(attributeDataTypeCombo.getValue().equalsIgnoreCase("Multiple Selection")) {  
				populatePossibleValuesForMultiSelect(flov);
			}
			
			if (defaultValue!=null && defaultValue.trim().length()>0) {
				switch (attributeDataTypeCombo.getValue().trim().toUpperCase()) {			
				case "DATE":
					defaultValueDateFld.setValue(CommonUtils.convertStringToLocalDate(defaultValue, "dd/MM/yyyy"));
					break;
				case "FIXED LIST OF VALUES":
					defaultValueCombo.setValue(defaultValue);
					break;
				case "BOOLEAN":
					defaultValueBoolFld.setValue(defaultValue);
					break;
				case "MULTIPLE SELECTION":	
					populateDefaultValueForMultiSelect(defaultValue);
					break;
				case "IMAGE FILE":
				case "CUSTOM FILE":
				case "TEXT FILE":
					defaultValueTxtFld.setEnabled(false);
					defaultValueTxtFld.setVisible(true);
					break;
				default:
					defaultValueTxtFld.setValue(defaultValue);
					break;
				}
			}

			AddOrEditEquipmentAttributePopup popup = new AddOrEditEquipmentAttributePopup("Edit Equipment Attribute", false, this, attributeMaster, SCREENCD);

			add(equipmentTypeCombo, equipmentCombo, attributeNameFld, attributeDataTypeCombo, mandatoryChkBox, flovFld,
					multipleSelectionPossibleValuesLbl, multiSelectValueInputDiv, listOfValuesMultiSelectFld,
					defaultValueTxtFld, defaultValueCombo, defaultValueDateFld, defaultValueBoolFld,
					multipleSelectionDefaultValueLbl, defaultValueMultiSelectFld);

			equipmentTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					equipmentTypeChangeHandler();
				}
			});

			attributeDataTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					attributeDataTypeChangeHandler();
				}
			});

			flovFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					flovChangeHandler();
				}
			});
			
			addMultiSelectValueBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					addMultiSelectionOption();
				}
			});
			
			removeMultiSelectValueBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					removeMultiSelectOption();
				}
			});
			
			defaultValueTxtFld.setValueChangeMode(ValueChangeMode.EAGER);
//			defaultValueTxtFld.setPattern("^[0-9.-]*$");
//			defaultValueTxtFld.setPreventInvalidInput(true);
			defaultValueTxtFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<?> arg0) {

					if (attributeDataTypeCombo.getValue()!=null) {
						if (attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("Numeric")) {
							if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							{
								defaultValueTxtFld.setValue(arg0.getOldValue().toString());
							}
						}
						if (attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("Numeric") || attributeDataTypeCombo.getValue().trim().equalsIgnoreCase("AlphaNumeric")) {
							if (! ((String) defaultValueTxtFld.getValue()).matches("^\\w*$") || ((String) defaultValueTxtFld.getValue()).contains("_")) {
								defaultValueTxtFld.setValue(arg0.getOldValue().toString());
							}
						}
					}
				}
			});

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void populatePossibleValuesForMultiSelect(String flov) {
		try {
			JSONObject json = new JSONObject(flov);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));
			multiSelectValueArrayList.clear();
			for (int i = 0; i < jsonArray.length(); i++) {
				multiSelectValueArrayList.add(jsonArray.getString(i));
			}
			multiSelectValueDataProvider.refreshAll();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected void populateDefaultValueForMultiSelect(String defaultValue) {
		try {
			JSONObject json = new JSONObject(defaultValue);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));
			List<String> selectedItemList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				selectedItemList.add(jsonArray.getString(i));
			}
			defaultValueMultiSelectFld.setItems(multiSelectValueArrayList);
			defaultValueMultiSelectFld.select(selectedItemList);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	protected void updateMultiSelectOptions() {
		Set<String> selectedItems = defaultValueMultiSelectFld.getSelectedItems();
		defaultValueMultiSelectFld.setItems(new ArrayList<String>());
		defaultValueMultiSelectFld.setItems(multiSelectValueArrayList);
		List<String> updatedSelectedItemList = new ArrayList<String>();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachitem = iterator.next();
			if (multiSelectValueArrayList.contains(eachitem)) {
				updatedSelectedItemList.add(eachitem);
			}
		}

		defaultValueMultiSelectFld.select(updatedSelectedItemList);
	}

	protected void addMultiSelectionOption() {
		multiSelectValueTxtFld.setErrorMessage("");
		multiSelectValueTxtFld.setInvalid(false);
		if (multiSelectValueTxtFld.getValue() == null || multiSelectValueTxtFld.getValue().trim().length() == 0) {
			multiSelectValueTxtFld.setInvalid(true);
			multiSelectValueTxtFld.setErrorMessage("Please enter a value.");
			return;
		}

		for (int i = 0; i < multiSelectValueArrayList.size(); i++) {
			if (multiSelectValueArrayList.get(i).trim().equalsIgnoreCase(multiSelectValueTxtFld.getValue().trim())) {
				multiSelectValueTxtFld.setInvalid(true);
				multiSelectValueTxtFld.setErrorMessage("Provided text already exists in list.");
				return;
			}
		}

		multiSelectValueArrayList.add(multiSelectValueTxtFld.getValue().trim());
		multiSelectValueDataProvider.refreshAll();
		updateMultiSelectOptions();
	}

	protected void removeMultiSelectOption() {
		if (listOfValuesMultiSelectFld.getValue() == null) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select an item to remove",
					DialogTypes.INFO);
			return;
		}
		multiSelectValueArrayList.remove(listOfValuesMultiSelectFld.getValue());
		multiSelectValueDataProvider.refreshAll();
		updateMultiSelectOptions();
	}

	private void attributeDataTypeChangeHandler() {

		defaultValueTxtFld.setVisible(false);
		defaultValueCombo.setVisible(false);
		defaultValueDateFld.setVisible(false);

		defaultValueTxtFld.clear();
		defaultValueCombo.clear();
		defaultValueDateFld.clear();
		flovFld.clear();
		flovFld.setEnabled(false);

		defaultValueBoolFld.setVisible(false);
		multipleSelectionDefaultValueLbl.setVisible(false);
		defaultValueMultiSelectFld.setVisible(false);
		defaultValueBoolFld.clear();
		defaultValueBoolFld.setValue("False");
		defaultValueMultiSelectFld.clear();
		defaultValueMultiSelectFld.setItems(new ArrayList<String>());

		multiSelectValueTxtFld.clear();
		multiSelectValueInputDiv.setEnabled(false);
		listOfValuesMultiSelectFld.clear();
		multiSelectValueArrayList.clear();
		multiSelectValueDataProvider.refreshAll();
		listOfValuesMultiSelectFld.setEnabled(false);

		if (attributeDataTypeCombo.getValue() != null) {
			switch (attributeDataTypeCombo.getValue().trim().toUpperCase()) {
			case "DATE":
				defaultValueDateFld.setVisible(true);
				break;
			case "FIXED LIST OF VALUES":
				defaultValueCombo.setVisible(true);
				flovFld.setEnabled(true);
				break;
			case "BOOLEAN":
				defaultValueBoolFld.setVisible(true);
				break;
			case "MULTIPLE SELECTION":
				multiSelectValueInputDiv.setEnabled(true);
				listOfValuesMultiSelectFld.setEnabled(true);
				multipleSelectionDefaultValueLbl.setVisible(true);
				defaultValueMultiSelectFld.setVisible(true);
				break;
			case "IMAGE FILE":
			case "CUSTOM FILE":
			case "TEXT FILE":
				defaultValueTxtFld.setEnabled(false);
				defaultValueTxtFld.setVisible(true);
				break;
			default:
				defaultValueTxtFld.setEnabled(true);
				defaultValueTxtFld.setVisible(true);
				/*
				 * defaultValueTxtFld.clear(); defaultValueCombo.clear();
				 * defaultValueDateFld.clear(); flovFld.clear(); flovFld.setEnabled(false);
				 * defaultValueBoolFld.clear(); defaultValueBoolFld.setEnabled(false);
				 * defaultValueMultiSelectFld.clear();
				 * defaultValueMultiSelectFld.setEnabled(false); multiSelectValueTxtFld.clear();
				 * multiSelectValueInputDiv.setEnabled(false);
				 */
				break;
			}
		} else {
			defaultValueTxtFld.setEnabled(true);
			defaultValueTxtFld.setVisible(true);
			flovFld.setEnabled(false);
		}
	}

	private void equipmentTypeChangeHandler() {
		List<String> listOfValues = new ArrayList<String>();
		if (equipmentTypeCombo.getValue()!=null && equipmentTypeCombo.getValue().trim().length()>0) {
			if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("ACTIVE")) {
				activeEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(activeEquipmentTypeMap.get(k));
				});	
			} else if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("PASSIVE")) {
				passiveEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(passiveEquipmentTypeMap.get(k));
				});	
			}				
		}
		equipmentCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
	}
	

	private void flovChangeHandler() {
		defaultValueCombo.clear();
		if (flovFld.getValue()!=null && flovFld.getValue().trim().length()>0) {
			String[] parsedValueArray = flovFld.getValue().split("[,]");
			List<String> listOfValues = new ArrayList<String>();
			for (int i = 0; i < parsedValueArray.length; i++) {
				listOfValues.add(parsedValueArray[i]);
			}
			defaultValueCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
		}
		else
		{
			defaultValueCombo.setDataProvider(new ListDataProvider<String>(new ArrayList<String>()));
		}
	}

	public boolean validation() {
		equipmentTypeCombo.setInvalid(false);
		attributeNameFld.setInvalid(false);
		attributeDataTypeCombo.setInvalid(false);
		flovFld.setInvalid(false);
		defaultValueTxtFld.setInvalid(false);
		defaultValueCombo.setInvalid(false);
		defaultValueDateFld.setInvalid(false);

		if (equipmentTypeCombo.getValue()==null|| equipmentTypeCombo.getValue().trim().length()==0) {
			equipmentTypeCombo.setInvalid(true);
			equipmentTypeCombo.setErrorMessage("Please enter "+equipmentTypeCombo.getLabel().toLowerCase());
			return false;
		}

		if (equipmentCombo.getValue()==null || equipmentCombo.getValue().trim().length()==0) {
			equipmentCombo.setInvalid(true);
			equipmentCombo.setErrorMessage("Please enter "+equipmentCombo.getLabel().toLowerCase());
			return false;
		}

		if (attributeNameFld.getValue()==null || attributeNameFld.getValue().trim().length()==0) {
			attributeNameFld.setInvalid(true);
			attributeNameFld.setErrorMessage("Please enter "+attributeNameFld.getLabel().toLowerCase());
			return false;
		}

		if (attributeDataTypeCombo.getValue()==null || attributeDataTypeCombo.getValue().trim().length()==0) {
			attributeDataTypeCombo.setInvalid(true);
			attributeDataTypeCombo.setErrorMessage("Please enter "+attributeDataTypeCombo.getLabel().toLowerCase());
			return false;
		}
		
		if(attributeDataTypeCombo.getValue().equalsIgnoreCase("Multiple Selection")) { 
			if(multiSelectValueArrayList.size() == 0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "POSSIBLE_VAL_MULTI_SELECT_TYPE_REQ", DialogTypes.INFO);
				return false;
			}
		}
		
		if (mandatoryChkBox.getValue()) {
			if (attributeDataTypeCombo.getValue().equalsIgnoreCase("Date")) {
				if (defaultValueDateFld.getValue() == null) {
					defaultValueDateFld.setErrorMessage("Please enter "+defaultValueDateFld.getLabel().toLowerCase());
					defaultValueDateFld.setInvalid(true);
					defaultValueDateFld.focus();
					return false;
				}
			} 
			else
				if (attributeDataTypeCombo.getValue().equalsIgnoreCase("Fixed List of Values")) {
					if (defaultValueCombo.getValue() == null || defaultValueCombo.getValue().trim().length() == 0) {
						defaultValueCombo.setErrorMessage("Please enter "+defaultValueCombo.getLabel().toLowerCase());
						defaultValueCombo.setInvalid(true);
						defaultValueCombo.focus();
						return false;
					}
				} 
				else if(attributeDataTypeCombo.getValue().equalsIgnoreCase("Boolean")) {
					String defBoolVal = getBooleanDefaultValue();

					if(defBoolVal == null || defBoolVal.trim().length() == 0) {
						SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DEF_VAL_BOOLEAN_TYPE_REQ", DialogTypes.INFO);
						return false;
					}                                                                                                                                                                  
				}
				else if(attributeDataTypeCombo.getValue().equalsIgnoreCase("Multiple Selection")) {
					Set<String> defMultiSelVal = defaultValueMultiSelectFld.getSelectedItems();
					if(defMultiSelVal.isEmpty()) {
						SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DEF_VAL_MULTISELECT_TYPE_REQ", DialogTypes.INFO);
						return false;
					} 
				} 
				else if (attributeDataTypeCombo.getValue().equalsIgnoreCase("Image File")
						 || attributeDataTypeCombo.getValue().equalsIgnoreCase("Text File")
						 || attributeDataTypeCombo.getValue().equalsIgnoreCase("Custom File")) {
					//do nothing
				}
				else
				{
					if (defaultValueTxtFld.getValue() == null || defaultValueTxtFld.getValue().trim().length() == 0) {
						defaultValueTxtFld.setErrorMessage("Please enter "+defaultValueTxtFld.getLabel().toLowerCase());
						defaultValueTxtFld.setInvalid(true);
						defaultValueTxtFld.focus();
						return false;
					}
				} 
		}

		/*if (flovFld.getValue()==null || flovFld.getValue().trim().length()==0) {
			flovFld.setInvalid(true);
			flovFld.setErrorMessage("Please enter "+flovFld.getLabel().toLowerCase());
			return false;
		}*/

		//		switch (attributeDataTypeCombo.getValue().trim().toUpperCase()) {			
		//		case "DATE":
		//			if (defaultValueDateFld.getValue()==null) {
		//				defaultValueDateFld.setInvalid(true);
		//				defaultValueDateFld.setErrorMessage("Please enter "+defaultValueDateFld.getLabel().toLowerCase());
		//				return false;
		//			}
		//			break;				
		//		case "FIXED LIST OF VALUES":
		//			if (defaultValueCombo.getValue()==null || defaultValueCombo.getValue().trim().length()==0) {
		//				defaultValueCombo.setInvalid(true);
		//				defaultValueCombo.setErrorMessage("Please enter "+defaultValueCombo.getLabel().toLowerCase());
		//				return false;
		//			}
		//			break;
		//		default:
		//			if (defaultValueTxtFld.getValue()==null || defaultValueTxtFld.getValue().trim().length()==0) {
		//				defaultValueTxtFld.setInvalid(true);
		//				defaultValueTxtFld.setErrorMessage("Please enter "+defaultValueTxtFld.getLabel().toLowerCase());
		//				return false;
		//			}
		//			break;
		//		}
		return true;
	}


	public long getAttributeId() {
		return attributeId;
	}

	public int getEquipmentTypeId() {
		Map<Long, String> equipmentTypeMap = new HashMap<>();
		if (equipmentCombo.getValue()==null)
			return 0;
		else
		{
			if (equipmentTypeCombo.getValue()!=null && equipmentTypeCombo.getValue().trim().length()>0) {
				if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("ACTIVE")) {
					equipmentTypeMap = activeEquipmentTypeMap;
				} else if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("PASSIVE")) {
					equipmentTypeMap = passiveEquipmentTypeMap;
				}
				Iterator<Long> equipmentKeys = equipmentTypeMap.keySet().iterator();
				while (equipmentKeys.hasNext()) {
					long key = equipmentKeys.next();
					if (equipmentTypeMap.get(key).trim().equals(equipmentCombo.getValue().trim())) {
						//System.out.println("key from get="+key);
						return Integer.valueOf(key+"");
					}

				}
			}
		}
		return 0;
	}

	public String getAttributeName() {
		if (attributeNameFld.getValue()==null)
			return "";
		else
			return attributeNameFld.getValue();
	}

	public String getAttributeDataType() {
		if (attributeDataTypeCombo.getValue()==null)
			return "";
		else
			return attributeDataTypeCombo.getValue()+"";
	}

	public int getMandatory() {
		if (mandatoryChkBox.getValue()) {
			return 1;
		} else {
			return 0;
		}
	}

	public String getFlov() {
		if (flovFld.getValue()==null)
			return "";
		else
			return flovFld.getValue();
	}
	
	public String getPossibleValuesForMultiSelection() throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		for(int i = 0; i < multiSelectValueArrayList.size(); i++) {
			jsonArray.put(multiSelectValueArrayList.get(i));
		}
		
		retVal.put("MultiSelectOptions", jsonArray.toString());
		
		return retVal.toString();
	}
	
	public String getMultiSelectDefaultValue() throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Set<String> selectedItems = defaultValueMultiSelectFld.getSelectedItems();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachVal = iterator.next();
			jsonArray.put(eachVal);
		}

		retVal.put("MultiSelectDefaultValue", jsonArray.toString());

		return retVal.toString();
	}
	
	public String getBooleanDefaultValue() {
		return defaultValueBoolFld.getValue();
	}

	public String getDefaultValue() throws JSONException {
		if (attributeDataTypeCombo.getValue()!=null) {
			switch (attributeDataTypeCombo.getValue().trim().toUpperCase()) {			
			case "DATE":
				if (defaultValueDateFld.getValue()==null)
					return "";
				else
					return CommonUtils.convertLocalDateToString(defaultValueDateFld.getValue(), "dd/MM/yyyy");
			case "FIXED LIST OF VALUES":
				if (defaultValueCombo.getValue()==null)
					return "";
				else
					return defaultValueCombo.getValue();
			case "BOOLEAN":
				return getBooleanDefaultValue();
			case "MULTIPLE SELECTION":
				return getMultiSelectDefaultValue();
			case "IMAGE FILE":
			case "CUSTOM FILE":
			case "TEXT FILE":
				return "";
			default:
				if (defaultValueTxtFld.getValue()==null)
					return "";
				else
					return defaultValueTxtFld.getValue();
			}
		}
		else
		{
			if (defaultValueTxtFld.getValue()==null)
				return "";
			else
				return defaultValueTxtFld.getValue();
		}
	}


}
