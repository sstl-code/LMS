package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/equipment_type_vendor_association_master-styles.css")
public class EquipmentTypeVendorAssociationMaster extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENT_TYPE_VENDOR_ASSOCIATION_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<EquipmentTypeVendorAssociationMasterDataBean> equipmentVendorAssociationDataBeanList;
	private ConfigView parent;
	private boolean vendorOrOperator;
	//private Label lbl1, lbl2, lbl3, lbl4, lbl5;
	//private String siteCode;

	public EquipmentTypeVendorAssociationMaster(ConfigView parent, boolean vendorOrOperator) {
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		
		this.parent = parent;
		this.vendorOrOperator = vendorOrOperator;

		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");
		
		if (vendorOrOperator) {
			filterFld.setPlaceholder("Filter Equipment Type Vendor Association");
		}
		else
		{
			addBtn.setText("Add Equipment Type Operator Association");
			filterFld.setPlaceholder("Filter Equipment Type Operator Association");
		}

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		//Div eachrowDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV6");

//		for (int i = 0; i < fieldCounts; i++) {
//			Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV");
//			Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL");
//			eachrowDiv.add(lbl);
//			tableHeaderDiv.add(eachrowDiv);
//		}
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);
//		Label lbl6 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL6");
//		eachrowDiv6.add(lbl6);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2);
		if (vendorOrOperator) {
			lbl1.setText("Vendor");
			tableHeaderDiv.add(eachrowDiv3, eachrowDiv4, eachrowDiv5);
		}
		else {
			eachrowDiv1.removeClassName(SCREENCD+"_EACH_HEADER_ROW_DIV1");
			eachrowDiv2.removeClassName(SCREENCD+"_EACH_HEADER_ROW_DIV2");
			
			eachrowDiv1.addClassName(SCREENCD+"_EACH_HEADER_ROW_DIV_2FLDS");
			eachrowDiv2.addClassName(SCREENCD+"_EACH_HEADER_ROW_DIV_2FLDS");
		}

		filterDiv.add(filterFld , addBtn);

		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				addDialog(true);
			}
		});
		
		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				try {
					equipmentVendorAssociationDataBeanList.stream().filter(new Predicate<EquipmentTypeVendorAssociationMasterDataBean>() {

					@Override
					public boolean test(EquipmentTypeVendorAssociationMasterDataBean t) {
						String filterTxt = filterFld.getValue();
						if (filterTxt == null || filterTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if (vendorOrOperator) {
							if (StringUtils.containsIgnoreCase(t.getVendor(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getEquipmentType(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getInputFileFormat(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getOutputFileFormat(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getServiceAgent(), filterTxt)) {
								t.setVisible(true);
								return true;
							}
						} else {
							if (StringUtils.containsIgnoreCase(t.getVendor(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getEquipmentType(), filterTxt)) {
								t.setVisible(true);
								return true;
							}
						}
						
						t.setVisible(false);
						return false;
					}
				}).collect(Collectors.toList());
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		filterFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		populateData();
	}
	
	protected void populateData() {
		tableContainerDiv.removeAll();
		equipmentVendorAssociationDataBeanList = new ArrayList<>();
		String response = getEquipmentTypeVendorAssociation();
//				"[{\"EquipmentTypeVendorAssociationId\":1,\"EquipmentTypeVendorAssociation\":\"Battery\",\"EquipmentTypeVendorAssociationName\":\"Exide Industries\",\"Description\":\"Battery 24V\","
//				+ "\"ServiceType\":\"Active\"},{\"EquipmentTypeVendorAssociationId\":2,\"EquipmentTypeVendorAssociation\":\"Dish Antenna\",\"EquipmentTypeVendorAssociationName\":\"Airtel\",\"Description\":"
//				+ "\"Dish _Antenna_02 added\",\"ServiceType\":\"Passive\"}]";
		try {
			JSONArray ja = new JSONArray(response);
			for (int i = 0; i < ja.length(); i++) {
				JSONObject jo = ja.getJSONObject(i);
				String vendor = "", equipmentType = "", inputFileFormat="", outputFileFormat="", serviceAgent="", warrantyPeriod="";
			
				
				if (jo.getString("VendorName")!=null && 
						!jo.getString("VendorName").trim().equalsIgnoreCase("null")) {
					vendor = jo.getString("VendorName");
				}
				if (jo.getString("EquipmenTtype")!=null && 
						!jo.getString("EquipmenTtype").trim().equalsIgnoreCase("null")) {
					equipmentType = jo.getString("EquipmenTtype");
				}
				if (jo.getString("InputFileFormat")!=null && 
						!jo.getString("InputFileFormat").trim().equalsIgnoreCase("null")) {
					inputFileFormat = jo.getString("InputFileFormat");
				}
				if (jo.getString("OutputFileFormat")!=null && 
						!jo.getString("OutputFileFormat").trim().equalsIgnoreCase("null")) {
					outputFileFormat = jo.getString("OutputFileFormat");
				}
				if (jo.getString("ServiceAgent")!=null && 
						!jo.getString("ServiceAgent").trim().equalsIgnoreCase("null")) {
					serviceAgent = jo.getString("ServiceAgent");
				}
				if (jo.getString("WarrantyPeriodInDays")!=null && 
						!jo.getString("WarrantyPeriodInDays").trim().equalsIgnoreCase("null")) {
					
					warrantyPeriod = jo.getString("WarrantyPeriodInDays");
					//System.out.println(warrantyPeriod);
				}
				
				if (vendorOrOperator) {
					Iterator<Long> it = parent.vendorMap.keySet().iterator();
					while (it.hasNext()) {
						Long type = it.next();
						if (parent.vendorMap.get(type).equals(vendor)) {
							EquipmentTypeVendorAssociationMasterDataBean bean = new EquipmentTypeVendorAssociationMasterDataBean(vendor, equipmentType, inputFileFormat, 
									outputFileFormat, serviceAgent, /*warrantyPeriod,*/ parent.vendorMap, parent.activeEquipmentTypeMap, 
									parent.passiveEquipmentTypeMap, this, vendorOrOperator);
							equipmentVendorAssociationDataBeanList.add(bean);
							tableContainerDiv.add(bean);
							break;
						}			
					}		
				}
				else
				{
					Iterator<Long> it = parent.operatorMap.keySet().iterator();
					while (it.hasNext()) {
						Long type = it.next();
						if (parent.operatorMap.get(type).equals(vendor)) {
							EquipmentTypeVendorAssociationMasterDataBean bean = new EquipmentTypeVendorAssociationMasterDataBean(vendor, equipmentType, inputFileFormat, 
									outputFileFormat, serviceAgent, /*warrantyPeriod,*/ parent.operatorMap, parent.activeEquipmentTypeMap, 
									parent.passiveEquipmentTypeMap, this, vendorOrOperator);
							equipmentVendorAssociationDataBeanList.add(bean);
							tableContainerDiv.add(bean);
							break;
						}				
					}			
				}
				
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void addDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		if (vendorOrOperator) {
			AddOrEditEquipmentTypeVendorAssociation addEquipmentTypeVendorAssociation = new AddOrEditEquipmentTypeVendorAssociation(this, parent.vendorMap, 
					parent.activeEquipmentTypeMap, parent.passiveEquipmentTypeMap, vendorOrOperator);
		}
		else
		{
			AddOrEditEquipmentTypeVendorAssociation addEquipmentTypeVendorAssociation = new AddOrEditEquipmentTypeVendorAssociation(this, parent.operatorMap, 
					parent.activeEquipmentTypeMap, parent.passiveEquipmentTypeMap, vendorOrOperator);
		}
	}
	
//	public void selectedRowChangeHandler(ConfigBaseDataBean selectedBean) 
//	{
//		for (ConfigBaseDataBean equipmentTypeVendorAssociationMasterDataBean : equipmentTypeVendorAssociationMasterDataBeanList) {
//			if (!equipmentTypeVendorAssociationMasterDataBean.equals(selectedBean)) {
//				equipmentTypeVendorAssociationMasterDataBean.selectDeselect(true);
//			}
//		}
//	}

	private String getEquipmentTypeVendorAssociation()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPEVENDOR");
			//System.out.println(url);
			url = url + "?EquipmentTypeId=-1";
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

}
