package com.umt.siteassetinventory.framework.componentfactory;

import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.FileTypeAttributeUploadDialog;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class UIFileAttributeComponent extends Div {

	private static final long serialVersionUID = 1L;
	
	private static final String SCREENCD = "FILE_ATTRIBUTE_COMPONENT";
	private Label attributeNameLbl;
	private Div attributeNameDiv;
	private Label fileNameLbl;
	private Anchor fileLink;
	private Button uploadBtn;
	private Div fileInfoDiv;
	private JSONObject fileJSON;
	private String attributeName;
	private int attributeDataType;
	private String mandatory;
	private String fileType;
	
	public UIFileAttributeComponent(String attributeName, int attributeDataType, String mandatory, String fileType) {
		this.attributeName = attributeName;
		this.attributeDataType = attributeDataType;
		this.mandatory = mandatory;
		//this.fileType = fileType;
		this.fileType = attributeName;
		attributeNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRIBUTE_NAME_LBL");
		attributeNameLbl.setText(this.attributeName);
		
		attributeNameDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTE_NAME_DIV");
		attributeNameDiv.add(attributeNameLbl);
		fileNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILE_NAME_LBL");
		fileLink = new Anchor();
		fileLink.setTarget("_blank");
		fileLink.addClassName(SCREENCD + "FILE_HYPER_LINK");
		uploadBtn = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BTN");
		uploadBtn.setText(SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "FILE_ATTRIB_BTN"));
		fileInfoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_INFO_DIV");
		fileInfoDiv.add(fileNameLbl, fileLink, uploadBtn);
		fileNameLbl.setText("No file chosen");
		fileLink.setVisible(false);
		add(attributeNameDiv, fileInfoDiv);
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		
		uploadBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				uploadHandler();
			}
		});
	}
	
	private void uploadHandler() {
		String [] acceptedFileTypes = null;
		if(attributeDataType == 8) {
			acceptedFileTypes = ".png,.jpg,.jpeg,.gif,.bmp".split("[,]");
		} else if(attributeDataType == 9) {
			acceptedFileTypes = ".txt".split("[,]");
		} else if(attributeDataType == 10) {
			acceptedFileTypes = ".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.bmp,.xls,.xlsx".split("[,]");
		}

		FileTypeAttributeUploadDialog uploadDlg = new FileTypeAttributeUploadDialog(attributeName, fileType, acceptedFileTypes);
		uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
				FileTypeAttributeUploadDialog dlg = (FileTypeAttributeUploadDialog)event.getSource();
				if(!dlg.isOpened()) {
					if(dlg.isGetDocUploadStatus()) {
						fileJSON = dlg.getFileDetail();
					}
					else {
						fileJSON = null;
					}
					refreshFileNameOnFileSelection();
				}
			}
		});
	}
	
	private void refreshFileNameOnFileSelection() {
		fileNameLbl.setVisible(true);
		fileLink.setVisible(false);
		if(fileJSON == null) {
			fileNameLbl.setText("No file chosen");
		} else {
			try {
				fileNameLbl.setText(fileJSON.getString("Name"));
				fileNameLbl.setTitle(fileJSON.getString("Name"));
			} catch (Exception ex) {
				fileNameLbl.setText("Unable to show file name");
			}
		}
	}
	
	public void setFileLink(String fileName, String href) {
		fileLink.setText(fileName);
		fileLink.setTitle(fileName);
		fileLink.setHref(href);
		fileNameLbl.setVisible(false);
		fileLink.setVisible(true);
	}
	
	public void setFileDetail(JSONObject fileJSON) {
		this.fileJSON = fileJSON;
	}
	
	public JSONObject getFileJSON() {
		return fileJSON;
	}
}
