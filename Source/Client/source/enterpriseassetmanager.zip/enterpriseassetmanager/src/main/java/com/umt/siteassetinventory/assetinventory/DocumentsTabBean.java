package com.umt.siteassetinventory.assetinventory;

import java.util.Date;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.server.VaadinServletRequest;

@CssImport("./styles/doc_tab-styles.css")
public class DocumentsTabBean extends VerticalLayout{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "DOCUMENTS_TAB";
	private String sitecode,filename,timestamp;
	private Div docRowDiv;
	private Button viewBtn;
	private VerticalLayout docContainerVL;

	public DocumentsTabBean(String sitecode,String filename,String timestamp) 
	{
		this.sitecode=sitecode;
		this.filename=filename;
		this.timestamp=timestamp;
	}
	public VerticalLayout createdocumentRow()
	{
		docContainerVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DOC_CONTAINER_VL_BEAN");
		docRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DOC_ROW_DIV");
		Div btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		viewBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
		btnDiv.add(viewBtn);
		//viewBtn.addThemeVariants(ButtonVariant.LUMO_SMALL);
		
		Div filenameDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_NAME_DIV");
		Label filenameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILENAME_LBL");
		filenameLbl.setText(filename);
		filenameDiv.add(filenameLbl);
		
		Div timeStampDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TIME_STAMP_DIV");
		Label timeStampLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TIMESTAMP_LBL");
		Date uploadDateTime = new Date();
		try {
			uploadDateTime.setTime(Long.parseLong(timestamp));
			timeStampLbl.setText(CommonUtils.getDisplayDateTime(uploadDateTime));
		} catch (Exception e) {
			e.printStackTrace();
			timeStampLbl.setText("");
		}
		
		timeStampDiv.add(timeStampLbl);
		docRowDiv.add(filenameDiv,timeStampDiv,btnDiv);
		docContainerVL.add(docRowDiv);
		
		viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				viewButtonClickHandler();
			}
		});
		return docContainerVL;
	}
	protected void viewButtonClickHandler() 
	{
		try
		{
			String url = VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
					+ "/" + VaadinServletRequest.getCurrent().getContextPath()
					+ "/ViewAssetDocument";
			
			url = url + "?SiteCode=" + sitecode+"&FileName="+filename+"&TimeStamp="+timestamp;
			UI.getCurrent().getPage().open(url);
		}catch (Exception e) {
			e.printStackTrace();
			
	    }	
		
	}

}
