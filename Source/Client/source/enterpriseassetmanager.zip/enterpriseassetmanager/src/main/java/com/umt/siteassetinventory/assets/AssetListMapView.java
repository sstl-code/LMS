package com.umt.siteassetinventory.assets;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;

import com.flowingcode.vaadin.addons.googlemaps.GoogleMap;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker;
import com.flowingcode.vaadin.addons.googlemaps.LatLon;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMap.MapType;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker.GoogleMapMarkerClickEvent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.html.Div;

public class AssetListMapView extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_LIST_MAP_VIEW";
	private GoogleMap siteMap;
	private String selectedSitecode;
	private AssetsView parent;
	private List<MapMarkerData> mapMarkerList = new ArrayList<AssetListMapView.MapMarkerData>();
	private Div mainLayoutDiv;
	private String lat,longi;
	
	public AssetListMapView(AssetsView parent) 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.parent=parent;
		
		siteMap = new GoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", null, null);
		siteMap.setSizeFull();
		siteMap.setMapType(MapType.ROADMAP);
		siteMap.setDraggable(true);
		siteMap.setZoom(5);
		siteMap.setHeightFull();
		
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT2");
		mainLayoutDiv.add(siteMap);
		add(mainLayoutDiv);
	}
	public void populateAssetDetails(String response) 
	{
		//System.out.println("mapresponse::"+response);
		try
		{
			mapMarkerList.clear();
			JSONArray jsarr=new JSONArray(response);
			for(int i=0;i<jsarr.length();i++)
			{	
				lat=jsarr.getJSONObject(i).getString("Latitude");
				longi=jsarr.getJSONObject(i).getString("Longitude");
				if(lat.trim().length()>0 && longi.trim().length()>0)
				{
					MapMarkerData marker = new MapMarkerData();
					marker.setSiteCode(jsarr.getJSONObject(i).getString("StoreSerialNo"));
					marker.setLatitude(jsarr.getJSONObject(i).getString("Latitude"));
					marker.setLongitude(jsarr.getJSONObject(i).getString("Longitude"));
					marker.setEquipmentType(jsarr.getJSONObject(i).getString("EquipmentType"));
					marker.setEquipmentSerialNo(jsarr.getJSONObject(i).getString("EquipmentSerialNo"));
					
					mapMarkerList.add(marker);	
				}
			/*	if(lat.trim().length()<=0 && longi.trim().length()<=0)
				{
					mapMarkerList.clear();
				}*/
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
			
		populateMap();
	}
	private void populateMap() {
		siteMap = new GoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", null, null);
		siteMap.setSizeFull();
		siteMap.setMapType(MapType.ROADMAP);
		siteMap.setDraggable(true);
		siteMap.setZoom(5);
		siteMap.setHeightFull();
		siteMap.setId("MY_GOOGLE_MAP");
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		//siteMap.getStyle().set("", "");
		
		//System.out.println("mapMarkerList.size()="+mapMarkerList.size());
		for(int i = 0; i < mapMarkerList.size(); i++) {
			//map.setCenter(new LatLon(Double.parseDouble(latitude), Double.parseDouble(longitude)));
			MapMarkerData eachItem = mapMarkerList.get(i);
			GoogleMapMarker marker = siteMap.addMarker(eachItem.getSiteCode(), new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())), false, "");
			
			
			
			mapMarkerList.get(i).setMarker(marker);
			//String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getSiteCode() + "</span><br><em>" + eachItem.getSiteRegion() + "</em><br><div style=\"width:200px\"><small>" + eachItem.getSiteAddress() + "</small></div></body></html>"; 
		//	String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getSiteCode(); 
			String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getEquipmentSerialNo()  + "</em><br><div style=\"width:200px\"><small>" + eachItem.getEquipmentType() + "</small></div></body></html>"; 
			marker.addInfoWindow(htmlContent);
			//marker.setInfoWindowVisible(true);
			marker.setAnimationEnabled(true);
		//	marker.getCaption().e
			
			marker.addClickListener(new ComponentEventListener<GoogleMapMarker.GoogleMapMarkerClickEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(GoogleMapMarkerClickEvent event) {
					GoogleMapMarker marker = event.getSource();
					//System.out.println(marker.getCaption());
					if(parent != null) {
			//			parent.setSelectedSite(marker.getCaption());
						closeOtherMarkerInfoWindow(marker.getCaption());
						parent.addMapMarkerClickHandler(marker.getCaption());
					}
				}
			});
			
		}
	//	add(siteMap);
		mainLayoutDiv.removeAll();
		mainLayoutDiv.add(siteMap);
	}
	public void setSiteCode(String sitecode)
	{
		this.selectedSitecode=sitecode;
	}
	public void closeOtherMarkerInfoWindow(String code) {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if (!eachItem.getSiteCode().trim().equalsIgnoreCase(code)) {
					eachItem.getMarker().setInfoWindowVisible(false);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	public void closeMarkerInfoWindow() {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				//if (eachItem.getSiteCode().trim().equalsIgnoreCase(selectedSiteCode)) {
					eachItem.getMarker().setInfoWindowVisible(false);
					//break;
				//}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void setSelectedSite(String siteCode) 
	{
		//System.out.println("selectedAssetId2="+siteCode);
		try {
			selectedSitecode = siteCode;
			for(int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if(eachItem.getSiteCode().trim().equalsIgnoreCase(siteCode)) {
					siteMap.setCenter(new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())));
					eachItem.getMarker().setInfoWindowVisible(true);
					break;
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	private class MapMarkerData implements Serializable {
		private static final long serialVersionUID = 1L;
		private String siteCode;
		private String siteAddress;
		private String siteRegion;
		private String latitude;
		private String longitude;
		private String equipmentType;
		private String equipmentSerialNo;
		private GoogleMapMarker marker;
		
		public MapMarkerData() {
			
		}

		public void setEquipmentSerialNo(String equipmentSerialNo) {
			this.equipmentSerialNo=equipmentSerialNo;
			
		}

		public void setEquipmentType(String equipmentType) {
			this.equipmentType=equipmentType;
			
		}
		public String getEquipmentType() {
			return equipmentType;
		}

		public String getEquipmentSerialNo() {
			return equipmentSerialNo;
		}

		public GoogleMapMarker getMarker() {
			return marker;
		}

		public void setMarker(GoogleMapMarker marker) {
			this.marker = marker;
		}

		public String getSiteCode() {
			return siteCode;
		}

		public void setSiteCode(String siteCode) {
			this.siteCode = siteCode;
		}


		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}
	}

}
