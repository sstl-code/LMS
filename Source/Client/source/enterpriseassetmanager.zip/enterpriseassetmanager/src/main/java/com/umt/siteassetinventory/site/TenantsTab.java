package com.umt.siteassetinventory.site;


import java.net.URLEncoder;

import org.codehaus.jettison.json.JSONArray;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/tenants-tab-styles.css")
public class TenantsTab extends Div  {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "TENANTS_TAB";
	private Div containerBodyDiv,containerDiv;
	private String siteCode;

	public TenantsTab(String siteCode, SiteView siteView) {
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.siteCode=siteCode;
		
		Label eventTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EVENT_TYPE_LBL");
		Label opCoNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "OPCO_NAME_LBL");
		Label solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		Label projectReferenceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PROJECT_REF_NO_LBL");
		Label MRFAI_DateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MRFAI_DATE_LBL");
		Label removal_DateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMOVAL_DATE_LBL");
		Label remarksLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMARKS_LBL");
		Label tenantStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		Label projectStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PROJECT_STATUS_LBL");

		
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		containerBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_BODY_DIV");
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		
		headerDiv.add(eventTypeLbl,opCoNameLbl,solutionTypeLbl,projectReferenceNoLbl,MRFAI_DateLbl,tenantStatusLbl,
				removal_DateLbl,remarksLbl,projectStatusLbl);
		populateData();
		
		containerDiv.add(headerDiv,containerBodyDiv);
		add(containerDiv);
	}

	private void populateData() {
		try {
			String resp=getSiteOperators();
		//	System.out.println("resp="+resp);
			
		containerBodyDiv.removeAll();
			
//		String	resp2="[\r\n" + 
//					"  {\r\n" + 
//					"    \"SiteCode\": \"STIPL.ABCD\",\r\n" + 
//					"    \"ProjectReferenceNo\": \"STIPL.ABCD.001\",\r\n" + 
//					"    \"ProjectStatus\": \"New Built Project Started\",\r\n" + 
//					"    \"EventType\": \"NB\",\r\n" + 
//					"    \"MRFAI_Date\": \"12/12/2022\",\r\n" + 
//					"    \"TenantStatus\": 1,\r\n" + 
//					"    \"Removal_Date\": \"\",\r\n" + 
//					"    \"OpCoName\": \"RJIO\",\r\n" + 
//					"    \"Remarks\": \"Any meaningful remarks\",\r\n" + 
//					"    \"SolutionType\": \"ODSC\"\r\n" + 
//					"  }\r\n" + 
//					"]";
//	
		
		
	//	System.out.println("r==="+resp);
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						
						String recordStatus=jsarr.getJSONObject(i).getString("RecordStatus");
						
						if(recordStatus.equals("1")) {
						Div rowdiv=createRows(jsarr.getJSONObject(i).getString("EventType"),
								jsarr.getJSONObject(i).getString("OpCoName"),
								jsarr.getJSONObject(i).getString("SolutionType"),
								jsarr.getJSONObject(i).getString("ProjectReferenceNo"),
								jsarr.getJSONObject(i).getString("EffectiveDate"),
								jsarr.getJSONObject(i).getString("TenantStatus"),
								jsarr.getJSONObject(i).getString("RemovalDate"),
								jsarr.getJSONObject(i).getString("Remarks"),
								jsarr.getJSONObject(i).getString("ProjectStatus"));
						
						containerBodyDiv.add(rowdiv);
						}
					}
					
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
			}else {}

			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	

	private String getSiteOperators() {
		String resp="";
		try {
			if(siteCode!=null) {
				
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEOPERATORS");
			url=url+"?SiteCode="+siteCode;
			
		//	System.out.println("url="+url);

			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
		//	System.out.println("resp="+resp);
			}else {
				resp=null;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resp;
	}
	
	private Div createRows(String EventType, String OpCoName, String SolutionType, String ProjectReferenceNo, 
			String MRFAI_Date, String TenantStatus, String Removal_Date, String Remarks, String ProjectStatus) {
		
		Div rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Label eventTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN","EVENT_TYPE_LBL");
		Label opCoNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "OPCO_NAME_LBL");
		Label solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "SOLUTION_TYPE_LBL");
		Label projectReferenceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "PROJECT_REF_NO_LBL");
		Label MRFAI_DateLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "MRFAI_DATE_LBL");
		Label removal_DateLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "REMOVAL_DATE_LBL");
		Label remarksLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "REMARKS_LBL");
		Label tenantStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "STATUS_LBL");
		Label projectStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD+"_BEAN", "PROJECT_STATUS_LBL");
		
		eventTypeLbl.setText(EventType);
		opCoNameLbl.setText(OpCoName);
		solutionTypeLbl.setText(SolutionType);
		projectReferenceNoLbl.setText(ProjectReferenceNo);
	//	MRFAI_DateLbl.setText(MRFAI_Date);
	//	tenantStatusLbl.setText(TenantStatus);
//		removal_DateLbl.setText(Removal_Date);
		remarksLbl.setText(Remarks);
		projectStatusLbl.setText(ProjectStatus);
		
		if(TenantStatus.equals("1")) {
			tenantStatusLbl.setText("Active");
		}else {
			tenantStatusLbl.setText("Inactive");
		}
		
		if(MRFAI_Date!=null && MRFAI_Date.length()>0) {
			MRFAI_DateLbl.setText(CommonUtils.convertDateToDifferentFormat(MRFAI_Date,"dd/MM/yyyy","dd-MMM-yyyy"));
		}else {
			MRFAI_DateLbl.setText("-");
		}
		if(Removal_Date!=null && Removal_Date.length()>0) {
			removal_DateLbl.setText(CommonUtils.convertDateToDifferentFormat(Removal_Date,"dd/MM/yyyy","dd-MMM-yy"));
		}else {
			removal_DateLbl.setText("-");
		}
	
	
		rowDiv.add(eventTypeLbl,opCoNameLbl,solutionTypeLbl,projectReferenceNoLbl,MRFAI_DateLbl,tenantStatusLbl,
				removal_DateLbl,remarksLbl,projectStatusLbl);
		
		
		return rowDiv;
		
	}

}
