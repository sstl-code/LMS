package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

public class SiteAgreementDetailBean extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_AGREEMENT_DETAIL_BEAN";
	private SiteAgreementsTab viewSiteAgreementsTab;
	private long agreementId;
	private String agreementName, agreementDate, startDate, endDate, fileName, fileDesc, fileUrl, viewUrlToOpen="",agreementstatus,agreementtype,siteCode;
	private boolean fileExist = false;
	private Button viewDetailsButton;
	private JSONObject existingAgreementAttributesJson;
	private String partitionid;
	
	//	private int paymentFrequency;
	//	private double paymentAmt;
	//	private int paymentUnit;
	//	private int paymentMode;
	//	private int escalationFrequency;
	//	private int escalationUnit;
	//	private double escalationAmt;


	public SiteAgreementDetailBean(long agreementId, String agreementName, String agreementDate, String startDate, String endDate, String fileName, String fileDesc, String 
			fileUrl,/*int paymentFrequency, double paymentAmt, int paymentUnit, int paymentMode, int escalationFrequency, int escalationUnit, double escalationAmt,*/ 
			String agreementstatus,String agreementtype,String siteCode,SiteAgreementsTab siteAgreementsTab) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.viewSiteAgreementsTab = siteAgreementsTab;
		this.agreementId= agreementId;
		this.agreementName= agreementName;
		this.agreementDate= agreementDate;
		this.startDate= startDate;
		this.endDate= endDate;
		this.fileName= fileName;
		this.fileDesc= fileDesc;
		this.fileUrl= fileUrl;
		this.agreementstatus=agreementstatus;
		this.agreementtype=agreementtype;
		this.siteCode=siteCode;
		//		this.paymentFrequency= paymentFrequency;
		//		this.paymentAmt= paymentAmt;
		//		this.paymentUnit= paymentUnit;
		//		this.paymentMode= paymentMode;
		//		this.escalationFrequency= escalationFrequency;
		//		this.escalationUnit= escalationUnit;
		//		this.escalationAmt= escalationAmt;

		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		Label agreementIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_ID_LBL");
		Button editAgreementButton = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
		Button viewAgreementButton = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
		Button deactivateButton = UIFieldFactory.createButton(SCREENCD, "DEACTIVATE_BTN");
		agreementIdLbl.setText("Agreement ID: "+agreementId);
		
		viewDetailsButton= UIFieldFactory.createButton(SCREENCD, "VIEW_DETAILS_BTN");
		
		
		if (fileUrl.length()==0) {
			viewAgreementButton.setEnabled(false);
			fileExist = false;
		}
		else
		{
			fileUrl = fileUrl.substring(fileUrl.indexOf("/RuleServer"));
			fileExist = true;
			try {
				String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
				if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
					viewUrlToOpen = truebyl_domain.substring(0, truebyl_domain.length()-1) + fileUrl;
				}
				else
				{
					System.out.println("TRUEBYL_DOMAIN not set in Environment variables");
					viewUrlToOpen = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
							ApplicationConfiguration.getServerPort() + fileUrl;	
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("TRUEBYL_DOMAIN not set in Environment variables");
				viewUrlToOpen = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						ApplicationConfiguration.getServerPort() + fileUrl;	
			}
		}
		Anchor anchor = new Anchor(viewUrlToOpen, viewAgreementButton);
		anchor.setTarget("_blank");
		headerDiv.add(agreementIdLbl, anchor,viewDetailsButton,editAgreementButton, deactivateButton);

		//		Div col1 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN1");
		//		Div col2 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN2");
		//		Div col3 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN3");
		//		Div col4 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN4");
		Div agreementDetailDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "AGREEMENT_DETAILS_DIV");
		
		Div eachAgreementDetailDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_NAME_DETAIL_DIV");
		Label agreementNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_NAME_CAPTION");
		Label agreementNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_NAME_VALUE");
		agreementNameVal.setText(agreementName);
		eachAgreementDetailDiv1.add(agreementNameCaption, agreementNameVal);

		Div eachAgreementDetailDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		Label agreementDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DATE_CAPTION");
		Label agreementDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DATE_VALUE");
		agreementDateVal.setText(agreementDate);
		eachAgreementDetailDiv2.add(agreementDateCaption, agreementDateVal);

		Div eachAgreementDetailDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		Label startDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "START_DATE_CAPTION");
		Label startDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "START_DATE_VALUE");
		startDateVal.setText(startDate);
		eachAgreementDetailDiv3.add(startDateCaption, startDateVal);

		Div eachAgreementDetailDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		Label endDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "END_DATE_CAPTION");
		Label endDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "END_DATE_VALUE");
		endDateVal.setText(endDate);
		eachAgreementDetailDiv4.add(endDateCaption, endDateVal);
		
		String status="";
		if(agreementstatus.equalsIgnoreCase("1")) {
			status="Active";
		}else if(agreementstatus.equalsIgnoreCase("0")) {
			editAgreementButton.setEnabled(false);
			status="Pending";
		}else if(agreementstatus.equalsIgnoreCase("2")) {
			editAgreementButton.setEnabled(false);
			deactivateButton.setEnabled(false);
			status="Deactive";
		}else if(agreementstatus.equalsIgnoreCase("3")) {
			status="Expired";
			editAgreementButton.setEnabled(false);
		}else if(agreementstatus.equalsIgnoreCase("4")) {
			status="Rejected";
			//editAgreementButton.setEnabled(false);
		}
		else {}
		Div eachAgreementDetailDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_STATUS_DIV");
		Label statusCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_CAPTION");
		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VALUE");
		statusVal.setText(status);
		eachAgreementDetailDiv6.add(statusCaption,statusVal);
		if(status.equalsIgnoreCase("Active")) {
			statusVal.getStyle().set("background-color", CommonUtils.getStatusColorCode(status));
		}else if(status.equalsIgnoreCase("Pending")) {
			//statusVal.getStyle().set("background-color","gainsboro");
			statusVal.getStyle().set("background-color","orange");
		}else if(status.equalsIgnoreCase("Expired")) {
			statusVal.getStyle().set("background-color","red");
		}else {
			statusVal.getStyle().set("background-color", CommonUtils.getStatusColorCode(status));
		}
		String type="";
		if(agreementtype.equalsIgnoreCase("1")) {
			type="Main";
		}else if(agreementtype.equalsIgnoreCase("2")) {
			type="Addendum";
		}
		Div eachAgreementDetailDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_TYPE_DIV");
		Label typeCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_CAPTION");
		Label typeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_VALUE");
		typeVal.setText(type);
		eachAgreementDetailDiv5.add(typeCaption,typeVal);
		
		Label agreementFileCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_FILE_CAPTION");
		Div fileDetailDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_DETAILS_DIV");
		
		Div eachFileDetailDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_FILE_DETAIL_DIV");
		Label fileNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "FILE_NAME_CAPTION");
		Label fileNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "FILE_NAME_VALUE");
		fileNameVal.setText(fileName);
		eachFileDetailDiv1.add(fileNameCaption, fileNameVal);

		Div eachFileDetailDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_FILE_DETAIL_DIV");
		Label fileDescCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "FILE_DESC_CAPTION");
		Label fileDescVal = UIHtmlFieldFactory.createLabel(SCREENCD, "FILE_DESC_VALUE");
		fileDescVal.setText(fileDesc);
		eachFileDetailDiv2.add(fileDescCaption, fileDescVal);
		

		//		Div eachAgreementDetailDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label paymentFrequencyCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_FREQUENCY_CAPTION");
		//		Label paymentFrequencyVal = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_FREQUENCY_VALUE");
		//		paymentFrequencyVal.setText(CommonUtils.getPaymentFrequencyCd(paymentFrequency));
		//		eachAgreementDetailDiv5.add(paymentFrequencyCaption, paymentFrequencyVal);
		//
		//		Div eachAgreementDetailDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label paymentAmtCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_AMT_CAPTION");
		//		Label paymentAmtVal = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_AMT_VALUE");
		//		paymentAmtVal.setText(paymentAmt+"");
		//		eachAgreementDetailDiv6.add(paymentAmtCaption, paymentAmtVal);
		//		
		//		Div eachAgreementDetailDiv7 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label paymentTypeCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_TYPE_CAPTION");
		//		Label paymentTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_TYPE_VALUE");
		//		paymentTypeVal.setText(CommonUtils.getEscalationOrPaymentUnitCd(paymentUnit));
		//		eachAgreementDetailDiv7.add(paymentTypeCaption, paymentTypeVal);
		//		
		//		Div eachAgreementDetailDiv8 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label paymentModeCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_MODE_CAPTION");
		//		Label paymentModeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_MODE_VALUE");
		//		paymentModeVal.setText(CommonUtils.getPaymentModeCd(paymentMode));
		//		eachAgreementDetailDiv8.add(paymentModeCaption, paymentModeVal);
		//		
		//		Div eachAgreementDetailDiv9 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label escalationFrequencyCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_FREQUENCY_CAPTION");
		//		Label escalationFrequencyVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_FREQUENCY_VALUE");
		//		escalationFrequencyVal.setText(CommonUtils.getEscalationFrequencyCd(escalationFrequency));
		//		eachAgreementDetailDiv9.add(escalationFrequencyCaption, escalationFrequencyVal);
		//		
		//		Div eachAgreementDetailDiv10 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label escalationTypeCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_TYPE_CAPTION");
		//		Label escalationTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_TYPE_VALUE");
		//		escalationTypeVal.setText(CommonUtils.getEscalationOrPaymentUnitCd(escalationUnit));
		//		eachAgreementDetailDiv10.add(escalationTypeCaption, escalationTypeVal);
		//		
		//		Div eachAgreementDetailDiv11 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_AGREEMENT_DETAIL_DIV");
		//		Label escalationAmtCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_AMT_CAPTION");
		//		Label escalationAmtVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ESCALATION_AMT_VALUE");
		//		escalationAmtVal.setText(escalationAmt+"");
		//		eachAgreementDetailDiv11.add(escalationAmtCaption, escalationAmtVal);


		//		col1.add(eachAgreementDetailDiv1, eachAgreementDetailDiv5, eachAgreementDetailDiv9);
		//		col2.add(eachAgreementDetailDiv2, eachAgreementDetailDiv6, eachAgreementDetailDiv10);
		//		col3.add(eachAgreementDetailDiv3, eachAgreementDetailDiv7, eachAgreementDetailDiv11);
		//		col4.add(eachAgreementDetailDiv4, eachAgreementDetailDiv8);
		fileDetailDiv.add(eachFileDetailDiv1, eachFileDetailDiv2);
		agreementDetailDiv.add(eachAgreementDetailDiv1, eachAgreementDetailDiv2, eachAgreementDetailDiv3,
				eachAgreementDetailDiv4,eachAgreementDetailDiv5,eachAgreementDetailDiv6);
		containerDiv.add(agreementDetailDiv, agreementFileCaption, fileDetailDiv);
		add(headerDiv, containerDiv);

		editAgreementButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				editDialog(false);
			}
		});
		
//		deactivateButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
//			
//			@Override
//			public void onComponentEvent(ClickEvent<Button> event) {
//				removeAgreement();
//			}
//		});
		
		
		viewDetailsButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
//				anchor.setVisible(false);
//				viewDetailsButton.setVisible(false);
//				editAgreementButton.setVisible(false);
//				deactivateButton.setVisible(false);
				viewSiteAgreementsTab.viewRentReferenceButton.setVisible(false);
				viewSiteAgreementsTab.addAgreementButton.setVisible(false);
				viewSiteAgreementsTab.backButton.setVisible(true);
				viewAgreementAttributes();
			}
		});
		
		deactivateButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

				String title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "WARNING_DIALOG_TITLE");
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showWarningMessage(SCREENCD, "REMOVE_ROW_WARNING", title);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						Dialog srcDlg = event.getSource();
						if(!srcDlg.isOpened()) 
						{
							if(srcDlg.getId().isPresent() && srcDlg.getId().get().equals("9999"))
							{
								removeAgreement();
								srcDlg.close();
							}
							if(srcDlg.getId().isPresent() && srcDlg.getId().get().equals("-9999"))
							{
								srcDlg.close();
							}
						}
						
					}
				});
			}
		});
		
		setAgreementAttributes();

	}

	

	private void removeAgreement() {
		try {
			Form l_objInputForm = new Form();
			l_objInputForm.add("SiteCode", viewSiteAgreementsTab.getSiteCode());
			l_objInputForm.add("AgreementId", agreementId);

			String base_URL = ApplicationConfiguration.getServiceEndpoint("REMOVESITEAGREEMENT");
			//System.out.println(l_objInputForm.toString()+" "+base_URL);
			String res = RestServiceHandler.deleteJSON_DELETE(base_URL, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(" res::"+res);
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "SITE_AGREEMENT_REMOVE_SUCCESSFUL",
					ApplicationConstants.DialogTypes.INFO);
			viewSiteAgreementsTab.removeAgreementrow(this);
		} catch (Exception ex) {
			ex.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(ex.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	}

	private void editDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddSiteAgreement addSiteAgreement = new AddSiteAgreement(viewSiteAgreementsTab, this, agreementId, agreementName, agreementDate, startDate, endDate,agreementtype, fileDesc, 
				fileName, fileExist,viewSiteAgreementsTab.getSiteCode());
				/*, paymentFrequency, paymentAmt, paymentUnit, paymentMode, escalationFrequency, escalationUnit, escalationAmt*/
		addSiteAgreement.setSiteCode(viewSiteAgreementsTab.getSiteCode());
	}


	//	private void removeAgreement()
	//	{
	//		String base_URL=ApplicationConfiguration.getServiceEndpoint("RETURNEQUIPMENT");
	//		try {
	//
	//			Form formData = new Form();
	//			formData.add("StoreSerialNo", assetId);
	//			formData.add("StoreId", 9995);
	//			formData.add("StatusId", 3);
	//			formData.add("StoreLocId", viewSiteAgreementsTab.getSiteCode());
	//			//System.out.println("input:: " + formData.toString());
	//			String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAgreementInventoryUIFramework.getFramework().getToken());
	//			//System.out.println("Return:" + response);
	//			//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
	//			SiteAgreementInventoryUIFramework.getFramework().showMessage(SCREENCD, "AGREEMENT_REMOVE_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
	//			viewSiteAgreementsTab.refreshData();
	//			
	//		} catch (Exception e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//			SiteAgreementInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
	//		}
	//	}
	
	protected void viewAgreementAttributes() {
		try {
			viewSiteAgreementsTab.getagreementAttributeDiv().removeAll();
			viewSiteAgreementsTab.getagreementAttributeDiv().setVisible(true);
			viewSiteAgreementsTab.getContainerDiv().setVisible(false);
			
			
			JSONArray allAttributes = retrieveAgreementLevelAttributes();
			for(int i=0; i<allAttributes.length(); i++)
			{
				JSONObject js=allAttributes.getJSONObject(i);
				String attrDataType = allAttributes.getJSONObject(i).getString("AttributeDatatype");
				Div row = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				if((attrDataType.equals("8") || attrDataType.equals("9") || attrDataType.equals("10"))) {
					Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
					Label attri_value = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_VALUE_LBL");
					attri_nme.setText(js.getString("AttributeName"));
					
					if (existingAgreementAttributesJson.length() <= 0) {//setAgreementAttributes response ::::::: {}
						if (js.getString("DefaultValue") != null || js.getString("DefaultValue").length() > 0) {
							attri_value.setText(js.getString("DefaultValue"));
						} else {
							attri_value.setText("-");
						}

					} else {
						if (existingAgreementAttributesJson.has(js.getString("AttributeName"))) {
							if (js.getString("AttributeName") != null || js.getString("AttributeName").length() > 0) {
							//	attri_value.setText(existingAgreementAttributesJson.getString(js.getString("AttributeName")));
								
								JSONObject fileDetailJSON = new JSONObject(existingAgreementAttributesJson.getString(js.getString("AttributeName")));
								
								Anchor link = new Anchor();
								link.addClassName(SCREENCD + "_FILE_ATTRIBUTE_VALUE");
								link.setText(fileDetailJSON.getString("Name"));
								String href = getFileURL(fileDetailJSON.getString("UUID"));
								link.setHref(href);
								link.setTarget("_blank");
								//row.add(link);
								row.add(attri_nme, link);
										
							} else {
								attri_value.setText("-");
								row.add(attri_nme,attri_value);
							}
						} else {
							attri_value.setText("-");
							row.add(attri_nme,attri_value);
						}
					}
					
				}else if (attrDataType.equals("7")) {
					Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
				//	Label attri_value = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_VALUE_LBL");
					Span attri_value = UIHtmlFieldFactory.createSpan("", SCREENCD, "ATTRI_VALUE_LBL");
					attri_nme.setText(js.getString("AttributeName"));
					
					if(existingAgreementAttributesJson.length()<=0){//setAgreementAttributes response ::::::: {}
						if(js.getString("DefaultValue")!=null || js.getString("DefaultValue").length()>0) {
							//attri_value.setText(js.getString("DefaultValue"));
							JSONObject multiSelectValueJSON = new JSONObject(js.getString("DefaultValue"));
							JSONArray valArray = new JSONArray(multiSelectValueJSON.getString("MultiSelectDefaultValue"));
							if(valArray!=null || valArray.length()>0) {
								StringBuilder multiSelectListHtmlView = new StringBuilder();
								multiSelectListHtmlView.append("<ul style = \"margin-block-start: 0px; margin-block-end: 0px; padding-inline-start: 16px;\">");
								for(int j = 0; j < valArray.length(); j++) {
									multiSelectListHtmlView.append("<li>" + valArray.getString(j) + "</li>");
								}
								multiSelectListHtmlView.append("</ul>");
								attri_value = UIHtmlFieldFactory.createSpan("", SCREENCD, "ATTRI_VALUE_LBL");
								attri_value.getElement().setProperty("innerHTML", multiSelectListHtmlView.toString());
							}
							
							
						}else {
							attri_value.setText("-");
						}
						
					}else {
						if(existingAgreementAttributesJson.has(js.getString("AttributeName"))) {
							if(js.getString("AttributeName")!=null || js.getString("AttributeName").length()>0) {
							//	attri_value.setText(existingAgreementAttributesJson.getString(js.getString("AttributeName")));
								JSONObject multiSelectValueJSON = new JSONObject(existingAgreementAttributesJson.getString(js.getString("AttributeName")));
								JSONArray valArray = new JSONArray(multiSelectValueJSON.getString("MultiSelectValue"));
								StringBuilder multiSelectListHtmlView = new StringBuilder();
								multiSelectListHtmlView.append("<ul style = \"margin-block-start: 0px; margin-block-end: 0px; padding-inline-start: 16px;\">");
								for(int j = 0; j < valArray.length(); j++) {
									multiSelectListHtmlView.append("<li>" + valArray.getString(j) + "</li>");
								}
								multiSelectListHtmlView.append("</ul>");
								attri_value = UIHtmlFieldFactory.createSpan("", SCREENCD, "ATTRI_VALUE_LBL");
								attri_value.getElement().setProperty("innerHTML", multiSelectListHtmlView.toString());
							}else {
								//attri_value.setText("-");
							}
						}else {
							//attri_value.setText("-");
						}
					}
					
					row.add(attri_nme, attri_value);
					

				}else {
					Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
					Label attri_value = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_VALUE_LBL");
					attri_nme.setText(js.getString("AttributeName"));
					if (existingAgreementAttributesJson.length() <= 0) {//setAgreementAttributes response ::::::: {}
						if (js.getString("DefaultValue").length() > 0) {
							attri_value.setText(js.getString("DefaultValue"));
						} else {
							attri_value.setText("-");
						}

					} else {
						if (existingAgreementAttributesJson.has(js.getString("AttributeName"))) {
							if (js.getString("AttributeName") != null || js.getString("AttributeName").length() > 0) {
								attri_value.setText(existingAgreementAttributesJson.getString(js.getString("AttributeName")));
										
							} else {
								attri_value.setText("-");
							}
						} else {
							attri_value.setText("-");
						}
					}
					row.add(attri_nme, attri_value);
				}
				viewSiteAgreementsTab.getagreementAttributeDiv().add(row);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}



	private JSONArray retrieveAgreementLevelAttributes() {
		String res = "",res1="";
		JSONArray eachAgreementAttrJsArr=new JSONArray();
		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");
			res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
		
		} 
		catch (Exception e) {
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			return null;
		}

		try {
			if (res != null) {
				JSONArray ja = new JSONArray(res);
				for (int i = 0; i < ja.length(); i++) {
					if (ja.getJSONObject(i).getInt("AttributeType")==10) {
						eachAgreementAttrJsArr.put(ja.getJSONObject(i));
					}
				}
			//	System.out.println("Agreement Array= "+eachAgreementAttrJsArr);
			}
		}
		catch(JSONException ex)
		{
			ex.printStackTrace();	
		}
		return eachAgreementAttrJsArr;
	}
	
	private void setAgreementAttributes()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETAGREEMENTATTRIBUTES");
			url = url + "?SiteCode=" + URLEncoder.encode(siteCode)+"&AgreementId="+agreementId;
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			System.out.println("setAgreementAttributes response ::::::: "+response);
			existingAgreementAttributesJson = new JSONObject(response);
			//Iterator<String> attributeNames = existingAgreementAttributesJson.keys();
			
		} catch(Exception e) {
			e.printStackTrace();
		}		

	}
	
	protected String getFileURL(String fileId) {
		String retVal = "";
		try {
			partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
			String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
			if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
				retVal = truebyl_domain + "RuleServer/files/" + partitionid + "/SiteService/" + fileId + "/stream";
			}
			else
			{
				retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/SiteService/" 
						       + fileId + "/stream";
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
				       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/SiteService/" 
				       + fileId + "/stream";	
		}
		return retVal;
	}
}
