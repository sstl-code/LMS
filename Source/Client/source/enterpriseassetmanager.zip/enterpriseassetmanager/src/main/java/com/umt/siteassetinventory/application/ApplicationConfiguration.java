package com.umt.siteassetinventory.application;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Base64;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;

import com.ruleengine.manager.RuleManager;
import com.ruleengine.settings.KeyManager;
import com.ruleengine.settings.KeyManager.KeyName;
import com.ruleengine.settings.ParamsStore;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.utility.ClientHelper;

public class ApplicationConfiguration implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private static Properties applicationConfiguration = new Properties();
	
	private static final String CONFIGURATION_FILE_NAME = "config.properties";
	
	private static String superToken = "";
	
	private static String serverIp = "";
	
	private static String serverPort = "";
	
	private static String scheme = "";
	
	public static void init()
	{
		InputStream configFileInputStream = null;
		try
		{
			configFileInputStream = ApplicationConfiguration.class.getClassLoader().getResourceAsStream(CONFIGURATION_FILE_NAME);
		
			if (configFileInputStream != null) 
			{
				applicationConfiguration.load(configFileInputStream);
				updateKeysWithParamStoreConfiguration();
				initializeParameters();
			} 
			else 
			{
				throw new FileNotFoundException("Configuration file '" + CONFIGURATION_FILE_NAME + "' not found in the classpath.");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(configFileInputStream != null)
			{
				try
				{
					configFileInputStream.close();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				configFileInputStream = null;
			}
		}
	}
	
	private static void updateKeysWithParamStoreConfiguration() {
		try {
			ParamsStore paramStore = new ParamsStore("truebylui", true);
			Properties properties = paramStore.getParams(RuleManager.DEF_PART);
			Iterator<Entry<Object, Object>> iterator = properties.entrySet().iterator();
			while (iterator.hasNext()) {
				Entry<Object, Object> eachEntry = iterator.next();
				try {
					applicationConfiguration.put(eachEntry.getKey(), eachEntry.getValue());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private static void initializeParameters() {
		serverIp = getConfigurationValue("SERVER_IP");
		serverPort = getConfigurationValue("SERVER_PORT");
		
		if(serverPort != null && serverPort.trim().length() > 0) {
			serverPort = ":" + serverPort;
		}
		
		scheme = getConfigurationValue("SCHEME");
	}
	
	public static String getServerIp() {
		return serverIp;
	}
	
	public static String getServerPort() {
		return serverPort;
	}
	
	public static String getScheme() {
		return scheme;
	}
	
	public static String getConfigurationValue(String key)
	{
		String value = "";
		try
		{
			value = applicationConfiguration.getProperty(key);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();			
		}
		return value;
	}
	
	public static String getServiceEndpoint(String servicename) {
		String retVal = "";
		try {
			String endPointUrl = getConfigurationValue(servicename);
			retVal = getScheme() + "://" + getServerIp()
					+ getServerPort() + endPointUrl;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return retVal;
	}
}
