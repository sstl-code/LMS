package com.umt.siteassetinventory.site;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.server.VaadinServletRequest;

public class SiteAssetDetailBean extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_ASSET_DETAIL_BEAN";
	private SiteAssetsTab viewSiteAssetsTab;
	private String assetId;
	private String equipment_id;
	private String assetType;

	public SiteAssetDetailBean(String assetId, String assetType, String assetName, String serialNo, String installationDate, String vendorName, String status, SiteAssetsTab siteAssetsTab) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.viewSiteAssetsTab = siteAssetsTab;
		this.assetId = assetId;
		this.assetType=assetType;
		getEquipmentId();
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		Label assetIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_ID_LBL");
		Button viewAssetButton = UIFieldFactory.createButton(SCREENCD, "VIEW_ASSET_BTN");
		Button removeAssetButton = UIFieldFactory.createButton(SCREENCD, "REMOVE_ASSET_BTN");
		assetIdLbl.setText("Asset ID: "+assetId);
		headerDiv.add(assetIdLbl, viewAssetButton, removeAssetButton);

		Div col1 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN1");
		Div col2 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN2");
		Div col3 = UIHtmlFieldFactory.createDiv(SCREENCD, "COLUMN3");

		Div eachAssetDetailDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label assetTypeCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_CAPTION");
		Label assetTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_VALUE");
		assetTypeVal.setText(assetType);
		eachAssetDetailDiv1.add(assetTypeCaption, assetTypeVal);

		Div eachAssetDetailDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label assetNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_CAPTION");
		Label assetNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_VALUE");
		assetNameVal.setText(assetName);
		eachAssetDetailDiv2.add(assetNameCaption, assetNameVal);

		Div eachAssetDetailDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label serialNoCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_CAPTION");
		Label serialNoVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_VALUE");
		serialNoVal.setText(serialNo);
		eachAssetDetailDiv3.add(serialNoCaption, serialNoVal);

		Div eachAssetDetailDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label installationDateCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_CAPTION");
		Label installationDateVal = UIHtmlFieldFactory.createLabel(SCREENCD, "INSTALLATION_DATE_VALUE");
		installationDateVal.setText(installationDate);
		eachAssetDetailDiv4.add(installationDateCaption, installationDateVal);
		
		Div eachAssetDetailDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label vendorNameCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_CAPTION");
		if (siteAssetsTab.isActiveOrPassive()) {
			vendorNameCaption.setText("Operator Name");
		}
		Label vendorNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_VALUE");
		vendorNameVal.setText(vendorName);
		eachAssetDetailDiv5.add(vendorNameCaption, vendorNameVal);

		Div eachAssetDetailDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ASSET_DETAIL_DIV");
		Label statusCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_CAPTION");
		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VALUE");
		statusVal.setText(status);
		statusVal.getStyle().set("background-color", CommonUtils.getStatusColorCode(status));
		eachAssetDetailDiv6.add(statusCaption, statusVal);

		col1.add(eachAssetDetailDiv1, eachAssetDetailDiv4);
		col2.add(eachAssetDetailDiv2, eachAssetDetailDiv5);
		col3.add(eachAssetDetailDiv3, eachAssetDetailDiv6);
		containerDiv.add(col1, col2, col3);
		add(headerDiv, containerDiv);
		
		viewAssetButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
			/*	String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() + "/"
						+ "siteassetinventory/assetsview?StoreSerialNo="+assetId;*/
				
				String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() 
						+VaadinServletRequest.getCurrent().getContextPath()
						+ "/assetsview?StoreSerialNo="+assetId+"&EquipmentId="+equipment_id;
				UI.getCurrent().getPage().open(url);
						
			}
		});
		
		removeAssetButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				removeAsset();	
			}
		});
		
		
	}

	private void getEquipmentId() {
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTID");
			String res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
		//	System.out.println("GETEQUIPMENTID:::"+res);
		//	this.equipment_id;
			JSONArray array_list = new JSONArray(res);
			//System.out.println(equipmentType);
			for(int i = 0; i < array_list.length(); i++) {
				JSONObject json = array_list.getJSONObject(i);
				if(assetType.equalsIgnoreCase(json.getString("EquipmentType"))) {
					equipment_id = json.getString("EquipmentTypeId");
					//System.out.println(eqi_id);
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		//return equipment_id;
		
	}

	private void removeAsset()
	{
		String base_URL=ApplicationConfiguration.getServiceEndpoint("REMOVEASSETFROMSITE");
		try {

			Form formData = new Form();
			formData.add("SiteCode", viewSiteAssetsTab.getSiteCode());
			formData.add("StoreSerialNo", assetId);
//			formData.add("StoreId", 9995);
//			formData.add("StatusId", 3);
//			formData.add("StoreLocId", viewSiteAssetsTab.getSiteCode());
			//System.out.println("input:: " + formData.toString());
			String response = RestServiceHandler.deleteJSON_DELETE(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("Return:" + response);
			//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "ASSET_REMOVE_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
			viewSiteAssetsTab.refreshData();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	}
}
