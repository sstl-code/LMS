package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/attribute_master-styles.css")
public class OtherAttributeMaster extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "OTHER_ATTRIBUTE_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<OtherAttributeMasterDataBean> attributeMasterDataBeanList;
	private ConfigView parent;
	//private Label lbl1, lbl2, lbl3, lbl4, lbl5;
	//private String siteCode;

	public OtherAttributeMaster(ConfigView parent) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;

		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		filterFld.setPlaceholder("Filter Other Attributes");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		Div eachrowDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV6");

		//		for (int i = 0; i < fieldCounts; i++) {
		//			Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV");
		//			Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL");
		//			eachrowDiv.add(lbl);
		//			tableHeaderDiv.add(eachrowDiv);
		//		}
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);
		Label lbl6 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL6");
		eachrowDiv6.add(lbl6);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5, eachrowDiv6);

		filterDiv.add(filterFld , addBtn);

		//AddSiteAssetPopup popup = new AddSiteAssetPopup("Add " + assetParam + " Asset", this, siteAssetsTab, SCREENCD);

		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				addDialog(true);
			}
		});

		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				try {
					attributeMasterDataBeanList.stream().filter(new Predicate<OtherAttributeMasterDataBean>() {

						@Override
						public boolean test(OtherAttributeMasterDataBean t) {
							String filterTxt = filterFld.getValue().trim();
							if (filterTxt == null || filterTxt.trim().length() == 0) {
								t.setVisible(true);
								return true;
							}
							if (StringUtils.containsIgnoreCase(t.getAttributeId()+"", filterTxt)
									|| StringUtils.containsIgnoreCase(t.getAttributeName(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getAttributeType(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getDataType(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getMandatory(), filterTxt)
									|| StringUtils.containsIgnoreCase(t.getDefaultValue(), filterTxt)) {
								t.setVisible(true);
								return true;
							}
							t.setVisible(false);
							return false;
						}
					}).collect(Collectors.toList());
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		filterFld.setValueChangeMode(ValueChangeMode.EAGER);

		populateData();
	}

	protected void populateData() {
		tableContainerDiv.removeAll();
		attributeMasterDataBeanList = new ArrayList<>();
		String response = getAttributes();
		//				"[{\"OtherAttributeId\":1,\"OtherAttribute\":\"Battery\",\"OtherAttributeName\":\"Exide Industries\",\"Description\":\"Battery 24V\","
		//				+ "\"ServiceType\":\"Active\"},{\"OtherAttributeId\":2,\"OtherAttribute\":\"Dish Antenna\",\"OtherAttributeName\":\"Airtel\",\"Description\":"
		//				+ "\"Dish _Antenna_02 added\",\"ServiceType\":\"Passive\"}]";
		try {
			JSONArray ja = new JSONArray(response);
			for (int i = 0; i < ja.length(); i++) {
				JSONObject jo = ja.getJSONObject(i);
				String attributeId = "", attributeName = "", attributeType = "", dataType="", mandatory="", defaultValue="", flov="";
				if(jo.getInt("AttributeType")==7 || jo.getInt("AttributeType")==8 || jo.getInt("AttributeType")==9 || jo.getInt("AttributeType")==10) {
					attributeId = jo.getLong("AttributeId")+""; 
					if (jo.getString("AttributeName")!=null) {
						attributeName = jo.getString("AttributeName");
					}
					/*if (jo.getInt("AttributeType")!=null) {
					attributeType = jo.getString("AttributeType");
				}*/
					if (jo.getInt("Mandatory")==0) {
						mandatory = "No";
					} else if (jo.getInt("Mandatory")==1) {
						mandatory = "Yes";
					}
					if (jo.getString("DefaultValue")!=null) {
						defaultValue = jo.getString("DefaultValue");
					}
					if (jo.getString("FLOV")!=null) {
						flov = jo.getString("FLOV");
					}
					OtherAttributeMasterDataBean bean = new OtherAttributeMasterDataBean(attributeId, attributeName, CommonUtils.getAttributeTypeCd(jo.getInt("AttributeType")), 
							CommonUtils.getAttributeDataTypeCd(jo.getInt("AttributeDatatype")), mandatory, defaultValue, flov, this);
					attributeMasterDataBeanList.add(bean);
					tableContainerDiv.add(bean);
				}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void addDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddOrEditAttribute addOtherAttribute = new AddOrEditAttribute(this);
	}

	//	public void selectedRowChangeHandler(ConfigBaseDataBean selectedBean) 
	//	{
	//		for (ConfigBaseDataBean attributeMasterDataBean : attributeMasterDataBeanList) {
	//			if (!attributeMasterDataBean.equals(selectedBean)) {
	//				attributeMasterDataBean.selectDeselect(true);
	//			}
	//		}
	//	}

	private String getAttributes()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

}
