package com.umt.siteassetinventory.assets;

import org.codehaus.jettison.json.JSONException;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class ChangeAssetDetailsParamsPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private String screencd;
	private boolean dataSaved=false;
	private int changeParam;
	private AssetDetailsTab viewAssetDetailsTab;
	private ChangeAssetDetailsParams changeAssetDetailsParams;


	public ChangeAssetDetailsParamsPopup(String title, int changeParam, Component component, AssetDetailsTab assetDetailsTab, String screencd) {

		super(title, component);
		super.setWidth("600px");
		////System.out.println(title);
		this.changeAssetDetailsParams = (ChangeAssetDetailsParams) component;
		this.viewAssetDetailsTab = assetDetailsTab;
		this.screencd = screencd;
		this.changeParam = changeParam;
	}

	@Override
	public void saveOperartion() {
		////System.out.println("Working");
		String msg= "";
		try {
			if (changeAssetDetailsParams.validation()) {
				if (changeParam==1) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ISSUEEQUIPMENT");

					Form formData = new Form();
					formData.add("StoreSerialNo", viewAssetDetailsTab.getSerialno());
					formData.add("StoreId", changeAssetDetailsParams.getStoreId());
					formData.add("StatusId", changeAssetDetailsParams.getStatusId());
					formData.add("StoreLocId", changeAssetDetailsParams.getStoreLocId());
					formData.add("Remarks", changeAssetDetailsParams.getRemarks());

					//System.out.println("input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Issue:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ASSET_ISSUE_SUCCESSFUL");
					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);	
				}
				else if (changeParam==2) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("RETURNEQUIPMENT");

					Form formData = new Form();
					formData.add("StoreSerialNo", viewAssetDetailsTab.getSerialno());
					formData.add("StoreId", changeAssetDetailsParams.getStoreId());
					formData.add("StatusId", changeAssetDetailsParams.getStatusId());
					formData.add("StoreLocId", changeAssetDetailsParams.getStoreLocId());
					formData.add("Remarks", changeAssetDetailsParams.getRemarks());

					//System.out.println("input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Ret:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ASSET_RETURN_SUCCESSFUL");
					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);	
				}
				else if (changeParam==3) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("CHANGEEQUIPMENTSTATUS");

					Form formData = new Form();
					formData.add("StoreSerialNo", viewAssetDetailsTab.getSerialno());
					formData.add("NewStatusId", changeAssetDetailsParams.getStatusId());
					formData.add("Remarks", changeAssetDetailsParams.getRemarks());

					//System.out.println("input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Status change:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ASSET_STATUS_CHANGE_SUCCESSFUL");
					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewAssetDetailsTab.refreshDetails(dataSaved);
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
