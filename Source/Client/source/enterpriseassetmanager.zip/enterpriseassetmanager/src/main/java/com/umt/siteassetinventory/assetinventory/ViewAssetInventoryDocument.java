package com.umt.siteassetinventory.assetinventory;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Base64;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewAssetDocument")
public class ViewAssetInventoryDocument extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private String sitecode,filename,timestamp,fileExtension;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		sitecode = request.getParameter("SiteCode");
		filename = request.getParameter("FileName");
		timestamp = request.getParameter("TimeStamp");
		
		fileExtension=filename.substring(filename.lastIndexOf(".") + 1);
		
		String homeDirectory = System.getProperty("user.home");
		String assetDataFile2 = homeDirectory + File.separator + "AssetDocuments" + File.separator + sitecode
				+ File.separator + timestamp+ /*"_"*/"-" + filename;
		
		File file = new File(assetDataFile2);
		Path path= Paths.get(assetDataFile2);
		
		OutputStream outputStream =null;
		try
		{
			outputStream = response.getOutputStream();
/*			fis = new FileInputStream(file);

			bis = new BufferedInputStream(fis);
			bis.read();
			byte[] pdfFileContent = Base64.getDecoder().decode(bis);
				byte[] arr = new byte[(int)bis.read().length()];
			dis = new DataInputStream(bis);
					int i;
			 * while((i=bis.read())!=-1){    
					     System.out.print((char)i);    
					    }    */
				
			 byte[] arr = Files.readAllBytes(path);
		
		//	outputStream.write(arr);
			
			if (arr != null && arr.length > 0) 
			{
					try {
					
						outputStream = response.getOutputStream();
						if(fileExtension.toUpperCase().equals("HTML")) {
							response.setContentType("text/html");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".html"*/);
						}
						else if(fileExtension.toUpperCase().equals("PDF")) {
							response.setContentType("application/pdf");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".pdf"*/);
						}
						else if(fileExtension.toUpperCase().equals("DOC")) {
							response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".doc"*/);
						}
						else if(fileExtension.toUpperCase().equals("DOCX")) {
							response.setContentType("application/msword");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".docx"*/);
						}
						else if(fileExtension.toUpperCase().equals("TXT")) {
							response.setContentType("text/plain");
							response.setHeader("Content-Disposition","inline; filename="+filename+".txt");
						}
						else if(fileExtension.toUpperCase().equals("JPG")) {
							response.setContentType("image/jpg");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".jpg"*/);
						}
						else if(fileExtension.toUpperCase().equals("PNG")) {
							response.setContentType("image/png");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".png"*/);
						}
						else if(fileExtension.toUpperCase().equals("JPEG")) {
							response.setContentType("image/jpeg");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".jpeg"*/);
						}
						else if(fileExtension.toUpperCase().equals("GIF")) {
							response.setContentType("image/gif");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".gif"*/);
						}
						else if (fileExtension.toUpperCase().equals("XLS")) {
							response.setContentType("application/vnd.ms-excel");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".xls"*/);
						} 
						else if (fileExtension.toUpperCase().equals("XLSX")) {
							response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
							response.setHeader("Content-Disposition","inline; filename="+filename/*+".xlsx"*/);
						}
					
						outputStream.write(arr);
					} catch (Exception ex) {
						ex.printStackTrace();
						if(outputStream != null) {
							outputStream.write("Failed to process the request.".getBytes());
						}
					} finally {
						if (outputStream != null) {
							try {
								outputStream.flush();
								outputStream.close();
							} catch (IOException ex) {
								ex.printStackTrace();
							}
						}
					}
				}
				else {
					PrintWriter out = response.getWriter();
					out.println("Failed to process the request.");
				}    
	
		}  catch (Exception ex) {
				ex.printStackTrace();
				PrintWriter out = response.getWriter();
				out.println("Failed to process the request.");
			}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
