package com.umt.siteassetinventory.configuration;


import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditAttributePopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditAttribute addOrEditAttribute;
	private String screencd;
	private boolean dataSaved;
	private OtherAttributeMaster viewAttributeMaster;
	private boolean addOrEdit;


	public AddOrEditAttributePopup(String title, boolean addOrEdit, Component component, OtherAttributeMaster master, String screencd) {

		super(title, component);
		if(component.getParent().isPresent()) {
			component.getParent().get().getElement().getStyle().set("overflow-y", "auto");
			component.getParent().get().getElement().getStyle().set("display", "flex");
			component.getParent().get().getElement().getStyle().set("height", "500px");
		}
		
		setWidth("700px");
		//System.out.println(title);
		this.addOrEditAttribute = (AddOrEditAttribute) component;
		this.viewAttributeMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditAttribute.validation()) {
				if (addOrEdit) {
			//		save_btn.setEnabled(false);
					String base_URL=ApplicationConfiguration.getServiceEndpoint("CREATEATTRIBUTE_MASTER");
					JSONObject attributeJson = new JSONObject();
					attributeJson.put("AttributeName", addOrEditAttribute.getAttributeName());
					attributeJson.put("AttributeType", CommonUtils.getAttributeType(addOrEditAttribute.getAttributeType())+"");
					attributeJson.put("AttributeDatatype", CommonUtils.getAttributeDataType(addOrEditAttribute.getAttributeDataType())+"");
					attributeJson.put("Mandatory", addOrEditAttribute.getMandatory()+"");
					attributeJson.put("DefaultValue", addOrEditAttribute.getDefaultValue());
					if(addOrEditAttribute.getAttributeDataType().equalsIgnoreCase("Multiple Selection")) {
						attributeJson.put("FLOV", addOrEditAttribute.getPossibleValuesForMultiSelection());
					} else {
						attributeJson.put("FLOV", addOrEditAttribute.getFlov());
					}

					Form formData = new Form();
					formData.add("Attribute", attributeJson);
					formData.add("ModBy", SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ATTRIBUTE_SAVE_SUCCESSFUL");	
				}
				else
				{
				//	save_btn.setEnabled(false);
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEATTRIBUTE_MASTER");
					
					Form formData = new Form();
					formData.add("AttributeName", addOrEditAttribute.getAttributeName());
//					formData.add("AttributeType", addOrEditAttribute.getAttributeType());
//					formData.add("AttributeDatatype", CommonUtils.getAttributeDataType(addOrEditAttribute.getAttributeDataType()));
					formData.add("Mandatory", addOrEditAttribute.getMandatory());
					formData.add("DefaultValue", addOrEditAttribute.getDefaultValue());
					//formData.add("FLOV", addOrEditAttribute.getFlov());
					
					if(addOrEditAttribute.getAttributeDataType().equalsIgnoreCase("Multiple Selection")) {
						formData.add("FLOV", addOrEditAttribute.getPossibleValuesForMultiSelection());
					} else {
						formData.add("FLOV", addOrEditAttribute.getFlov());
					}

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ATTRIBUTE_UPDATE_SUCCESSFUL");	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewAttributeMaster.populateData();
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			save_btn.setEnabled(true);
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		//	save_btn.setEnabled(true);
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		finally {
			save_btn.setEnabled(true);
		}


	}

}
