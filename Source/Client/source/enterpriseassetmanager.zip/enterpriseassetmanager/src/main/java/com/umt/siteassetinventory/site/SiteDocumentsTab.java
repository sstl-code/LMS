package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

@CssImport("./styles/site_doc-styles.css")
public class SiteDocumentsTab extends VerticalLayout
{
	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "SITE_DOCUMENT";

	private String siteCode = "";
	private VerticalLayout documentsVL;
	private List<SiteDocumentUploadBean> siteDocumentUploadDatalist = new ArrayList<SiteDocumentUploadBean>();
	private SiteDocumentUploadBean eachDocument;
	//private boolean firstTimeLoad = true;
	private Div documentsHeader;


	public SiteDocumentsTab()
	{
		addClassName(SCREENCD + "_" + "MAIN_LAYOUT");

		Label headerLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL");

		/*	Icon addbtn = VaadinIcon.PLUS_CIRCLE_O.create();
		addbtn.addClassName(SCREENCD+"_ADD_BTN_ICON");*/
		//Label addbtnLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ADD_BTN_LBL");
		Button addbtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");
		//addbtnDiv.add(/*addbtn*/addbtnLbl);

		HorizontalLayout headerLayout = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "HEADER_HL");
		headerLayout.add(headerLbl, addbtn);

		Div documentsContainer = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENT_CONTAINER_DIV");
		documentsHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENT_HEADER_DIV");
		Label type = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE");
		Label name = UIHtmlFieldFactory.createLabel(SCREENCD, "NAME");
		Label desc = UIHtmlFieldFactory.createLabel(SCREENCD, "DESC");
		documentsHeader.add(type, name, desc);


		documentsVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DOCUMENT_VL");

		documentsContainer.add(documentsHeader,documentsVL);
		add(headerLayout,documentsContainer);


		addbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

				SiteDocumentUploadDialog dlg= new SiteDocumentUploadDialog(siteCode);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						SiteDocumentUploadDialog srcDlg = (SiteDocumentUploadDialog)event.getSource();
						if(!srcDlg.isOpened()&&(srcDlg.isGetDocUploadStatus()==true))
						{
							populateSiteDocuments(siteCode);
						} 
					}
				});
			}
		});
	}

	public void loadSiteDocumentScreen(String siteCode) {
		/*if(firstTimeLoad) {*/

		this.siteCode = siteCode;
		if(siteCode!=null && siteCode.length()>0) {
			populateSiteDocuments(siteCode);
		}
		
		//			firstTimeLoad = false;
		//
		//		}
	}

	//	private List<SiteDocumentUploadBean> generateOtherDocumentRow(SiteDocumentUploadDialog obj,String siteCode) 
	//	{
	//
	//		List<String> Fieldlist= new ArrayList<>();
	//		Fieldlist.add(obj.getDocumentNameTextfield().getValue());
	//		siteDocumentUploadDatalist.clear();
	//		for(int i=0;i<Fieldlist.size();i++)
	//		{
	//			String getTextfield=Fieldlist.get(i);
	//			eachDocument =new SiteDocumentUploadBean(getTextfield,this,siteCode);
	//			documentsVL.add(eachDocument.getSiteDocumentUploadBean());
	//			siteDocumentUploadDatalist.add(eachDocument);
	//		}
	//		return siteDocumentUploadDatalist;
	//
	//	}

	public List<SiteDocumentUploadBean> populateSiteDocuments(String siteCode) 
	{
		documentsVL.removeAll();
		siteDocumentUploadDatalist.clear();
		String outputResponse="";
		try 
		{
			String base_URL=ApplicationConfiguration.getServiceEndpoint("GETSITEDOCUMENTS");
			base_URL = base_URL.trim()+ "?SiteCode=" + URLEncoder.encode(siteCode);
			//System.out.println(base_URL);
			outputResponse = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());	
			//System.out.println(base_URL+" :::::: "+outputResponse);
			if(outputResponse.equals(null) || outputResponse.trim().length()==0)
			{
				return null;
			}
			else { 

				JSONArray jsonArr=new JSONArray(outputResponse);
				//siteDocumentUploadDatalist.clear();
				for(int i=0;i<jsonArr.length();i++)
				{ 
					JSONObject jsonObj = jsonArr.getJSONObject(i); 
					String attributes = jsonObj.getString("attributes");
					JSONObject attributesJson = new JSONObject(attributes);
					String desc = ""; 
					if (attributesJson.has("description") && attributesJson.getString("description")!=null && attributesJson.getString("description").trim().length()>0) {
						desc = attributesJson.getString("description");
					}
					eachDocument =new SiteDocumentUploadBean(jsonObj.getString("fileuid"), attributesJson.getString("type"), jsonObj.getString("filename"), 
							desc, jsonObj.getString("url"), this, siteCode);
					
					documentsVL.add(eachDocument.getSiteDocumentUploadBean());
					if (i==0) {
						System.out.println(jsonObj.getString("url").substring(0, jsonObj.getString("url").indexOf("/RuleServer"))+" replaced by "+
				      	eachDocument.getViewUrlToOpen().substring(0, eachDocument.getViewUrlToOpen().indexOf("/RuleServer")));
					}
					siteDocumentUploadDatalist.add(eachDocument);
				}
			}

		}catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

		return siteDocumentUploadDatalist;


	}

	public void removeDocumentrow(SiteDocumentUploadBean beanobj) 
	{

		documentsVL.remove(beanobj.recordHL);
		siteDocumentUploadDatalist.remove(beanobj);
		//siteDocumentUploadDatalist.remove(beanobj.RecordHL);
		/*int position = beanobj.getPosition();
        //////System.out.println("pos"+position);
        String docTypename = siteDocumentUploadDatalist.get(position).getDocName1();
        siteDocumentUploadDatalist.remove(docTypename);*/
	}

}
