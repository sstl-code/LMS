package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/store_master-styles.css")
public class StoreMasterDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "STORE_MASTER_DATA_BEAN";
	private long storeId;
	private String storeName, address;
	private int status;
	private StoreMaster parent;
	private Div eachrowDiv;
	//private Button editBtn, deactivateBtn;
	private Div editDiv, deactivateDiv;
	//private boolean selected = false;


	public StoreMasterDataBean(long storeId, String storeName, String address, int status, StoreMaster storeMaster) 
	{
		this.storeId = storeId;
		this.storeName = storeName;
		this.address = address;
		this.status = status;
		this.parent = storeMaster;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		//Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");


		Label storeIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL1");
		storeIdVal.setText(storeId+"");
		eachdataDiv1.add(storeIdVal);
		
		Label storeNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL2");
		storeNameVal.setText(storeName);
		eachdataDiv2.add(storeNameVal);

		Label addressVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL3");
		addressVal.setText(address);
		eachdataDiv3.add(addressVal);

		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL4");
		statusVal.setText(CommonUtils.getStatusCd(status));
		eachdataDiv4.add(statusVal);

		editDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EDIT_DIV");
		Image editIcon = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
//		Icon editIcon = VaadinIcon.PENCIL.create();
		editDiv.add(editIcon);
		//editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
//		deactivateBtn = UIFieldFactory.createButton(SCREENCD, "DEACTIVATE_BTN");
		
		deactivateDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DEACTIVATE_DIV");
		Icon deactivateIcon = VaadinIcon.TRASH.create();
		deactivateDiv.add(deactivateIcon);

		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3,eachdataDiv4,editDiv/*,deactivateDiv*/);
		add(eachrowDiv);

		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//selectedRowChangeHandler();
			}
		});
		
		editDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> arg0) {
				editDialog(false);
			}
		});
	}
	
	private void editDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddOrEditStore editStore = new AddOrEditStore(parent, this, storeId, storeName, address, CommonUtils.getStatusCd(status));
	}
	
//	private void selectedRowChangeHandler()
//	{
//		selectDeselect(selected);
//		parent.selectedRowChangeHandler(this);
//	}
	
//	protected void selectDeselect(boolean selectedOrDeselected)
//	{
//		if (selectedOrDeselected) {
//			selected = false;
//			eachrowDiv.removeClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//		else
//		{
//			selected = true;
//			eachrowDiv.addClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//	}

	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	public Long getStoreId() {
		return storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public String getAddress() {
		return address;
	}

	public String getStatus() {
		return CommonUtils.getStatusCd(status);
	}


//	public boolean isSelected() {
//		return selected;
//	}

}
