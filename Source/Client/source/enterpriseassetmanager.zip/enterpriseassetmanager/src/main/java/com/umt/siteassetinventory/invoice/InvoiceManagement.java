package com.umt.siteassetinventory.invoice;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.Route;

@Route(value = "invoicemanagement", layout = MainView.class)
@CssImport("./styles/invoice-mangement.css")
public class InvoiceManagement extends Div{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "INVOICE_MANAGEMENT";
	private TextField filterRecords;
	private Div  headerDiv,containerDiv,containerBodyDiv,btnRowDiv,footerLayout,prevBtndiv,nextBtndiv;
	private TextField siteIdField,invoiceNoField,sapVendorCode;
	private ComboBox<String> invoiceStatusField;
	private ComboBox<String> invoiceTypeField;
	private DatePicker invoiceGenerationDateField;
	private List<InvoiceManagementBean> beanList=new ArrayList<InvoiceManagementBean>();
	private Button retrievebtn,holdbtn,unholdbtn,approvebtn,rejectBtn,addInvoiceBtn ,clearbtn,saveTdsBtn,saveGLCode;
	private Tab rentalTab,electricityTab,emgSubTab,financeSubTab;
	protected Tabs parentTabs,subParentTabs;
	private Div  rentalTabVL,electricityTabVL,emgSubTabVL,financeSubTabVL;
	private int remainder,pg,numberofpg;
	private int limit = 10;
	private int clickCnt = 0;
	private int totalCnt;
	private int remainingCnt,quotientCnt;
	private Label pagenumberLbl,totalcountLbl;
	private DatePicker startDateField,endDateField;
	private boolean emgTab=true,isrentalTab=true,isUsageTab=false;
	private Tab rentalTabEmg,rentalTabFinance,electricityTabEmg,electricityTabFinance;
	private Div  rentalemgSubTabVL,rentalfinanceSubTabVL,electricityemgSubTabVL,electricityfinanceSubTabVL;
	private VerticalLayout filterMenuLayout,filterMenuContainerLayout;
	private boolean toggleClick = true;
	private Div fieldrowDiv2;
	private Label siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
	rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,dueDateLbl,grossAmtLbl,
	billingCycleLbl,statusLbl,remarkLbl,selectLbl,tdscomboLbl,tdsfieldLbl,submissiondateLbl,fileuidLbl,iconLbl,editiconLbl,
	billforOp,invoiceAmt,gst,invoicearrears,glcodeLbl;
	private boolean financeTab=true;
	private HashMap<String,String> invoicetypemap=new HashMap<String,String>();
	private HashMap<String,String> statustypemap=new HashMap<String,String>();
	private List<String> invoiceTypeList=new ArrayList<String>(),statusList=new ArrayList<String>();
	private int pageNo = 0, pageSize = 10;
	private boolean retrieveBtnClicked=false;
	
	

	public InvoiceManagement() {
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Invoice Management");
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		pageSize = Integer.parseInt(ApplicationConfiguration.getConfigurationValue("INVOICE_MANAGEMENT_RECORD_COUNT_LIMIT"));
		
		Div tabrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TAB_ROW_DIV");
		rentalTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "RENTAL_TAB_LBL"));
		electricityTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ELECTRICITY_TAB_LBL"));
		
		rentalTabEmg=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "RENTAL_TAB_EMG_LBL"));
		rentalTabFinance=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "RENTAL_TAB_FINANCE_LBL"));
		electricityTabEmg=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ELECTRICITY_TAB_EMG_LBL"));
		electricityTabFinance=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ELECTRICITY_TAB_FINANCE_LBL"));
		
		addInvoiceBtn=UIFieldFactory.createButton(SCREENCD, "ADD_INVOICE_BTN");
		
		parentTabs = new Tabs();
		parentTabs.addClassName(SCREENCD + "_PARENT_TABS");
	//	parentTabs.add(rentalTab,electricityTab);
		parentTabs.add(rentalTabEmg,rentalTabFinance,electricityTabEmg,electricityTabFinance,addInvoiceBtn);
		tabrowDiv.add(parentTabs);
	//	parentTabs.setSelectedTab(rentalTab);
		parentTabs.setSelectedTab(rentalTabEmg);
		
		rentalTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "RENTAL_TAB_VL");
		electricityTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "ELECTRICITY_TAB_VL");
		
		Div subtabrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SUB_TAB_ROW_DIV");
		emgSubTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EMG_TAB_LBL"));
		financeSubTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "FINANCE_TAB_LBL"));
		
		emgSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "EMG_SUB_TAB_VL");
		financeSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "FINANCE_SUB_TAB_VL");
		
		rentalemgSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "EMG_SUB_TAB_VL");
		rentalfinanceSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "FINANCE_SUB_TAB_VL");
		electricityemgSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "EMG_SUB_TAB_VL");
		electricityfinanceSubTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "FINANCE_SUB_TAB_VL");
		
		subParentTabs = new Tabs();
		subParentTabs.addClassName(SCREENCD + "_SUB_PARENT_TABS");
		subParentTabs.add(emgSubTab,financeSubTab);
		subParentTabs.setSelectedTab(emgSubTab);
		
	//	subtabrowDiv.add(subParentTabs,addInvoiceBtn);
		
		
		
		
		Div searchDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_DIV"); 
		Label searchLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SEARCH_LBL");
		Div fieldrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROW_DIV");
		
		fieldrowDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROW_DIV2");
		filterRecords = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_RECORD_FIELD");
		filterRecords.setSuffixComponent(VaadinIcon.SEARCH.create());
		filterRecords.setValueChangeMode(ValueChangeMode.EAGER);
		Label filterRecordsLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILTER_RECORDS_LBL");
		Div filtericonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_ICON_DIV");
		com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon filterIcon = FontAwesome.Solid.FILTER.create();
		filterIcon.addClassName(SCREENCD+"_FILTERICON");
		filtericonDiv.add(filterIcon);
		filtericonDiv.setTitle("Additional Filter");
		fieldrowDiv2.add(filterRecordsLbl,filterRecords,filtericonDiv);
		
		siteIdField=UIFieldFactory.createTextField("", false, SCREENCD,"SITEID_FIELD");
	//	invoiceTypeField=UIFieldFactory.createTextField("", false, SCREENCD,"INVOICETYPE_FIELD");
		invoiceTypeField=UIFieldFactory.createComboBox(invoiceTypeList, false, SCREENCD,"INVOICETYPE_FIELD");
		invoiceNoField=UIFieldFactory.createTextField("", false, SCREENCD,"INVOICENO_FIELD");
		sapVendorCode=UIFieldFactory.createTextField("", false, SCREENCD,"SAP_VENDOR_CODE_FIELD");
		invoiceStatusField=UIFieldFactory.createComboBox(statusList, false,SCREENCD,"INVOICESTATUS_FIELD");
	//	invoiceGenerationDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "INVOICE_GEN_DATE_FIELD");
		retrievebtn = UIFieldFactory.createButton(SCREENCD, "RETRIEVE_BTN");
		clearbtn = UIFieldFactory.createButton(SCREENCD, "CLEAR_BTN");
		saveTdsBtn=UIFieldFactory.createButton(SCREENCD, "SAVE_TDS_BTN");
		saveGLCode=UIFieldFactory.createButton(SCREENCD, "SAVE_GLCODE_BTN");
		startDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "START_DATE_FIELD");
		endDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "END_DATE_FIELD");
	//	fieldrowDiv.add(siteIdField,invoiceIdField,invoiceNoField,sapVendorCode,invoiceStatusField,/*invoiceGenerationDateField,*/
	//			startDateField,endDateField,retrievebtn);
		searchDiv.add(/*searchLbl,fieldrowDiv,*/fieldrowDiv2);
		
		btnRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_ROW_DIV");
		holdbtn = UIFieldFactory.createButton(SCREENCD, "HOLD_BTN");
		unholdbtn = UIFieldFactory.createButton(SCREENCD, "UNHOLD_BTN");
		approvebtn = UIFieldFactory.createButton(SCREENCD, "APPROVE_BTN");
		rejectBtn=UIFieldFactory.createButton(SCREENCD, "REJECT_BTN");
	//	btnRowDiv.add(holdbtn,unholdbtn,approvebtn);
	//	btnRowDiv.setVisible(false);
		
	
		
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		footerLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_LAYOUT");
		btnRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_ROW_DIV");
		
	//	add(tabrowDiv,searchDiv,containerDiv,btnRowDiv);
/*		rentalTabVL.setVisible(true);
		electricityTabVL.setVisible(false);
		financeSubTabVL.setVisible(false);
		emgSubTabVL.setVisible(true);
		emgSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
		add(tabrowDiv,rentalTabVL,electricityTabVL,subtabrowDiv,emgSubTabVL,financeSubTabVL);*/
//		rentalTabVL.add(searchDiv,containerDiv,btnRowDiv);
		
	//	add(tabrowDiv,rentalemgSubTabVL,rentalfinanceSubTabVL,electricityemgSubTabVL,electricityfinanceSubTabVL);
	
		filterMenuLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "MENU_LAYOUT");
		filterMenuContainerLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "CONTAINER_LAYOUT");
		Div menuDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUHEADER_DIV");
		Div menuFieldDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUFIELD_DIV");
		Div menuBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUBTN_DIV");
		Label menuLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MENU_LBL");
		menuDiv.add(menuLbl);
		
	//	filterMenuContainerLayout.add(searchDiv,containerDiv,btnRowDiv);
		
		filterMenuContainerLayout.add(rentalemgSubTabVL,rentalfinanceSubTabVL,electricityemgSubTabVL,electricityfinanceSubTabVL);
		
		menuFieldDiv.add(siteIdField,invoiceTypeField,invoiceNoField,sapVendorCode,invoiceStatusField,
				startDateField,endDateField);
		menuBtnDiv.add(retrievebtn,clearbtn);
		filterMenuLayout.add(menuDiv,menuFieldDiv,menuBtnDiv);
		
		Div filterMenuContainerHL = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_HL");
		filterMenuContainerHL.add(filterMenuLayout,filterMenuContainerLayout);
	
		add(tabrowDiv,filterMenuContainerHL);
				
		
		
		rentalemgSubTabVL.setVisible(true);
		rentalfinanceSubTabVL.setVisible(false);
		electricityemgSubTabVL.setVisible(false);
		electricityfinanceSubTabVL.setVisible(false);
		
		
		
		initalizeToggleMenu();
		populateInvoiceTypeLists();
		populateStatusLists();
		
		
		
		filtericonDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				if (toggleClick) {
					filterMenuLayout.addClassName("SIDEBAR_MENU_COLLAPSED");
					filterMenuContainerLayout.removeClassName("CONTAINER_LAYOUT_COLLAPSED");
					filterMenuContainerLayout.addClassName("EXPAND_CONTAINER_LAYOUT");
					
					filterMenuLayout.removeClassName("SIDEBAR_MENU_EXPAND");
					fieldrowDiv2.getStyle().set("padding-left", "22px");
					containerDiv.getStyle().set("margin-left", "22px");
					
				
					toggleClick = false;
				} else {
					filterMenuLayout.removeClassName("SIDEBAR_MENU_COLLAPSED");
					filterMenuContainerLayout.removeClassName("EXPAND_CONTAINER_LAYOUT");
					filterMenuContainerLayout.addClassName("CONTAINER_LAYOUT_COLLAPSED");
					
					filterMenuLayout.addClassName("SIDEBAR_MENU_EXPAND");
					fieldrowDiv2.getStyle().set("padding-left", "0px");
					containerDiv.getStyle().set("margin-left", "0px");
					
			
					toggleClick = true;
				}
			}
		});
		
		
		retrievebtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				pageNo=0;
				pageSize=10;
				retrieveBtnClicked=true;
				retrieveRecords(emgTab,0,10,true);
			}
		});

		approvebtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				approveRecords();
			}
		});
		
		holdbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				holdRecords();
			}
		});
		
		unholdbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				unholdRecords();
			}
		});

		rejectBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				rejectRecords();
			}
		});
		clearbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				clearFields();
			}
		});
		saveTdsBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				updateTds();
			}
		});
		saveGLCode.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				updateGLCode();
			}
		});
		
		addInvoiceBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				try {
					AddInvoiceDialog dlg =new AddInvoiceDialog(isrentalTab,isUsageTab,emgTab,"create");
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;

						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							AddInvoiceDialog srcDlg = (AddInvoiceDialog)event.getSource();
							if(!srcDlg.isOpened() && srcDlg.success) {
								
								retrieveRecords(emgTab,0,10,false);
							}
						}

					});
				}catch(Exception e) {
					e.printStackTrace();
				}
				
			}
		});




		createPagination();
	/*	 parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				containerDiv.removeAll();
				btnRowDiv.removeAll();
				if(event.getSelectedTab().equals(rentalTab)) {
					isrentalTab=true;
					isUsageTab=false;
					rentalTabVL.setVisible(true);
					electricityTabVL.setVisible(false);

				}else if(event.getSelectedTab().equals(electricityTab)) {
					isrentalTab=false;
					isUsageTab=true;
					electricityTabVL.setVisible(true);
					rentalTabVL.setVisible(false);

				} 

			}
		});
*/
		
		rentalemgSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;
			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				containerDiv.removeAll();
				btnRowDiv.removeAll();
				retrieveBtnClicked=false;
				if(event.getSelectedTab().equals(rentalTabEmg)) {
					retrieveBtnClicked=false;
					pageNo = 0;
					pageSize = 10;
					isrentalTab=true;
					isUsageTab=false;
					emgTab=true;
					toggleClick = true;
					addInvoiceBtn.setVisible(true);
					initalizeToggleMenu();
				//	rentalTabVL.setVisible(true);
				//	electricityTabVL.setVisible(false);
					rentalemgSubTabVL.setVisible(true);
					rentalfinanceSubTabVL.setVisible(false);
					electricityemgSubTabVL.setVisible(false);
					electricityfinanceSubTabVL.setVisible(false);
					
					rentalemgSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					clearRecords();
		//			filterRecords();
					populateInvoiceTypeLists();
					retrieveRecords(emgTab,0,10,retrieveBtnClicked);

				}else if(event.getSelectedTab().equals(rentalTabFinance)) {
					retrieveBtnClicked=false;
					pageNo = 0;
					pageSize = 10;
					isrentalTab=true;
					isUsageTab=false;
					emgTab=false;
					toggleClick = true;
					addInvoiceBtn.setVisible(false);
					initalizeToggleMenu();
				//	rentalTabVL.setVisible(true);
				//	electricityTabVL.setVisible(false);
					rentalemgSubTabVL.setVisible(false);
					rentalfinanceSubTabVL.setVisible(true);
					electricityemgSubTabVL.setVisible(false);
					electricityfinanceSubTabVL.setVisible(false);
					
					rentalfinanceSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					clearRecords();
		//			filterRecords();
					populateInvoiceTypeLists();
					retrieveRecords(emgTab,0,10,retrieveBtnClicked);

				}else if(event.getSelectedTab().equals(electricityTabEmg)) {
					retrieveBtnClicked=false;
					pageNo = 0;
					pageSize = 10;
					isrentalTab=false;
					isUsageTab=true;
					emgTab=true;
					toggleClick = true;
					addInvoiceBtn.setVisible(true);
					initalizeToggleMenu();
				//	electricityTabVL.setVisible(true);
				//	rentalTabVL.setVisible(false);
					rentalemgSubTabVL.setVisible(false);
					rentalfinanceSubTabVL.setVisible(false);
					electricityemgSubTabVL.setVisible(true);
					electricityfinanceSubTabVL.setVisible(false);
					
					electricityemgSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					clearRecords();
			//		filterRecords();
					populateInvoiceTypeLists();
					retrieveRecords(emgTab,0,10,retrieveBtnClicked);
					
				} 
				else if(event.getSelectedTab().equals(electricityTabFinance)) {
					retrieveBtnClicked=false;
					pageNo = 0;
					pageSize = 10;
					isrentalTab=false;
					isUsageTab=true;
					emgTab=false;
					toggleClick = true;
					addInvoiceBtn.setVisible(false);
					initalizeToggleMenu();
			//		electricityTabVL.setVisible(true);
			//		rentalTabVL.setVisible(false);
					rentalemgSubTabVL.setVisible(false);
					rentalfinanceSubTabVL.setVisible(false);
					electricityemgSubTabVL.setVisible(false);
					electricityfinanceSubTabVL.setVisible(true);
					
					electricityfinanceSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					clearRecords();
			//		filterRecords();
					populateInvoiceTypeLists();
					retrieveRecords(emgTab,0,10,retrieveBtnClicked);
					

				} 

			}
		});
		
	/*	 subParentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				containerDiv.removeAll();
				btnRowDiv.removeAll();
				if(event.getSelectedTab().equals(emgSubTab)) {
					emgSubTabVL.setVisible(true);
					financeSubTabVL.setVisible(false);
					emgSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					emgTab=true;

				}else if(event.getSelectedTab().equals(financeSubTab)) {
					financeSubTabVL.setVisible(true);
					emgSubTabVL.setVisible(false);
					financeSubTabVL.add(searchDiv,containerDiv,btnRowDiv);
					emgTab=false;

				} 

			}
		});*/
		 
		 if(isrentalTab==true && isUsageTab==false && emgTab==true) {//Rental Emg
			 	holdbtn.setVisible(true);
				unholdbtn.setVisible(true);
				approvebtn.setVisible(true);
				rejectBtn.setVisible(true);
				addInvoiceBtn.setVisible(true);
			}else if(isrentalTab==true && isUsageTab==false && emgTab==false){//Rental Finance
				holdbtn.setVisible(false);
				unholdbtn.setVisible(false);
				approvebtn.setVisible(true);
				rejectBtn.setVisible(true);
				approvebtn.getStyle().set("margin-left", "auto");
				addInvoiceBtn.setVisible(false);
			}else if(isrentalTab==false && isUsageTab==true && emgTab==true){//usage Emg
				holdbtn.setVisible(false);
				unholdbtn.setVisible(false);
				approvebtn.setVisible(false);
				rejectBtn.setVisible(false);
				addInvoiceBtn.setVisible(true);
			}else if(isrentalTab==false && isUsageTab==true && emgTab==false){//usage finance
				holdbtn.setVisible(false);
				unholdbtn.setVisible(false);
				approvebtn.setVisible(false);
				rejectBtn.setVisible(false);
				addInvoiceBtn.setVisible(false);
			}else {}


		 retrieveRecords(emgTab,0,10,false);
		
		 filterRecords.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
				private static final long serialVersionUID = 1L;
				
				@Override
				public void valueChanged(ValueChangeEvent<?> event) {
					beanList.stream().filter(new Predicate<InvoiceManagementBean>() {

						@Override
						public boolean test(InvoiceManagementBean t) {
							
							
							String searchTxt = filterRecords.getValue().trim();
							if (searchTxt == null || searchTxt.trim().length() == 0) {
							//	 t.getRowDiv().setVisible(true);
							//	 t.usageDetailsDiv.setVisible(true);
								t.eachrowWrapperDiv.setVisible(true);
								
								return true;
							}
							if (   //    StringUtils.containsIgnoreCase(t.landlordName(), searchTxt)
									StringUtils.containsIgnoreCase(t.getLandlordName(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getSiteId(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getSiteName(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getCircle(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoiceNo(), searchTxt)
									|| StringUtils.containsIgnoreCase(String.valueOf(t.getInvoiceId()), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoicetype(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getbillType(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getrentStatus(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getsapvendorcode(), searchTxt)
								//	|| StringUtils.containsIgnoreCase(t.getLandlordName(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoiceDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoiceStartDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoiceEndDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getdueDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getgrossAmt(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getBillingCycle(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getstatus(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getSubmissionDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getSolutionType(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getRentShare(), searchTxt)
							//		|| StringUtils.containsIgnoreCase(t.getTds(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getGstRate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getInvoiceAmt(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getBillForOp(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getArrears(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getGLcodes(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getTdsFieldValue(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getTdsApplicable(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getremarks(), searchTxt)) {
							
							//	System.out.println("inside_filter_Div");
							//	t.getRowDiv().setVisible(true);
						//		t.usageDetailsDiv.setVisible(true);
								t.eachrowWrapperDiv.setVisible(true);
								
								return true;
							}else {
							//	System.out.println("outside_filter_Div");
							//	t.getRowDiv().setVisible(false);
							//	t.usageDetailsDiv.setVisible(false);
							//	t.isChargeVisible=false;
							//	t.setcareticon(false);
								t.eachrowWrapperDiv.setVisible(false);
						//		System.out.println("t.isChargeVisible=="+t.isChargeVisible);

								return false;
							}
							
						}
					
					}).collect(Collectors.toList());
					

				}
			});
		 
	//	 filterRecords();
	//	 retrieveRecords(emgTab,0,10,false);
		
		
	}
	public void filterRecords() {
		beanList.stream().filter(new Predicate<InvoiceManagementBean>() {
			@Override
			public boolean test(InvoiceManagementBean t) {
				String searchTxt = filterRecords.getValue();
				if (searchTxt == null || searchTxt.trim().length() == 0) {
					t.getRowDiv().setVisible(true);
					return true;
				}
				     if (StringUtils.containsIgnoreCase(t.getLandlordName(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSiteId(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSiteName(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getCircle(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoiceNo(), searchTxt)
						|| StringUtils.containsIgnoreCase(String.valueOf(t.getInvoiceId()), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoicetype(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getbillType(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getrentStatus(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getsapvendorcode(), searchTxt)
					//	|| StringUtils.containsIgnoreCase(t.getLandlordName(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoiceDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoiceStartDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoiceEndDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getdueDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getgrossAmt(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getBillingCycle(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getstatus(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSubmissionDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSolutionType(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getRentShare(), searchTxt)
				//		|| StringUtils.containsIgnoreCase(t.getTds(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getGstRate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getInvoiceAmt(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getBillForOp(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getArrears(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getremarks(), searchTxt)) {
				
					t.getRowDiv().setVisible(true);
					return true;
				}else {
					t.getRowDiv().setVisible(false);
					return false;
				}
				
			}
		
		}).collect(Collectors.toList());
	}
	
	private void initalizeToggleMenu() {
		if (toggleClick) {
			filterMenuLayout.addClassName("SIDEBAR_MENU_COLLAPSED");
			filterMenuContainerLayout.removeClassName("CONTAINER_LAYOUT_COLLAPSED");
			filterMenuContainerLayout.addClassName("EXPAND_CONTAINER_LAYOUT");
			
			filterMenuLayout.removeClassName("SIDEBAR_MENU_EXPAND");
			fieldrowDiv2.getStyle().set("padding-left", "22px");
			containerDiv.getStyle().set("margin-left", "22px");
			
		
			toggleClick = false;
		} else {
			filterMenuLayout.removeClassName("SIDEBAR_MENU_COLLAPSED");
			filterMenuContainerLayout.removeClassName("EXPAND_CONTAINER_LAYOUT");
			filterMenuContainerLayout.addClassName("CONTAINER_LAYOUT_COLLAPSED");
			
			filterMenuLayout.addClassName("SIDEBAR_MENU_EXPAND");
			fieldrowDiv2.getStyle().set("padding-left", "0px");
			containerDiv.getStyle().set("margin-left", "0px");
	
			toggleClick = true;
		}
		
	}
	protected void clearFields() {
		siteIdField.clear();
		startDateField.clear();
		endDateField.clear();
		invoiceTypeField.clear();
		invoiceNoField.clear();
		sapVendorCode.clear();
		invoiceStatusField.clear();
		filterRecords.clear();
		beanList.clear();
		containerBodyDiv.removeAll();
		footerLayout.setVisible(false);
		retrieveBtnClicked=false;
		
		retrieveRecords(emgTab,0,10,false);
	}
	
	protected void clearRecords() {
		siteIdField.clear();
		startDateField.clear();
		endDateField.clear();
		invoiceTypeField.clear();
		invoiceNoField.clear();
		sapVendorCode.clear();
		invoiceStatusField.clear();
		filterRecords.clear();
		beanList.clear();
		containerBodyDiv.removeAll();
		footerLayout.setVisible(false);
		retrieveBtnClicked=false;
	}


	protected void retrieveRecords(boolean emgTab, int pageNo2, int pageSize2,boolean retrieveBtnClicked) {
		
		
		circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		landlordNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDNAME_LBL");
		sapvendorCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAPVENDORCODE_LBL");
		landlordrentsharePercentageLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_RENT_SHARE_PERCENT_LBL");
		solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		billingTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_TYPE_LBL");
		rentStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RENT_STATUS_LBL");
		typeofinvoiceLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_OF_INVOICE_LBL");
		invoiceIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_ID_LBL");
		invoiceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICENO_LBL");
		invoiceDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_DATE_LBL");
		dueDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DUE_DATE_LBL");
		billingCycleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_CYCLE_LBL");
		invoiceStartDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_START_DATE_LBL");
		invoiceEndDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_END_DATE_LBL");
		grossAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "GROSS_AMT_LBL");
	//	Label rejectreasonLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REJECT_REASON_LBL");
		remarkLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMARK_LBL");
		statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		selectLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SELECT_LBL");
		submissiondateLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "SUMBMISSIONDATE_LBL");
		fileuidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILEUID_LBL");
		iconLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "ICON_LBL");
		editiconLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "EDITICON_LBL");
		
		billforOp= UIHtmlFieldFactory.createLabel(SCREENCD, "BILLFOROP_LBL");
		invoiceAmt= UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICEAMT_LBL");
		gst= UIHtmlFieldFactory.createLabel(SCREENCD, "GST_LBL");
		invoicearrears= UIHtmlFieldFactory.createLabel(SCREENCD, "ARREARS_LBL");
		
		tdscomboLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TDS_COMBO_FIELD");
		tdsfieldLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TDS_PERCENT_FIELD");
		
		glcodeLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "GLCODE_COMBO_FIELD");
		
		headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		containerBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_BODY_DIV");
		
		headerDiv.removeAll();
		headerDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
				rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,
				grossAmtLbl,gst,invoiceAmt,billforOp,invoicearrears,
				billingCycleLbl,glcodeLbl,statusLbl,/*rejectreasonLbl,*/fileuidLbl,remarkLbl,selectLbl,editiconLbl,iconLbl);
		
		containerBodyDiv.removeAll();
		containerDiv.removeAll();
		
		containerDiv.add(headerDiv,containerBodyDiv);
		beanList.clear();
		
	
		if(isrentalTab==true && isUsageTab==false && emgTab==true) {//Rental Emg
//			headerDiv.getStyle().set("width","2481px !important");
//			containerBodyDiv.getStyle().set("width","2481px !important");
//			headerDiv.getStyle().set("width","2881px !important");
//			containerBodyDiv.getStyle().set("width","2881px !important");
//			headerDiv.getStyle().set("width","3031px !important");
//			containerBodyDiv.getStyle().set("width","3031px !important");
			
			headerDiv.getStyle().set("width","3131px !important");
			containerBodyDiv.getStyle().set("width","3131px !important");
			getRecordsForRentalEmgTab(pageNo2,pageSize2,retrieveBtnClicked);
		}else if(isrentalTab==true && isUsageTab==false && emgTab==false){//Rental Finance
//			headerDiv.getStyle().set("width","2761px !important");
//			containerBodyDiv.getStyle().set("width","2761px !important");
//			headerDiv.getStyle().set("width","3161px !important");
//			containerBodyDiv.getStyle().set("width","3161px !important");		
//			headerDiv.getStyle().set("width","3311px !important");
//			containerBodyDiv.getStyle().set("width","3311px !important");
			
			headerDiv.getStyle().set("width","3411px !important");
			containerBodyDiv.getStyle().set("width","3411px !important");
			getRecordsForRentalFinanceTab(pageNo2,pageSize2,retrieveBtnClicked);
		}else if(isrentalTab==false && isUsageTab==true && emgTab==true){//usage Emg
		//	headerDiv.getStyle().set("width","2881px !important");
		//	containerBodyDiv.getStyle().set("width","2881px !important");
//			headerDiv.getStyle().set("width","2641px !important");
//			containerBodyDiv.getStyle().set("width","2641px !important");

//			headerDiv.getStyle().set("width","2891px !important");
//			containerBodyDiv.getStyle().set("width","2891px !important");
			headerDiv.getStyle().set("width","2991px !important");
			containerBodyDiv.getStyle().set("width","2991px !important");
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			getRecordsForUsageEmgTab(pageNo2,pageSize2,retrieveBtnClicked);
		}else if(isrentalTab==false && isUsageTab==true && emgTab==false){//usage finance
//			headerDiv.getStyle().set("width","3161px !important");
//			containerBodyDiv.getStyle().set("width","3161px !important");
//			headerDiv.getStyle().set("width","2921px !important");
//			containerBodyDiv.getStyle().set("width","2921px !important");

//			headerDiv.getStyle().set("width","3071px !important");
//			containerBodyDiv.getStyle().set("width","3071px !important");
			headerDiv.getStyle().set("width","3171px !important");
			containerBodyDiv.getStyle().set("width","3171px !important");
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			getRecordsForUsageFinanceTab(pageNo2,pageSize2,retrieveBtnClicked);
		}else {}
		
		
	}

	


	private void getRecordsForRentalFinanceTab(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		try {
			beanList.clear();
			String resp=getRentalInvoiceRecordsForFinance(pageNo2,pageSize2,retrieveBtnClicked);
			
			
			headerDiv.removeAll();
			headerDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
					rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,
					dueDateLbl,grossAmtLbl,grossAmtLbl,gst,invoiceAmt,billforOp,invoicearrears,billingCycleLbl,statusLbl,fileuidLbl,remarkLbl,tdscomboLbl,
					tdsfieldLbl,glcodeLbl,selectLbl/*,editiconLbl*/);
					
		
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						JSONObject usage_detailsjs=new JSONObject();
					
						InvoiceManagementBean beanobj=new InvoiceManagementBean(
								jsarr.getJSONObject(i).getString("InvoiceId"),
								jsarr.getJSONObject(i).getString("Circle"),
								jsarr.getJSONObject(i).getString("SiteCode"),
								jsarr.getJSONObject(i).getString("SiteName"),
								jsarr.getJSONObject(i).getString("LandlordName"),
								jsarr.getJSONObject(i).getString("SapVendorCode"),
								jsarr.getJSONObject(i).getString("InvoiceDate"),
								jsarr.getJSONObject(i).getString("DueDate"),
								jsarr.getJSONObject(i).getString("periodStartDate"),
								jsarr.getJSONObject(i).getString("periodEndDate"),
								jsarr.getJSONObject(i).getString("RentShare"),
								jsarr.getJSONObject(i).getString("SolutionType"),
								jsarr.getJSONObject(i).getString("BillingType"),
								jsarr.getJSONObject(i).getString("BillingCycle"),
								jsarr.getJSONObject(i).getString("RentStatus"),
								jsarr.getJSONObject(i).getString("InvoiceType"),
								jsarr.getJSONObject(i).getString("Status"),
								jsarr.getJSONObject(i).getString("InvoiceNo"),
								jsarr.getJSONObject(i).getString("GrossInvoiceAmount"),
								jsarr.getJSONObject(i).getString("DueOn"),
								jsarr.getJSONObject(i).getString("Gst_Rate"),
								jsarr.getJSONObject(i).getString("InvoiceAmount"),
								jsarr.getJSONObject(i).getString("BillForOperator"),
								jsarr.getJSONObject(i).getString("InvoiceArrears"),
								jsarr.getJSONObject(i).getString("SubmissionDate"),
								jsarr.getJSONObject(i).getString("ReceivedDate"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),
								jsarr.getJSONObject(i).getString("RejectReason"),
								jsarr.getJSONObject(i).getString("Remarks1"),
								jsarr.getJSONObject(i).getString("Remarks2"),
								jsarr.getJSONObject(i).getString("Fileuuid"),
								jsarr.getJSONObject(i).getString("LandlordId"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),
								jsarr.getJSONObject(i).getString("autoflag"),
								jsarr.getJSONObject(i).getString("GLCode"),
								jsarr.getJSONObject(i).getString("agreementName"),
								jsarr.getJSONObject(i).getString("agreementId"),
								emgTab,isrentalTab,isUsageTab,financeTab,usage_detailsjs,
								this);
						
						containerBodyDiv.add(beanobj);
						beanList.add(beanobj);
						
						
					}
					footerLayout.setVisible(true);
					int pageNumber = pageNo2+1;
					pagenumberLbl.setText(pageNumber+"");
					if(jsarr.length()>=pageSize2) {
						nextBtndiv.setEnabled(true);
					}
					else {
						nextBtndiv.setEnabled(false);
					}
					if(pageNo2==0) {
						prevBtndiv.setEnabled(false);
					}
				//	displayNextRecords();
					btnRowDiv.setVisible(true);
					btnRowDiv.removeAll();
				//	btnRowDiv.add(holdbtn,unholdbtn,approvebtn,rejectBtn,footerLayout);
					btnRowDiv.add(approvebtn,rejectBtn,saveTdsBtn,saveGLCode,footerLayout);
					approvebtn.getStyle().set("margin-left", "auto");
					
				}else {
					nextBtndiv.setEnabled(false);
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				beanList.clear();
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
				int pageNumber = pageNo2+1;
				pagenumberLbl.setText(pageNumber+"");
				nextBtndiv.setEnabled(false);
			}else {}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	
		
	}

	
	private void getRecordsForRentalEmgTab(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		try {
			beanList.clear();
			String resp=getRentalInvoiceRecordsForEmg(pageNo2,pageSize2,retrieveBtnClicked);
		//	System.out.println(resp);
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						JSONObject usage_detailsjs=new JSONObject();
					
					
						InvoiceManagementBean beanobj=new InvoiceManagementBean(
								jsarr.getJSONObject(i).getString("InvoiceId"),
								jsarr.getJSONObject(i).getString("Circle"),
								jsarr.getJSONObject(i).getString("SiteCode"),
								jsarr.getJSONObject(i).getString("SiteName"),
								jsarr.getJSONObject(i).getString("LandlordName"),
								jsarr.getJSONObject(i).getString("SapVendorCode"),
								jsarr.getJSONObject(i).getString("InvoiceDate"),
								jsarr.getJSONObject(i).getString("DueDate"),
								jsarr.getJSONObject(i).getString("Period_StartDate"),
								jsarr.getJSONObject(i).getString("Period_EndDate"),
								jsarr.getJSONObject(i).getString("RentShare"),
								jsarr.getJSONObject(i).getString("SolutionType"),
								jsarr.getJSONObject(i).getString("BillingType"),
								jsarr.getJSONObject(i).getString("BillingCycle"),
								jsarr.getJSONObject(i).getString("RentStatus"),
								jsarr.getJSONObject(i).getString("InvoiceType"),
								jsarr.getJSONObject(i).getString("Status"),
								jsarr.getJSONObject(i).getString("InvoiceNo"),
								jsarr.getJSONObject(i).getString("GrossInvoiceAmount"),
								jsarr.getJSONObject(i).getString("DueOn"),
								jsarr.getJSONObject(i).getString("Gst_Rate"),
								jsarr.getJSONObject(i).getString("InvoiceAmount"),
								jsarr.getJSONObject(i).getString("BillForOperator"),
								jsarr.getJSONObject(i).getString("InvoiceArrears"),
								jsarr.getJSONObject(i).getString("SubmissionDate"),
								jsarr.getJSONObject(i).getString("ReceivedDate"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),
								jsarr.getJSONObject(i).getString("RejectReason"),
								jsarr.getJSONObject(i).getString("Remarks1"),
								jsarr.getJSONObject(i).getString("Remarks2"),
								jsarr.getJSONObject(i).getString("Fileuuid"),
								jsarr.getJSONObject(i).getString("autoflag"),
								jsarr.getJSONObject(i).getString("GLCode"),
								jsarr.getJSONObject(i).getString("agreementName"),
								jsarr.getJSONObject(i).getString("agreementId"),
								emgTab,isrentalTab,isUsageTab,usage_detailsjs,
								this);
						
						containerBodyDiv.add(beanobj);
						beanList.add(beanobj);
						
						
					}
					footerLayout.setVisible(true);
					int pageNumber = pageNo2+1;
					pagenumberLbl.setText(pageNumber+"");
				//	System.out.println("jsarr.length()=="+jsarr.length());
				//	System.out.println("pageSize2=="+pageSize2);
			//		System.out.println("pageNo2=="+pageNo2);
					if(jsarr.length()>=pageSize2) {
						nextBtndiv.setEnabled(true);
					}
					else {
						nextBtndiv.setEnabled(false);
					}
					if(pageNo2==0) {
						prevBtndiv.setEnabled(false);
					}
				//	displayNextRecords();
					btnRowDiv.setVisible(true);
					btnRowDiv.removeAll();
					btnRowDiv.add(holdbtn,unholdbtn,approvebtn,rejectBtn,footerLayout);
					approvebtn.getStyle().set("margin-left", "0px");
					
				}else {
					nextBtndiv.setEnabled(false);
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				beanList.clear();
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
				int pageNumber = pageNo2+1;
				pagenumberLbl.setText(pageNumber+"");
		//		System.out.println("pageSize222=="+pageSize2);
		//		System.out.println("pageNo222=="+pageNo2);
				nextBtndiv.setEnabled(false);
			}else {}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	
		
	}

	
	
	private void getRecordsForUsageEmgTab(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		try {
			beanList.clear();
			String resp=getUsageInvoiceRecordsForEmg(pageNo2,pageSize2,retrieveBtnClicked);
			
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						JSONObject usage_detailsjs=new JSONObject();
						
						usage_detailsjs.put("MeterSerialNo",jsarr.getJSONObject(i).getString("MeterSerialNo"));
						usage_detailsjs.put("ConsumerNo",jsarr.getJSONObject(i).getString("ConsumerNo"));
						usage_detailsjs.put("MeterType",jsarr.getJSONObject(i).getString("MeterType"));
						usage_detailsjs.put("SanctionLoad",jsarr.getJSONObject(i).getString("SanctionLoad"));
						usage_detailsjs.put("NoOfDays",jsarr.getJSONObject(i).getString("NoOfDays"));
						usage_detailsjs.put("OpeningReading",jsarr.getJSONObject(i).getString("OpeningReading"));
						usage_detailsjs.put("ClosingReading",jsarr.getJSONObject(i).getString("ClosingReading"));
						usage_detailsjs.put("CalculatedConsumption",jsarr.getJSONObject(i).getString("CalculatedConsumption"));
						usage_detailsjs.put("ManualConsumption",jsarr.getJSONObject(i).getString("ManualConsumption"));
						usage_detailsjs.put("PerDayConsumption",jsarr.getJSONObject(i).getString("PerDayConsumption"));
						usage_detailsjs.put("EBAmount",jsarr.getJSONObject(i).getString("EBAmount"));
						usage_detailsjs.put("UnitRate",jsarr.getJSONObject(i).getString("UnitRate"));
						usage_detailsjs.put("FixLoadCharge",jsarr.getJSONObject(i).getString("FixLoadCharge"));
						usage_detailsjs.put("DGCharge",jsarr.getJSONObject(i).getString("DGCharge"));
						usage_detailsjs.put("FCUCharge",jsarr.getJSONObject(i).getString("FCUCharge"));
						usage_detailsjs.put("LatePaymentServiceCharge",jsarr.getJSONObject(i).getString("LatePaymentServiceCharge"));
						usage_detailsjs.put("OtherCharges",jsarr.getJSONObject(i).getString("OtherCharges"));
						usage_detailsjs.put("LpscPayable",jsarr.getJSONObject(i).getString("LpscPayable"));
						usage_detailsjs.put("FinalPayableAmount",jsarr.getJSONObject(i).getString("FinalPayableAmount"));
						usage_detailsjs.put("Fileuuid",jsarr.getJSONObject(i).getString("Fileuuid"));
						
						
						
						InvoiceManagementBean beanobj=new InvoiceManagementBean(
								jsarr.getJSONObject(i).getString("InvoiceId"),
								jsarr.getJSONObject(i).getString("Circle"),
								jsarr.getJSONObject(i).getString("SiteCode"),
								jsarr.getJSONObject(i).getString("SiteName"),
								jsarr.getJSONObject(i).getString("LandlordName"),
								jsarr.getJSONObject(i).getString("SapVendorCode"),
								jsarr.getJSONObject(i).getString("InvoiceDate"),
								jsarr.getJSONObject(i).getString("DueDate"),
								jsarr.getJSONObject(i).getString("Period_StartDate"),
								jsarr.getJSONObject(i).getString("Period_EndDate"),
								jsarr.getJSONObject(i).getString("RentShare"),
								jsarr.getJSONObject(i).getString("SolutionType"),
								jsarr.getJSONObject(i).getString("BillingType"),
								jsarr.getJSONObject(i).getString("BillingCycle"),
								jsarr.getJSONObject(i).getString("RentStatus"),
								jsarr.getJSONObject(i).getString("InvoiceType"),
								jsarr.getJSONObject(i).getString("Status"),
								jsarr.getJSONObject(i).getString("InvoiceNo"),
								jsarr.getJSONObject(i).getString("GrossInvoiceAmount"),
								jsarr.getJSONObject(i).getString("DueOn"),
								jsarr.getJSONObject(i).getString("Gst_Rate"),
								jsarr.getJSONObject(i).getString("InvoiceAmount"),
								jsarr.getJSONObject(i).getString("BillForOperator"),
								jsarr.getJSONObject(i).getString("InvoiceArrears"),
								jsarr.getJSONObject(i).getString("SubmissionDate"),
								jsarr.getJSONObject(i).getString("ReceivedDate"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),
								jsarr.getJSONObject(i).getString("RejectReason"),
								jsarr.getJSONObject(i).getString("Remarks1"),
								jsarr.getJSONObject(i).getString("Remarks2"),
								jsarr.getJSONObject(i).getString("Fileuuid"),null,
								jsarr.getJSONObject(i).getString("GLCode"),
								jsarr.getJSONObject(i).getString("agreementName"),
								jsarr.getJSONObject(i).getString("agreementId"),
								emgTab,isrentalTab,isUsageTab,usage_detailsjs,
								this);
						
						containerBodyDiv.add(beanobj);
						beanList.add(beanobj);
						
						
					}
					footerLayout.setVisible(true);
					int pageNumber = pageNo2+1;
					pagenumberLbl.setText(pageNumber+"");
			//		System.out.println("jsarr.length()=="+jsarr.length());
		//			System.out.println("pageSize2=="+pageSize2);
		//			System.out.println("pageNo2=="+pageNo2);
					if(jsarr.length()>=pageSize2) {
						nextBtndiv.setEnabled(true);
					}
					else {
						nextBtndiv.setEnabled(false);
					}
					if(pageNo2==0) {
						prevBtndiv.setEnabled(false);
					}
				//	displayNextRecords();
					btnRowDiv.setVisible(true);
					btnRowDiv.removeAll();
					btnRowDiv.add(holdbtn,unholdbtn,approvebtn,rejectBtn,footerLayout);
					approvebtn.getStyle().set("margin-left", "0px");
					
				}else {
					//System.out.println("jsarr.length()=="+jsarr.length());
					//System.out.println("pageSize2=="+pageSize2);
					nextBtndiv.setEnabled(false);
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				beanList.clear();
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
				int pageNumber = pageNo2+1;
				pagenumberLbl.setText(pageNumber+"");
				nextBtndiv.setEnabled(false);
			}else {}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}



	private void getRecordsForUsageFinanceTab(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		try {
			beanList.clear();
			headerDiv.removeAll();
			headerDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
					rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,
					grossAmtLbl,grossAmtLbl,gst,invoiceAmt,billforOp,invoicearrears,
					billingCycleLbl,statusLbl,fileuidLbl,remarkLbl,tdscomboLbl,
					tdsfieldLbl,glcodeLbl,selectLbl,/*editiconLbl,*/iconLbl);
			
			String resp=getUsageInvoiceRecordsForFinance(pageNo2,pageSize2,retrieveBtnClicked);
			
		
		
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						JSONObject usage_detailsjs=new JSONObject();
						
						usage_detailsjs.put("MeterSerialNo",jsarr.getJSONObject(i).getString("MeterSerialNo"));
						usage_detailsjs.put("ConsumerNo",jsarr.getJSONObject(i).getString("ConsumerNo"));
						usage_detailsjs.put("MeterType",jsarr.getJSONObject(i).getString("MeterType"));
						usage_detailsjs.put("SanctionLoad",jsarr.getJSONObject(i).getString("SanctionLoad"));
						usage_detailsjs.put("NoOfDays",jsarr.getJSONObject(i).getString("NoOfDays"));
						usage_detailsjs.put("OpeningReading",jsarr.getJSONObject(i).getString("OpeningReading"));
						usage_detailsjs.put("ClosingReading",jsarr.getJSONObject(i).getString("ClosingReading"));
						usage_detailsjs.put("CalculatedConsumption",jsarr.getJSONObject(i).getString("CalculatedConsumption"));
						usage_detailsjs.put("ManualConsumption",jsarr.getJSONObject(i).getString("ManualConsumption"));
						usage_detailsjs.put("PerDayConsumption",jsarr.getJSONObject(i).getString("PerDayConsumption"));
						usage_detailsjs.put("EBAmount",jsarr.getJSONObject(i).getString("EBAmount"));
						usage_detailsjs.put("UnitRate",jsarr.getJSONObject(i).getString("UnitRate"));
						usage_detailsjs.put("FixLoadCharge",jsarr.getJSONObject(i).getString("FixLoadCharge"));
						usage_detailsjs.put("DGCharge",jsarr.getJSONObject(i).getString("DGCharge"));
						usage_detailsjs.put("FCUCharge",jsarr.getJSONObject(i).getString("FCUCharge"));
						usage_detailsjs.put("LatePaymentServiceCharge",jsarr.getJSONObject(i).getString("LatePaymentServiceCharge"));
						usage_detailsjs.put("OtherCharges",jsarr.getJSONObject(i).getString("OtherCharges"));
						usage_detailsjs.put("LpscPayable",jsarr.getJSONObject(i).getString("LpscPayable"));
						usage_detailsjs.put("FinalPayableAmount",jsarr.getJSONObject(i).getString("FinalPayableAmount"));
						usage_detailsjs.put("Fileuuid",jsarr.getJSONObject(i).getString("Fileuuid"));
						
					
						InvoiceManagementBean beanobj=new InvoiceManagementBean(
								jsarr.getJSONObject(i).getString("InvoiceId"),
								jsarr.getJSONObject(i).getString("Circle"),
								jsarr.getJSONObject(i).getString("SiteCode"),
								jsarr.getJSONObject(i).getString("SiteName"),
								jsarr.getJSONObject(i).getString("LandlordName"),
								jsarr.getJSONObject(i).getString("SapVendorCode"),
								jsarr.getJSONObject(i).getString("InvoiceDate"),
								jsarr.getJSONObject(i).getString("DueDate"),
								jsarr.getJSONObject(i).getString("Period_StartDate"),
								jsarr.getJSONObject(i).getString("Period_EndDate"),
								jsarr.getJSONObject(i).getString("RentShare"),
								jsarr.getJSONObject(i).getString("SolutionType"),
								jsarr.getJSONObject(i).getString("BillingType"),
								jsarr.getJSONObject(i).getString("BillingCycle"),
								jsarr.getJSONObject(i).getString("RentStatus"),
								jsarr.getJSONObject(i).getString("InvoiceType"),
								jsarr.getJSONObject(i).getString("Status"),
								jsarr.getJSONObject(i).getString("InvoiceNo"),
								jsarr.getJSONObject(i).getString("GrossInvoiceAmount"),
								jsarr.getJSONObject(i).getString("DueOn"),
								jsarr.getJSONObject(i).getString("Gst_Rate"),
								jsarr.getJSONObject(i).getString("InvoiceAmount"),
								jsarr.getJSONObject(i).getString("BillForOperator"),
								jsarr.getJSONObject(i).getString("InvoiceArrears"),
								jsarr.getJSONObject(i).getString("SubmissionDate"),
								jsarr.getJSONObject(i).getString("ReceivedDate"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),
								jsarr.getJSONObject(i).getString("RejectReason"),
								jsarr.getJSONObject(i).getString("Remarks1"),
								jsarr.getJSONObject(i).getString("Remarks2"),
								jsarr.getJSONObject(i).getString("Fileuuid"),
								jsarr.getJSONObject(i).getString("LandlordId"),
								jsarr.getJSONObject(i).getString("Tds_Rate"),null,
								jsarr.getJSONObject(i).getString("GLCode"),
								jsarr.getJSONObject(i).getString("agreementName"),
								jsarr.getJSONObject(i).getString("agreementId"),
								emgTab,isrentalTab,isUsageTab,financeTab,usage_detailsjs,
								this);
						
						containerBodyDiv.add(beanobj);
						beanList.add(beanobj);
						
						
					}
					footerLayout.setVisible(true);
					int pageNumber = pageNo2+1;
					pagenumberLbl.setText(pageNumber+"");
					if(jsarr.length()>=pageSize2) {
						nextBtndiv.setEnabled(true);
					}
					else {
						nextBtndiv.setEnabled(false);
					}
					if(pageNo2==0) {
						prevBtndiv.setEnabled(false);
					}
				//	displayNextRecords();
					btnRowDiv.setVisible(true);
					btnRowDiv.removeAll();
					//btnRowDiv.add(holdbtn,unholdbtn,approvebtn,rejectBtn,footerLayout);
					btnRowDiv.add(approvebtn,rejectBtn,saveTdsBtn,saveGLCode,footerLayout);
					approvebtn.getStyle().set("margin-left", "auto");
					
				}else {
					
					nextBtndiv.setEnabled(false);
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				beanList.clear();
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
				int pageNumber = pageNo2+1;
				pagenumberLbl.setText(pageNumber+"");
				nextBtndiv.setEnabled(false);
			}else {}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	
		
	}
	
	


	protected void approveRecords() {
	
		if((isrentalTab==true || isUsageTab==true) && emgTab==true) {//EMG TAB
			JSONArray jsarr=new JSONArray();
			Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
			while (listIterator.hasNext()) {
				InvoiceManagementBean eachRow = listIterator.next();
				if (eachRow.isChecked() && (eachRow.status().equals("0") || eachRow.status().equals("4"))) {//to be processed & rejected by finance records																				
					JSONObject jsobj=new JSONObject();
					try {
						jsobj.put("invoiceid",eachRow.getInvoiceId());
						jsobj.put("remarks",eachRow.getRemarks());
						jsarr.put(jsobj);
					} catch (JSONException e) {
						e.printStackTrace();
					}
					
				}
			}
		
	//		System.out.println("approve emg jsarr1::::"+jsarr);
		//	System.out.println("isrentalTab && emgTab::::"+isrentalTab+emgTab);
			if (jsarr==null || jsarr.length()<=0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'To be processed' to approve",ApplicationConstants.DialogTypes.INFO);	
				return;
			}
			
			try {
				Form formData = new Form();
				formData.add("invoiceDetails",jsarr.toString());
		
				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("APPROVE_INVOICE_EMG");
				RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"APPROVE_DATA_EMG",ApplicationConstants.DialogTypes.INFO);
				retrieveRecords(emgTab,0,10,false);
				retrieveBtnClicked=false;
				pageNo = 0;
				pageSize = 10;
				filterRecords();
			}catch(Exception e) {
				e.printStackTrace();
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}else if((isrentalTab==true || isUsageTab==true) && emgTab==false) {//FINANCE TAB
			JSONArray jsarr=new JSONArray();
			Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
			while (listIterator.hasNext()) {
				InvoiceManagementBean eachRow = listIterator.next();
				if (eachRow.isChecked() && eachRow.status().equals("3")) {
					
					JSONObject jsobj=new JSONObject();
					try {
						jsobj.put("invoiceid",eachRow.getInvoiceId());
						jsobj.put("remarks",eachRow.getRemarks());
						jsarr.put(jsobj);
					} catch (JSONException e) {
						e.printStackTrace();
					}
					
				}
			}
		
	//		System.out.println("approve finance jsarr2::::"+jsarr);
	//		System.out.println("isrentalTab && emgTab::::"+isrentalTab+emgTab);
			if (jsarr==null || jsarr.length()<=0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'Approved By EMG' to approve",ApplicationConstants.DialogTypes.INFO);	
				return;
			}
			
			try {
				Form formData = new Form();
				formData.add("invoiceDetails",jsarr.toString());
		
				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("APPROVE_INVOICE_FINANCE");
				RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"APPROVE_DATA_FINANCE",ApplicationConstants.DialogTypes.INFO);	
				retrieveRecords(emgTab,0,10,false);
				retrieveBtnClicked=false;
				pageNo = 0;
				pageSize = 10;
				filterRecords();
			}catch(Exception e) {
				e.printStackTrace();
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			
		}else {}
		
		
	}
	
	protected void unholdRecords() {
		JSONArray jsarr=new JSONArray();
		Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			InvoiceManagementBean eachRow = listIterator.next();
			if (eachRow.isChecked() && eachRow.status().equals("1")) {
				
				JSONObject jsobj=new JSONObject();
				try {
					jsobj.put("invoiceid",eachRow.getInvoiceId());
					jsobj.put("remarks",eachRow.getRemarks());
					jsarr.put(jsobj);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				
			}
		}
	
//		System.out.println("jsarr::::"+jsarr);
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'Hold By EMG' to unhold",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("invoiceDetails",jsarr.toString());
	
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UNHOLD_INVOICE");
			RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"UNHOLD_DATA",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(emgTab,0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

		
	}

	protected void holdRecords() {
		JSONArray jsarr=new JSONArray();
		Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			InvoiceManagementBean eachRow = listIterator.next();
			if (eachRow.isChecked() && eachRow.status().equals("0")) {
				
				JSONObject jsobj=new JSONObject();
				try {
					jsobj.put("invoiceid",eachRow.getInvoiceId());
					jsobj.put("remarks",eachRow.getRemarks());
					jsarr.put(jsobj);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				
			}
		}
	
//		System.out.println("jsarr::::"+jsarr);
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'To be processed' to hold",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("invoiceDetails",jsarr.toString());
	
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("HOLD_INVOICE");
			RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"HOLD_DATA",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(emgTab,0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	
		
	}
	protected void updateGLCode() {
		JSONArray jsarr=new JSONArray();
		Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			InvoiceManagementBean eachRow = listIterator.next();
			if (eachRow.isChecked()&& eachRow.status().equals("3") ) {
				
				JSONObject jsobj=new JSONObject();
				try {
	//				System.out.println("eachRow.getGLCode()=="+eachRow.getGLCode());
					if(eachRow.getGLCode()==null || eachRow.getGLCode().length()<=0) {
						eachRow.glcodeComboField.setInvalid(true);
						eachRow.glcodeComboField.setErrorMessage("Please select value");
						eachRow.glcodeComboField.focus();
						return;
					}
					else if(eachRow.getGLCode()!=null) {
						eachRow.glcodeComboField.setInvalid(false);
						eachRow.glcodeComboField.setErrorMessage("");
						jsobj.put("invoiceid", eachRow.getInvoiceId());
						jsobj.put("GLCode", eachRow.getGLCode());
						jsarr.put(jsobj);
					}else {}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		}
	
	//	System.out.println("jsarr::::"+jsarr);
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'Approved By Emg' to update GL Code",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("GLCodeDetails",jsarr.toString());
	
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPDATE_GLCODE_INVOICE");
			RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"UPDATE_GLCODE_INVOICE",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(emgTab,0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	}
	protected void updateTds() {
		JSONArray jsarr=new JSONArray();
		Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			InvoiceManagementBean eachRow = listIterator.next();
			if (eachRow.isChecked()&& eachRow.status().equals("3") ) {
				
				JSONObject jsobj=new JSONObject();
				try {
				//	&& eachRow.tdsApplicable().equalsIgnoreCase("Applicable")
//					jsobj.put("invoiceid",eachRow.getInvoiceId());
//					jsobj.put("Tds_Rate",Double.parseDouble(eachRow.getTds()));
//					jsarr.put(jsobj);
//					System.out.println("eachRow.tdsApplicable()=="+eachRow.tdsApplicable());
					if(eachRow.tdsApplicable()==null) {
						eachRow.getTdsApplicableField().setInvalid(true);
						eachRow.getTdsApplicableField().setErrorMessage("Please select a value");
						eachRow.getTdsApplicableField().focus();
						return;
					}
					if(eachRow.tdsApplicable().equalsIgnoreCase("Applicable") && eachRow.getTds().equalsIgnoreCase("null")) {
						eachRow.tds_percentField.setInvalid(true);
						eachRow.tds_percentField.setErrorMessage("Please Fill this field");
						eachRow.tds_percentField.focus();
						return;
					}
					else if(eachRow.tdsApplicable().equalsIgnoreCase("Applicable") && Double.parseDouble(eachRow.getTds())<=0.0) {
						eachRow.tds_percentField.setInvalid(true);
						eachRow.tds_percentField.setErrorMessage("Value must be greater than 0");
						eachRow.tds_percentField.focus();
						return;
					}
					else if(eachRow.tdsApplicable().equalsIgnoreCase("Applicable") && Double.parseDouble(eachRow.getTds())>0.0) {
						eachRow.tds_percentField.setInvalid(false);
						eachRow.tds_percentField.setErrorMessage("");
						jsobj.put("invoiceid",eachRow.getInvoiceId());
						jsobj.put("Tds_Rate",Double.parseDouble(eachRow.getTds()));
						jsarr.put(jsobj);
					}else if(eachRow.tdsApplicable().equalsIgnoreCase("Not Applicable") && Double.parseDouble(eachRow.getTds())<=0.0) {
						eachRow.tds_percentField.setInvalid(false);
						eachRow.tds_percentField.setErrorMessage("");
						jsobj.put("invoiceid",eachRow.getInvoiceId());
						jsobj.put("Tds_Rate",Double.parseDouble(eachRow.getTds()));
						jsarr.put(jsobj);
					}else {
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		}
	
		System.out.println("jsarr::::"+jsarr);
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'Approved By Emg' to update TDS",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("invoiceDetails",jsarr.toString());
	
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPDATE_INVOICE_FINANCE");
			RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"UPDATE_INVOICE_FINANCE",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(emgTab,0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
	}
	
	protected void rejectRecords() {
		if ((isrentalTab==true || isUsageTab==true) && emgTab == true) {// EMG TAB
			JSONArray jsarr = new JSONArray();
			Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
			while (listIterator.hasNext()) {
				InvoiceManagementBean eachRow = listIterator.next();
				if (eachRow.isChecked() && eachRow.status().equals("0")) {

					JSONObject jsobj = new JSONObject();
					try {
						jsobj.put("invoiceid", eachRow.getInvoiceId());
						jsobj.put("remarks", eachRow.getRemarks());
						jsarr.put(jsobj);
					} catch (JSONException e) {
						e.printStackTrace();
					}

				}
			}

//		System.out.println("reject emg jsarr1::::"+jsarr);
//		System.out.println("isrentalTab && emgTab::::"+isrentalTab+emgTab);
			if (jsarr == null || jsarr.length() <= 0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'To be processed' to reject",ApplicationConstants.DialogTypes.INFO);	
				return;
			}

			try {
				Form formData = new Form();
				formData.add("invoiceDetails", jsarr.toString());

				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("REJECT_INVOICE_EMG");
				RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "REJECT_DATA_EMG",ApplicationConstants.DialogTypes.INFO);
				retrieveRecords(emgTab,0,10,false);
				retrieveBtnClicked=false;
				pageNo = 0;
				pageSize = 10;
				filterRecords();
			} catch (Exception e) {
				e.printStackTrace();
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),ApplicationConstants.DialogTypes.ERROR);
						
			}
		} else if ((isrentalTab==true || isUsageTab==true) && emgTab == false) {// FINANCE TAB
			JSONArray jsarr = new JSONArray();
			Iterator<InvoiceManagementBean> listIterator = beanList.iterator();
			while (listIterator.hasNext()) {
				InvoiceManagementBean eachRow = listIterator.next();
				if (eachRow.isChecked() && eachRow.status().equals("3")) {

					JSONObject jsobj = new JSONObject();
					try {
						jsobj.put("invoiceid", eachRow.getInvoiceId());
						jsobj.put("remarks", eachRow.getRemarks());
						jsarr.put(jsobj);
					} catch (JSONException e) {
						e.printStackTrace();
					}

				}
			}

//			System.out.println("reject finance jsarr2::::"+jsarr);
//			System.out.println("isrentalTab && emgTab::::"+isrentalTab+emgTab);
			if (jsarr == null || jsarr.length() <= 0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'Approved By EMG' to reject",ApplicationConstants.DialogTypes.INFO);	
				return;
			}

			try {
				Form formData = new Form();
				formData.add("invoiceDetails", jsarr.toString());

				
				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("REJECT_INVOICE_FINANCE");
				RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "REJECT_DATA_FINANCE",ApplicationConstants.DialogTypes.INFO);
				retrieveRecords(emgTab,0,10,false);
				retrieveBtnClicked=false;
				pageNo = 0;
				pageSize = 10;
				filterRecords();
			} catch (Exception e) {
				e.printStackTrace();
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),ApplicationConstants.DialogTypes.ERROR);
						
			}
		}else {}

	}
					
	/****GET RENTAL INVOICE API  
	 * @param pageSize2 
	 * @param pageNo2 
	 * @param retrieveBtnClicked ****/
	private String getRentalInvoiceRecordsForEmg(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		
		String resp="",status="";
		String invoicetype="";
		try {
			String startdate="",sitecode="";
			String enddate="";
		//	System.out.println("date="+startDateField.getValue());
			
			if(startDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(startDateField.getValue());
				startdate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(endDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(endDateField.getValue());
				enddate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(siteIdField.getValue().toString().length()>0) {
				sitecode=URLEncoder.encode(siteIdField.getValue().toString());
			}
			
		//	System.out.println("startdate="+startdate);
			if(invoiceStatusField.getValue()!=null) {
				if(statustypemap.containsKey(invoiceStatusField.getValue())) {
					status=statustypemap.get(invoiceStatusField.getValue());
				}else {
					status="";
				}
				
			}
			if(invoiceTypeField.getValue()!=null) {
				if(invoicetypemap.containsKey(invoiceTypeField.getValue())) {
					invoicetype=invoicetypemap.get(invoiceTypeField.getValue());
				}else {
					invoicetype="";
				}
				
			}
			String sapvendorcode="";
			if(sapVendorCode.getValue().length()>0) {
				sapvendorcode=sapVendorCode.getValue();
			}else {
				sapvendorcode="";
			}
			
	//		System.out.println("pageSize="+pageSize);
	//		System.out.println("pageNo="+pageNo);
			String url = ApplicationConfiguration.getServiceEndpoint("GETRENTALINVOICE");
//			url=url+"?SiteCode="+siteIdField.getValue()+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
//					"&InvoiceType="+invoiceIdField.getValue()+
//					"&Status="+invoiceStatusField.getValue()+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+""+"&PageSize="+"1000000";
			if(retrieveBtnClicked) {
				url=url+"?SiteCode="+sitecode+"&LandlordId="+sapvendorcode+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
						"&InvoiceType="+invoicetype+
						"&Status="+status+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNo="+String.valueOf(pageNo2)+"&PageSize="+String.valueOf(pageSize2);
		
			}else {
				url=url+"?SiteCode="+""+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+""+
						"&InvoiceType="+""+
						"&Status="+""+"&StartDate="+""+"&EndDate="+""+"&PageNo="+String.valueOf(pageNo2)+"&PageSize="+String.valueOf(pageSize2);
		
			}
			
			
			System.out.println("url==="+url);
		
			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
	//		System.out.println("resp="+resp);
			
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			
		}
		return resp;
	}
	
					
	
	/****GET_RENTAL_INVOICE_FOR_FINANCE  API 
	 * @param pageSize2 
	 * @param pageNo2 
	 * @param retrieveBtnClicked ****/
	private String getRentalInvoiceRecordsForFinance(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		String resp="",status="";
		String invoicetype="";
		try {
			String startdate="",sitecode="";
			String enddate="";
		//	System.out.println("date="+startDateField.getValue());
			
			if(startDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(startDateField.getValue());
				startdate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(endDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(endDateField.getValue());
				enddate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(siteIdField.getValue().toString().length()>0) {
				sitecode=URLEncoder.encode(siteIdField.getValue().toString());
			}
			if(invoiceStatusField.getValue()!=null) {
				if(statustypemap.containsKey(invoiceStatusField.getValue())) {
					status=statustypemap.get(invoiceStatusField.getValue());
				}else {
					status="";
				}
				
			}
			if(invoiceTypeField.getValue()!=null) {
				if(invoicetypemap.containsKey(invoiceTypeField.getValue())) {
					invoicetype=invoicetypemap.get(invoiceTypeField.getValue());
				}else {
					invoicetype="";
				}
				
			}
			String sapvendorcode="";
			if(sapVendorCode.getValue().length()>0) {
				sapvendorcode=sapVendorCode.getValue();
			}else {
				sapvendorcode="";
			}
			
		//	System.out.println("startdate="+startdate);
		
			String url = ApplicationConfiguration.getServiceEndpoint("GET_RENTAL_INVOICE_FOR_FINANCE");
//			url=url+"?SiteCode="+siteIdField.getValue()+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
//					"&InvoiceType="+invoiceTypeField.getValue()+
//					"&Status="+invoiceStatusField.getValue()+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+""+"&PageSize="+"1000000";
			
			if(retrieveBtnClicked) {
				url=url+"?SiteCode="+sitecode+"&LandlordId="+sapvendorcode+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
						"&InvoiceType="+invoicetype+
						"&Status="+status+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
			}else {
				url=url+"?SiteCode="+""+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+""+
						"&InvoiceType="+""+
						"&Status="+""+"&StartDate="+""+"&EndDate="+""+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
		
			}
			System.out.println("url="+url);
		
			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
	//		System.out.println("resp="+resp);
			
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		return resp;
	}

	
					
	
	
	/****GET_USAGE_INVOICE API  
	 * @param pageSize2 
	 * @param pageNo2 
	 * @param retrieveBtnClicked ****/
	private String getUsageInvoiceRecordsForEmg(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		String resp="",status="";
		String invoicetype="";
		try {
			String startdate="",sitecode="";
			String enddate="";
		
			if(startDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(startDateField.getValue());
				startdate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(endDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(endDateField.getValue());
				enddate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(siteIdField.getValue().toString().length()>0) {
				sitecode=URLEncoder.encode(siteIdField.getValue().toString());
			}
			if(invoiceStatusField.getValue()!=null) {
				if(statustypemap.containsKey(invoiceStatusField.getValue())) {
					status=statustypemap.get(invoiceStatusField.getValue());
				}else {
					status="";
				}
				
			}
			if(invoiceTypeField.getValue()!=null) {
				if(invoicetypemap.containsKey(invoiceTypeField.getValue())) {
					invoicetype=invoicetypemap.get(invoiceTypeField.getValue());
				}else {
					invoicetype="";
				}
				
			}
			String sapvendorcode="";
			if(sapVendorCode.getValue().length()>0) {
				sapvendorcode=sapVendorCode.getValue();
			}else {
				sapvendorcode="";
			}
			
			String url = ApplicationConfiguration.getServiceEndpoint("GET_USAGE_INVOICE");
//			url=url+"?SiteCode="+siteIdField.getValue()+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
//					"&InvoiceType="+invoiceTypeField.getValue()+
//					"&Status="+invoiceStatusField.getValue()+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+""+"&PageSize="+"1000000";
			
			
			System.out.println("retrieveBtnClicked=="+retrieveBtnClicked);
			if(retrieveBtnClicked) {
				url=url+"?SiteCode="+sitecode+"&LandlordId="+sapvendorcode+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
						"&InvoiceType="+invoicetype+
						"&Status="+status+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
			}else {
				url=url+"?SiteCode="+""+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+""+
						"&InvoiceType="+""+
						"&Status="+""+"&StartDate="+""+"&EndDate="+""+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
		
			}
			
			System.out.println("url==="+url);
			
			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
	
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		return resp;
	}
	
	
	/****GET_RENTAL_INVOICE_FOR_FINANCE  API 
	 * @param pageSize2 
	 * @param pageNo2 
	 * @param retrieveBtnClicked ****/
	private String getUsageInvoiceRecordsForFinance(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		String resp="",status="";
		String invoicetype="",sapvendorcode="";
		try {
			String startdate="",sitecode="";
			String enddate="";
		
			if(startDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(startDateField.getValue());
				startdate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(endDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(endDateField.getValue());
				enddate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(siteIdField.getValue().toString().length()>0) {
				sitecode=URLEncoder.encode(siteIdField.getValue().toString());
			}
			if(invoiceStatusField.getValue()!=null) {
				if(statustypemap.containsKey(invoiceStatusField.getValue())) {
					status=statustypemap.get(invoiceStatusField.getValue());
				}else {
					status="";
				}
				
			}
			if(invoiceTypeField.getValue()!=null) {
				if(invoicetypemap.containsKey(invoiceTypeField.getValue())) {
					invoicetype=invoicetypemap.get(invoiceTypeField.getValue());
				}else {
					invoicetype="";
				}
				
			}
			if(sapVendorCode.getValue().length()>0) {
				sapvendorcode=sapVendorCode.getValue();
			}else {
				sapvendorcode="";
			}
			
			String url = ApplicationConfiguration.getServiceEndpoint("GET_USAGE_INVOICE_FOR_FINANCE");
//			url=url+"?SiteCode="+siteIdField.getValue()+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
//					"&InvoiceType="+invoiceTypeField.getValue()+
//					"&Status="+invoiceStatusField.getValue()+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+""+"&PageSize="+"1000000";
			
			if(retrieveBtnClicked) {
				url=url+"?SiteCode="+sitecode+"&LandlordId="+sapvendorcode+"&Circle="+""+"&InvoiceNo="+invoiceNoField.getValue()+
						"&InvoiceType="+invoicetype+
						"&Status="+status+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
			}else {
				url=url+"?SiteCode="+""+"&LandlordId="+""+"&Circle="+""+"&InvoiceNo="+""+
						"&InvoiceType="+""+
						"&Status="+""+"&StartDate="+""+"&EndDate="+""+"&PageNo="+pageNo2+"&PageSize="+pageSize2;
		
			}
			
			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		return resp;
	}

 
 private void createPagination() {
		
		Label pageLabel=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_LBL");
		pageLabel.setText("Page");
		Div pgNumberdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PG_NO_DIV");
		pagenumberLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_NO_LBL");
		pgNumberdiv.add(pagenumberLbl);
		totalcountLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"TOTAL_COUNT_LBL");
		
		Div arrowdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ARROW_DIV");
		nextBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "NEXT_BTN_DIV");
		Icon rightarrowIcon = VaadinIcon.ANGLE_RIGHT.create();
		nextBtndiv.add(rightarrowIcon);
		prevBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PREV_BTN_DIV");
		Icon leftarrowIcon = VaadinIcon.ANGLE_LEFT.create();
		prevBtndiv.add(leftarrowIcon);
		arrowdiv.add(prevBtndiv,nextBtndiv);
		
		leftarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		rightarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		prevBtndiv.setEnabled(false);
		nextBtndiv.setEnabled(false);
		
		footerLayout.add(pageLabel,pgNumberdiv,totalcountLbl,arrowdiv);
		
		
		nextBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
		/*		clickCnt++;
				prevBtndiv.setEnabled(true);
				containerBodyDiv.removeAll();
				pageNo++;
				retrieveRecords(emgTab);
		//		displayNextRecords();
				
				int clickcount=clickCnt+1;
				int startNo = (clickCnt*limit)+1;
				int endNo = (clickCnt+1)*limit;
				if(endNo>totalCnt)
				{
					pagenumberLbl.setText(clickcount+"");
					totalcountLbl.setText(" of "+ pg);
				}
				else
				{
					pagenumberLbl.setText(clickcount+"");
					totalcountLbl.setText(" of "+ pg);
				}
				if(remainingCnt!=0 && clickCnt==quotientCnt) {
					nextBtndiv.setEnabled(false);
				}*/
				prevBtndiv.setEnabled(true);

				pageNo=pageNo+1;
			//	System.out.println("pageNo======"+pageNo);
			//	System.out.println("pageSize2233=="+pageSize2);
			//	System.out.println("pageNo2233=="+pageNo);
				retrieveRecords(emgTab,pageNo,pageSize,retrieveBtnClicked);
			}
		});
		
		prevBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
			/*	clickCnt--;
				nextBtndiv.setEnabled(true);
				
				if(clickCnt==0) {
					prevBtndiv.setEnabled(false);
				}
				containerBodyDiv.removeAll();
				
				retrieveRecords(emgTab);
		//		displayNextRecords();
				
				int clickcount=clickCnt+1;
				int startNo = (clickCnt*limit)+1;
				int endNo = (clickCnt+1)*limit;
		
				pagenumberLbl.setText(clickcount+"");
				totalcountLbl.setText(" of "+ pg);*/
				nextBtndiv.setEnabled(true);
				//pageNo--;
				pageNo=pageNo-1;
				System.out.println("pageNo======"+pageNo);
				retrieveRecords(emgTab,pageNo,pageSize,retrieveBtnClicked);
				if(pageNo==0) {
					prevBtndiv.setEnabled(false);
				}

				
			}
		});
	

		
	}
	
	private void displayNextRecords() {
		containerBodyDiv.removeAll();
				
		int totalCnt = beanList.size();
		remainder=totalCnt%limit;
		numberofpg=totalCnt/limit;
		remainingCnt = totalCnt%limit;
		quotientCnt = totalCnt/limit;
	
		
		
		if(beanList.size()!=0) {
			if(clickCnt!=quotientCnt) {
				for(int i=clickCnt*limit;i<(clickCnt+1)*limit;i++) {
					containerBodyDiv.add(beanList.get(i));
					}
			}
			else {
				for(int j = quotientCnt*limit;j<(quotientCnt*limit)+remainingCnt;j++) {
					containerBodyDiv.add(beanList.get(j));
					
				}
			}
		}

		
		if(remainder==0)
		{
			pg=numberofpg;
		}
		if(remainder!=0)
		{
			pg=numberofpg+1;
		}
		
		int startNo = (clickCnt*limit)+1;
		int endNo = (clickCnt+1)*limit;
		if(endNo>totalCnt) {
			pagenumberLbl.setText(startNo+"");
			totalcountLbl.setText(" of "+ pg);
		}
		else {
			pagenumberLbl.setText(startNo+"");
			totalcountLbl.setText(" of "+ pg);
		}
		
		if(totalCnt>limit) {
			nextBtndiv.setEnabled(true);
		}
		else {
			nextBtndiv.setEnabled(false);
		}
		

	}

	public Label getIconLbl() {
		return iconLbl;
	}
	private void populateInvoiceTypeLists() {
		
		invoicetypemap.clear();
		invoiceTypeList.clear();
		
		
		int count=1,count2=15;
		if(isrentalTab) {
		invoiceTypeList.clear();
		String	str[]= {"Rent","Maintenance","Escalation","Rent+ Space Charges + Conservancy Fee","Space Charges & Conservancy Fee",
					"Space Charges","Waiver","Debit Note","Credit Note","Interest Charges","NFA","SD - License Fee","Others","Advance"};
			for (int i = 0; i < str.length; i++) {
	
				invoicetypemap.put(str[i], String.valueOf(count));
				invoiceTypeList.add(str[i]);
				count++;
			}
			invoiceTypeField.setItems(invoiceTypeList);
		}else {
			invoiceTypeList.clear();
			String	str[]= {"SD-EB","EB-Advance","EB","FCU","DG","EB+FCU","EB+DG","EBFixedCharges"};
			for (int i = 0; i < str.length; i++) {
	
				invoicetypemap.put(str[i], String.valueOf(count2));
				invoiceTypeList.add(str[i]);
				count2++;
			}
			invoiceTypeField.setItems(invoiceTypeList);
		}
		
		
	
				
		
	}
	private void populateStatusLists() {
		
		statustypemap.clear();
		statusList.clear();
		int count=0;
		String str[] = {"To be processed","Hold By EMG","Rejected By EMG","Approved By EMG","Rejected By Finance",
				"Approved By Finance"};
	
				
		for (int i = 0; i < str.length; i++) {
			statustypemap.put(str[i],String.valueOf(count));
			statusList.add(str[i]);
			count++;
		}
		invoiceStatusField.setItems(statusList);
		
	}


}
