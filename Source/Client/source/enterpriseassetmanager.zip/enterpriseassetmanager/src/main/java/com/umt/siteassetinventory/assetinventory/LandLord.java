package com.umt.siteassetinventory.assetinventory;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.Route;

@Route(value = "landlord", layout = MainView.class)
public class LandLord extends BaseStructure implements AfterNavigationObserver{

	private static final long serialVersionUID = 1L;

	@Override
	public void afterNavigation(AfterNavigationEvent event) {
		// TODO Auto-generated method stub
		
	}

	

}
