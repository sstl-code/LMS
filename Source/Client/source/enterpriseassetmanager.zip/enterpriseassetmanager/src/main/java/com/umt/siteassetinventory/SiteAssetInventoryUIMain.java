package com.umt.siteassetinventory;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.bean.UserInfoBean;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.StyleSheet;
import com.vaadin.flow.server.ServiceException;
import com.vaadin.flow.server.SessionDestroyEvent;
import com.vaadin.flow.server.SessionDestroyListener;
import com.vaadin.flow.server.SessionInitEvent;
import com.vaadin.flow.server.SessionInitListener;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinServlet;
import com.vaadin.flow.server.VaadinServletConfiguration;
import com.vaadin.flow.server.VaadinServletRequest;

@SuppressWarnings("deprecation")
@StyleSheet("https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap")
public class SiteAssetInventoryUIMain extends UI {
	private static final long serialVersionUID = 1L;

	protected SiteAssetInventoryUIFramework i_objFramework = null;

	@Override
	protected void init(VaadinRequest vaadinRequest) {
		super.init(vaadinRequest);

		i_objFramework = new SiteAssetInventoryUIFramework();

		UserInfoBean userInfo = SessionManager
				.getUserInfoFromCookie(((VaadinServletRequest) vaadinRequest).getHttpServletRequest());

		if (userInfo != null) {
			i_objFramework.setUserInfo(userInfo);
		} 
		try {
			i_objFramework.setMobileView(vaadinRequest.getHeader("user-agent").contains("Mobile"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public SiteAssetInventoryUIFramework getFramework() {
		return this.i_objFramework;
	}
		
	public String getToken() {
		if(this.i_objFramework != null) {
			return this.i_objFramework.getToken();
		}
		return "";
	}

	@WebServlet(urlPatterns = "/*", name = "SiteAssetInventoryServlet", asyncSupported = true)
	@VaadinServletConfiguration(ui = SiteAssetInventoryUIMain.class, productionMode = false)
	public static class TowerPortalServlet extends VaadinServlet
			implements SessionInitListener, SessionDestroyListener {
		private static final long serialVersionUID = 1L;

		@Override
		public void init(ServletConfig servletConfig) throws ServletException {
			// TODO Auto-generated method stub
			super.init(servletConfig);		
		}

		@Override
		protected void servletInitialized() throws ServletException {
			super.servletInitialized();
			getService().addSessionInitListener(this);
			getService().addSessionDestroyListener(this);
		}

		@Override
		public void sessionInit(SessionInitEvent event) throws ServiceException {
			// Do session start stuff here
		}

		@Override
		public void sessionDestroy(SessionDestroyEvent event) {
			// Do session end stuff here
		}
	}
}
