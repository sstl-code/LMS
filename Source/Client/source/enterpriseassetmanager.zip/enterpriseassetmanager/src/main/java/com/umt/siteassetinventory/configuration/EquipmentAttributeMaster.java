package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/equipment_attribute_master-styles.css")
public class EquipmentAttributeMaster extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENT_ATTRIBUTE_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<EquipmentAttributeMasterDataBean> attributeMasterDataBeanList;
	private ConfigView parent;
	//private Label lbl1, lbl2, lbl3, lbl4, lbl5;
	//private String siteCode;

	public EquipmentAttributeMaster(ConfigView parent) {
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		
		this.parent = parent;

		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		filterFld.setPlaceholder("Filter Equipment Attributes");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		Div eachrowDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV6");

//		for (int i = 0; i < fieldCounts; i++) {
//			Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV");
//			Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL");
//			eachrowDiv.add(lbl);
//			tableHeaderDiv.add(eachrowDiv);
//		}
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);
		Label lbl6 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL6");
		eachrowDiv6.add(lbl6);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5, eachrowDiv6);

		filterDiv.add(filterFld , addBtn);
		
		//AddSiteAssetPopup popup = new AddSiteAssetPopup("Add " + assetParam + " Asset", this, siteAssetsTab, SCREENCD);

		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				addDialog(true);
			}
		});
		
		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				try {
				attributeMasterDataBeanList.stream().filter(new Predicate<EquipmentAttributeMasterDataBean>() {

					@Override
					public boolean test(EquipmentAttributeMasterDataBean t) {
						String filterTxt = filterFld.getValue();
						if (filterTxt == null || filterTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if (StringUtils.containsIgnoreCase(t.getAttributeId()+"", filterTxt)
								|| StringUtils.containsIgnoreCase(t.getAttributeName(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getEquipmentType()+"", filterTxt)
								|| StringUtils.containsIgnoreCase(t.getDataType(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getMandatory(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getDefaultValue(), filterTxt)) {
							t.setVisible(true);
							return true;
						}
						t.setVisible(false);
						return false;
					}
				}).collect(Collectors.toList());
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		filterFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		populateData();
	}
	
	protected void populateData() {
		tableContainerDiv.removeAll();
		attributeMasterDataBeanList = new ArrayList<>();
		String response = getEquipmentAttribute();
//				"[{\"EquipmentAttributeId\":1,\"EquipmentAttribute\":\"Battery\",\"EquipmentAttributeName\":\"Exide Industries\",\"Description\":\"Battery 24V\","
//				+ "\"ServiceType\":\"Active\"},{\"EquipmentAttributeId\":2,\"EquipmentAttribute\":\"Dish Antenna\",\"EquipmentAttributeName\":\"Airtel\",\"Description\":"
//				+ "\"Dish _Antenna_02 added\",\"ServiceType\":\"Passive\"}]";
		try {
			JSONArray ja = new JSONArray(response);
			for (int i = 0; i < ja.length(); i++) {
				JSONObject jo = ja.getJSONObject(i);
				String attributeId = "", attributeName = "", equipmentType = "", dataType="", mandatory="", defaultValue="", flov="";
			
				attributeId = jo.getLong("AttributeId")+""; 
				if (jo.getString("AttributeName")!=null) {
					attributeName = jo.getString("AttributeName");
				} 
				Map<Long, String> equipmentTypeMap = new HashMap<>();
				parent.activeEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					equipmentTypeMap.put(k, parent.activeEquipmentTypeMap.get(k));
				});
				parent.passiveEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					equipmentTypeMap.put(k, parent.passiveEquipmentTypeMap.get(k));
				});
				equipmentType = equipmentTypeMap.get(jo.getLong("EquipmentTypeId"));
				if (jo.getInt("Mandatory")==0) {
					mandatory = "No";
				} else if (jo.getInt("Mandatory")==1) {
					mandatory = "Yes";
				}
				if (jo.getString("DefaultValue")!=null) {
					defaultValue = jo.getString("DefaultValue");
				}
				if (jo.getString("FLOV")!=null) {
					flov = jo.getString("FLOV");
				}
				EquipmentAttributeMasterDataBean bean = new EquipmentAttributeMasterDataBean(attributeId, attributeName, equipmentType, 
						CommonUtils.getAttributeDataTypeCd(jo.getInt("AttributeDatatype")), mandatory, defaultValue, flov, 
						parent.activeEquipmentTypeMap, parent.passiveEquipmentTypeMap, this);
				attributeMasterDataBeanList.add(bean);
				tableContainerDiv.add(bean);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void addDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddOrEditEquipmentAttribute addEquipmentAttribute = new AddOrEditEquipmentAttribute(this, parent.activeEquipmentTypeMap, 
				parent.passiveEquipmentTypeMap);
	}
	
//	public void selectedRowChangeHandler(ConfigBaseDataBean selectedBean) 
//	{
//		for (ConfigBaseDataBean attributeMasterDataBean : attributeMasterDataBeanList) {
//			if (!attributeMasterDataBean.equals(selectedBean)) {
//				attributeMasterDataBean.selectDeselect(true);
//			}
//		}
//	}

	private String getEquipmentAttribute()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTESFORASSETS");
			//System.out.println(url);
			url = url + "?EquipmentTypeId=-1";
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

}
