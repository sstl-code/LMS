package com.umt.siteassetinventory.invoice;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.server.VaadinServletRequest;

public class InvoiceManagementBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "INVOICE_MANAGEMENT_BEAN";
	private Div rowDiv,row2Div;
	private Checkbox selectRow;
	private TextField remarkField,rejectReasonField;
	public NumberField tds_percentField;
	private String invoiceid,Status,siteCode,Sitename,Landlordname,Circle,SapVendorCode,invoiceno,invoiceType,Billingtype,rentStatus,
	invoicedate,Period_StartDate,Period_EndDate,dueDate,grossInvoiceAmount,Billingcycle,statusStr,remarks,landlordid,SubmissionDate,RentShare,
	solutiontype,tdsRate,DueOn,Gst_Rate,ReceivedDate,InvoiceArrears,BillForOperator,InvoiceAmount,Remarks1,Remarks2,glcode; 
	private ComboBox<String> tdsComboField;
	private List<String> tdsList=new ArrayList<String>();
	private String invoiceTypeStr,billingTypeStr;
	public Div usageDetailsDiv,eachrowWrapperDiv;
	private boolean clickevent=false;
	private JSONObject usage_detailsjs;
	private Div urlDiv;
	private Image viewImg;
	private String fileuid;
	boolean isEmgTab,isRentalTab,isUsageTab;
	
	private Label siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
	rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,dueDateLbl,grossAmtLbl,
	billingCycleLbl,statusLbl,remarkLbl,selectLbl,tdscomboLbl,tdsfieldLbl,submissiondateLbl,fileuidLbl,billforOp,invoiceAmt,gst,
	invoicearrears,glcodeLbl;
	
	private Div downarrow_div,editicon_div;
	private com.vaadin.flow.component.icon.Icon offeringSidebarCaretDownicon;
//	protected boolean isChargeVisible = false;
	public boolean isChargeVisible = false;
	private Anchor anchor=new Anchor();
	private String partitionid;
	private com.vaadin.flow.component.icon.Icon editIcon;
	private InvoiceManagement invoiceManagement;
	private String rentalremarks;
	private String invoicegst;
	public ComboBox<String> glcodeComboField;
	private List<String> glcodeList=new ArrayList<String>();
	private String agreementName,agreementId;
	

	public InvoiceManagementBean(String invoiceid, String Circle, String siteCode, String Sitename, String Landlordname,
			String SapVendorCode, String invoicedate, String dueDate, String Period_StartDate, String Period_EndDate, String RentShare,
			String solutiontype, String Billingtype, String Billingcycle, String rentStatus, String invoiceType, String Status,
			String invoiceno,String grossInvoiceAmount,String DueOn,String Gst_Rate,String InvoiceAmount,String BillForOperator,
			String InvoiceArrears,String SubmissionDate,String ReceivedDate,String Tds_Rate,String RejectReason,String Remarks1,
			String Remarks2,String fileuid,String autoflag,String glcode,String agreementName,String agreementId,boolean isEmgTab,boolean isRentalTab,boolean isUsageTab,JSONObject usage_detailsjs,
			InvoiceManagement invoiceManagement) {//EMG TAB
		
		this.invoiceid=invoiceid;
		this.Status=Status;
		this.siteCode=siteCode;
		this.Sitename=Sitename;
		this.Landlordname=Landlordname;
		this.Circle=Circle;
		this.SapVendorCode=SapVendorCode;
		this.invoiceno=invoiceno;
		this.invoiceType=invoiceType;
		this.Billingtype=Billingtype;
//		this.Landlordname=Landlordname;
		this.invoicedate=invoicedate;
		this.Period_StartDate=Period_StartDate;
		this.Period_EndDate=Period_EndDate;
		this.grossInvoiceAmount=grossInvoiceAmount;
		this.Billingcycle=Billingcycle;
		this.SubmissionDate=SubmissionDate;
		this.usage_detailsjs=usage_detailsjs;
		this.isUsageTab=isUsageTab;
		this.isEmgTab=isEmgTab;
		this.isRentalTab=isRentalTab;
		this.fileuid=fileuid;
		this.solutiontype=solutiontype;
		this.dueDate=dueDate;
		this.rentStatus=rentStatus;
		this.RentShare=RentShare;
		this.tdsRate=tdsRate;
		this.Remarks1=Remarks1;
		this.Remarks2=Remarks2;
		this.invoiceManagement=invoiceManagement;
	
		this.DueOn=DueOn;
		this.Gst_Rate=Gst_Rate;
		this.ReceivedDate=ReceivedDate;
		this.InvoiceArrears=InvoiceArrears;
		this.BillForOperator=BillForOperator;
		this.InvoiceAmount=InvoiceAmount;
		this.glcode=glcode;
		this.agreementName=agreementName;
		this.agreementId=agreementId;
		
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
	//	row2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		eachrowWrapperDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_WRAPPER_DIV");
		usageDetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "USAGE_DETAILS_DIV");
	//	usageDetailsDiv = UIHtmlFieldFactory.createDiv("NORMAL_PRODUCT_","CHARGE_VL");
		

		circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		landlordNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDNAME_LBL");
		sapvendorCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAPVENDORCODE_LBL");
		landlordrentsharePercentageLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_RENT_SHARE_PERCENT_LBL");
		solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		billingTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_TYPE_LBL");
		rentStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RENT_STATUS_LBL");
		typeofinvoiceLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_OF_INVOICE_LBL");
		invoiceIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_ID_LBL");
		invoiceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICENO_LBL");
		invoiceDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_DATE_LBL");
		dueDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DUE_DATE_LBL");
		billingCycleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_CYCLE_LBL");
		invoiceStartDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_START_DATE_LBL");
		invoiceEndDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_END_DATE_LBL");
		grossAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "GROSS_AMT_LBL");
		statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		rejectReasonField= UIFieldFactory.createTextField("", true, SCREENCD,"REJECT_REASON_FIELD");
		remarkField= UIFieldFactory.createTextField("", true, SCREENCD,"REMARKS_FIELD");
		selectRow = UIFieldFactory.createCheckbox(false, false, SCREENCD, "SELECT_ROW");
		submissiondateLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "SUMBMISSIONDATE_LBL");
		
		billforOp= UIHtmlFieldFactory.createLabel(SCREENCD, "BILLFOROP_LBL");
		invoiceAmt= UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICEAMT_LBL");
		gst= UIHtmlFieldFactory.createLabel(SCREENCD, "GST_LBL");
		invoicearrears= UIHtmlFieldFactory.createLabel(SCREENCD, "ARREARS_LBL");
		//Label fileuidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILEUID_LBL");
		glcodeLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "GLCODE_COMBO_FIELD");
		glcodeLbl.setText(glcode);
		
		downarrow_div=UIHtmlFieldFactory.createDiv(SCREENCD, "DOWNARROW_DIV");
		
		offeringSidebarCaretDownicon = VaadinIcon.CHEVRON_DOWN_SMALL.create();
		offeringSidebarCaretDownicon.addClassName("INVOICE_MANAGEMENT_BEAN_USAGE_OPEN_CLOSED_ICON");
		downarrow_div.add(offeringSidebarCaretDownicon);
		
		
		editicon_div=UIHtmlFieldFactory.createDiv(SCREENCD, "EDITICON_DIV");
		editIcon = VaadinIcon.PENCIL.create();
		editIcon.addClassName(SCREENCD+"_EDITICON");
		editicon_div.add(editIcon);
		
		
		urlDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "URL_DIV");
		viewImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_ICON");
		anchor = new Anchor("",viewImg);
		anchor.addClassName(SCREENCD+"_URL_DIV");
	//	urlDiv.add(viewImg);
		
		if(fileuid.length()>0) {
			try {
				partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String fileurl=VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
//					+"/RuleServer/files/crestdig0001/InvoiceService/"+fileuid+"/stream";
					+"/RuleServer/files/"+partitionid+"/InvoiceService/"+fileuid+"/stream";
//			String fileurl2="https://172.18.0.11:5030/RuleServer/files/crestdig0001/InvoiceService/bbf699d8-53a2-4187-997d-51bfe71f5019/stream";
			viewImg.setTitle(fileurl);
			anchor = new Anchor(fileurl,viewImg);
			anchor.addClassName(SCREENCD+"_URL_DIV");
			anchor.setTarget("_blank");
			viewImg.getStyle().set("cursor","pointer");
		/*	urlDiv.getStyle().set("cursor","pointer");
			urlDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					openUrl();
					
				}
			});*/
		}else {
//			urlDiv.setEnabled(false);
//			urlDiv.getStyle().set("cursor","no-drop");
			viewImg.setEnabled(false);
			anchor.setEnabled(false);
			viewImg.getStyle().set("cursor","no-drop");
		}
		
		populateInvoiceType(invoiceType);
		populateBillType(Billingtype);
		
		siteIdLbl.setText(siteCode);
		circleLbl.setText(Circle);
		siteNameLbl.setText(Sitename);
		landlordNameLbl.setText(Landlordname);
		sapvendorCodeLbl.setText(SapVendorCode);
		landlordrentsharePercentageLbl.setText(CommonUtils.roundValue(RentShare,2));
		solutionTypeLbl.setText(solutiontype);
		billingTypeLbl.setText(billingTypeStr);
		rentStatusLbl.setText(rentStatus);
	//	typeofinvoiceLbl.setText(invoiceType);
		typeofinvoiceLbl.setText(invoiceTypeStr);
		invoiceIdLbl.setText(invoiceid);
		invoiceNoLbl.setText(invoiceno);
		grossAmtLbl.setText(CommonUtils.roundValue(grossInvoiceAmount,2));
		billingCycleLbl.setText(Billingcycle);
		billforOp.setText(BillForOperator);
		invoiceAmt.setText(CommonUtils.roundValue(InvoiceAmount,2));
	//	gst.setText(CommonUtils.roundValue(Gst_Rate,2));

		if(Gst_Rate.indexOf(".")==2) {
			invoicegst=Gst_Rate.substring(0,2);
			gst.setText(Gst_Rate.substring(0,2));
		}else {
			invoicegst=Gst_Rate.substring(0,1);
			gst.setText(Gst_Rate.substring(0,1));
		}
		invoicearrears.setText(CommonUtils.roundValue(InvoiceArrears,2));
		
	/*	invoiceDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(invoicedate)));
		invoiceStartDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(Period_StartDate)));
		invoiceEndDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(Period_EndDate)));
		dueDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(dueDate)) );
		submissiondateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(SubmissionDate)));*/
		invoiceDateLbl.setText(invoicedate);
		invoiceStartDateLbl.setText(Period_StartDate);
		invoiceEndDateLbl.setText(Period_EndDate);
		dueDateLbl.setText(dueDate);
		submissiondateLbl.setText(SubmissionDate);
	//	statusLbl.setText(Status);
/*		if(isEmgTab) {
			remarks=Remarks1;
			remarkField.setValue(Remarks1);//Emg tab
		}else {
			remarks=Remarks2;
			remarkField.setValue(Remarks2); //Finance tab
		}
*/		
		
		
		usageDetailsDiv.setVisible(false);
		downarrow_div.setVisible(false);
		rowDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
				rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,
				grossAmtLbl,gst,invoiceAmt,billforOp,invoicearrears,
				billingCycleLbl,glcodeLbl,statusLbl,/*urlDiv*/anchor,/*rejectReasonField,*/remarkField,selectRow,editicon_div,downarrow_div);
		
//		add(rowDiv);
		eachrowWrapperDiv.add(rowDiv,usageDetailsDiv);
		add(eachrowWrapperDiv);
		
	
		
	/*	if(Integer.parseInt(Status)==0) {//ar
			statusLbl.setText("To be processed");
		}else if(Integer.parseInt(Status)==1) {
			statusLbl.setText("Approved");
		}else if(Integer.parseInt(Status)==2) {
			statusLbl.setText("Rejected");
		}else if(Integer.parseInt(Status)==3) {
			statusLbl.setText("Approved By EMG");
		}else if(Integer.parseInt(Status)==4) {
			statusLbl.setText("Rejected By Finance");
		}else if(Integer.parseInt(Status)==5) {
			statusLbl.setText("Approved By Finance");
		}
		else {
			statusLbl.setText("-");
		}*/
		
/*		if(Integer.parseInt(Status)==0) {/////ab
			statusLbl.setText("To be processed");
		}else if(Integer.parseInt(Status)==1) {
			statusLbl.setText("Approved By EMG");
		}else if(Integer.parseInt(Status)==2) {
			statusLbl.setText("Hold By EMG");
		}else if(Integer.parseInt(Status)==3) {
			statusLbl.setText("Rejected By Finance");
		}else if(Integer.parseInt(Status)==4) {
			statusLbl.setText("Approved By Finance");
		}else if(Integer.parseInt(Status)==5) {
			statusLbl.setText("Sent to SAP");
		}else if(Integer.parseInt(Status)==6) {
			statusLbl.setText("Payment Record Received");
		}
		else {
			statusLbl.setText("-");
		}
		*/
		if(Integer.parseInt(Status)==0) {//ps
			statusStr="To be processed";
			statusLbl.setText("To be processed");
			selectRow.setEnabled(true);
			
			
			editicon_div.setEnabled(true);
			editIcon.getStyle().set("cursor", "pointer");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==1) {
			statusStr="Hold By EMG";
			statusLbl.setText("Hold By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==2) {
			statusStr="Rejected By EMG";
			statusLbl.setText("Rejected By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==3) {
			statusStr="Approved By EMG";
			statusLbl.setText("Approved By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==4) {
			statusStr="Rejected By Finance";
			statusLbl.setText("Rejected By Finance");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(true);
			editIcon.getStyle().set("cursor", "pointer");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setTitle(Remarks2);
		}else if(Integer.parseInt(Status)==5) {
			statusStr="Approved By Finance";
			statusLbl.setText("Approved By Finance");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
		}
		else if(Integer.parseInt(Status)==6) {
			statusStr="Sent To SAP";
			statusLbl.setText("Sent To SAP");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
			
		}else if(Integer.parseInt(Status)==7) {
			statusStr="Payment Record Received";
			statusLbl.setText("Payment Record Received");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
		}
		else if(Integer.parseInt(Status)==8) {
			statusStr="Cancelled";
			statusLbl.setText("Cancelled");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			remarkField.setEnabled(false);
		}else if(Integer.parseInt(Status)==9) {
			statusStr="Resend";
			statusLbl.setText("Resend");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			remarkField.setEnabled(false);
			
		}
		else {
			statusLbl.setText("-");
		}
		
		if(isRentalTab==true && isUsageTab==false && isEmgTab==true) {//Rental Emg
			usageDetailsDiv.setVisible(false);
			downarrow_div.setVisible(false);
			invoiceManagement.getIconLbl().setVisible(false);
		}else if(isRentalTab==true && isUsageTab==false && isEmgTab==false){//Rental Finance
			usageDetailsDiv.setVisible(false);
			downarrow_div.setVisible(false);
			invoiceManagement.getIconLbl().setVisible(false);
		}else if(isRentalTab==false && isUsageTab==true && isEmgTab==true){//usage Emg
			downarrow_div.setVisible(true);
			invoiceManagement.getIconLbl().setVisible(true);
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			downarrow_div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					rowClickHandler();
				}
			});
			
		}else if(isRentalTab==false && isUsageTab==true && isEmgTab==false){//usage finance

			downarrow_div.setVisible(true);
			invoiceManagement.getIconLbl().setVisible(true);
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			downarrow_div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					rowClickHandler();
				}
			});
			
		}else {}
		
		editicon_div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				editInvoice();
			}
		});
		
		if(autoflag!=null && autoflag.equalsIgnoreCase("1")) {
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
		}
		
	}


	public InvoiceManagementBean(String invoiceid, String Circle, String siteCode, String Sitename, String Landlordname,
			String SapVendorCode, String invoicedate, String dueDate, String Period_StartDate, String Period_EndDate, String RentShare,
			String solutiontype, String Billingtype, String Billingcycle, String rentStatus, String invoiceType, String Status,
			String invoiceno,String grossInvoiceAmount,String DueOn,String Gst_Rate,String InvoiceAmount,String BillForOperator,
			String InvoiceArrears,String SubmissionDate,String ReceivedDate,String Tds_Rate,String RejectReason,String Remarks1,
			String Remarks2,String fileuid,String landlordid,String tdsRate,String autoflag,String glcode,String agreementName,String agreementId,boolean isEmgTab,boolean isRentalTab,boolean isUsageTab,
			boolean isFinanceTab,JSONObject usage_detailsjs,InvoiceManagement invoiceManagement) {//Finance 
		

		this.invoiceid=invoiceid;
		this.Status=Status;
		this.siteCode=siteCode;
		this.Sitename=Sitename;
		this.Landlordname=Landlordname;
		this.Circle=Circle;
		this.SapVendorCode=SapVendorCode;
		this.invoiceno=invoiceno;
		this.invoiceType=invoiceType;
		this.Billingtype=Billingtype;
	//	this.Landlordname=Landlordname;
		this.invoicedate=invoicedate;
		this.Period_StartDate=Period_StartDate;
		this.Period_EndDate=Period_EndDate;
		this.grossInvoiceAmount=grossInvoiceAmount;
		this.Billingcycle=Billingcycle;
		this.landlordid=landlordid;
		this.SubmissionDate=SubmissionDate;
		this.usage_detailsjs=usage_detailsjs;
		this.isUsageTab=isUsageTab;
		this.isEmgTab=isEmgTab;
		this.isRentalTab=isRentalTab;
		this.solutiontype=solutiontype;
		this.dueDate=dueDate;
		this.rentStatus=rentStatus;
		this.RentShare=RentShare;
		this.tdsRate=tdsRate;
		this.Remarks1=Remarks1;
		this.Remarks2=Remarks2;
		this.invoiceManagement=invoiceManagement;
		
		this.DueOn=DueOn;
		this.Gst_Rate=Gst_Rate;
		this.ReceivedDate=ReceivedDate;
		this.InvoiceArrears=InvoiceArrears;
		this.BillForOperator=BillForOperator;
		this.InvoiceAmount=InvoiceAmount;
		this.glcode=glcode;
		this.agreementName=agreementName;
		this.agreementId=agreementId;
		
		addClassName(SCREENCD+"_MAIN_LAYOUT");
	//	rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		eachrowWrapperDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_WRAPPER_DIV");
		usageDetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "USAGE_DETAILS_DIV");
//		usageDetailsDiv = UIHtmlFieldFactory.createDiv("NORMAL_PRODUCT_","CHARGE_VL");
		
		circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		landlordNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDNAME_LBL");
		sapvendorCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAPVENDORCODE_LBL");
		landlordrentsharePercentageLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_RENT_SHARE_PERCENT_LBL");
		solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		billingTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_TYPE_LBL");
		rentStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RENT_STATUS_LBL");
		typeofinvoiceLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_OF_INVOICE_LBL");
		invoiceIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_ID_LBL");
		invoiceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICENO_LBL");
		invoiceDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_DATE_LBL");
		dueDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DUE_DATE_LBL");
		billingCycleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_CYCLE_LBL");
		invoiceStartDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_START_DATE_LBL");
		invoiceEndDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_END_DATE_LBL");
		grossAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "GROSS_AMT_LBL");
		statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		rejectReasonField= UIFieldFactory.createTextField("", false, SCREENCD,"REJECT_REASON_FIELD");
		remarkField= UIFieldFactory.createTextField("", false, SCREENCD,"REMARKS_FIELD");
		selectRow = UIFieldFactory.createCheckbox(false, false, SCREENCD, "SELECT_ROW");
		submissiondateLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "SUMBMISSIONDATE_LBL");
		
		billforOp= UIHtmlFieldFactory.createLabel(SCREENCD, "BILLFOROP_LBL");
		invoiceAmt= UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICEAMT_LBL");
		gst= UIHtmlFieldFactory.createLabel(SCREENCD, "GST_LBL");
		invoicearrears= UIHtmlFieldFactory.createLabel(SCREENCD, "ARREARS_LBL");
		
		downarrow_div=UIHtmlFieldFactory.createDiv(SCREENCD, "DOWNARROW_DIV");
		
		offeringSidebarCaretDownicon = VaadinIcon.CHEVRON_DOWN_SMALL.create();
		offeringSidebarCaretDownicon.addClassName("INVOICE_MANAGEMENT_BEAN_USAGE_OPEN_CLOSED_ICON");
		downarrow_div.add(offeringSidebarCaretDownicon);
		
		editicon_div=UIHtmlFieldFactory.createDiv(SCREENCD, "EDITICON_DIV");
		editIcon = VaadinIcon.PENCIL.create();
		editIcon.addClassName(SCREENCD+"_EDITICON");
		editicon_div.add(editIcon);
		
		urlDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "URL_DIV");
		viewImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_ICON");
	//	urlDiv.add(viewImg);
		anchor = new Anchor("",viewImg);
		anchor.addClassName(SCREENCD+"_URL_DIV");
		
		
		populateTdsLists();
		tdsComboField=UIFieldFactory.createComboBox(tdsList, false, SCREENCD,"TDS_COMBO_FIELD");
		tds_percentField= UIFieldFactory.createNumberField(false, SCREENCD,"TDS_PERCENT_FIELD");
		
		glcodeComboField=UIFieldFactory.createComboBox(glcodeList, false, SCREENCD,"GLCODE_COMBO_FIELD");
		glcodeComboField.setPlaceholder("Select value");
		getGLCodes();
		glcodeComboField.setValue(glcode);
		
		
		glcodeComboField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					glcodeComboField.setInvalid(false);
					glcodeComboField.setErrorMessage("");
				}else {
					glcodeComboField.setInvalid(true);
					glcodeComboField.focus();
					glcodeComboField.setErrorMessage("Please select  value");
				}

			}
		});
		
		tdsComboField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					tdsComboField.setInvalid(false);
					tdsComboField.setErrorMessage("");
					
					tds_percentField.setInvalid(false);
					tds_percentField.setErrorMessage("");
				}else {
					tdsComboField.setInvalid(true);
					tdsComboField.focus();
					tdsComboField.setErrorMessage("Please select  value");
				}

			}
		});
		
		
	//	populateTdsField(landlordid);
/*		if(Double.parseDouble(tdsRate)>0.0) {
			tdsComboField.setValue(tdsList.get(0));
			tds_percentField.setValue(Double.parseDouble(tdsRate));
		}else {
			tdsComboField.setValue(tdsList.get(1));
			populateTdsField(landlordid);
		}*/
		
		if(Double.parseDouble(tdsRate)<=0.0) {
			tdsComboField.setValue(tdsList.get(1));
			tds_percentField.setValue(0.0);
			tds_percentField.setEnabled(false);
		}else if(Double.parseDouble(tdsRate)>0.0) {
			tdsComboField.setValue(tdsList.get(0));
			tds_percentField.setEnabled(true);
			tds_percentField.setValue(Double.parseDouble(tdsRate));
		//	populateTdsField(landlordid);
		}else {
		//	tds_percentField.setValue(Double.parseDouble(tdsRate));
		}

		
	//	populateTdsLists();
	//	populateTdsField(landlordid);
		populateInvoiceType(invoiceType);
		populateBillType(Billingtype);
		
		siteIdLbl.setText(siteCode);
		circleLbl.setText(Circle);
		siteNameLbl.setText(Sitename);
		landlordNameLbl.setText(Landlordname);
		sapvendorCodeLbl.setText(SapVendorCode);
		landlordrentsharePercentageLbl.setText(CommonUtils.roundValue(RentShare,2));
		solutionTypeLbl.setText(solutiontype);
		billingTypeLbl.setText(billingTypeStr);
		rentStatusLbl.setText(rentStatus);
	//	typeofinvoiceLbl.setText(invoiceType);
		typeofinvoiceLbl.setText(invoiceTypeStr);
		invoiceIdLbl.setText(invoiceid);
		invoiceNoLbl.setText(invoiceno);
		grossAmtLbl.setText(CommonUtils.roundValue(grossInvoiceAmount,2));
		billingCycleLbl.setText(Billingcycle);
		billforOp.setText(BillForOperator);
		invoiceAmt.setText(CommonUtils.roundValue(InvoiceAmount,2));
	//	gst.setText(CommonUtils.roundValue(Gst_Rate,2));
	
		if(Gst_Rate.indexOf(".")==2) {
			invoicegst=Gst_Rate.substring(0,2);
			gst.setText(Gst_Rate.substring(0,2));
		}else {
			invoicegst=Gst_Rate.substring(0,1);
			gst.setText(Gst_Rate.substring(0,1));
		}
		invoicearrears.setText(CommonUtils.roundValue(InvoiceArrears,2));
		
		
		/*	invoiceDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(invoicedate)));
		invoiceStartDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(Period_StartDate)));
		invoiceEndDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(Period_EndDate)));
		dueDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(dueDate)) );
		submissiondateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(SubmissionDate)));*/
		invoiceDateLbl.setText(invoicedate);
		invoiceStartDateLbl.setText(Period_StartDate);
		invoiceEndDateLbl.setText(Period_EndDate);
		dueDateLbl.setText(dueDate);
		submissiondateLbl.setText(SubmissionDate);
	//	statusLbl.setText(Status);
		if(isFinanceTab) {
			remarks=Remarks2;
			remarkField.setValue(Remarks2); //Finance tab
		}
		if(fileuid.length()>0) {
			try {
				partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String fileurl=VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
				//	+"/RuleServer/files/crestdig0001/InvoiceService/"+fileuid+"/stream";
					+"/RuleServer/files/"+partitionid+"/InvoiceService/"+fileuid+"/stream";
			viewImg.setTitle(fileurl);
			anchor = new Anchor(fileurl,viewImg);
			anchor.addClassName(SCREENCD+"_URL_DIV");
			anchor.setTarget("_blank");
			viewImg.getStyle().set("cursor","pointer");
		
		/*	urlDiv.getStyle().set("cursor","pointer");
			urlDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					openUrl();
					
				}
			});*/
		}else {
//			urlDiv.setEnabled(false);
//			urlDiv.getStyle().set("cursor","no-drop");
			viewImg.setEnabled(false);
			anchor.setEnabled(false);
			viewImg.getStyle().set("cursor","no-drop");
		}
		tdsComboField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if(value!=null && value.equalsIgnoreCase("Not Applicable"))
				{
					tds_percentField.setEnabled(false);
					tds_percentField.setValue(0.0);
				
				}
				if(value!=null && value.equalsIgnoreCase("Applicable"))
				{
					tds_percentField.setEnabled(true);
					if(Double.parseDouble(tdsRate)<=0.0) {
						populateTdsField(landlordid);
					}else {
						tds_percentField.setValue(Double.parseDouble(tdsRate));
					}
				
				}

			}
		});
		
		
		
		usageDetailsDiv.setVisible(false);
		downarrow_div.setVisible(false);
		row2Div.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
				rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,
				grossAmtLbl,gst,invoiceAmt,billforOp,invoicearrears,
				billingCycleLbl,statusLbl,/*urlDiv*/anchor,/*rejectReasonField,*/remarkField,tdsComboField,tds_percentField,glcodeComboField,
				selectRow,/*editicon_div,*/downarrow_div);
		
	//	add(rowDiv);
		eachrowWrapperDiv.add(row2Div,usageDetailsDiv);
		add(eachrowWrapperDiv);
		
		
		if(Integer.parseInt(Status)==0) {//ps
			statusStr="To be processed";
			statusLbl.setText("To be processed");
			selectRow.setEnabled(true);
			
			
			editicon_div.setEnabled(true);
			editIcon.getStyle().set("cursor", "pointer");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==1) {
			statusStr="Hold By EMG";
			statusLbl.setText("Hold By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==2) {
			statusStr="Rejected By EMG";
			statusLbl.setText("Rejected By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==3) {
			statusStr="Approved By EMG";
			statusLbl.setText("Approved By EMG");
//			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks1;
			remarkField.setValue(Remarks1);
			remarkField.setTitle(Remarks1);
		}else if(Integer.parseInt(Status)==4) {
			statusStr="Rejected By Finance";
			statusLbl.setText("Rejected By Finance");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(true);
			editIcon.getStyle().set("cursor", "pointer");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
		}else if(Integer.parseInt(Status)==5) {
			statusStr="Approved By Finance";
			statusLbl.setText("Approved By Finance");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
		}else if(Integer.parseInt(Status)==6) {
			statusStr="Sent To SAP";
			statusLbl.setText("Sent To SAP");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
			tdsComboField.setEnabled(false);
			tds_percentField.setEnabled(false);
		}else if(Integer.parseInt(Status)==7) {
			statusStr="Payment Record Received";
			statusLbl.setText("Payment Record Received");
			selectRow.setEnabled(false);
			
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
			
			rentalremarks=Remarks2;
			remarkField.setValue(Remarks2);
			remarkField.setEnabled(false);
			remarkField.setTitle(Remarks2);
			tdsComboField.setEnabled(false);
			tds_percentField.setEnabled(false);
		}
		else {
			statusLbl.setText("-");
		}
		
		
		if(isRentalTab==true && isUsageTab==false && isEmgTab==true) {//Rental Emg
			usageDetailsDiv.setVisible(false);
			downarrow_div.setVisible(false);
			invoiceManagement.getIconLbl().setVisible(false);
		}else if(isRentalTab==true && isUsageTab==false && isEmgTab==false){//Rental Finance
			usageDetailsDiv.setVisible(false);
			downarrow_div.setVisible(false);
			invoiceManagement.getIconLbl().setVisible(false);
		}else if(isRentalTab==false && isUsageTab==true && isEmgTab==true){//usage Emg
//			rowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
//				private static final long serialVersionUID = 1L;
//
//				@Override
//				public void onComponentEvent(ClickEvent<Div> event) {
//					rowClickHandler();
//				}
//			});
			downarrow_div.setVisible(true);
			invoiceManagement.getIconLbl().setVisible(true);
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			downarrow_div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					rowClickHandler();
				}
			});
			
		}else if(isRentalTab==false && isUsageTab==true && isEmgTab==false){//usage finance
//			rowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
//				private static final long serialVersionUID = 1L;
//
//				@Override
//				public void onComponentEvent(ClickEvent<Div> event) {
//					rowClickHandler();
//				}
//			});
			downarrow_div.setVisible(true);
			invoiceManagement.getIconLbl().setVisible(true);
			landlordrentsharePercentageLbl.getStyle().set("display","none");
			rentStatusLbl.getStyle().set("display","none");
			downarrow_div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					rowClickHandler();
				}
			});
			
		}else {}
		
		if(autoflag!=null && autoflag.equalsIgnoreCase("1")) {
			editicon_div.setEnabled(false);
			editIcon.getStyle().set("cursor", "no-drop");
		}

	}
	
	private void populateBillType(String billingtype2) {
		switch(billingtype2){    
		case "1":    
			billingTypeStr="Agreement Based";
		 break; 
		case "2":    
			billingTypeStr="Invoice Based";
		 break; 
		case "3":    
			billingTypeStr="NFA Based";
		 break; 
		case "4":    
			billingTypeStr="Galaxy Based";
		 break; 
		default:     
			  break;
			}    
		
	}


	private void populateInvoiceType(String invoiceType) {
		
		switch(invoiceType){    
		case "1":    
			invoiceTypeStr="Rent";
		 break;  
		case "2":  
			invoiceTypeStr="Maintenance";
		 break;  
		case "3":  
			invoiceTypeStr="Escalation";
		 break;  
		case "4":  
			invoiceTypeStr="Rent+ Space Charges + Conservancy Fee";
		 break; 
		case "5":  
			invoiceTypeStr="Space Charges & Conservancy Fee";
		 break; 
		case "6":  
			invoiceTypeStr="Space Charges";
		 break; 
		case "7":  
			invoiceTypeStr="Waiver";
		 break; 
		case "8":  
			invoiceTypeStr="Debit Note";
		 break; 
		case "9":  
			invoiceTypeStr="Credit Note";
		 break; 
		case "10":  
			invoiceTypeStr="Interest Charges";
		 break; 
		case "11":  
			invoiceTypeStr="NFA";
		 break; 
		case "12":  
			invoiceTypeStr="SD - License Fee";
		 break; 
		case "13":  
			invoiceTypeStr="Others";
		 break; 
		case "14":  
			invoiceTypeStr="Advance";
		 break; 
		
		case "15":  
			invoiceTypeStr="SD-EB";
		 break; 
		case "16":  
			invoiceTypeStr="EB-Advance";
		 break; 
		case "17":  
			invoiceTypeStr="EB";
		 break; 
		case "18":  
			invoiceTypeStr="FCU";
		 break; 
		case "19":  
			invoiceTypeStr="DG";
		 break; 
		case "20":  
			invoiceTypeStr="EB+FCU";
		 break; 
		case "21":  
			invoiceTypeStr="EB+DG";
		 break; 
		 
		case "22":  
			invoiceTypeStr="EBFixedCharges";
		 break; 
		 
		    
		default:     
		  break;
		}    
		
	}

	private void rowClickHandler() {
		try {

	/*		usageDetailsDiv.setVisible(true);
			usageDetailsDiv.removeAll();
			row2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			eachrowWrapperDiv.replace(rowDiv,row2Div);
	
			
			if(isRentalTab==false && isUsageTab==true && isEmgTab==true){//usage Emg
				row2Div.getStyle().set("cursor","pointer");
				row2Div.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
						rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,grossAmtLbl,
						billingCycleLbl,statusLbl,urlDiv,remarkField,selectRow);
				
			}else if(isRentalTab==false && isUsageTab==true && isEmgTab==false){//usage finance
				row2Div.getStyle().set("cursor","pointer");
				row2Div.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
						rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,grossAmtLbl,
						billingCycleLbl,statusLbl,urlDiv,remarkField,tdsComboField,tds_percentField,selectRow);
				populateTdsLists();
			}*/
			usageDetailsDiv.removeAll();
			if(isChargeVisible)
			{
				offeringSidebarCaretDownicon.getStyle().set("transform", "rotate(0deg)");
				usageDetailsDiv.removeClassName("INVOICE_MANAGEMENT_BEAN_USAGE_DETAILS_DIV_SLIDE_DOWN");
				usageDetailsDiv.addClassName("INVOICE_MANAGEMENT_BEAN_USAGE_DETAILS_DIV_SLIDE_UP");
				usageDetailsDiv.setVisible(false);
				isChargeVisible = false;
			}
			else
			{
				offeringSidebarCaretDownicon.getStyle().set("transform", "rotate(180deg)");
				usageDetailsDiv.removeClassName("INVOICE_MANAGEMENT_BEAN_USAGE_DETAILS_DIV_SLIDE_UP");
				usageDetailsDiv.addClassName("INVOICE_MANAGEMENT_BEAN_USAGE_DETAILS_DIV_SLIDE_DOWN");
				usageDetailsDiv.setVisible(true);
				isChargeVisible = true;
			}
	
			
			if(usage_detailsjs!=null && usage_detailsjs.length()>0) {
				
				
				Label meterserialnoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MTERNO_LBL");
				Label consumernoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMERNO_LBL");
				Label metertypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "METERTYPE_LBL");
				Label sanctionloadLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SANCTIONLOAD_LBL");
				Label noofdaysLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NOOFDAYS_LBL");
				Label opening_readingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "OPENINGREADING_LBL");
				Label closing_readingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CLOSINGREADING_LBL");
				Label calculated_consumptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CALCULATEDCONSUMPTION_LBL");
				Label manual_consumptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MANUALCONSUMPTION_LBL");
				Label per_day_consumptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PERDAYCONSUMPTION_LBL");
				Label eb_amountLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EBAMT_LBL");
				Label unit_rateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "UNITRATE_LBL");
				Label fix_load_chargeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FIXLOAD_LBL");
				Label dg_chargeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DG_LBL");
				Label fcu_chargeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FCU_LBL");
				Label late_payment_service_chargeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LPSCCHARGE_LBL");
				Label otherchargesLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "OTHERCHARGE_LBL");
				Label lpsc_payableLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LPSCPAY_LBL");
				Label final_payable_amountLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FINALAMT_LBL");
				Label fileuidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILEUID_LBL");


				Label meterserialnoLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "MTERNO_LBL1");
				Label consumernoLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMERNO_LBL1");
				Label metertypeLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "METERTYPE_LBL1");
				Label sanctionloadLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "SANCTIONLOAD_LBL1");
				Label noofdaysLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "NOOFDAYS_LBL1");
				Label opening_readingLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "OPENINGREADING_LBL1");
				Label closing_readingLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "CLOSINGREADING_LBL1");
				Label calculated_consumptionLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "CALCULATEDCONSUMPTION_LBL1");
				Label manual_consumptionLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "MANUALCONSUMPTION_LBL1");
				Label per_day_consumptionLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "PERDAYCONSUMPTION_LBL1");
				Label eb_amountLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "EBAMT_LBL1");
				Label unit_rateLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "UNITRATE_LBL1");
				Label fix_load_chargeLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "FIXLOAD_LBL1");
				Label dg_chargeLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "DG_LBL1");
				Label fcu_chargeLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "FCU_LBL1");
				Label late_payment_service_chargeLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LPSCCHARGE_LBL1");
				Label otherchargesLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "OTHERCHARGE_LBL1");
				Label lpsc_payableLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LPSCPAY_LBL1");
				Label final_payable_amountLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "FINALAMT_LBL1");
				Label fileuidLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "FILEUID_LBL1");
				
				
				

				meterserialnoLbl1.setText(usage_detailsjs.getString("MeterSerialNo"));
				consumernoLbl1.setText(usage_detailsjs.getString("ConsumerNo"));
			//	metertypeLbl1.setText(usage_detailsjs.getString("MeterType"));
				sanctionloadLbl1.setText(usage_detailsjs.getString("SanctionLoad"));
				noofdaysLbl1.setText(usage_detailsjs.getString("NoOfDays"));
				opening_readingLbl1.setText(usage_detailsjs.getString("OpeningReading"));
				closing_readingLbl1.setText(usage_detailsjs.getString("ClosingReading"));
				calculated_consumptionLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("CalculatedConsumption"),2));
				manual_consumptionLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("ManualConsumption"),2));
				per_day_consumptionLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("PerDayConsumption"),2));
				eb_amountLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("EBAmount"),2));
				unit_rateLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("UnitRate"),2));
				fix_load_chargeLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("FixLoadCharge"),2));
				dg_chargeLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("DGCharge"),2));
				fcu_chargeLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("FCUCharge"),2));
				late_payment_service_chargeLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("LatePaymentServiceCharge"),2));
				otherchargesLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("OtherCharges"),2));
			//	lpsc_payableLbl1.setText(usage_detailsjs.getString("LpscPayable"));
				final_payable_amountLbl1.setText(CommonUtils.roundValue(usage_detailsjs.getString("FinalPayableAmount"),2));
				fileuid=usage_detailsjs.getString("Fileuuid");
				
				if(usage_detailsjs.getString("LpscPayable").equals("1")) {
					lpsc_payableLbl1.setText("Yes");
				}else {
					lpsc_payableLbl1.setText("No");
				}
				
				
				if(usage_detailsjs.getString("MeterType").equalsIgnoreCase("1")) {
					metertypeLbl1.setText("SEB Meter");
				}else if(usage_detailsjs.getString("MeterType").equalsIgnoreCase("2")) {
					metertypeLbl1.setText("Sub Meter");
				}else if(usage_detailsjs.getString("MeterType").equalsIgnoreCase("3")) {
					metertypeLbl1.setText("Prepaid Meter");
				}else if(usage_detailsjs.getString("MeterType").equalsIgnoreCase("4")) {
					metertypeLbl1.setText("SEB Prepaid Meter");
				}else {}
				
				urlDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "URL_DIV");
				viewImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_ICON");
				urlDiv.add(viewImg);
				
				

				Div col1 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col2 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col3 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col4 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col5 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col6 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col7 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col8 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col9 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col10 = UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col11= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col12= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col13= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col14= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col15= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col16= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col17= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col18= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col19= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				Div col20= UIHtmlFieldFactory.createDiv(SCREENCD, "COL_DIV");
				
				col1.add(meterserialnoLbl,meterserialnoLbl1);
				col2.add(consumernoLbl,consumernoLbl1);
				col3.add(metertypeLbl,metertypeLbl1);
				col4.add(sanctionloadLbl,sanctionloadLbl1);
				col5.add(noofdaysLbl,noofdaysLbl1);
				col6.add(opening_readingLbl,opening_readingLbl1);
				col7.add(closing_readingLbl,closing_readingLbl1);
				col8.add(calculated_consumptionLbl,calculated_consumptionLbl1);
				col9.add(manual_consumptionLbl,manual_consumptionLbl1);
				col10.add(per_day_consumptionLbl,per_day_consumptionLbl1);
				col11.add(eb_amountLbl,eb_amountLbl1);
				col12.add(unit_rateLbl,unit_rateLbl1);
				col13.add(fix_load_chargeLbl,fix_load_chargeLbl1);
				col14.add(dg_chargeLbl,dg_chargeLbl1);
				col15.add(fcu_chargeLbl,fcu_chargeLbl1);
				col16.add(late_payment_service_chargeLbl,late_payment_service_chargeLbl1);
				col17.add(otherchargesLbl,otherchargesLbl1);
				col18.add(lpsc_payableLbl,lpsc_payableLbl1);
				col19.add(final_payable_amountLbl,final_payable_amountLbl1);
			//	col20.add(fileuidLbl,urlDiv);
				
				
				Div rowDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROWDIV");
				Div rowDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROWDIV");
				rowDiv1.add(col1,col2,col3,col4,col5,col6,col7,col8,col9,col10);
				rowDiv2.add(col11,col12,col13,col14,col15,col16,col17,col18,col19/*,col20*/);
			
				usageDetailsDiv.add(rowDiv1,rowDiv2);
				
		/*		row2Div.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Div> event) {
						usageDetailsDiv.setVisible(false);
						eachrowWrapperDiv.replace(row2Div,rowDiv);
						rowDiv.removeAll();
						if(isRentalTab==false && isUsageTab==true && isEmgTab==true){//usage Emg
							rowDiv.getStyle().set("cursor","pointer");
							rowDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
									rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,grossAmtLbl,
									billingCycleLbl,statusLbl,urlDiv,remarkField,selectRow);
							
						}else if(isRentalTab==false && isUsageTab==true && isEmgTab==false){//usage finance
							rowDiv.getStyle().set("cursor","pointer");
							rowDiv.add(siteIdLbl,circleLbl,siteNameLbl,landlordNameLbl,sapvendorCodeLbl,landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
									rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,submissiondateLbl,dueDateLbl,grossAmtLbl,
									billingCycleLbl,statusLbl,urlDiv,remarkField,tdsComboField,tds_percentField,selectRow);
							populateTdsLists();
						}
					}
				});*/
				
				
			
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	protected void editInvoice() {
		try {
			
			AddInvoiceDialog dlg =new AddInvoiceDialog(isRentalTab,isUsageTab,isEmgTab,"edit");
			dlg.setDataFieldsValue(invoiceid,siteCode,Sitename,Circle,Landlordname,Billingcycle,rentStatus,dueDate,invoiceno,Billingtype,RentShare,
					invoiceType,invoicedate,Period_StartDate,Period_EndDate,grossInvoiceAmount,SubmissionDate,solutiontype,SapVendorCode,
					Status,DueOn,invoicegst,ReceivedDate,InvoiceArrears,BillForOperator,rentalremarks,
					InvoiceAmount,usage_detailsjs,agreementName,agreementId);
		
			dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
					AddInvoiceDialog srcDlg = (AddInvoiceDialog)event.getSource();
					if(!srcDlg.isOpened() && srcDlg.success) {	
						invoiceManagement.retrieveRecords(isEmgTab,0,10,false);
						invoiceManagement.filterRecords();
					}
				}

			});
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	protected void openUrl() {
		try
		{
/*			String fileurl=VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
				//	+ "/" + VaadinServletRequest.getCurrent().getContextPath()
					+"/RuleServer/files/crestdig0001/InvoiceService/"+fileuid+"/stream";
			System.out.println("fileurl="+fileurl);
			
			String fileurl2="https://172.18.0.11:5030/RuleServer/files/crestdig0001/InvoiceService/d922fb04-9b3d-4dad-a87e-1de535d5a024/stream";
			
			String url = VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
				//	+ "/" + VaadinServletRequest.getCurrent().getContextPath()
					+  VaadinServletRequest.getCurrent().getContextPath()
					+ "/ViewDocument";
			url = url + "?imgUrl=" +fileurl;
			System.out.println("url="+url);
			UI.getCurrent().getPage().open(url);*/
		}catch (Exception e) {
			e.printStackTrace();
			
	    }
		
	}

	private void populateTdsLists() {
		tdsList=new ArrayList<String>();
		
		String str[] = {"Applicable","Not Applicable"};
				
		for (int i = 0; i < str.length; i++) {
			tdsList.add(str[i]);
		
		}
		
	//	tdsComboField.setItems(tdsList);
	//	tdsComboField.setValue(tdsList.get(0));
	}
	
	protected void populateTdsField(String LandlordId) {
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETLANDLORDATTRIBUTES");
			url = url + "?LandlordId=" + LandlordId;
			System.out.println("LandlordId===="+LandlordId);
			String res = RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			if (res != null && res.trim().length() > 0) {
				System.out.println("res===="+res);
				JSONObject js=new JSONObject(res);
				if (js.length() > 0) {
					String otherinfo=js.getString("OtherInfo");
					if(otherinfo!=null || otherinfo.length()>0) {
						JSONObject js1=new JSONObject(otherinfo);
						if(js1.length()>0) {
							if(js1.has("TDS") && js1.getString("TDS").length()>0) {
								tds_percentField.setValue(Double.parseDouble(js1.getString("TDS")));
								tds_percentField.setEnabled(true);
								tdsComboField.setValue("Applicable");
							}else {
								//tds_percentField.setValue(Double.parseDouble(tdsRate));
								tds_percentField.setValue(0.0);
							//	tds_percentField.setEnabled(false);
							//	tdsComboField.setValue("Not Applicable");
							}
						}
					}
					
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
/*	public boolean isChecked() {
		return selectRow.getValue();
	}

	public int getInvoiceId() {
		return Integer.parseInt(invoiceid);
	}

	public String status() {
		return Status;
		
	}

	public String getRemarks() {
		return remarkField.getValue().toString();
	}

	public Div getRowDiv() {
		if(isEmgTab) {
			System.out.println("inside");
			return rowDiv;
		}else {
			System.out.println("inside2");
			return row2Div;
		}
		
	}



	public String getSiteName() {
		return Sitename;
	}

	public String getSiteId() {
		System.out.println(siteCode);
		return siteCode;
	}

	public String getCircle() {
		return Circle;
	}

	public String getsapvendorcode() {
		return SapVendorCode;
	}

	public String getInvoiceNo() {
		return invoiceno;
	}

	public String getInvoicetype() {
		return invoiceTypeStr;
	}

	public String getbillType() {
		return billingTypeStr;
	}

	public String getrentStatus() {
		System.out.println(rentStatus);
		return rentStatus;
	}

	public String getLandlordName() {
		// TODO Auto-generated method stub
		return Landlordname;
	}

	public String getInvoiceDate() {
		// TODO Auto-generated method stub
		return invoicedate;
	}

	public String getInvoiceStartDate() {
		// TODO Auto-generated method stub
		return Period_StartDate;
	}

	public String getInvoiceEndDate() {
		// TODO Auto-generated method stub
		return Period_EndDate;
	}

	public String getdueDate() {
		// TODO Auto-generated method stub
		return dueDate;
	}

	public String getgrossAmt() {
		// TODO Auto-generated method stub
		return grossInvoiceAmount;
	}

	public String getBillingCycle() {
		// TODO Auto-generated method stub
		return Billingcycle;
	}

	public String getstatus() {
		// TODO Auto-generated method stub
		return statusStr;
	}

	public String getremarks() {
		// TODO Auto-generated method stub
		return remarks;
	}
	public String getSubmissionDate() {
		return SubmissionDate;
	}


	public String getTds() {
		// TODO Auto-generated method stub
		return String.valueOf(tds_percentField.getValue());
	}


	public String getSolutionType() {
		return solutiontype;
	}


	public String getRentShare() {
		// TODO Auto-generated method stub
		return RentShare;
	}


	public String tdsApplicable() {
		// TODO Auto-generated method stub
		return tdsComboField.getValue();
	}


	public String getGstRate() {
		// TODO Auto-generated method stub
		return Gst_Rate;
	}


	public String getInvoiceAmt() {
		// TODO Auto-generated method stub
		return InvoiceAmount;
	}


	public String getBillForOp() {
		// TODO Auto-generated method stub
		return BillForOperator;
	}


	public String getArrears() {
		// TODO Auto-generated method stub
		return InvoiceArrears;
	}
	*/
	
	public boolean isChecked() {
		return selectRow.getValue();
	}

	public int getInvoiceId() {
		return Integer.parseInt(invoiceid);
	}

	public String status() {
		return Status;
		
	}

	public String getRemarks() {
		return remarkField.getValue().toString();
	}

	public Div getRowDiv() {
		if(isEmgTab) {
			return rowDiv;
		}else {
			return row2Div;
		}
	}

	public String getSiteName() {
		return Sitename;
	}

	public String getSiteId() {
		return siteCode;
	}

	public String getCircle() {
		return Circle;
	}

	public String getsapvendorcode() {
		return SapVendorCode;
	}

	public String getInvoiceNo() {
		return invoiceno;
	}

	public String getInvoicetype() {
		return invoiceTypeStr;
	}

	public String getbillType() {
		return billingTypeStr;
	}

	public String getrentStatus() {
		return rentStatus;
	}

	public String getLandlordName() {
		// TODO Auto-generated method stub
		return Landlordname;
	}

	public String getInvoiceDate() {
		// TODO Auto-generated method stub
		return invoicedate;
	}

	public String getInvoiceStartDate() {
		// TODO Auto-generated method stub
		return Period_StartDate;
	}

	public String getInvoiceEndDate() {
		// TODO Auto-generated method stub
		return Period_EndDate;
	}

	public String getdueDate() {
		// TODO Auto-generated method stub
		return dueDate;
	}

	public String getgrossAmt() {
		// TODO Auto-generated method stub
		return CommonUtils.roundValue(grossInvoiceAmount,2);
	}

	public String getBillingCycle() {
		// TODO Auto-generated method stub
		return Billingcycle;
	}

	public String getstatus() {
		// TODO Auto-generated method stub
		return statusStr;
	}

	public String getremarks() {
//		if(isEmgTab) {
//			return Remarks1;
//		}else {
//			return Remarks2;
//		}
		
		return rentalremarks;
		
	}
	public String getSubmissionDate() {
		return SubmissionDate;
	}


	public String getTds() {
		// TODO Auto-generated method stub
	//	System.out.println("tds_percentField.getValue()=="+String.valueOf(tds_percentField.getValue()));
		String tds="";
		if(tds_percentField.getValue()==null) {
			 tds="null";
		}else {
			tds= String.valueOf(tds_percentField.getValue());
		}
		
		return tds;
		
	}


	public String getSolutionType() {
		return solutiontype;
	}


	public String getRentShare() {
		return CommonUtils.roundValue(RentShare,2);
	}


	public String tdsApplicable() {
		// TODO Auto-generated method stub
		return tdsComboField.getValue();
	}


	public String getGstRate() {
		//return CommonUtils.roundValue(Gst_Rate,2);
		return invoicegst;
	}


	public String getInvoiceAmt() {
		// TODO Auto-generated method stub
		return CommonUtils.roundValue(InvoiceAmount,2);
	}


	public String getBillForOp() {
		// TODO Auto-generated method stub
		return BillForOperator;
	}


	public String getArrears() {
		// TODO Auto-generated method stub
		return CommonUtils.roundValue(InvoiceArrears,2);
	}
	
	private void getGLCodes()
	{
		glcodeList.clear();
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETGLCODE");
			//System.out.println(url);
			String resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
		//	System.out.println(url + " response ::::::: "+resp);
			
			if(resp!=null || resp.length()>0) {
				JSONArray ja = new JSONArray(resp);
				if(ja.length()>0) {
					for (int i = 0; i < ja.length(); i++) {
						JSONObject jo = ja.getJSONObject(i);
						glcodeList.add(jo.getString("GLCode"));
					}
					glcodeComboField.setItems(glcodeList);
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			
		}		
	}


	public String getGLCode() {
		return glcodeComboField.getValue();
	}
	public String getGLcodes() {
		return glcode;
	}
	public String getTdsFieldValue() {
		String tds="";
		if(!isEmgTab) {
			tds=tdsRate;
		}else {
			tds="none";
		}
		return tds;
	}
	public String getTdsApplicable() {
		String tds="";
		if(!isEmgTab) {
			tds=tdsComboField.getValue();
		}else {
			tds="none";
		}
		return tds;
	}
	
	public ComboBox<String> getTdsApplicableField() {
		return tdsComboField;
	}
	
	

}
