package com.umt.siteassetinventory.configuration;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditStorePopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditStore addOrEditStore;
	private String screencd;
	private boolean dataSaved;
	private StoreMaster viewStoreMaster;
	private boolean addOrEdit;


	public AddOrEditStorePopup(String title, boolean addOrEdit, Component component, StoreMaster master, String screencd) {

		super(title, component);
		setWidth("500px");
		//System.out.println(title);
		this.addOrEditStore = (AddOrEditStore) component;
		this.viewStoreMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditStore.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDSTORE");
					JSONObject storeInfoJson = new JSONObject();
					storeInfoJson.put("Name", addOrEditStore.getStoreName());
					storeInfoJson.put("Address", addOrEditStore.getAddress());

					Form formData = new Form();
					formData.add("StoreInfo", storeInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "STORE_SAVE_SUCCESSFUL");	
				}
				else
				{
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATESTORE");

					JSONObject storeInfoJson = new JSONObject();
					storeInfoJson.put("Name", addOrEditStore.getStoreName());
					storeInfoJson.put("Address", addOrEditStore.getAddress());
					storeInfoJson.put("Status", CommonUtils.getStatus(addOrEditStore.getStatus()));

					Form formData = new Form();
					formData.add("StoreInfo", storeInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "STORE_UPDATE_SUCCESSFUL");	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewStoreMaster.populateData();
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
