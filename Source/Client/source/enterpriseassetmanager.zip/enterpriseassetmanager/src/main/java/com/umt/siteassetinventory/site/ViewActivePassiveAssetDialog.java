package com.umt.siteassetinventory.site;

import java.net.URLEncoder;

import org.codehaus.jettison.json.JSONArray;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/view-active-passive-asset-dialog-styles.css")
public class ViewActivePassiveAssetDialog extends Dialog{

	private static final long serialVersionUID = 1L;
	private static String SCREENCD = "VIEW_ACTIVE_PASSIVE_ASSET_DIALOG";
	private Div mainLayout;
	private Div titleBar;
	private Div buttonBar;
	private Div bodyLayout,activeDiv,passiveDiv;
	private String sitecode;
	private JSONArray activAssetarr,passiveAssetarr;

	public ViewActivePassiveAssetDialog(String sitecode) {
		this.sitecode=sitecode;
		
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label dlgTitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE");
		Image closeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_ICON");
		titleBar.add(dlgTitleLbl,closeIcon);
		
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		Button cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(cancelBtn);
		
		activeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_DIV");
		passiveDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PASSIVE_DIV");
		bodyLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_LAYOUT");
		bodyLayout.add(activeDiv,passiveDiv);
		
		retrieveAssets();
		
		
		closeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Image> event) {
				close();

			}
		});
		
		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});


		
		
		
		mainLayout.add(titleBar, bodyLayout, buttonBar);
		add(mainLayout);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();
		
	}


	private void retrieveAssets() {
		try {
			JSONArray jsarr=null;
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url = url + "?StoreSerialNo=-1&StoreId=9996&StatusId=-1&VendorId=" + "-1" + "&EquipmentTypeId=" 
					+ "-1" + "&StoreLocId=" + URLEncoder.encode(sitecode) + "&EquipmentSerialNo=-1";
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			activAssetarr=new JSONArray();
			passiveAssetarr=new JSONArray();
			if(response!=null && response.trim().length()>0) {
				jsarr=new JSONArray(response);
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						if(jsarr.getJSONObject(i).getInt("ServiceType")==1) {
							activAssetarr.put(jsarr.getJSONObject(i));
						}else if(jsarr.getJSONObject(i).getInt("ServiceType")==0) {
							passiveAssetarr.put(jsarr.getJSONObject(i));
						}else {}
						
					}
					
				}
			}
		
			populateActiveAssets();
			populatePassiveAssets();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			
		}		
		
	}
	
	private void populateActiveAssets() {
		try {
			activeDiv.removeAll();
			Div activeheader=UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_HEADER_DIV");
			Label headerLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ACTIVE_HEADER");
			activeheader.add(headerLbl);
			Div activebody=UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_BODY_DIV");
			activeDiv.add(activeheader,activebody);
			
			if (activAssetarr.length() > 0) {
				activebody.removeAll();
				Div bodyheaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_HEADER_DIV");
				Label assetType_key = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_KEY");
				Label assetName_key = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_KEY");
				Label serialNum_key = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_KEY");
				Label operatorName_key = UIHtmlFieldFactory.createLabel(SCREENCD, "OP_NAME_KEY");
				Label installdate_key = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_KEY");
				bodyheaderDiv.add(assetType_key,assetName_key,serialNum_key,operatorName_key,installdate_key);
				activebody.add(bodyheaderDiv);
				
				for (int i = 0; i < activAssetarr.length(); i++) {
					Div rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_ROW_DIV");
					
					Label assetType_val = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_VAL");
					assetType_val.setText(activAssetarr.getJSONObject(i).getString("EquipmentType"));
					
					Label assetName_val = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_VAL");
					assetName_val.setText(activAssetarr.getJSONObject(i).getString("Description"));
				
					Label serialNum_val = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_VAL");
					serialNum_val.setText(activAssetarr.getJSONObject(i).getString("EquipmentSerialNo"));
					
			
					Label operatorName_val = UIHtmlFieldFactory.createLabel(SCREENCD, "OP_NAME_VAL");
					operatorName_val.setText(activAssetarr.getJSONObject(i).getString("VendorName"));
					
					Label installdate_val = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_VAL");
					installdate_val.setText(activAssetarr.getJSONObject(i).getString("CreationDate"));
					
					
					rowDiv.add(assetType_val,assetName_val,serialNum_val,operatorName_val,installdate_val);
					
					
					activebody.add(rowDiv);
				} 

			}else if(activAssetarr.length()<=0) {
				activebody.removeAll();
				Label noActiveassetLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_ACTIVE_ASSET");
				activebody.add(noActiveassetLbl);
			}else {
				
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}

	private void populatePassiveAssets() {
		try {
			passiveDiv.removeAll();
			Div passiveheader=UIHtmlFieldFactory.createDiv(SCREENCD, "PASSIVE_HEADER_DIV");
			Label headerLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PASSIVE_HEADER");
			passiveheader.add(headerLbl);
			Div passivebody=UIHtmlFieldFactory.createDiv(SCREENCD, "PASSIVE_BODY_DIV");
			passiveDiv.add(passiveheader,passivebody);
			
			if (passiveAssetarr.length() > 0) {
				passivebody.removeAll();
				
				Div bodyheaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_HEADER_DIV");
				Label assetType_key = UIHtmlFieldFactory.createLabel(SCREENCD, "PASSIVE_TYPE_KEY");
				Label assetName_key = UIHtmlFieldFactory.createLabel(SCREENCD, "PASSIVE_NAME_KEY");
				Label serialNum_key = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_KEY2");
				Label operatorName_key = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_KEY");
				Label installdate_key = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_KEY2");
				bodyheaderDiv.add(assetType_key,assetName_key,serialNum_key,operatorName_key,installdate_key);
				passivebody.add(bodyheaderDiv);
				
				for (int i = 0; i < passiveAssetarr.length(); i++) {
					Div rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_ROW_DIV");
					
				
					Label assetType_val = UIHtmlFieldFactory.createLabel(SCREENCD, "PASSIVE_TYPE_VAL");
					assetType_val.setText(passiveAssetarr.getJSONObject(i).getString("EquipmentType"));
				
					Label assetName_val = UIHtmlFieldFactory.createLabel(SCREENCD, "PASSIVE_NAME_VAL");
					assetName_val.setText(passiveAssetarr.getJSONObject(i).getString("Description"));
					
					Label serialNum_val = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_VAL2");
					serialNum_val.setText(passiveAssetarr.getJSONObject(i).getString("EquipmentSerialNo"));
					
					Label operatorName_val = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_VAL");
					operatorName_val.setText(passiveAssetarr.getJSONObject(i).getString("VendorName"));
					
			
					Label installdate_val = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_VAL2");
					installdate_val.setText(passiveAssetarr.getJSONObject(i).getString("CreationDate"));
					
					
					rowDiv.add(assetType_val,assetName_val,serialNum_val,operatorName_val,installdate_val);
					
					passivebody.add(rowDiv);
				}

			}else if(passiveAssetarr.length()<=0) {
				passivebody.removeAll();
				Label noActiveassetLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_PASSIVE_ASSET");
				passivebody.add(noActiveassetLbl);
			}else {
				
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}

}
