package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;

@CssImport("./styles/attribute_parent-styles.css")
public class AttributeParent extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ATTRIBUTE_PARENT";

	private Tab equipmentAttributesTab, otherAttributesTab;
	private ConfigView parent;
	private EquipmentAttributeMaster equipmentAttributesTabVL;
	private OtherAttributeMaster otherAttributesTabVL;
	

	public AttributeParent(ConfigView parent) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;

		Tabs attributesParentTabs = new Tabs();
		attributesParentTabs.addClassName(SCREENCD+"_TABS");
		equipmentAttributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EQUIPMENT_ATTRIBUTES_TAB_LBL"));
		otherAttributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "OTHER_ATTRIBUTES_TAB_LBL"));

		attributesParentTabs.add(/*equipmentAttributesTab,*/otherAttributesTab);

		equipmentAttributesTabVL = new EquipmentAttributeMaster(parent);
		otherAttributesTabVL = new OtherAttributeMaster(parent);

	//	equipmentAttributesTabVL.setVisible(true);
	//	otherAttributesTabVL.setVisible(false);
		equipmentAttributesTabVL.setVisible(false);
		otherAttributesTabVL.setVisible(true);

		attributesParentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(equipmentAttributesTab)) {
					equipmentAttributesTabVL.setVisible(true);
					otherAttributesTabVL.setVisible(false);

				} else if(event.getSelectedTab().equals(otherAttributesTab)) {
					equipmentAttributesTabVL.setVisible(false);
					otherAttributesTabVL.setVisible(true);

				} 
			}
		});
		
		add(attributesParentTabs, equipmentAttributesTabVL, otherAttributesTabVL);
	}

}
