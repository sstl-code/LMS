package com.umt.siteassetinventory.framework.bean;

import java.io.Serializable;
import java.util.Date;

public class UserInfoBean implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String emailId;

	private String userType;
	
	private boolean companyProfileCreated;
	
	private String loginMedia;
	
	private Date loginDateTime;
	
	private String token;
	
	private String partnerCode;
	
	public UserInfoBean() {
		companyProfileCreated = false;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getLoginDateTime() {
		return loginDateTime;
	}

	public void setLoginDateTime(Date loginDateTime) {
		this.loginDateTime = loginDateTime;
	}
	
	public String getStringifiedLoginDateTime() {
		return this.loginDateTime.toString();
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public boolean isCompanyProfileCreated() {
		return companyProfileCreated;
	}
	
	public String getLoginMedia() {
		return loginMedia;
	}

	public void setLoginMedia(String loginMedia) {
		this.loginMedia = loginMedia;
	}
	
	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
		
		if(partnerCode != null && partnerCode.trim().length() > 0) {
			companyProfileCreated = true;
		}
	}
}
