package com.umt.siteassetinventory.configuration;

import java.util.Map;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.Route;

@Route(value = "configuration", layout = MainView.class)
@CssImport("./styles/configuration-styles.css")
public class ConfigView extends BaseStructure implements AfterNavigationObserver {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "CONFIG_VIEW";
	private ConfigView parent;
	private Tab vendorsTab,operatorsTab,equipmentTypesTab,storesTab,statusTab,attributesTab, equipmentTypeVendorAssociationTab,
	equipmentTypeOperatorAssociationTab,GLCodeTab;
	private String route, vendorsResponse;
	
	private VendorMaster vendorsTabVL, operatorsTabVL;
	private EquipmentTypeMaster  equipmentTypesTabVL;
	private StoreMaster storesTabVL;
	private StatusMaster statusTabVL;
	private AttributeParent attributesTabVL;
	private EquipmentTypeVendorAssociationMaster equipmentTypeVendorAssociationTabVL, equipmentTypeOperatorAssociationTabVL;
	protected Map<Long, String> vendorMap, operatorMap, activeEquipmentTypeMap, passiveEquipmentTypeMap, allStoreMap, activeStoreMap;
	private GLCodeMaster GLCodeMasterVL;

	public ConfigView() 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		parent=this;
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Configuration");
		//	getAssetsViewobj(parent);

		vendorsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "VENDORS_TAB_LBL"));
		operatorsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "OPERATORS_TAB_LBL"));
		equipmentTypesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EQUIPMENT_TYPES_TAB_LBL"));
		storesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "STORES_TAB_LBL"));
		statusTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "STATUS_TAB_LBL"));
		attributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ATTRIBUTES_TAB_LBL"));
		equipmentTypeVendorAssociationTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EQUIPMENT_TYPE_VENDOR_ASSOCIATION_TAB_LBL"));
		equipmentTypeOperatorAssociationTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EQUIPMENT_TYPE_OPERATOR_ASSOCIATION_TAB_LBL"));
		GLCodeTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "GLCODE_TAB_LBL"));

		parentTabs.add(/*vendorsTab,operatorsTab,equipmentTypesTab,storesTab,statusTab,*/attributesTab,GLCodeTab/*,equipmentTypeVendorAssociationTab, equipmentTypeOperatorAssociationTab*/);
//		parentTabs.add(vendorsTab,operatorsTab,equipmentTypesTab,storesTab,statusTab,attributesTab,GLCodeTab,
//				equipmentTypeVendorAssociationTab, equipmentTypeOperatorAssociationTab);
		add(rowDiv);
		rowDiv.remove(col1Div);
		col2Div.getStyle().set("width", "100% !important");
		
		vendorsTabVL = new VendorMaster(parent, true);
		operatorsTabVL = new VendorMaster(parent, false);
		equipmentTypesTabVL = new EquipmentTypeMaster(parent);
		storesTabVL = new StoreMaster(parent);
		statusTabVL = new StatusMaster(parent);
		attributesTabVL = new AttributeParent(parent);
		equipmentTypeVendorAssociationTabVL = new EquipmentTypeVendorAssociationMaster(parent, true);
		equipmentTypeOperatorAssociationTabVL = new EquipmentTypeVendorAssociationMaster(parent, false);
		GLCodeMasterVL=new GLCodeMaster(parent);
	

		parentTabs.setSelectedTab(attributesTab);
		attributesTabVL.setVisible(true);
		
//		parentTabs.setSelectedTab(vendorsTab);
//		vendorsTabVL.setVisible(true);
		vendorsTabVL.setVisible(false);
		operatorsTabVL.setVisible(false);
		equipmentTypesTabVL.setVisible(false);
		storesTabVL.setVisible(false);
		statusTabVL.setVisible(false);
//		attributesTabVL.setVisible(false);
		equipmentTypeVendorAssociationTabVL.setVisible(false);
		equipmentTypeOperatorAssociationTabVL.setVisible(false);
		GLCodeMasterVL.setVisible(false);
		
	
		col2ValueDiv.add(vendorsTabVL, operatorsTabVL, equipmentTypesTabVL, storesTabVL, statusTabVL, attributesTabVL,GLCodeMasterVL, 
				equipmentTypeVendorAssociationTabVL, equipmentTypeOperatorAssociationTabVL);

		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(vendorsTab)) {
					vendorsTabVL.setVisible(true);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(operatorsTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(true);
					equipmentTypesTabVL.setVisible(false);
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(equipmentTypesTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(true);
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(storesTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);
					storesTabVL.setVisible(true);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(statusTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);	
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(true);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(attributesTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);	
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(true);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(equipmentTypeVendorAssociationTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);	
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(true);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(equipmentTypeOperatorAssociationTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);	
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(true);
					GLCodeMasterVL.setVisible(false);
				} else if(event.getSelectedTab().equals(GLCodeTab)) {
					vendorsTabVL.setVisible(false);
					operatorsTabVL.setVisible(false);
					equipmentTypesTabVL.setVisible(false);	
					storesTabVL.setVisible(false);
					statusTabVL.setVisible(false);
					attributesTabVL.setVisible(false);
					equipmentTypeVendorAssociationTabVL.setVisible(false);
					equipmentTypeOperatorAssociationTabVL.setVisible(false);
					GLCodeMasterVL.setVisible(true);
				} 
			}
		});
	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) {
		//	System.out.println("route="+event.getLocation().getPathWithQueryParameters());
		route=event.getLocation().getPathWithQueryParameters();

	}

	public String getVendorsResponse() {
		return vendorsResponse;
	}

	public void setVendorsResponse(String vendorsResponse) {
		this.vendorsResponse = vendorsResponse;
	}
}
