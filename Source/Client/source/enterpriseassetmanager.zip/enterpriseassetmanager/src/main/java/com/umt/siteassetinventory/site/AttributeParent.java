package com.umt.siteassetinventory.site;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;

@CssImport("./styles/attribute_parent-styles.css")
public class AttributeParent extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ATTRIBUTE_PARENT";

	private Tab siteAttributesTab, propertyAttributesTab;
	private SiteView parent;
	private SiteAttributesTab siteAttributesTabVL;
	private PropertyAttributesTab propertyAttributesTabVL;
	private Div edit_Div;
	protected Button edit_btn;
	private boolean siteOrProperty = true;

	public boolean isSiteOrProperty() {
		return siteOrProperty;
	}


	public void setSiteOrProperty(boolean siteOrProperty) {
		this.siteOrProperty = siteOrProperty;
	}


	public AttributeParent(String SiteCode, SiteView parent) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;
		edit_Div = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_DIV");
		edit_btn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
		

		Tabs attributesParentTabs = new Tabs();
		attributesParentTabs.addClassName(SCREENCD+"_SITEVIEW_TABS");
		siteAttributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "SITE_ATTRIBUTES_TAB_LBL"));
		propertyAttributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PROPERTY_ATTRIBUTES_TAB_LBL"));

		attributesParentTabs.add(siteAttributesTab, propertyAttributesTab);
		edit_Div.add(attributesParentTabs, edit_btn);

		siteAttributesTabVL = new SiteAttributesTab(SiteCode, parent, this);
		propertyAttributesTabVL = new PropertyAttributesTab(SiteCode, parent, this);

		siteAttributesTabVL.setVisible(true);
		propertyAttributesTabVL.setVisible(false);

		attributesParentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(siteAttributesTab)) {
					siteAttributesTabVL.setVisible(true);
					propertyAttributesTabVL.setVisible(false);
					siteOrProperty = true;

				} else if(event.getSelectedTab().equals(propertyAttributesTab)) {
					siteAttributesTabVL.setVisible(false);
					propertyAttributesTabVL.setVisible(true);
					siteOrProperty = false;

				} 
			}
		});
		
		add(edit_Div, siteAttributesTabVL, propertyAttributesTabVL);
	}

}
