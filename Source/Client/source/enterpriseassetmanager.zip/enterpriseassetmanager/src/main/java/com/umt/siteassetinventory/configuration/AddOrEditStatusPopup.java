package com.umt.siteassetinventory.configuration;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditStatusPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditStatus addOrEditStatus;
	private String screencd;
	private boolean dataSaved;
	private StatusMaster viewStatusMaster;
	private boolean addOrEdit;


	public AddOrEditStatusPopup(String title, boolean addOrEdit, Component component, StatusMaster master, String screencd) {

		super(title, component);
		setWidth("500px");
		//System.out.println(title);
		this.addOrEditStatus = (AddOrEditStatus) component;
		this.viewStatusMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditStatus.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDSTORESTATUS");
					JSONObject statusInfoJson = new JSONObject();
					statusInfoJson.put("StoreId", addOrEditStatus.getStoreId());
					statusInfoJson.put("StatusCode", addOrEditStatus.getStatusCode());
					statusInfoJson.put("Description", addOrEditStatus.getStatusDesc());

					Form formData = new Form();
					formData.add("StatusInfo", statusInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "STATUS_SAVE_SUCCESSFUL");	
				}
				else
				{
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATESTORESTATUS");

					JSONObject statusInfoJson = new JSONObject();
					statusInfoJson.put("StoreId", addOrEditStatus.getStoreId());
					statusInfoJson.put("StatusCode", addOrEditStatus.getStatusCode());
					statusInfoJson.put("Description", addOrEditStatus.getStatusDesc());
					statusInfoJson.put("Status", CommonUtils.getStatus(addOrEditStatus.getRecStatus()));

					Form formData = new Form();
					formData.add("StatusInfo", statusInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "STATUS_UPDATE_SUCCESSFUL");	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewStatusMaster.populateData();
							close();	
						}
					}
				});
			}	
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

	}

}