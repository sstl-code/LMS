package com.umt.siteassetinventory.framework.resourcemanager;

import java.io.Serializable;

public class ResourceUtil implements Serializable {
	private static final long serialVersionUID = 1L;

	public static String[] parseConfiguredValue(String value) {
		if (value == null || value.trim().length() == 0) {
			return null;
		}
		try {
			String[] configuredvalues = value.split("[|]");
			return configuredvalues;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public static String getConfiguredValueAt(String[] configuredvalues, int index) {
		if (configuredvalues == null || index >= configuredvalues.length) {
			return "";
		}

		try {
			return configuredvalues[index] == null || configuredvalues[index].trim().length() == 0 ? ""
					: configuredvalues[index];
		} catch (Exception ex) {
			ex.printStackTrace();
			return "";
		}
	}
}
