package com.umt.siteassetinventory.framework.componentfactory;

import java.io.InputStream;


import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

@CssImport("./styles/upload_component-styles.css")
public class UIUploadComponent extends Div {

	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "UPLOAD_COMPONENT";
	private Upload upload;
	private InputStream inputStream = null;
	private String fileExtension = "";
	private String base64EncodedFileContent = "";
	private boolean uploadFailed = false;
	private FailedEvent failedEvent;
	private boolean uploadRejected = false;
	private FileRejectedEvent rejectedEvent;
	private Button uploadButton;
	private Label dropLabel;
	private Image dropIcon;
	private String fileName="";

	public UIUploadComponent(MemoryBuffer fileBuffer, boolean dialog) {
		//		Label uploadedFileName = UIHtmlFieldFactory.createLabel(SCREENCD, "UPLOADED_FILE_NAME");
		//		HorizontalLayout headerLayout = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "HEADER_HL");
		//removeIcon = FontAwesome.Regular.TIMES_CIRCLE.create();
		//		Image removeIcon = UIHtmlFieldFactory.createImage("CAPTURE_TIMED_VALUE_DLG","CANCEL_ICON");
		//		removeIcon.addClassName(SCREENCD + "_REMOVE_ICON");
		//ProgressBar uploadProgressBar = new ProgressBar(0, 100, 0);
		//uploadProgressBar.addClassName(SCREENCD+"_UPLOAD_PROGRESS_BAR");
		//MemoryBuffer fileBuffer = new MemoryBuffer();
		upload = new Upload(fileBuffer);

		if(dialog)
			setClassNameInDialog();
		else
			setClassNameOutDialog();
		upload.getStyle().set("display", "flex");
		upload.getStyle().set("flex-direction", "column");
		uploadButton = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BUTTON");
		uploadButton.getStyle().set("position", "absolute");	
		upload.setUploadButton(uploadButton);
		
		dropLabel = UIHtmlFieldFactory.createLabel(SCREENCD, "DROP_LBL");
		dropLabel.getElement().setProperty("innerHTML", SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DROP_LBL"));
		dropLabel.getStyle().set("position", "absolute");
		upload.setDropLabel(dropLabel);
		
		dropIcon = UIHtmlFieldFactory.createImage(SCREENCD, "UPLOAD_TO_CLOUD_ICON");
		dropIcon.getStyle().set("position", "absolute");
		upload.setDropLabelIcon(dropIcon);	
		
		if(dialog)
			setStyleofComponentsInDialog();
		else
			setStyleofComponentsOutDialog();
		

		/*upload.addStartedListener(new ComponentEventListener<StartedEvent>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(StartedEvent event) {
				System.out.println("upload started");
				uploadedFileName.setText(event.getFileName());
				headerLayout.add(uploadedFileName, removeIcon);
			}
		});*/

		/*upload.addProgressListener(new ComponentEventListener<ProgressUpdateEvent>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ProgressUpdateEvent event) {
				double readBytes = Double.parseDouble(event.getReadBytes()+"");
				double contentLength = Double.parseDouble(event.getContentLength()+"");
				double value = uploadProgressBar.getValue() + ((readBytes/contentLength) * 100);
				System.out.println(readBytes+" upload getReadBytes:: "+event.getReadBytes());
				System.out.println(contentLength+" upload getContentLength:: "+event.getContentLength());
				System.out.println("value:: "+value);
				uploadProgressBar.setValue(value);
			}
		});*/

		/*removeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Image> event) {
				try {
					upload.getElement().setPropertyJson("files", Json.createArray());
					headerLayout.removeAll();
					uploadProgressBar.setValue(0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});*/

		upload.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				ClassLoader loader = Thread.currentThread().getContextClassLoader();
				setFileName(event.getFileName());
				try {
					Thread.currentThread().setContextClassLoader(WorkbookFactory.class.getClassLoader());
					inputStream = fileBuffer.getInputStream();
					fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					
//					uploadButton.removeClassName(SCREENCD+"_UPLOAD_BUTTON");
//					uploadButton.addClassName(SCREENCD+"_UPLOAD_BUTTON_DISABLED");
				} catch (Throwable ex) {
					//	ex.printStackTrace();
				}
				finally {
					Thread.currentThread().setContextClassLoader(loader);
				}
			}
		});
		
		
		upload.getElement().addEventListener("file-abort", event1 -> {
			base64EncodedFileContent="";
		//	fileName="";
		//	System.out.println("click");
		});
		
		
		upload.addFailedListener(e -> {
			base64EncodedFileContent = "";
			uploadFailed = true;
			setFailedEvent(e);
		});

		upload.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				uploadRejected = true;
				setRejectedEvent(event);
			}
		});
		
		if(CommonUtils.getClientView())
		{
			/*upload = new Upload(fileBuffer);
	//		uploadButton = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BUTTON");
			Label dropLabel = UIHtmlFieldFactory.createLabel(SCREENCD, "DROP_LBL");
			dropLabel.getElement().setProperty("innerHTML", WorkflowUIFramework.getFramework().getLabel(SCREENCD, "DROP_LBL"));
			Image dropIcon = UIHtmlFieldFactory.createImage(SCREENCD, "UPLOAD_TO_CLOUD_ICON");
			Div d=new Div();
			d.add(dropLabel);
			d.addClassName("Div1");*/
			
			uploadButton.removeClassName(SCREENCD+"_UPLOAD_BUTTON");
			dropLabel.removeClassName(SCREENCD+"_DROP_LBL");
			dropIcon.removeClassName(SCREENCD+"_UPLOAD_TO_CLOUD_ICON");
			//upload.removeClassName(SCREENCD+"_UPLOAD_COMPONENT_OUT_DIALOG_MOBILE_VIEW");
			
			uploadButton.addClassName("UPLOAD_COMPONENT_UPLOAD_BUTTON_MOBILE_VIEW");
			dropLabel.addClassName("UPLOAD_COMPONENT_DROP_LBL_MOBILE_VIEW");
			dropIcon.addClassName("UPLOAD_COMPONENT_UPLOAD_TO_CLOUD_ICON_MOBILE_VIEW");
			upload.addClassName(SCREENCD+"_UPLOAD_COMPONENT_OUT_DIALOG_MOBILE_VIEW");
			
			setStyleofComponentsMobileView();
			
//			upload.setUploadButton(uploadButton);
//			upload.setDropLabel(d/*dropLabel*/);
//	//		upload.setDropLabelIcon(dropIcon);	
//		    System.out.println(upload.getDropLabel());
			
		}

		add(upload);

	}
	
	public Upload getUpload()
	{
		return upload;
	}
	
	public void setStyleofComponentsMobileView()
	{
		uploadButton.getStyle().set("margin-top", "115px");
		uploadButton.getStyle().set("margin-left", "50px");
		
		dropLabel.getStyle().set("margin-left", "140px");
		dropLabel.getStyle().set("margin-top", "95px");
		
		dropIcon.getStyle().set("margin-left", "210px");
		dropIcon.getStyle().set("margin-top", "40px");
	}

	public void setStyleofComponentsInDialog()
	{
		uploadButton.getStyle().set("margin-top", "175px");
		uploadButton.getStyle().set("margin-left", "180px");
		
		dropLabel.getStyle().set("margin-left", "140px");
		dropLabel.getStyle().set("margin-top", "95px");
		
		dropIcon.getStyle().set("margin-left", "210px");
		dropIcon.getStyle().set("margin-top", "40px");
	}
	
/*	public void setStyleofComponentsOutDialog()
	{
		uploadButton.getStyle().set("margin-top", "175px");
		uploadButton.getStyle().set("margin-left", "110px");
		
		dropLabel.getStyle().set("margin-left", "70px");
		dropLabel.getStyle().set("margin-top", "95px");
		
		dropIcon.getStyle().set("margin-left", "140px");
		dropIcon.getStyle().set("margin-top", "40px");
	}*/
	public void setStyleofComponentsOutDialog()
	{
		uploadButton.getStyle().set("margin-top", "175px");
		uploadButton.getStyle().set("margin-left", "180px");
		
		dropLabel.getStyle().set("margin-left", "140px");
		dropLabel.getStyle().set("margin-top", "95px");
		
		dropIcon.getStyle().set("margin-left", "210px");
		dropIcon.getStyle().set("margin-top", "40px");
		
	/*	if(CommonUtils.getClientView())
		{
			uploadButton.addClassName("UPLOAD_COMPONENT_UPLOAD_BUTTON_MOBILE_VIEW");
			dropLabel.addClassName("UPLOAD_COMPONENT_DROP_LBL_MOBILE_VIEW");
			dropIcon.addClassName("UPLOAD_COMPONENT_UPLOAD_TO_CLOUD_ICON_MOBILE_VIEW");
			upload.addClassName(SCREENCD+"_UPLOAD_COMPONENT_OUT_DIALOG_MOBILE_VIEW");
		}*/
	}
	
	public void setClassNameInDialog()
	{
		upload.addClassName(SCREENCD+"_UPLOAD_COMPONENT_IN_DIALOG");
	}
	
	public void setClassNameOutDialog()
	{
		upload.addClassName(SCREENCD+"_UPLOAD_COMPONENT_OUT_DIALOG");
	}
	
	public void setAcceptedFiles(String[] acceptedFileTypes)
	{
		upload.setAcceptedFileTypes(acceptedFileTypes);	
	}
	
	public void setMaxFileSize(int maxfilesize)
	{
		upload.setMaxFileSize(maxfilesize);
	}
	
	public void setDropAllowed(boolean dropAllowed)
	{
		upload.setDropAllowed(dropAllowed);	
	}
	
	public void setUploadButton(Component button)
	{
		upload.setUploadButton(button);
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public String getBase64EncodedFileContent() {
		return base64EncodedFileContent;
	}

	public boolean isUploadFailed() {
		return uploadFailed ;
	}

	public FailedEvent getFailedEvent() {
		return failedEvent;
	}

	public void setFailedEvent(FailedEvent failedEvent) {
		this.failedEvent = failedEvent;
	}
	
	public boolean isUploadRejected() {
		return uploadRejected ;
	}

	public FileRejectedEvent getRejectedEvent() {
		return rejectedEvent;
	}

	public void setRejectedEvent(FileRejectedEvent rejectedEvent) {
		this.rejectedEvent = rejectedEvent;
	}

	public String getFileName() {
		return fileName;
	} 
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
}
