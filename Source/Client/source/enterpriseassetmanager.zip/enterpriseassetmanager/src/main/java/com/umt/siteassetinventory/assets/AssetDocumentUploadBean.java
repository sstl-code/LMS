package com.umt.siteassetinventory.assets;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

@CssImport("./styles/asset_document_upload_bean-styles.css")
public class AssetDocumentUploadBean extends VerticalLayout {
	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "ASSET_DOCUMENT_UPLOAD_BEAN";

	private String uid, documentType, documentName, documentDesc, viewUrl, viewUrlToOpen ="", truebyl_domain ="";
	public HorizontalLayout recordHL;
	/*private int position;*/
	private AssetDocumentsTab parent;
	private String assetId = "";
	public AssetDocumentUploadBean child;
	private Label docTypeLbl, docNameLbl, docDescLbl;

	public AssetDocumentUploadBean(String uid, String documentType, String documentName, String documentDesc, String viewUrl, AssetDocumentsTab parent/*, int position*/, String assetId) {
		super();
		this.uid = uid;
		this.documentType = documentType;
		this.documentName = documentName;
		this.documentDesc = documentDesc;
		this.viewUrl = viewUrl;
		this.parent = parent;
		/*this.position = position;*/
		this.assetId = assetId;
	}

	public HorizontalLayout getAssetDocumentUploadBean() {

		recordHL = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "RECORD_HL");
		docTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_TYPE_LBL");
		docTypeLbl.setText(documentType);
		docNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_NAME_LBL");
		docNameLbl.setText(documentName);
		docDescLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_DESC_LBL");
		docDescLbl.setText(documentDesc);

		Image viewIcon= UIHtmlFieldFactory.createImage("DOCUMENTS","VIEW_BTN_ICON");
		viewIcon.addClassName(SCREENCD+"_VIEW_BTN_ICON");
		//		Div viewBtn = UIHtmlFieldFactory.createDiv(SCREENCD, "VIEW_BTN");
		//		viewBtn.add(viewIcon);

		//Icon removeIcon = FontAwesome.Solid.TRASH.create();
		Image removeIcon= UIHtmlFieldFactory.createImage("DOCUMENTS","REMOVE_BTN_ICON");
		removeIcon.addClassName(SCREENCD+"_REMOVE_BTN_ICON");
		Div removeBtn = UIHtmlFieldFactory.createDiv(SCREENCD, "REMOVE_BTN");
		removeBtn.add(removeIcon);

		Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_DIV");


		//buttonDiv.add(viewBtn, removeBtn);

		recordHL.add(docTypeLbl, docNameLbl, docDescLbl, buttonDiv);

		viewUrl = viewUrl.substring(viewUrl.indexOf("/RuleServer"));
		try {
			truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
			if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
				viewUrlToOpen = truebyl_domain.substring(0, truebyl_domain.length()-1) + viewUrl;
			}
			else
			{
				System.out.println("TRUEBYL_DOMAIN not set in Environment variables");
				viewUrlToOpen = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						ApplicationConfiguration.getServerPort() + viewUrl;	
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("TRUEBYL_DOMAIN not set in Environment variables");
			viewUrlToOpen = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
					ApplicationConfiguration.getServerPort() + viewUrl;	
		}
		Anchor anchor = new Anchor(viewUrlToOpen, viewIcon);
		anchor.setTarget("_blank");
		buttonDiv.add(anchor, removeBtn);

		//		viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(ClickEvent<Div> event) {
		//				viewBtnClicked();
		//			}
		//		});


		removeBtn.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {

				String title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "WARNING_DIALOG_TITLE");
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showWarningMessage(SCREENCD, "REMOVE_ROW_WARNING", title);
				dlg.addOpenedChangeListener(
						new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
								Dialog srcDlg = event.getSource();
								if (!srcDlg.isOpened()) {
									if (srcDlg.getId().isPresent() && srcDlg.getId().get().equals("9999")) {
										RemoveDocumentRowClicked(assetId);
										srcDlg.close();
									}
									if (srcDlg.getId().isPresent() && srcDlg.getId().get().equals("-9999")) {
										srcDlg.close();
									}
								}
							}
						});
			}
		});

		return recordHL;

	}

	protected void viewBtnClicked() {	
		viewUrl = viewUrl.substring(viewUrl.indexOf("/RuleServer"));
		String viewUrlToOpen = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + ApplicationConfiguration.getServerPort() + viewUrl;
		UI.getCurrent().getPage().open(viewUrlToOpen);
	}

	protected void RemoveDocumentRowClicked(String assetId) {

		try {
			Form l_objInputForm = new Form();
			l_objInputForm.add("StoreSerialNo", getAssetId());
			l_objInputForm.add("FileUID", getUid());

			String base_URL = ApplicationConfiguration.getServiceEndpoint("REMOVEASSETDOCUMENT");
			//System.out.println(l_objInputForm.toString()+" "+base_URL);
			String res = RestServiceHandler.deleteJSON_DELETE(base_URL, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(" res::"+res);
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "DOC_DELETE_SUCCESSFUL",
					ApplicationConstants.DialogTypes.INFO);
			parent.removeDocumentrow(this);
		} catch (Exception ex) {
			ex.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(ex.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getUid() {
		return uid;
	}

	public String getViewUrlToOpen() {
		return viewUrlToOpen;
	}


}
