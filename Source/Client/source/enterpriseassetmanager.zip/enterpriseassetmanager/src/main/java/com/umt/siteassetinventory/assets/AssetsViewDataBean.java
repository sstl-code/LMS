package com.umt.siteassetinventory.assets;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/assets-view.css")
public class AssetsViewDataBean extends Div
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSETS_VIEW_BEAN";
	private String assetId,equipmentType, equipmentSerialNo,creationDate;
	private AssetsView parent;
	private Div eachrowDiv;
	private AssetsViewDataBean child;
	private String eqi_id;

	public AssetsViewDataBean(String assetId, String equipmentType, String equipmentSerialNo, String creationDate, AssetsView assetView)  
	{
		this.assetId=assetId;
		this.equipmentType=equipmentType;
		this.equipmentSerialNo=equipmentSerialNo;
		this.creationDate=creationDate;
		this.parent=assetView;
		
		child=this;
		eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
		
		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		
		
		Label assetidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSETID_LBL");
		assetidLbl.setText(assetId);
		eachdataDiv1.add(assetidLbl);
		
		Label equipmenttypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EQUIPMENT_TYPE_LBL");
		equipmenttypeLbl.setText(equipmentType);
		eachdataDiv2.add(equipmenttypeLbl);
		
		Label equipmentSerialnoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIALNO_LBL");
		equipmentSerialnoLbl.setText(equipmentSerialNo);
		eachdataDiv3.add(equipmentSerialnoLbl);
		
		Label creationDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CREATION_DATE_LBL");
		creationDateLbl.setText(creationDate);
		eachdataDiv4.add(creationDateLbl);
		
		eachrowDiv.add(/*eachdataDiv1,*/eachdataDiv2,eachdataDiv3,eachdataDiv4);
		add(eachrowDiv);
		
		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				
				try {
					parent.addAttributesTab(getEquipmentId(), assetId);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			//	System.out.println("click:---" + eqi_id);
				
				eachRowSelectionChangeHandler(assetId,event.getSource());
			}
		});
	
	}
	public String getEquipmentId() throws Exception {
		
		String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTID");
		String res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
		
		//System.out.println("EquipmentID: " + res);
		JSONArray array_list = new JSONArray(res);
		//System.out.println(equipmentType);
		for(int i = 0; i < array_list.length(); i++) {
			JSONObject json = array_list.getJSONObject(i);
			if(equipmentType.equalsIgnoreCase(json.getString("EquipmentType"))) {
				eqi_id = json.getString("EquipmentTypeId");
				//System.out.println(eqi_id);
			}
		}
		return eqi_id;
		
		
	}
	public String getTheFirstEquipmentID(String equipmentType) throws Exception {
		String id = null;
		String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTID");
		String res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
		
		JSONArray array_list = new JSONArray(res);
		for(int i = 0; i < array_list.length(); i++) {
			JSONObject json = array_list.getJSONObject(i);
			if(equipmentType.equalsIgnoreCase(json.getString("EquipmentType"))) {
				id = json.getString("EquipmentTypeId");
				
			}
		}
		
		
		return id;
	}
	protected void eachRowSelectionChangeHandler(String assetid2, Div selectedRow) 
	{
		parent.selectedRowChangeHandler(assetid2);
		parent.deselectOtherRows(child);
		selectedRow.addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
		parent.sendEquipmentName(equipmentType,equipmentSerialNo);
	}
	
	public void deselectEachDiv(AssetsViewDataBean child2)
	{
		
		for(int i = 0; i < parent.getAssetBeanList().size(); i++) 
		{
			if(!child2.equals(parent.getAssetBeanList().get(i))) 
			{
				eachrowDiv.removeClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
			}
		}
		
	}
	public Div getEachRowDiv() 
	{
		return eachrowDiv;
	}
	public void selectAssetViewBeanNode(String paramAssetId2) {
		deselectEachDiv(this);
		if(paramAssetId2.equalsIgnoreCase(assetId))
		{
			if(eachrowDiv != null)
			{
				eachrowDiv.addClassName(SCREENCD + "_DATA_ROW_SELECTED");
				parent.sendEquipmentName(equipmentType,equipmentSerialNo);
			}
		}
		
	}

}
