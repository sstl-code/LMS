package com.umt.siteassetinventory.site;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.FileTypeAttributeUploadDialog;
import com.umt.siteassetinventory.utility.LocalStorage;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.component.checkbox.Checkbox;

@CssImport("./styles/add_site_agreement-styles.css")
public class AddSiteAgreement extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_SITE_AGREEMENT";

	private TextField agreementNameFld, agreementDocDescFld;
	/*private NumberField paymentAmtFld, escalationAmtFld;
	private ComboBox<String> paymentFrequencyCombo, paymentTypeCombo, paymentModeCombo, escalationFrequencyCombo, escalationTypeCombo;*/
	private DatePicker agreementDateFld, startDateFld, endDateFld;
	private String siteCode, base64EncodedFileContent = "", existingFileName = "", fileFormat = "", existingAgreementName = "", existingFileDesc = "";
	private long agreementId;
	//private Button uploadButton;
	private UIUploadComponent uploadDiv;
	private Tab basicTab, detailsTab;
	private Div tabsVL, basicTabVL, detailsTabVL;
	private Tabs addAgreementsTabs;
//	private HashMap<String, List<Object>> dynamicAgreementAttributesMap;
	private LinkedHashMap<String, List<Object>> dynamicAgreementAttributesMap;
	private JSONObject agreementAttributesJson;
	private boolean detailsTabEnabled = false, fileExist = false; /*fileUploaded = false*/
	private JSONObject existingAgreementAttributesJson;
//	private HashMap<String, List<Object>> updateddynamicAgreementAttributesMap;
	private LinkedHashMap<String, List<Object>> updateddynamicAgreementAttributesMap;
	private ComboBox<String> agreementtypeCombo;
	private List<String> agreementTypeList=new ArrayList<String>();
	private HashMap<String,Integer> agreementtypemap=new HashMap<String,Integer>();
	private String agreementtype;
	private Map<String, JSONObject> fileAttributeMap = new HashMap<String, JSONObject>();
	private String partitionid = "";
	private Div eachAttributeDiv;
	private List<String> operatorList=new ArrayList<String>();
	private String sitecode;
	
	private JSONObject  temp_agreementAttributesJson;
	private String formvalue;
	private Label existingFileNameLbl;
	private String KEY_NAME = "ADD_AGREEMENT_FORMVALUE";
	private AddSiteAgreementPopup popupobj;
	
	public String existingfileName;

	public AddSiteAgreement(SiteAgreementsTab siteAgreementsTab,String sitecode) {//Add Agreement
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.sitecode=sitecode;
		addAgreementsTabs = new Tabs();
		addAgreementsTabs.addClassName(SCREENCD+"_TABS");
		basicTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "BASIC_TAB_LBL"));
		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAILS_TAB_LBL"));

		addAgreementsTabs.add(basicTab, detailsTab);
	//	detailsTab.setEnabled(false);
		detailsTab.setEnabled(true);
		tabsVL = UIHtmlFieldFactory.createDiv(SCREENCD, "TABS_DIV");
		basicTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "BASIC_DIV");
		detailsTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_DIV");
		tabsVL.add(basicTabVL, detailsTabVL);

		basicTabVL.setVisible(true);
		detailsTabVL.setVisible(false);

		addAgreementsTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(basicTab)) {
					basicTabVL.setVisible(true);
					detailsTabVL.setVisible(false);

				} else if(event.getSelectedTab().equals(detailsTab)) {
					basicTabVL.setVisible(false);
					detailsTabVL.setVisible(true);

				} 
			}
		});

		agreementNameFld = UIFieldFactory.createTextField("", true, SCREENCD, "AGREEMENT_NAME_FIELD");
		//		paymentAmtFld = UIFieldFactory.createNumberField(true, SCREENCD, "PAYMENT_AMT_FIELD");
		//		escalationAmtFld = UIFieldFactory.createNumberField(false, SCREENCD, "ESCALATION_AMT_FIELD");
		populateAgreementTypeList();
		agreementtypeCombo = UIFieldFactory.createComboBox(agreementTypeList, true, SCREENCD, "AGREEMENT_TYPE_COMBO");

		agreementDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "AGREEMENT_DATE_FIELD");
		startDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "START_DATE_FIELD");
		endDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "END_DATE_FIELD_FIELD");
		Label agreementDocCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DOCUMENT_CAPTION");
		agreementDocDescFld = UIFieldFactory.createTextField("", false, SCREENCD, "AGREEMENT_DOC_DESC_FIELD");
		Label agreementDocUploadCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DOCUMENT_UPLOAD_CAPTION");
		//uploadButton = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BTN");
		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDiv.getUpload();
		existingFileNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EXISTING_FILE_NAME_LBL");
		uploadDiv.addComponentAsFirst(existingFileNameLbl);
		uploadDiv.getStyle().set("margin-top", "0px");
		uploadDiv.getStyle().set("width", "94%");
		uploadDoc.getStyle().set("width", "695px !important");
		((Button)uploadDoc.getUploadButton()).getStyle().set("margin-left", "290px");
		((Label)uploadDoc.getDropLabel()).getStyle().set("margin-left", "245px");
		((Image)uploadDoc.getDropLabelIcon()).getStyle().set("margin-left", "325px");
		//uploadDoc.addClassName("DOCUMENT_UPLOAD");
		uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif");

		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
					}
					if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
						fileFormat = "image/"+fileExtension.toLowerCase();
					}
					//fileName = uploadDiv.getFileName();
				} catch (Exception ex) {
					ex.printStackTrace();
					base64EncodedFileContent = "";
					//fileName = "";
				}

			}
		});

		/*uploadDoc.addFailedListener(e -> {
			base64EncodedFileContent = "";
		});*/

		uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
				event.getUpload().interruptUpload();
				//fileName = "";
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
				//fileName = "";
			}
		});
		
		uploadDoc.getElement().addEventListener("file-abort", event1 -> {
			base64EncodedFileContent="";
		});

		//		paymentFrequencyCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_FREQUENCY_LIST", ','), true, SCREENCD, "PAYMENT_FREQUENCY_FIELD");
		//		paymentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_TYPE_LIST", ','), true, SCREENCD, "PAYMENT_TYPE_FIELD");
		//		paymentModeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_MODE_LIST", ','), true, SCREENCD, "PAYMENT_MODE_FIELD");
		//		escalationFrequencyCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ESCALATION_FREQUENCY_LIST", ','), false, SCREENCD, "ESCALATION_FREQUENCY_FIELD");
		//		escalationTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ESCALATION_TYPE_LIST", ','), false, SCREENCD, "ESCALATION_TYPE_FIELD");

		AddSiteAgreementPopup popup = new AddSiteAgreementPopup("Add Agreement", true, this, siteAgreementsTab, SCREENCD);
		popupobj=popup;
		populateAgreementAttributes();
		basicTabVL.add(agreementNameFld, agreementDateFld, startDateFld, endDateFld,agreementtypeCombo, agreementDocCaption, agreementDocDescFld, agreementDocUploadCaption, uploadDiv/*, paymentFrequencyCombo, paymentAmtFld, paymentTypeCombo, paymentModeCombo, escalationFrequencyCombo,
				escalationTypeCombo, escalationAmtFld*/);
		add(addAgreementsTabs, tabsVL);
		
		setFormValue(sitecode);//save as draft
		
		try {
			partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public AddSiteAgreement(SiteAgreementsTab siteAgreementsTab, SiteAgreementDetailBean siteAgreementDetailBean, long agreementId, String agreementName, 
			String agreementDate, String startDate, String endDate,String agreementtype, String fileDesc, String fileName, boolean fileExist,/*, int paymentFrequency, double paymentAmt, int paymentUnit, int paymentMode, int escalationFrequency, 
			int escalationUnit, double escalationAmt*/String sitecode) {//Edit Agreement
		this.agreementId = agreementId;
		this.existingAgreementName = agreementName;
		this.existingFileDesc = fileDesc;
		this.existingFileName = fileName;
		this.fileExist = fileExist;
		this.agreementtype=agreementtype;
		this.sitecode=sitecode;
		
		this.existingfileName=fileName;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		addAgreementsTabs = new Tabs();
		addAgreementsTabs.addClassName(SCREENCD+"_TABS");
		basicTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "BASIC_TAB_LBL"));
		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAILS_TAB_LBL"));

		addAgreementsTabs.add(basicTab, detailsTab);
		tabsVL = UIHtmlFieldFactory.createDiv(SCREENCD, "TABS_DIV");
		basicTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "BASIC_DIV");
		detailsTabVL = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_DIV");
		tabsVL.add(basicTabVL, detailsTabVL);

		basicTabVL.setVisible(true);
		detailsTabVL.setVisible(false);

		addAgreementsTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(basicTab)) {
					basicTabVL.setVisible(true);
					detailsTabVL.setVisible(false);

				} else if(event.getSelectedTab().equals(detailsTab)) {
					basicTabVL.setVisible(false);
					detailsTabVL.setVisible(true);
					//getAgreementAttributes(agreementId+"");
				} 
			}
		});

		try {
			agreementNameFld = UIFieldFactory.createTextField(agreementName, true, SCREENCD, "AGREEMENT_NAME_FIELD");
			//			paymentAmtFld = UIFieldFactory.createNumberField(true, SCREENCD, "PAYMENT_AMT_FIELD");
			//			escalationAmtFld = UIFieldFactory.createNumberField(false, SCREENCD, "ESCALATION_AMT_FIELD");

			agreementDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "AGREEMENT_DATE_FIELD");
			startDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "START_DATE_FIELD");
			endDateFld = UIFieldFactory.createDatePicker(true, SCREENCD, "END_DATE_FIELD_FIELD");
			
			populateAgreementTypeList();
			agreementtypeCombo = UIFieldFactory.createComboBox(agreementTypeList, true, SCREENCD, "AGREEMENT_TYPE_COMBO");
			if(agreementtype.equalsIgnoreCase("1")) {
				agreementtypeCombo.setValue("Main Agreement");
			}else {
				agreementtypeCombo.setValue("Addendum Agreement");
			}
			
			
			Label agreementDocCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DOCUMENT_CAPTION");
			agreementDocDescFld = UIFieldFactory.createTextField(fileDesc, false, SCREENCD, "AGREEMENT_DOC_DESC_FIELD");
			Label agreementDocUploadCaption = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_DOCUMENT_UPLOAD_CAPTION");
			MemoryBuffer fileBuffer = new MemoryBuffer();
			uploadDiv = new UIUploadComponent(fileBuffer, false);
			Upload uploadDoc = uploadDiv.getUpload();
			existingFileNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EXISTING_FILE_NAME_LBL");
			existingFileNameLbl.setText(fileName);
			uploadDiv.addComponentAsFirst(existingFileNameLbl);
			uploadDiv.getStyle().set("margin-top", "0px");
			uploadDiv.getStyle().set("width", "94%");
			uploadDoc.getStyle().set("width", "695px !important");
			((Button)uploadDoc.getUploadButton()).getStyle().set("margin-left", "290px");
			((Label)uploadDoc.getDropLabel()).getStyle().set("margin-left", "245px");
			((Image)uploadDoc.getDropLabelIcon()).getStyle().set("margin-left", "325px");
			//uploadDoc.addClassName("DOCUMENT_UPLOAD");
			uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif");

			uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(FinishedEvent event) {

					try
					{
						uploadDiv.remove(existingFileNameLbl);
						String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
						if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx")) 
						{
							byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
							base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
							if(fileExtension.equalsIgnoreCase("pdf"))
							{
								fileFormat = "application/pdf";
							}
							if(fileExtension.equalsIgnoreCase("txt"))
							{
								fileFormat = "text/plain";
							}
							if(fileExtension.equalsIgnoreCase("doc"))
							{
								fileFormat = "application/msword";
							}
							if(fileExtension.equalsIgnoreCase("docx"))
							{
								fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
							}
						}
						if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
						{
							BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
							ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
							ImageIO.write(image, fileExtension, outputStream);
							base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
							fileFormat = "image/"+fileExtension.toLowerCase();
						}
						//fileName = uploadDiv.getFileName();
						//fileUploaded = true;
					} catch (Exception ex) {
						ex.printStackTrace();
						base64EncodedFileContent = "";
						//fileName = existingFileName;
					}

				}
			});

			/*uploadDoc.addFailedListener(e -> {
				base64EncodedFileContent = "";
			});*/
			
			uploadDoc.getElement().addEventListener("file-abort", event1 -> {
				base64EncodedFileContent="";
			});

			uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(FailedEvent event) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
					event.getUpload().interruptUpload();
					//fileName = existingFileName;
				}
			});

			uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(FileRejectedEvent event) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
					//fileName = existingFileName;
				}
			});
			//uploadButton = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BTN");
			//			paymentFrequencyCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_FREQUENCY_LIST", ','), true, SCREENCD, "PAYMENT_FREQUENCY_FIELD");
			//			paymentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_TYPE_LIST", ','), true, SCREENCD, "PAYMENT_TYPE_FIELD");
			//			paymentModeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "PAYMENT_MODE_LIST", ','), true, SCREENCD, "PAYMENT_MODE_FIELD");
			//			escalationFrequencyCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ESCALATION_FREQUENCY_LIST", ','), false, SCREENCD, "ESCALATION_FREQUENCY_FIELD");
			//			escalationTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ESCALATION_TYPE_LIST", ','), false, SCREENCD, "ESCALATION_TYPE_FIELD");

			AddSiteAgreementPopup popup = new AddSiteAgreementPopup("Edit Agreement", false, this, siteAgreementsTab, SCREENCD);
			popupobj=popup;
			populateAgreementAttributes();
			basicTabVL.add(agreementNameFld, agreementDateFld, startDateFld, endDateFld,agreementtypeCombo, agreementDocCaption, agreementDocDescFld, agreementDocUploadCaption, uploadDiv/*, paymentFrequencyCombo, paymentAmtFld, paymentTypeCombo, paymentModeCombo, escalationFrequencyCombo, escalationTypeCombo, escalationAmtFld*/);
			add(addAgreementsTabs, tabsVL);

			//			paymentAmtFld.setValue(paymentAmt);
			//			escalationAmtFld.setValue(escalationAmt);
			agreementDateFld.setValue(CommonUtils.convertStringToLocalDate(agreementDate, "dd-MMM-yyyy"));
			startDateFld.setValue(CommonUtils.convertStringToLocalDate(startDate, "dd-MMM-yyyy"));
			endDateFld.setValue(CommonUtils.convertStringToLocalDate(endDate, "dd-MMM-yyyy"));
			agreementDateFld.setEnabled(false);
			startDateFld.setEnabled(false);
			endDateFld.setEnabled(false);
			agreementtypeCombo.setEnabled(false);

			//			paymentFrequencyCombo.setValue(CommonUtils.getPaymentFrequencyCd(paymentFrequency));
			//			paymentTypeCombo.setValue(CommonUtils.getEscalationOrPaymentUnitCd(paymentUnit));
			//			paymentModeCombo.setValue(CommonUtils.getPaymentModeCd(paymentMode));
			//			escalationFrequencyCombo.setValue(CommonUtils.getEscalationFrequencyCd(escalationFrequency));
			//			escalationTypeCombo.setValue(CommonUtils.getEscalationOrPaymentUnitCd(escalationUnit));
			
			partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
			getSiteOperators();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	public boolean validation() {
		agreementNameFld.setInvalid(false);
		agreementDateFld.setInvalid(false);
		startDateFld.setInvalid(false);
		endDateFld.setInvalid(false);
		//		paymentFrequencyCombo.setInvalid(false);
		//		paymentAmtFld.setInvalid(false);
		//		paymentTypeCombo.setInvalid(false);
		//		paymentModeCombo.setInvalid(false);

		if (agreementNameFld.getValue()==null || agreementNameFld.getValue().trim().length()==0) {
			agreementNameFld.setInvalid(true);
			agreementNameFld.setErrorMessage("Please enter "+agreementNameFld.getLabel().toLowerCase());
			agreementNameFld.focus();
			addAgreementsTabs.setSelectedTab(basicTab);
			return false;
		}

		if (agreementDateFld.getValue()==null || agreementDateFld.getValue().toString().trim().length()==0) {
			agreementDateFld.setInvalid(true);
			agreementDateFld.setErrorMessage("Please enter "+agreementDateFld.getLabel().toLowerCase());
			agreementDateFld.focus();
			addAgreementsTabs.setSelectedTab(basicTab);
			return false;
		}

		if (startDateFld.getValue()==null || startDateFld.getValue().toString().trim().length()==0) {
			startDateFld.setInvalid(true);
			startDateFld.setErrorMessage("Please enter "+startDateFld.getLabel().toLowerCase());
			startDateFld.focus();
			addAgreementsTabs.setSelectedTab(basicTab);
			return false;
		}

		if (endDateFld.getValue()==null || endDateFld.getValue().toString().trim().length()==0) {
			endDateFld.setInvalid(true);
			endDateFld.setErrorMessage("Please enter "+endDateFld.getLabel().toLowerCase());
			endDateFld.focus();
			addAgreementsTabs.setSelectedTab(basicTab);
			return false;
		}
		
		if(agreementtypeCombo.getValue()==null) {
			agreementtypeCombo.setInvalid(true);
			agreementtypeCombo.setErrorMessage("Please enter "+agreementtypeCombo.getLabel().toLowerCase());
			agreementtypeCombo.focus();
			addAgreementsTabs.setSelectedTab(basicTab);
			return false;
		}

		if (!fileExist && existingFileName.trim().length()==0) {
			if (getAgreementFileName().trim().length()==0 || base64EncodedFileContent==null || base64EncodedFileContent.trim().length()==0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "FILE_UPLOAD_MANDATORY", ApplicationConstants.DialogTypes.ERROR);
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}
		}

		if(detailsTab.isEnabled())
		{
			detailsTabEnabled = true;
			//updateAttributeJson=new JSONObject();
			agreementAttributesJson=new JSONObject();
	//		Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			Iterator<String> itrKeys = updateddynamicAgreementAttributesMap.keySet().iterator();
			UIFileAttributeComponent fileAttributeComp = null;
			//System.out.println("dynamicAgreementAttributesMap="+dynamicAgreementAttributesMap.toString());
		/*	try {
				if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
				{	

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=dynamicAgreementAttributesMap.get(key);

						if(value.size()>0)	//value obj
						{	
							String datatype=dynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=dynamicAgreementAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":
								// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((ComboBox<Object>) dynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if(((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									agreementAttributesJson.put(key, ((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((TextField) dynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((TextField) dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									agreementAttributesJson.put(key, ((TextField) dynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((TextField) dynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if(((TextField)dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									agreementAttributesJson.put(key, ((TextField)dynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
								{
									agreementAttributesJson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).getValue(), "dd/MM/yyyy"));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAgreementAttributesMap.get(key).get(1)).toString().length()<=0)
								{
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((TextField) dynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((TextField) dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									agreementAttributesJson.put(key, ((TextField) dynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							}
						}	
					}
					//					updateAttributeJson.put("SiteCode", getSiteCode());
					//					updateAttributeJson.put("AgreementId", getAgreementId());
					//					updateAttributeJson.put("AgreementAttributes",agreementAttributesJson);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}*/
			try {
				if(updateddynamicAgreementAttributesMap!=null && updateddynamicAgreementAttributesMap.size()>0)
				{	

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=updateddynamicAgreementAttributesMap.get(key);

						if(value.size()>0)	//value obj
						{	
							String datatype=updateddynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=updateddynamicAgreementAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":
								// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((ComboBox<Object>) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if(((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									agreementAttributesJson.put(key, ((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
						//		if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								if (mandatory.equalsIgnoreCase("1")&&((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
								{
									agreementAttributesJson.put(key, ((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if(((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									agreementAttributesJson.put(key, ((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
								{
									agreementAttributesJson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue(), "dd/MM/yyyy"));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).toString().length()<=0)
								{
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
									((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if (((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									agreementAttributesJson.put(key, ((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
								}
								break;
								
							case "BOOLEAN"://AbhraC
								agreementAttributesJson.put(key, ((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).getValue());
								break;
							case "MULTIPLE SELECTION":
								CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) dynamicAgreementAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
									addAgreementsTabs.setSelectedTab(detailsTab);
									return false;
								}
								if(!checkboxGroup.isEmpty()) {
									agreementAttributesJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
								}
								break;
							case "IMAGE FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return false;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "TEXT FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return false;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							case "CUSTOM FILE":
								fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
								if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
									SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
									return false;
								}
								if(fileAttributeComp.getFileJSON() != null) {
									agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
								}
								break;
							}
						}	
					}
					//					updateAttributeJson.put("SiteCode", getSiteCode());
					//					updateAttributeJson.put("AgreementId", getAgreementId());
					//					updateAttributeJson.put("AgreementAttributes",agreementAttributesJson);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		//		if (paymentFrequencyCombo.getValue()==null || paymentFrequencyCombo.getValue().trim().length()==0) {
		//			paymentFrequencyCombo.setInvalid(true);
		//			paymentFrequencyCombo.setErrorMessage("Please enter "+paymentFrequencyCombo.getLabel().toLowerCase());
		//			return false;
		//		}
		//
		//		if (paymentAmtFld.getValue()==null) {
		//			paymentAmtFld.setInvalid(true);
		//			paymentAmtFld.setErrorMessage("Please enter "+paymentAmtFld.getLabel().toLowerCase());
		//			return false;
		//		}
		//
		//		if (paymentTypeCombo.getValue()==null || paymentTypeCombo.getValue().trim().length()==0) {
		//			paymentTypeCombo.setInvalid(true);
		//			paymentTypeCombo.setErrorMessage("Please enter "+paymentTypeCombo.getLabel().toLowerCase());
		//			return false;
		//		}
		//
		//		if (paymentModeCombo.getValue()==null || paymentModeCombo.getValue().trim().length()==0) {
		//			paymentModeCombo.setInvalid(true);
		//			paymentModeCombo.setErrorMessage("Please enter "+paymentModeCombo.getLabel().toLowerCase());
		//			return false;
		//		}
		return true;
	}
	
	public String getMultiSelectValue(Set<String> selectedItems) throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachVal = iterator.next();
			jsonArray.put(eachVal);
		}

		retVal.put("MultiSelectValue", jsonArray.toString());

		return retVal.toString();
	}


	public long getAgreementId() {
		return agreementId;
	}

	public String getAgreementName() {
		if (agreementNameFld.getValue()==null)
			return "";
		else
			return agreementNameFld.getValue();
	}
	
	public String getExistingAgreementName() {
		return existingAgreementName;
	}
	
	
	public int getAgreementType() {
		int type = 0;
		
		if(agreementtypeCombo.getValue()!=null) {
			 if(agreementtypeCombo.getValue().equalsIgnoreCase("Main Agreement")){
					type= 1;
				}	else if(agreementtypeCombo.getValue().equalsIgnoreCase("Addendum Agreement")){
					type=2;
				}else {
					
				}
				
		}
		
		return type;
			
	}

	//	public String getPaymentAmt() {
	//		if (paymentAmtFld.getValue()==null)
	//			return "";
	//		else
	//			return paymentAmtFld.getValue()+"";
	//	}
	//
	//	public String getEscalationAmt() {
	//		if (escalationAmtFld.getValue()==null)
	//			return "";
	//		else
	//			return escalationAmtFld.getValue()+"";
	//	}
	//
	//	public String getPaymentFrequency() {
	//		if (paymentFrequencyCombo.getValue()==null)
	//			return "";
	//		else
	//			return paymentFrequencyCombo.getValue();
	//	}
	//
	//	public String getPaymentType() {
	//		if (paymentTypeCombo.getValue()==null)
	//			return "";
	//		else
	//			return paymentTypeCombo.getValue();
	//	}
	//
	//	public String getPaymentMode() {
	//		if (paymentModeCombo.getValue()==null)
	//			return "";
	//		else
	//			return paymentModeCombo.getValue();
	//	}
	//
	//	public String getEscalationFrequency() {
	//		if (escalationFrequencyCombo.getValue()==null)
	//			return "";
	//		else
	//			return escalationFrequencyCombo.getValue();
	//	}
	//
	//	public String getEscalationType() {
	//		if (escalationTypeCombo.getValue()==null)
	//			return "";
	//		else
	//			return escalationTypeCombo.getValue();
	//	}


	public String getAgreementDate() {
		if (agreementDateFld.getValue()==null || agreementDateFld.getValue().toString().trim().length()==0)
			return "";
		else
			return CommonUtils.convertLocalDateToString(agreementDateFld.getValue(), "MM/dd/yyyy");
	}

	public String getStartDate() {
		if (startDateFld.getValue()==null || startDateFld.getValue().toString().trim().length()==0)
			return "";
		else
			return CommonUtils.convertLocalDateToString(startDateFld.getValue(), "MM/dd/yyyy");
	}

	public String getEndDate() {
		if (endDateFld.getValue()==null || endDateFld.getValue().toString().trim().length()==0)
			return "";
		else
			return CommonUtils.convertLocalDateToString(endDateFld.getValue(), "MM/dd/yyyy");
	}

	public String getAgreementDocDesc() {
		if (agreementDocDescFld.getValue()==null)
			return "";
		else
			return agreementDocDescFld.getValue();
	}
	
	public String getExistingFileDesc() {
		return existingFileDesc;
	}

	public String getAgreementFileName() {
		
		if (uploadDiv.getFileName()==null)
			return "";
		else
			return uploadDiv.getFileName();

		//		if (uploadDiv.getFileName()!=null && uploadDiv.getFileName().trim().length()>0) {
		//			return uploadDiv.getFileName();
		//		} else if (fileName!=null && fileName.trim().length()>0) {
		//			return fileName;
		//		}
		//		return "";
	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
		if (detailsTab.isEnabled()) {
			setAgreementAttributes(this.agreementId+"");
		}
	}
	public void setSiteCode2(String siteCode) {
		this.siteCode = siteCode;
//		System.out.println("this.siteCode=="+this.siteCode);
//		if (detailsTab.isEnabled()) {
//			setAgreementAttributes(this.agreementId+"");
//		}
	}

	public String getBase64EncodedFileContent() {
		if (base64EncodedFileContent==null)
			return "";
		else
			return base64EncodedFileContent;
	}

	public void setBase64EncodedFileContent(String base64EncodedFileContent) {
		this.base64EncodedFileContent = base64EncodedFileContent;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public JSONObject getAgreementAttributesJson() {
		return agreementAttributesJson;
	}
	public JSONObject getTempAgreementAttributesJson() {
		return temp_agreementAttributesJson;
	}
	
	 
	
	public JSONObject getExistingAgreementAttributesJson() {
		return existingAgreementAttributesJson;
	}

	public boolean isDetailsTabEnabled() {
		return detailsTabEnabled;
	}
	
	/*public boolean sendFileDetails() {
		if (fileUploaded && getAgreementFileName().trim().length()>0)
			return true;
		else
			return false;
	}*/

	public void enableDetailsTab(String agreementId)
	{
		detailsTab.setEnabled(true);
		populateAgreementAttributes();
		setAgreementAttributes(agreementId);
		this.agreementId = Long.parseLong(agreementId);
		//System.out.println("AgreementId ::::::: "+agreementId);
		agreementDateFld.setEnabled(false);
		startDateFld.setEnabled(false);
		endDateFld.setEnabled(false);
		//getSiteAgreements(agreementId);
	}

	private void populateAgreementAttributes()
	{
		detailsTabVL.removeAll();
	//	dynamicAgreementAttributesMap = new HashMap<>();
	//	updateddynamicAgreementAttributesMap=new HashMap<>();
		
		dynamicAgreementAttributesMap = new LinkedHashMap<>();
		updateddynamicAgreementAttributesMap=new LinkedHashMap<>();
		try {
			JSONArray allAttributes = retrieveAgreementLevelAttributes();
			UIFileAttributeComponent fileAttribComp = null;
			eachAttributeDiv = null;
			for(int i=0; i<allAttributes.length(); i++)
			{
				JSONObject js=allAttributes.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				//Iterator<String> keys = js.keys();
				//Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ATTR_DATA_DIV");


				String attrname=js.getString("AttributeName");
				String defaultval= "";
				if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
					defaultval=js.getString("DefaultValue");
				}
				String mandatoryFlag=js.getString("Mandatory").toString();
				String attributeDatatype=js.getString("AttributeDatatype");
				
				eachAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ATTRIBUTE_FLD_DIV");

				switch(attributeDatatype.toString()/*key.toUpperCase()*/)
				{
				case "5":
					String datatype="FLOV";
					List<String> choiceList=new ArrayList<String>();
					String str=js.getString("FLOV");
					String flovVal[]=str.split(",");
					choiceList.clear();
					for(String s:flovVal)
					{
						choiceList.add(s);
					}
					ComboBox<String> attributeComboBox = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "ATTRIBUTE_COMBO_FIELD");
					attributeComboBox.setLabel(attrname);
					//attributeComboBox.setInvalid(false);
					if(defaultval.length()>0)
					{
						attributeComboBox.setValue(defaultval);
					}
					//	attrrow.add(attributeComboBox);

					dataTypeList.add(datatype);
					dataTypeList.add(attributeComboBox);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					//	additionalAttrDiv.add(attributeComboBox);
					if(mandatoryFlag.equals("1"))
					{

						attributeComboBox.setRequired(true);
						attributeComboBox.setErrorMessage("");
						attributeComboBox.setRequiredIndicatorVisible(true);
						
						attributeComboBox.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
							
							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<String> event) {
								String value = event.getValue();
								if (value != null) {
									attributeComboBox.setInvalid(false);
									attributeComboBox.setErrorMessage("");
								}else {
									attributeComboBox.setInvalid(true);
									attributeComboBox.focus();
									attributeComboBox.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
								}

							}
						});
					}
				//	detailsTabVL.add(attributeComboBox);
					eachAttributeDiv.add(attributeComboBox);
					
					if(attrname.equalsIgnoreCase("Operators")) {
						getSiteOperators();
						attributeComboBox.setItems(operatorList);
					}
					break;
				case "1":
				/*	datatype="NUMERIC";
					TextField attributeNumberTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					//	numberField.getStyle().set("width", "48.2%");
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(defaultval);
					}
					//	additionalAttrDiv.add(numberField);
					// 	attrrow.add(numberField);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					attributeNumberTxtFld.setValueChangeMode(ValueChangeMode.EAGER);
					attributeNumberTxtFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
							if(!arg0.getValue().toString().matches("^\\w*$"))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
						}
					});
				//	detailsTabVL.add(attributeNumberTxtFld);
					eachAttributeDiv.add(attributeNumberTxtFld);*/
					datatype="NUMERIC";
					NumberField attributeNumberTxtFld = UIFieldFactory.createNumberField(false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(Double.parseDouble(defaultval));
					}
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					eachAttributeDiv.add(attributeNumberTxtFld);
					break;
				case "4":
					datatype="DATE";
					DatePicker attributeDateFld = UIFieldFactory.createDatePicker(false, SCREENCD, "ATTRIBUTE_DATE_FIELD");
					attributeDateFld.setLabel(attrname);
					//	attributeDateFld.getStyle().set("width", "48.2%");
					//	additionalAttrDiv.add(attributeDateFld);
					//	attrrow.add(attributeDateFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeDateFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeDateFld.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
					}
					if(mandatoryFlag=="1")
					{
						attributeDateFld.setRequired(true);
						attributeDateFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeDateFld);
					eachAttributeDiv.add(attributeDateFld);
					break; 
				case "3":
					datatype="FREEFLOW";
					TextField attributeFreeflowFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeFreeflowFld.setLabel(attrname);
					//	attributeFreeflowFld.getStyle().set("width", "48.2%");
					attributeFreeflowFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeFreeflowFld);
					//	attrrow.add(attributeFreeflowFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeFreeflowFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeFreeflowFld.setRequired(true);
						attributeFreeflowFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeFreeflowFld);
					eachAttributeDiv.add(attributeFreeflowFld);
					break;
				case "2":
					datatype="ALPHANUMERIC";
					TextField attributeAlphanumericFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeAlphanumericFld.setLabel(attrname);
					//	attributeAlphanumericFld.getStyle().set("width", "48.2%");
					attributeAlphanumericFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeAlphanumericFld);
					//	attrrow.add(attributeAlphanumericFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeAlphanumericFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeAlphanumericFld.setRequired(true);
						attributeAlphanumericFld.setRequiredIndicatorVisible(true);
					}
					attributeAlphanumericFld.setValueChangeMode(ValueChangeMode.EAGER);
					attributeAlphanumericFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
							{
								attributeAlphanumericFld.setValue(arg0.getOldValue().toString());
							}
						}
					});
					//detailsTabVL.add(attributeAlphanumericFld);
					eachAttributeDiv.add(attributeAlphanumericFld);
				case "6":
					datatype = "BOOLEAN";
					Checkbox booleanFld=UIFieldFactory.createCheckbox(false,false, SCREENCD, "VALUE");
					booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
					booleanFld.addClassName(SCREENCD + "_VALUE");
					booleanFld.setLabel(attrname);
					if(defaultval != null && defaultval.trim().toLowerCase().equals("true")) {
						booleanFld.setValue(true);
					} else {
						booleanFld.setValue(false);
					}
					
					dataTypeList.add(datatype);
					dataTypeList.add(booleanFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(booleanFld);
					eachAttributeDiv.add(booleanFld);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "7":
					datatype = "MULTIPLE SELECTION";
					CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
					multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
					multiSelectFld.addClassName(SCREENCD + "_VALUE");
					multiSelectFld.setLabel(attrname);
					String possibleValues = js.getString("FLOV");
					renderMultiSelectField(multiSelectFld, possibleValues, defaultval, "",attrname);
										
					dataTypeList.add(datatype);
					dataTypeList.add(multiSelectFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(multiSelectFld);
					eachAttributeDiv.add(multiSelectFld);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "8":
					datatype = "IMAGE FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 8);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "9":
					datatype = "TEXT FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 9);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "10":
					datatype = "CUSTOM FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 10);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				default:
					break;   
				}
				detailsTabVL.add(eachAttributeDiv);
				dynamicAgreementAttributesMap.put(attrname,dataTypeList);
				updateddynamicAgreementAttributesMap.put(attrname,dataTypeList);

			}
			
			attributeUIOrchestration();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected String getFileURL(String fileId) {
		String retVal = "";
		try {
			String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
			if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
				retVal = truebyl_domain + "RuleServer/files/" + partitionid + "/SiteService/" + fileId + "/stream";
			}
			else
			{
				retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/SiteService/" 
						       + fileId + "/stream";
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
				       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/SiteService/" 
				       + fileId + "/stream";	
		}
		return retVal;
	}
	
	protected Div renderFileUploadComponent(String aname, int adatatype) {
		Div fileAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ATTRIB_DIV");
		Button fileAttributeBtn = UIFieldFactory.createButton(SCREENCD, "FILE_ATTRIB_BTN");
		fileAttributeBtn.setText(SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "FILE_ATTRIB_BTN"));
		
		fileAttributeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				String [] acceptedFileTypes = null;
				if(adatatype == 8) {
					acceptedFileTypes = ".png,.jpg,.jpeg,.gif,.bmp".split("[,]");
				} else if(adatatype == 9) {
					acceptedFileTypes = ".txt".split("[,]");
					//uploadDoc.setAcceptedFileTypes(".txt");
				} else if(adatatype == 10) {
					//uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif",".bmp",".xls",".xlsx");
					acceptedFileTypes = ".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.bmp,.xls,.xlsx".split("[,]");
				}

				FileTypeAttributeUploadDialog uploadDlg = new FileTypeAttributeUploadDialog(aname, "Agreement File Attribute", acceptedFileTypes);
				uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						FileTypeAttributeUploadDialog dlg = (FileTypeAttributeUploadDialog)event.getSource();
						if(!dlg.isOpened()) {
							if(dlg.isGetDocUploadStatus()) {
								JSONObject fileDetailJSON = dlg.getFileDetail();
								if(fileDetailJSON != null && fileDetailJSON.length() > 0) {
									fileAttributeMap.put(aname, fileDetailJSON);
								}
								else {
									fileAttributeMap.remove(aname);
								}
							}
							else {
								fileAttributeMap.remove(aname);
							}
						}
					}
				});
			}
		});
		
		Label fileAttributeLbl = UIHtmlFieldFactory.createLabel(aname, SCREENCD, "FILE_ATTRIB_LBL");
		fileAttributeDiv.add(fileAttributeLbl, fileAttributeBtn);
		return fileAttributeDiv;
	}
	
/*	protected void renderMultiSelectField(CheckboxGroup<String> multiSelectFld, String possibleValues, String defaultValue, 
			String attributeValue,String attributeName) {
		try {
			
			JSONObject json = new JSONObject(possibleValues);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));
			



			List<String> possibleValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				possibleValuesList.add(jsonArray.getString(i));
			}
			
			json = new JSONObject(defaultValue);

			jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));
			
			List<String> defaultValuesList = new ArrayList<String>();
			if(attributeName.equalsIgnoreCase("Operators")) {
				getSiteOperators();
				for(int i=0;i<operatorList.size();i++) {
					defaultValuesList.add(operatorList.get(i));
				}
			}else {
				for (int i = 0; i < jsonArray.length(); i++) {
					defaultValuesList.add(jsonArray.getString(i));
				}
			}
			
			
			multiSelectFld.setItems(possibleValuesList);
			
			if(attributeValue==null || attributeValue.equals("-") || attributeValue.equals("")) {
				multiSelectFld.select(defaultValuesList);
			} else {
				json = new JSONObject(attributeValue);
				jsonArray = new JSONArray(json.getString("MultiSelectValue"));
				List<String> attributeValuesList = new ArrayList<String>();
				for (int i = 0; i < jsonArray.length(); i++) {
					attributeValuesList.add(jsonArray.getString(i));
				}
				multiSelectFld.select(attributeValuesList);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/	
	
	protected void renderMultiSelectField(CheckboxGroup<String> multiSelectFld, String possibleValues, String defaultValue, 
			String attributeValue,String attributeName) {
		try {
			
			JSONObject json = new JSONObject(possibleValues);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));
			
			
			List<String> possibleValuesList = new ArrayList<String>();
			if(attributeName.equalsIgnoreCase("Operators")) {
				getSiteOperators();
				if(operatorList.size()>0) {
					for(int i=0;i<operatorList.size();i++) {
						possibleValuesList.add(operatorList.get(i));
					}
				}else {//no operators present
					for (int i = 0; i < jsonArray.length(); i++) {
						possibleValuesList.add(jsonArray.getString(i));
					}
					multiSelectFld.setEnabled(false);
				}
				
			}else {
				for (int i = 0; i < jsonArray.length(); i++) {
					possibleValuesList.add(jsonArray.getString(i));
				}
			}
			
			json = new JSONObject(defaultValue);

			jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));
			
			List<String> defaultValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				defaultValuesList.add(jsonArray.getString(i));
			}

			multiSelectFld.setItems(possibleValuesList);
			
			if(attributeValue==null || attributeValue.equals("-") || attributeValue.equals("")) {
				if(attributeName.equalsIgnoreCase("Operators") && operatorList.size()>0) {
					multiSelectFld.deselect(possibleValuesList);
				}else if(attributeName.equalsIgnoreCase("Operators") && operatorList.size()<=0){
					multiSelectFld.deselect(possibleValuesList);
				}else if(!attributeName.equalsIgnoreCase("Operators")) {
					multiSelectFld.select(defaultValuesList);
				}else {}
			}else {
				json = new JSONObject(attributeValue);
				jsonArray = new JSONArray(json.getString("MultiSelectValue"));
				List<String> attributeValuesList = new ArrayList<String>();
				for (int i = 0; i < jsonArray.length(); i++) {
					attributeValuesList.add(jsonArray.getString(i));
				}
				multiSelectFld.select(attributeValuesList);
			}
		
			
/*			if(attributeValue==null || attributeValue.equals("-") || attributeValue.equals("")) {
				multiSelectFld.select(defaultValuesList);
				//multiSelectFld.setItemEnabledProvider(item->!defaultValuesList.equals(item));
				if(attributeName.equalsIgnoreCase("Operators")) {
//					for (String key : defaultValuesList) {
//						System.out.println("key=="+key);
//					//	multiSelectFld.setItemEnabledProvider(item->key.equals(item));
//						multiSelectFld.setItemEnabledProvider(item->{
//							System.out.println("item="+item);
//							return !key.equals(item);
//							
//						});
//						
//					}
					
				//	multiSelectFld.setItemEnabledProvider(item->"Airtel".equals(item));
			//		multiSelectFld.setItemEnabledProvider(item->"RJIO".equals(item));
//					for(int i=0;i<possibleValuesList.size();i++) {
//						for (String key : defaultValuesList) {
//							if(!key.equalsIgnoreCase(possibleValuesList.get(i))) {
//								multiSelectFld.setEnabled(false);
//								
//							}
//						}
//					}
					
//					for (String key : defaultValuesList) {
//					multiSelectFld.getElement().getChildren().forEach(child -> {
//					    child.getComponent().ifPresent(component -> {
//					        if (component instanceof Checkbox) {
//					            final Checkbox checkbox = (Checkbox) component;
//					         //   for (String key : defaultValuesList) {
//					            //	System.out.println("checkbox.getLabel()="+checkbox.getLabel());
//						            if(checkbox.getLabel().equalsIgnoreCase(key)) {
//						            	child.setEnabled(false);
//						            	System.out.println("child.isEnabled()="+child.isEnabled());
//						            }
//					          //  }
//					        }
//					    });
//					});
//					}
					
				}
				
			}*/ 
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	private void setAgreementAttributes(String agreementId)
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETAGREEMENTATTRIBUTES");
			url = url + "?SiteCode=" + URLEncoder.encode(getSiteCode())+"&AgreementId="+agreementId;
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			System.out.println("setAgreementAttributes response ::::::: "+response);
			existingAgreementAttributesJson = new JSONObject(response);
			Iterator<String> attributeNames = existingAgreementAttributesJson.keys();
			while (attributeNames.hasNext()) {
				String attributeName = (String) attributeNames.next();
				if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
				{
					Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
					while (itrKeys.hasNext()) {
						String key = (String) itrKeys.next();
						if (attributeName.equals(key)) {
							List<Object> value=dynamicAgreementAttributesMap.get(key);
							if(value.size()>0)	//value obj
							{	
								String datatype=dynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
								//String mandatory=dynamicAgreementAttributesMap.get(key).get(2).toString();
								switch(datatype)
								{
								case "FLOV":
									((ComboBox<Object>) dynamicAgreementAttributesMap.get(key).get(1)).setValue(existingAgreementAttributesJson.getString(attributeName));							
									break;
								case "NUMERIC":
									if(existingAgreementAttributesJson.getString(attributeName).length()>0) {
										((NumberField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(Double.parseDouble(existingAgreementAttributesJson.getString(attributeName)));
									}
									
									break;
								case "ALPHANUMERIC":
									((TextField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(existingAgreementAttributesJson.getString(attributeName));
									break;
								case "DATE":
									if(existingAgreementAttributesJson.getString(attributeName).length()>0) {
										((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).setValue(CommonUtils.convertStringToLocalDate(
												existingAgreementAttributesJson.getString(attributeName), "dd/MM/yyyy"));
									}
									
									break;
								case "FREEFLOW":
									((TextField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(existingAgreementAttributesJson.getString(attributeName));
									break;
								case "BOOLEAN":
									String boolValue = existingAgreementAttributesJson.getString(attributeName);
									if(boolValue != null && boolValue.trim().length() > 0 && boolValue.trim().equalsIgnoreCase("true")) {
										((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).setValue(true);
									} else {
										((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).setValue(false);
									}
									break;
								case "MULTIPLE SELECTION":
									String multiSelectValue = existingAgreementAttributesJson.getString(attributeName);
									setMultiSelectValue(((CheckboxGroup<String>) dynamicAgreementAttributesMap.get(key).get(1)), multiSelectValue);
									break;
								case "IMAGE FILE":
									setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), existingAgreementAttributesJson.getString(attributeName));
									break;
								case "TEXT FILE":
									setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), existingAgreementAttributesJson.getString(attributeName));
									break;
								case "CUSTOM FILE":
									setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), existingAgreementAttributesJson.getString(attributeName));
									break;
								default :

								}
							}
							break;
						}
					}
				}		
			}
		} catch(Exception e) {
			e.printStackTrace();
		}		

	}
	
	private void setFileAttributeValue(UIFileAttributeComponent fileAttributeComponent, String fileAttributeValue) {
	//	System.out.println("fileAttributeValue==="+fileAttributeValue);
		if(fileAttributeValue == null || fileAttributeValue.trim().length() == 0) {
			return;
		}
		
		try {
			JSONObject fileDetailJSON = new JSONObject(fileAttributeValue);
			fileAttributeComponent.setFileDetail(fileDetailJSON);
			String href = getFileURL(fileDetailJSON.getString("UUID"));
			fileAttributeComponent.setFileLink(fileDetailJSON.getString("Name"), href); 
			//fileAttributeMap.put(attributeName, new );
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	private void setMultiSelectValue(CheckboxGroup<String> field, String multiSelectValue) {
		//System.out.println("multiSelectValue=="+multiSelectValue);
		if(multiSelectValue == null || multiSelectValue.trim().length() == 0) {
			return;
		}
		try {
			JSONObject json = new JSONObject(multiSelectValue);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectValue"));
			List<String> attributeValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				attributeValuesList.add(jsonArray.getString(i));
			}
			field.select(attributeValuesList);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private JSONArray retrieveAgreementLevelAttributes()
	{
		String res = "",res1="";
		JSONArray eachAgreementAttrJsArr=new JSONArray();
		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");
			res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("Agreementattr="+res);
			
		/*	res = "[{\"AttributeId\":247,\"AttributeName\":\"Clamp Charges\",\"AttributeType\":10,\"AttributeDatatype\":5,\"Mandatory\":1,\"DefaultValue\":"
					+ "\"Not Applicable\",\"FLOV\":\"Applicable,Not Applicable\"},{\"AttributeId\":248,\"AttributeName\":\"Frequency of Leaky Clamp Charges\","
					+ "\"AttributeType\":10,\"AttributeDatatype\":5,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"Fixed,Monthly,Quarterly,Half-Yearly,Yearly\"},"
					+ "{\"AttributeId\":249,\"AttributeName\":\"Clamp Charges Amount\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":"
					+ "\"\",\"FLOV\":\"\"},{\"AttributeId\":250,\"AttributeName\":\"Clamp Charges w e f\",\"AttributeType\":10,\"AttributeDatatype\":4,\"Mandatory\":0,"
					+ "\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":251,\"AttributeName\":\"Clamp Charges Escalation frequency\",\"AttributeType\":10,"
					+ "\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":252,\"AttributeName\":"
					+ "\"Clamp Charges Escalation Rate\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},"
					+ "{\"AttributeId\":253,\"AttributeName\":\"Clamp Charges Escalation Start Date\",\"AttributeType\":10,\"AttributeDatatype\":4,\"Mandatory\":0,"
					+ "\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":254,\"AttributeName\":\"Cable Tray Charges\",\"AttributeType\":10,\"AttributeDatatype\":5,"
					+ "\"Mandatory\":1,\"DefaultValue\":\"Not Applicable\",\"FLOV\":\"Applicable,Not Applicable\"},{\"AttributeId\":255,\"AttributeName\":\"Frequency of Cable Tray Charges\",\"AttributeType\":10,\"AttributeDatatype\":5,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"Fixed,Monthly,Quarterly,Half-Yearly,Yearly\"},{\"AttributeId\":256,\"AttributeName\":\"Cable Tray Charges Amount\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":257,\"AttributeName\":\"Cable Tray Charges w e f\",\"AttributeType\":10,\"AttributeDatatype\":4,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":258,\"AttributeName\":\"Cable Tray Charges Escalation frequency\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":259,\"AttributeName\":\"Cable Tray Charges Escalation Rate\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":260,\"AttributeName\":\"Cable Tray Charges Escalation Start Date\",\"AttributeType\":10,\"AttributeDatatype\":4,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":261,\"AttributeName\":\"FCU Charges Fixed\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"},{\"AttributeId\":262,\"AttributeName\":\"FCU Charges Per Month\",\"AttributeType\":10,\"AttributeDatatype\":1,\"Mandatory\":0,\"DefaultValue\":\"\",\"FLOV\":\"\"}]";
					*/
		} 
		catch (Exception e) {
			if(e.getMessage().contains("AppException-Access Violation")) {
				popupobj.saveAsDraft_btn.setEnabled(false);
				popupobj.clearDraft_btn.setEnabled(false);
				popupobj.save_btn.setEnabled(false);
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			return null;
		}

		try {
			if (res != null) {
				JSONArray ja = new JSONArray(res);
				for (int i = 0; i < ja.length(); i++) {
					if (ja.getJSONObject(i).getInt("AttributeType")==10) {
						eachAgreementAttrJsArr.put(ja.getJSONObject(i));
					}
				}
				System.out.println("Agreement Array= "+eachAgreementAttrJsArr);
			}
		}
		catch(JSONException ex)
		{
			ex.printStackTrace();	
		}
		return eachAgreementAttrJsArr;

	}
	
	private void attributeUIOrchestration() {
		
		System.out.println("dynamicAgreementAttributesMap="+dynamicAgreementAttributesMap.toString());
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Rent Status") || key.equalsIgnoreCase("EMD")|| key.equalsIgnoreCase("BG")
						||key.equalsIgnoreCase("Security Deposit") || key.equalsIgnoreCase("Space Charges")
						||key.equalsIgnoreCase("Maintenance")||key.equalsIgnoreCase("Leaky Cable")
						||key.equalsIgnoreCase("Clamp Charges")||key.equalsIgnoreCase("Cable Tray Charges")
						||key.equalsIgnoreCase("Agreement Registration") || key.equalsIgnoreCase("Security Amount Basis")
						|| key.equalsIgnoreCase("Escalation Basis")|| key.equalsIgnoreCase("Space Charges Frequency")
						||key.equalsIgnoreCase("Frequency of Maintenance Charges")
						||key.equalsIgnoreCase("Frequency of Leaky Cable Charges")
						||key.equalsIgnoreCase("Frequency of Leaky Clamp Charges")
						||key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
					if(keyvalue.size()>0)	//value obj
					{	
						String datatype=keyvalue.get(0).toString().toUpperCase();
						switch(datatype)
						{
						case "FLOV":
							if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
								attributeVisibility3(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(),key);
								
							}
							((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
								private static final long serialVersionUID = 1L;
		
								@Override
								public void valueChanged(ValueChangeEvent<?> event) {
									if (event.getValue() != null) {
										attributeVisibility3(event.getValue().toString().trim(),key);
									
										if(key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
										//	System.out.println("insude2");
										}
									}
								}
							});
							
							break;
						}
					}
				}

		
			}
			
		}		
		
	}

  protected void attributeVisibility2(String combovalue,String keyname) {
	if(combovalue.equalsIgnoreCase("FOC")&& keyname.equalsIgnoreCase("Rent Status")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Rent")) {
					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);/
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Rent Escalation")) {
					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Rent Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Rent Expiry Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Rent Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Rent Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
			/*	else if(key.equalsIgnoreCase("Escalation Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Escalation Percentage")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}*/
				else if(key.equalsIgnoreCase("Escalation Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						((ComboBox<Object>) keyvalue.get(1)).setValue("Not Applicable");
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Operators")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Auto Rentals")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Payment Day of Month")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
			}

		}
		
	}
	else if(keyname.equalsIgnoreCase("Rent Status") && (combovalue.equalsIgnoreCase("Per Operator") || 
			combovalue.equalsIgnoreCase("Operator Wise")|| 
			combovalue.equalsIgnoreCase("Upto 2 Operator")|| 
			combovalue.equalsIgnoreCase("Upto 3 Operator"))) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Operators")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						
					}
				}if(key.equalsIgnoreCase("Rent")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Rent Escalation")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Rent Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Rent Expiry Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					//	keyvalue.set(2,"1");
						custommandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Rent Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Rent Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Escalation Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Auto Rentals")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Payment Day of Month")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else {}
			}

		}
		
	}
	else if(keyname.equalsIgnoreCase("Escalation Basis") && !combovalue.equalsIgnoreCase("Not Applicable")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Escalation Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Escalation Percentage")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
			}

		}
		
	}
	else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("EMD")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("EMD Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("BG")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("BG Period")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("BG Claim Period")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("BG Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
			}

		}
		
	}
	/*else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Security Deposite")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Amount Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposite Month")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						//mandatoryFields(datatype,keyvalue);
						custommandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
				//		keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else {}
			}

		}
		
	}
	//else if(combovalue.equalsIgnoreCase("Fixed Amount")&& keyname.equalsIgnoreCase("Security Amount Basis")) {
	else if(combovalue.equalsIgnoreCase("Base on Lease Rent")&& keyname.equalsIgnoreCase("Security Amount Basis")) {//chnged on 9thMay based on uat requirement
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposite Month")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					   	custommandatoryFields(datatype,keyvalue);
					   	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
				//		mandatoryFields(datatype,keyvalue);
				 		custommandatoryFields(datatype,keyvalue);
				 		keyvalue.set(2,"0");
				//		keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else {}
			}
		}
	}*/
	else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Security Deposit")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Amount Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Month")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else {}
			}

		}
		
	}
	//else if(combovalue.equalsIgnoreCase("Fixed Amount")&& keyname.equalsIgnoreCase("Security Amount Basis")) {
//	else if(combovalue.equalsIgnoreCase("Fixed Amount") && keyname.equalsIgnoreCase("Security Amount Basis")) {
//		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
//		{	
//			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
//			while (itrKeys.hasNext()) 
//			{
//				String key = itrKeys.next();
//				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
//				if(key.equalsIgnoreCase("Security Deposit Amount")) {
//					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
//					}
//				}
//			}
//		}
//	}
	else if(combovalue.equalsIgnoreCase("Base on Lease Rent") && keyname.equalsIgnoreCase("Security Amount Basis")) {//chnged on 9thMay based on uat requirement
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Month")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						//mandatoryFields(datatype,keyvalue);
						custommandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
//				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
//					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
//					}
//				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
				//		keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					 	custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
					//	keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
				
			}
		}
	}
	else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Space Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
			//	if(key.equalsIgnoreCase("Space Charges Type")) {
				if(key.equalsIgnoreCase("Space Charges Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charge w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Additional Space")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Maintenance")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Maintenance Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Leaky Cable")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Clamp Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Clamp Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}
	
	else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Cable Tray Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}/*else if(key.equalsIgnoreCase("Cable Tray Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}*/else if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Available")&& keyname.equalsIgnoreCase("Agreement Registration")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Agreement Registration Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Agreement Registration Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Landlord")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Crest")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
			}

		}
		
	}
	else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Space Charges Frequency")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Additional Space")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						
						custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						
						custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						
						custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
//						mandatoryFields(datatype,keyvalue);
//						keyvalue.set(2,"1");
//						updateddynamicAgreementAttributesMap.put(key,keyvalue);
						
						custommandatoryFields(datatype,keyvalue);
					 	keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else {}
			}

		}
		
	}
	else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("EMD")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("EMD Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						updateddynamicAgreementAttributesMap.remove(key);
					}
				}
			}

		}
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("BG")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("BG Period")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
						
					}
				}else if(key.equalsIgnoreCase("BG Claim Period")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("BG Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
			}

		}
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Security Deposit")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Amount Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
					//	((ComboBox<Object>) keyvalue.get(1)).setValue("Fixed Amount");
					//	((ComboBox<Object>) keyvalue.get(1)).setValue(null);
						((ComboBox<Object>) keyvalue.get(1)).clear();
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Month")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else {}
			}

		}
		
	}
/*	else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Security Deposite")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Amount Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposite Month")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else {}
			}

		}
	}*/
	else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Space Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
//				if(key.equalsIgnoreCase("Space Charges Type")) {
				if(key.equalsIgnoreCase("Space Charges Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Space Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Space Charge w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Additional Space")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Maintenance")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Maintenance Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Leaky Cable")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						((ComboBox<Object>) keyvalue.get(1)).clear();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Clamp Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Clamp Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Clamp Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Cable Tray Charges")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}/*else if(key.equalsIgnoreCase("Cable Tray Charges")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}*/else if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else {}
			}

		}
		
	}else if(combovalue.equalsIgnoreCase("Not Available")&& keyname.equalsIgnoreCase("Agreement Registration")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Agreement Registration Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Agreement Registration Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Landlord")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Crest")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
			}

		}
		
	}
	//else if(keyname.equalsIgnoreCase("Rent Status") && !combovalue.equalsIgnoreCase("FOC") ) {
	else if(keyname.equalsIgnoreCase("Rent Status")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent")) {
					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						nonmandatoryFields(datatype,keyvalue);
//						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//							updateddynamicAgreementAttributesMap.remove(key);
//						}
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Escalation")) {
					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						nonmandatoryFields(datatype,keyvalue);
//						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//							updateddynamicAgreementAttributesMap.remove(key);
//						}
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Expiry Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
					//	mandatoryFields(datatype,keyvalue);
					//	keyvalue.set(2,"1");
						custommandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"0");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
		/*		else if(key.equalsIgnoreCase("Escalation Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Escalation Percentage")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(key.equalsIgnoreCase("Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}*/
				else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Escalation Basis")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Auto Rentals")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Payment Day of Month")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
				else if(combovalue.equalsIgnoreCase("All Operator") && key.equalsIgnoreCase("Operators")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
						
					}
				}
			}

		}
	
		
	}
	else if(keyname.equalsIgnoreCase("Escalation Basis") && combovalue.equalsIgnoreCase("Not Applicable")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Escalation Frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("Escalation Percentage")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
			}

		}
		
	}
	else if(keyname.equalsIgnoreCase("Security Amount Basis") && !combovalue.equalsIgnoreCase("Base on Lease Rent")) {//chnged on 9thMay based on uat requirement
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposit Month")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
//				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
//					if(keyvalue.size()>0) {
//						String datatype=keyvalue.get(0).toString().toUpperCase();
//						nonmandatoryFields(datatype,keyvalue);
//						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//							updateddynamicAgreementAttributesMap.remove(key);
//						}
//					}
//				}
				else if(key.equalsIgnoreCase("Security Deposit Amount")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicAgreementAttributesMap.put(key,keyvalue);
				}
			}
				else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else {}
				
			}
		}
	}
/*	//else if(keyname.equalsIgnoreCase("Security Amount Basis") && !combovalue.equalsIgnoreCase("Fixed Amount")) {
	else if(keyname.equalsIgnoreCase("Security Amount Basis") && !combovalue.equalsIgnoreCase("Base on Lease Rent")) {//chnged on 9thMay based on uat requirement
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				if(key.equalsIgnoreCase("Security Deposit Applicable")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("Security Deposite Month")) {//changes on 10May after uat
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else if(key.equalsIgnoreCase("SD Escalation frequency")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}
				else {}
			}
		}
	}*/
	else if(keyname.equalsIgnoreCase("Space Charges Frequency") && !combovalue.equalsIgnoreCase("Fixed")) {
		if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
		{	
			Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue = dynamicAgreementAttributesMap.get(key);

				if (key.equalsIgnoreCase("Additional Space")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype, keyvalue);
						if (updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				} else if (key.equalsIgnoreCase("Space Charges Amount")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype, keyvalue);
						if (updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				} else if (key.equalsIgnoreCase("Space Charge w e f")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype, keyvalue);
						if (updateddynamicAgreementAttributesMap.containsKey(key)) {
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				} else if (key.equalsIgnoreCase("Space Charges Escalation frequency")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype, keyvalue);
						keyvalue.set(2, "1");
						updateddynamicAgreementAttributesMap.put(key, keyvalue);
					}
				} else if (key.equalsIgnoreCase("Space Charges Escalation Rate")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype, keyvalue);
						keyvalue.set(2, "1");
						updateddynamicAgreementAttributesMap.put(key, keyvalue);
					}
				} else if (key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
					if (keyvalue.size() > 0) {
						String datatype = keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype, keyvalue);
						keyvalue.set(2, "1");
						updateddynamicAgreementAttributesMap.put(key, keyvalue);
					}
				} else {
				}
				
			}

		}
		
	}
	else {
		
	}
}

	
  
  
  protected void attributeVisibility3(String combovalue,String keyname) {
		if(combovalue.equalsIgnoreCase("FOC")&& keyname.equalsIgnoreCase("Rent Status")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Rent")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Rent Escalation")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Rent Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Rent Expiry Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Rent Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Rent Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
				
					else if(key.equalsIgnoreCase("Escalation Basis")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							((ComboBox<Object>) keyvalue.get(1)).setValue("Not Applicable");
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Operators")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Auto Rentals")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Payment Day of Month")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
				}

			}
			
		}
		else if(keyname.equalsIgnoreCase("Rent Status") && (combovalue.equalsIgnoreCase("Per Operator") || 
				combovalue.equalsIgnoreCase("Operator Wise")|| 
				combovalue.equalsIgnoreCase("Upto 2 Operator")|| 
				combovalue.equalsIgnoreCase("Upto 3 Operator"))) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Operators")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						}
					}if(key.equalsIgnoreCase("Rent")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Rent Escalation")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Rent Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Rent Expiry Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	mandatoryFields(datatype,keyvalue);
						//	keyvalue.set(2,"1");
							custommandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Rent Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Rent Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Escalation Basis")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Auto Rentals")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Payment Day of Month")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else {}
				}

			}
			
		}
		else if(keyname.equalsIgnoreCase("Escalation Basis") && !combovalue.equalsIgnoreCase("Not Applicable")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Escalation Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Escalation Percentage")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("EMD")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("EMD Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("BG")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("BG Period")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("BG Claim Period")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("BG Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
				}

			}
			
		}
		
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Security Deposit")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Security Amount Basis")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Month")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else {}
				}

			}
			
		}

		else if(combovalue.equalsIgnoreCase("Base on Lease Rent") && keyname.equalsIgnoreCase("Security Amount Basis")) {//chnged on 9thMay based on uat requirement
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Security Deposit Applicable")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Month")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							//mandatoryFields(datatype,keyvalue);
							custommandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"0");
						//	keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}

					else if(key.equalsIgnoreCase("Security Deposit Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//						//	mandatoryFields(datatype,keyvalue);
//						 	custommandatoryFields(datatype,keyvalue);
//						 	keyvalue.set(2,"0");
//						//	keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	mandatoryFields(datatype,keyvalue);
						 	custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
						//	keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	mandatoryFields(datatype,keyvalue);
						 	custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
					//		keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	mandatoryFields(datatype,keyvalue);
						 	custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
						//	keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
					
				}
			}
		}
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Space Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
				//	if(key.equalsIgnoreCase("Space Charges Type")) {
					if(key.equalsIgnoreCase("Space Charges Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							((ComboBox<Object>) keyvalue.get(1)).setValue("Fixed");
							//	((ComboBox<Object>) keyvalue.get(1)).setValue(null);
							((ComboBox<Object>) keyvalue.get(1)).clear();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Space Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Additional Space")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Maintenance")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
//							((ComboBox<Object>) keyvalue.get(1)).setValue("Fixed");
							//	((ComboBox<Object>) keyvalue.get(1)).setValue(null);
							((ComboBox<Object>) keyvalue.get(1)).clear();
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Maintenance Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					 if(key.equalsIgnoreCase("Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(!combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Maintenance Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					 if(key.equalsIgnoreCase("Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						}
					}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Leaky Cable")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							((ComboBox<Object>) keyvalue.get(1)).clear();
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}
		else if(!combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Clamp Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							((ComboBox<Object>) keyvalue.get(1)).clear();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Clamp Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}
		else if(!combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Clamp Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Applicable")&& keyname.equalsIgnoreCase("Cable Tray Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							((ComboBox<Object>) keyvalue.get(1)).clear();
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
		
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					 if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
						if(keyvalue.size()>0) {
				//			System.out.println(key);
				//			System.out.println("hhhhhhhhh");
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					 else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
					//		System.out.println(key);
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
							
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else {}
				}

			}
			
		}else if(!combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					 if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						}
					}
					 else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						 	custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
						}
					}
					else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Available")&& keyname.equalsIgnoreCase("Agreement Registration")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Agreement Registration Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Agreement Registration Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Landlord")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Crest")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Fixed")&& keyname.equalsIgnoreCase("Space Charges Frequency")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Additional Space")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("EMD")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("EMD Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							updateddynamicAgreementAttributesMap.remove(key);
						}
					}
				}

			}
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("BG")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("BG Period")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
							
						}
					}else if(key.equalsIgnoreCase("BG Claim Period")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("BG Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
				}

			}
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Security Deposit")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Security Amount Basis")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
						//	((ComboBox<Object>) keyvalue.get(1)).setValue("Fixed Amount");
						//	((ComboBox<Object>) keyvalue.get(1)).setValue(null);
							((ComboBox<Object>) keyvalue.get(1)).clear();
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Applicable")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Month")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else {}
				}

			}
			
		}
		else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Space Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
//					if(key.equalsIgnoreCase("Space Charges Type")) {
					if(key.equalsIgnoreCase("Space Charges Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Additional Space")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Maintenance")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Maintenance Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Leaky Cable")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Leaky Cable Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Clamp Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Clamp Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Clamp Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Frequency of Leaky Clamp Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Not Applicable")&& keyname.equalsIgnoreCase("Cable Tray Charges")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Frequency of Cable Tray Charges")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	((ComboBox<Object>) keyvalue.get(1)).clear();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Cable Tray Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
					else {}
				}

			}
			
		}else if(combovalue.equalsIgnoreCase("Not Available")&& keyname.equalsIgnoreCase("Agreement Registration")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Agreement Registration Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Agreement Registration Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Landlord")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Stamp Duty Expenses borne by Crest")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
				}

			}
			
		}
		//else if(keyname.equalsIgnoreCase("Rent Status") && !combovalue.equalsIgnoreCase("FOC") ) {
		else if(keyname.equalsIgnoreCase("Rent Status")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent")) {
						if(keyvalue.size()>0) {

							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Escalation")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Expiry Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
						//	mandatoryFields(datatype,keyvalue);
						//	keyvalue.set(2,"1");
							custommandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Rent Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
			
					else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Escalation Basis")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Auto Rentals")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(!combovalue.equalsIgnoreCase("FOC") && key.equalsIgnoreCase("Payment Day of Month")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(combovalue.equalsIgnoreCase("All Operator") && key.equalsIgnoreCase("Operators")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
							
						}
					}
				}

			}
		
			
		}
		else if(keyname.equalsIgnoreCase("Escalation Basis") && combovalue.equalsIgnoreCase("Not Applicable")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Escalation Frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("Escalation Percentage")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}
				}

			}
			
		}
		else if(keyname.equalsIgnoreCase("Security Amount Basis") && !combovalue.equalsIgnoreCase("Base on Lease Rent")) {//chnged on 9thMay based on uat requirement
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Security Deposit Applicable")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Security Deposit Month")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}

					else if(key.equalsIgnoreCase("Security Deposit Amount")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						mandatoryFields(datatype,keyvalue);
						keyvalue.set(2,"1");
						updateddynamicAgreementAttributesMap.put(key,keyvalue);
					}
				}
					else if(key.equalsIgnoreCase("Security Deposit Date")) {//changed on 10May after uat
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}

//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue); 
						}
					}else if(key.equalsIgnoreCase("SD Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else if(key.equalsIgnoreCase("SD Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
								updateddynamicAgreementAttributesMap.remove(key);
							}
						}
					}else {}
					
				}
			}
		}
		else if(keyname.equalsIgnoreCase("Space Charges Frequency") && !combovalue.equalsIgnoreCase("Fixed")) {
			if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAgreementAttributesMap.get(key);
					if(key.equalsIgnoreCase("Additional Space")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
//
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charges Amount")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charge w e f")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							nonmandatoryFields(datatype,keyvalue);
//							if(updateddynamicAgreementAttributesMap.containsKey(key)) {
//								updateddynamicAgreementAttributesMap.remove(key);
//							}
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}
					else if(key.equalsIgnoreCase("Space Charges Escalation frequency")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Rate")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else if(key.equalsIgnoreCase("Space Charges Escalation Start Date")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
//							mandatoryFields(datatype,keyvalue);
//							keyvalue.set(2,"1");
//							updateddynamicAgreementAttributesMap.put(key,keyvalue);
							
							custommandatoryFields(datatype,keyvalue);
						 	keyvalue.set(2,"0");
							updateddynamicAgreementAttributesMap.put(key,keyvalue);
						}
					}else {}
				}

			}
			
		}
		else {
			
		}
	}
  
  
  private void nonmandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(false);
			((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(false);
			((NumberField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(false);
			((DatePicker)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(false);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(false);
			((Div) keyvalue.get(3)).setVisible(false);
			break;
		}

		
	}
	private void mandatoryFields(String datatype, List<Object> keyvalue) {
		
	//	System.out.println("mandatoryFields");
		try {
			switch(datatype)
			{
			case "FLOV":
				((ComboBox<Object>)keyvalue.get(1)).setVisible(true);
				((ComboBox<Object>)keyvalue.get(1)).setRequired(true);
				((ComboBox<Object>)keyvalue.get(1)).setRequiredIndicatorVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				//((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
		//		System.out.println("keyvalue====="+((ComboBox<Object>)keyvalue.get(1)).getLabel());
				
				
				
				((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void valueChanged(ValueChangeEvent<?> event) {
						if (event.getValue() == null) {
						
							((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
							((ComboBox<Object>)keyvalue.get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
							
						}else {
							((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
							((ComboBox<Object>)keyvalue.get(1)).setErrorMessage("");
						}
					}
				});
				
				break;
			case "NUMERIC":
				((NumberField)keyvalue.get(1)).setVisible(true);
		//		((NumberField)keyvalue.get(1)).setRequired(true);
				((NumberField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
				//((TextField)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "ALPHANUMERIC":
				((TextField)keyvalue.get(1)).setVisible(true);
				((TextField)keyvalue.get(1)).setRequired(true);
				((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
				//((TextField)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "DATE":
				((DatePicker)keyvalue.get(1)).setVisible(true);
				((DatePicker)keyvalue.get(1)).setRequired(true);
				((DatePicker)keyvalue.get(1)).setRequiredIndicatorVisible(true);
				//((DatePicker)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				
				break;
			case "FREEFLOW":
				((TextField)keyvalue.get(1)).setVisible(true);
				((TextField)keyvalue.get(1)).setRequired(true);
				((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
			//	((TextField)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "BOOLEAN":
				datatype = "BOOLEAN";
				((Checkbox) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "MULTIPLE SELECTION":
				((CheckboxGroup) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "IMAGE FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "TEXT FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "CUSTOM FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		

		
	}
	
	private void custommandatoryFields(String datatype, List<Object> keyvalue) {
		switch(datatype)
		{
		
		case "FLOV":
			((ComboBox<Object>)keyvalue.get(1)).setVisible(true);
			((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
			((ComboBox<Object>)keyvalue.get(1)).setRequired(false);
			((ComboBox<Object>)keyvalue.get(1)).setRequiredIndicatorVisible(false);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "NUMERIC":
			((NumberField)keyvalue.get(1)).setVisible(true);
			((NumberField)keyvalue.get(1)).setInvalid(false);
			((NumberField)keyvalue.get(1)).setRequiredIndicatorVisible(false);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "ALPHANUMERIC":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((TextField)keyvalue.get(1)).setRequired(false);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(false);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "DATE":
			((DatePicker)keyvalue.get(1)).setVisible(true);
			((DatePicker)keyvalue.get(1)).setInvalid(false);
			((DatePicker)keyvalue.get(1)).setRequired(false);
			((DatePicker)keyvalue.get(1)).setRequiredIndicatorVisible(false);
			((Div) keyvalue.get(3)).setVisible(true);
			
			break;
		case "FREEFLOW":
			((TextField)keyvalue.get(1)).setVisible(true);
			((TextField)keyvalue.get(1)).setInvalid(false);
			((TextField)keyvalue.get(1)).setRequired(false);
			((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(false);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "BOOLEAN":
			datatype = "BOOLEAN";
			((Checkbox) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "MULTIPLE SELECTION":
			((CheckboxGroup) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "IMAGE FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "TEXT FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		case "CUSTOM FILE":
			((Div) keyvalue.get(1)).setVisible(true);
			((Div) keyvalue.get(3)).setVisible(true);
			break;
		}

		
	}
		
		private void populateAgreementTypeList() {
			agreementTypeList=new ArrayList<String>();
			agreementtypemap.clear();
			
			int count=1;
			String str[] = {"Main Agreement","Addendum Agreement"};
			for (int i = 0; i < str.length; i++) {
				agreementTypeList.add(str[i]);
				agreementtypemap.put(str[i],count);
				count++;
				
			}
		
		}
		
		
		public boolean validation2() {
			agreementNameFld.setInvalid(false);
			agreementDateFld.setInvalid(false);
			startDateFld.setInvalid(false);
			endDateFld.setInvalid(false);
			//		paymentFrequencyCombo.setInvalid(false);
			//		paymentAmtFld.setInvalid(false);
			//		paymentTypeCombo.setInvalid(false);
			//		paymentModeCombo.setInvalid(false);

			if (agreementNameFld.getValue()==null || agreementNameFld.getValue().trim().length()==0) {
				agreementNameFld.setInvalid(true);
				agreementNameFld.setErrorMessage("Please enter "+agreementNameFld.getLabel().toLowerCase());
				agreementNameFld.focus();
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}

			if (agreementDateFld.getValue()==null || agreementDateFld.getValue().toString().trim().length()==0) {
				agreementDateFld.setInvalid(true);
				agreementDateFld.setErrorMessage("Please provide valid "+agreementDateFld.getLabel().toLowerCase());
				agreementDateFld.focus();
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}

			if (startDateFld.getValue()==null || startDateFld.getValue().toString().trim().length()==0) {
				startDateFld.setInvalid(true);
				startDateFld.setErrorMessage("Please provide valid "+startDateFld.getLabel().toLowerCase());
				startDateFld.focus();
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}

			if (endDateFld.getValue()==null || endDateFld.getValue().toString().trim().length()==0) {
				endDateFld.setInvalid(true);
				endDateFld.setErrorMessage("Please provide valid "+endDateFld.getLabel().toLowerCase());
				endDateFld.focus();
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}
			
			if(agreementtypeCombo.getValue()==null) {
				agreementtypeCombo.setInvalid(true);
				agreementtypeCombo.setErrorMessage("Please enter "+agreementtypeCombo.getLabel().toLowerCase());
				agreementtypeCombo.focus();
				addAgreementsTabs.setSelectedTab(basicTab);
				return false;
			}

			if (!fileExist && existingFileName.trim().length()==0) {
				if (getAgreementFileName().trim().length()==0 || base64EncodedFileContent==null || base64EncodedFileContent.trim().length()==0) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "FILE_UPLOAD_MANDATORY", ApplicationConstants.DialogTypes.ERROR);
					addAgreementsTabs.setSelectedTab(basicTab);
					return false;
				}
			}

			if(detailsTab.isEnabled())
			{
				detailsTabEnabled = true;
				//updateAttributeJson=new JSONObject();
				agreementAttributesJson=new JSONObject();
		//		Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
				
				
				if(updateddynamicAgreementAttributesMap==null || updateddynamicAgreementAttributesMap.size()<=0) {
					SiteAssetInventoryUIFramework.getFramework().showMessage("Please fill up the Agreement Details", ApplicationConstants.DialogTypes.ERROR);
					return false;
				}
				Iterator<String> itrKeys = updateddynamicAgreementAttributesMap.keySet().iterator();
				UIFileAttributeComponent fileAttributeComp = null;
				//System.out.println("dynamicAgreementAttributesMap="+dynamicAgreementAttributesMap.toString());
				
				
			
				try {
					if(updateddynamicAgreementAttributesMap!=null && updateddynamicAgreementAttributesMap.size()>0)
					{	

						while (itrKeys.hasNext()) 
						{
							String key = itrKeys.next();
							List<Object> value=updateddynamicAgreementAttributesMap.get(key);

							if(value.size()>0)	//value obj
							{	
								String datatype=updateddynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
								String mandatory=updateddynamicAgreementAttributesMap.get(key).get(2).toString();
								switch(datatype)
								{
								case "FLOV":
									// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
									if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)			
									{
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
										((ComboBox<Object>) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if(((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)			
									{
										agreementAttributesJson.put(key, ((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
									}
									break;
								case "NUMERIC":
							//		if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
									if (mandatory.equalsIgnoreCase("1")&&((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)
									{
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
										((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if (((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
									{
										agreementAttributesJson.put(key, ((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
									}
									break;
								case "ALPHANUMERIC":
									if(mandatory.equalsIgnoreCase("1")&&((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
									{
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
										((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if(((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
									{
										agreementAttributesJson.put(key, ((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
									}
									break;
								case "DATE":
									if (mandatory.equalsIgnoreCase("1")&&((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()==null)
									{
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_DATE_VALUE_MANDATORY"));
										((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if (((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
									{
										agreementAttributesJson.put(key, CommonUtils.convertLocalDateToString(
												((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue(), "dd/MM/yyyy"));
									}
									break;
								case "FREEFLOW":
									if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
									{
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setInvalid(true);
										((HasValidation) updateddynamicAgreementAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ATTRIBUTE_VALUE_MANDATORY"));
										((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).focus();
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if (((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
									{
										agreementAttributesJson.put(key, ((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
									}
									break;
									
								case "BOOLEAN"://AbhraC
									agreementAttributesJson.put(key, ((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).getValue());
									break;
								case "MULTIPLE SELECTION":
									CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) dynamicAgreementAttributesMap.get(key).get(1);
									if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty() && checkboxGroup.isEnabled()==true) {
										SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty() && checkboxGroup.isEnabled()==false) {
										SiteAssetInventoryUIFramework.getFramework().showMessage("There is no operators present for this site.Please select rent status as FOC or All Operators to save", DialogTypes.INFO);
										addAgreementsTabs.setSelectedTab(detailsTab);
										return false;
									}
									if(!checkboxGroup.isEmpty()) {
										agreementAttributesJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
									}
									break;
								case "IMAGE FILE":
									fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
									if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
										SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
										return false;
									}
									if(fileAttributeComp.getFileJSON() != null) {
										agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
									}
									break;
								case "TEXT FILE":
									fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
									if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
										SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
										return false;
									}
									if(fileAttributeComp.getFileJSON() != null) {
										agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
									}
									break;
								case "CUSTOM FILE":
									fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
									if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
										SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
										return false;
									}
									if(fileAttributeComp.getFileJSON() != null) {
										agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
									}
									break;
								}
							}	
						}
						
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

			
			return true;
		}

	
		
		private void getSiteOperators(){
		try {
			operatorList.clear();
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEOPERATORS");
			url=url+"?SiteCode="+URLEncoder.encode(sitecode);
			String resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			if(resp!=null || resp.length()>0 || resp!="[]" || resp!="{}" ) {
				JSONArray js=new JSONArray(resp);
				if(js.length()>0) {
					for(int i=0;i<js.length();i++) {
						operatorList.add(js.getJSONObject(i).getString("OpCoName"));
					}
					
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
		
	public void getFormValues() {

		temp_agreementAttributesJson=new JSONObject();

		if(updateddynamicAgreementAttributesMap==null || updateddynamicAgreementAttributesMap.size()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please fill up the Agreement Details", ApplicationConstants.DialogTypes.ERROR);
			return ;
		}
		Iterator<String> itrKeys = updateddynamicAgreementAttributesMap.keySet().iterator();
		UIFileAttributeComponent fileAttributeComp = null;
	
		try {
			if(updateddynamicAgreementAttributesMap!=null && updateddynamicAgreementAttributesMap.size()>0)
			{	

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> value=updateddynamicAgreementAttributesMap.get(key);

					if(value.size()>0)	//value obj
					{	
						String datatype=updateddynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
						String mandatory=updateddynamicAgreementAttributesMap.get(key).get(2).toString();
						switch(datatype)
						{
						case "FLOV":
							if(((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)			
							{
								temp_agreementAttributesJson.put(key, ((ComboBox<Object>)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
							}
							break;
						case "NUMERIC":
							if (((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
							{
								temp_agreementAttributesJson.put(key, ((NumberField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
							}
							break;
						case "ALPHANUMERIC":
							if(((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
							{
								temp_agreementAttributesJson.put(key, ((TextField)updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
							}
							break;
						case "DATE":
							if (((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue()!=null)
							{
								temp_agreementAttributesJson.put(key, CommonUtils.convertLocalDateToString(
										((DatePicker) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue(), "dd/MM/yyyy"));
							}
							break;
						case "FREEFLOW":
							if (((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue().toString().length()>0)
							{
								temp_agreementAttributesJson.put(key, ((TextField) updateddynamicAgreementAttributesMap.get(key).get(1)).getValue());
							}
							break;
							
						case "BOOLEAN":
							temp_agreementAttributesJson.put(key, ((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).getValue());
							break;
						case "MULTIPLE SELECTION":
							CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) dynamicAgreementAttributesMap.get(key).get(1);
							if(mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
								SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
								addAgreementsTabs.setSelectedTab(detailsTab);
								
							}
							if(!checkboxGroup.isEmpty()) {
								temp_agreementAttributesJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
							}
							break;
					/*	case "IMAGE FILE":
							fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
							if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
								SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
								
							}
							if(fileAttributeComp.getFileJSON() != null) {
								temp_agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
							}
							break;
						case "TEXT FILE":
							fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
							if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
								SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
								
							}
							if(fileAttributeComp.getFileJSON() != null) {
								temp_agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
							}
							break;
						case "CUSTOM FILE":
							fileAttributeComp = (UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1);
							if(mandatory.equalsIgnoreCase("1") && fileAttributeComp.getFileJSON() == null) {
								SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
								
							}
							if(fileAttributeComp.getFileJSON() != null) {
								temp_agreementAttributesJson.put(key, fileAttributeComp.getFileJSON());
							}
							break;*/
						}
					}	
				}
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	
	public void setFormValue(String sitecode2)
	{
		try {
//			String formvalue=LocalStorage.showStoredValue(KEY_NAME);
	//		LocalStorage obj=new LocalStorage();
	//		String formvalue=obj.showStoredValue(KEY_NAME);
			
//			LocalStorage.getItem(
//					KEY_NAME,
//		            value -> {
//		            	System.out.println("Stored value::=="+value);
//		            	formvalue=value;
//		            	Agreementform(value,sitecode2);
//		            }
//		     );	
			
			String resp=CommonUtils.getDraftData("2");
			Agreementform(resp,sitecode2);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void Agreementform(String formvalue,String sitecode2) {
		
		try {
			System.out.println("formvalue:=="+formvalue);
			if(formvalue!=null) {// if present in local storage
				JSONObject js =new JSONObject(formvalue);
				
				if(js.getString("SiteCode").equalsIgnoreCase(sitecode2)) {
					JSONObject agreementDetails=js.getJSONObject("AgreementDetails");
					JSONObject fileDetails=agreementDetails.getJSONObject("FileDetails");
					
					agreementNameFld.setValue(agreementDetails.getString("Name"));
					agreementDocDescFld.setValue(fileDetails.getString("Description"));
				//	existingFileNameLbl.setText(fileDetails.getString("Name"));
					if(agreementDetails.getString("Type")!=null || agreementDetails.getString("Type").length()>0) {
						if(agreementDetails.getString("Type").equalsIgnoreCase("1")) {
							agreementtypeCombo.setValue("Main Agreement");
						}else if(agreementDetails.getString("Type").equalsIgnoreCase("2")){
							agreementtypeCombo.setValue("Addendum Agreement");
						}else {
							agreementtypeCombo.setValue("");
						}
						
					}
					if(agreementDetails.getString("AgreementDate").length()>0) {
						agreementDateFld.setValue(CommonUtils.convertStringToLocalDate(agreementDetails.getString("AgreementDate"), "MM/dd/yyyy"));
					}
					if(agreementDetails.getString("StartDate").length()>0) {
						startDateFld.setValue(CommonUtils.convertStringToLocalDate(agreementDetails.getString("StartDate"), "MM/dd/yyyy"));
					}
					if(agreementDetails.getString("EndDate").length()>0) {
						endDateFld.setValue(CommonUtils.convertStringToLocalDate(agreementDetails.getString("EndDate"), "MM/dd/yyyy"));
					}
					
					
					
					JSONObject AgreementAttribute=js.getJSONObject("AgreementAttribute");
					Iterator<String> attributeNames = AgreementAttribute.keys();
					
					while (attributeNames.hasNext()) {
						String attributeName = (String) attributeNames.next();
						if(dynamicAgreementAttributesMap!=null && dynamicAgreementAttributesMap.size()>0)
						{
							Iterator<String> itrKeys = dynamicAgreementAttributesMap.keySet().iterator();
							while (itrKeys.hasNext()) {
								String key = (String) itrKeys.next();
								if (attributeName.equals(key)) {
									List<Object> value=dynamicAgreementAttributesMap.get(key);
									if(value.size()>0)
									{	
										String datatype=dynamicAgreementAttributesMap.get(key).get(0).toString().toUpperCase();
										
										switch(datatype)
										{
										case "FLOV":
											((ComboBox<Object>) dynamicAgreementAttributesMap.get(key).get(1)).setValue(AgreementAttribute.getString(attributeName));	
											break;
										case "NUMERIC":
											((NumberField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(Double.parseDouble(AgreementAttribute.getString(attributeName)));
											break;
										case "ALPHANUMERIC":
											((TextField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(AgreementAttribute.getString(attributeName));
											break;
										case "DATE":
											((DatePicker) dynamicAgreementAttributesMap.get(key).get(1)).setValue(CommonUtils.convertStringToLocalDate(
													AgreementAttribute.getString(attributeName), "dd/MM/yyyy"));
											break;
										case "FREEFLOW":
											((TextField) dynamicAgreementAttributesMap.get(key).get(1)).setValue(AgreementAttribute.getString(attributeName));
											break;
										case "BOOLEAN":
											String boolValue = AgreementAttribute.getString(attributeName);
											if(boolValue != null && boolValue.trim().length() > 0 && boolValue.trim().equalsIgnoreCase("true")) {
												((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).setValue(true);
											} else {
												((Checkbox) dynamicAgreementAttributesMap.get(key).get(1)).setValue(false);
											}
											break;
										case "MULTIPLE SELECTION":
											String multiSelectValue = AgreementAttribute.getString(attributeName);
											setMultiSelectValue(((CheckboxGroup<String>) dynamicAgreementAttributesMap.get(key).get(1)), multiSelectValue);
											break;
										case "IMAGE FILE":
											setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), AgreementAttribute.getString(attributeName));
											break;
										case "TEXT FILE":
											setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), AgreementAttribute.getString(attributeName));
											break;
										case "CUSTOM FILE":
											setFileAttributeValue(((UIFileAttributeComponent) dynamicAgreementAttributesMap.get(key).get(1)), AgreementAttribute.getString(attributeName));
											break;
										default :

										}
									}
									break;
								}
							}
						}		
					}
				}
				}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void resetFormValue() {
		agreementNameFld.clear();
		agreementDocDescFld.clear();
		existingFileNameLbl.setText("");
		agreementtypeCombo.clear();
		agreementDateFld.clear();
		startDateFld.clear();
		endDateFld.clear();
		temp_agreementAttributesJson=new JSONObject();
		agreementNameFld.setInvalid(false);
		agreementDateFld.setInvalid(false);
		startDateFld.setInvalid(false);
		endDateFld.setInvalid(false);
		populateAgreementAttributes();
	}

}
