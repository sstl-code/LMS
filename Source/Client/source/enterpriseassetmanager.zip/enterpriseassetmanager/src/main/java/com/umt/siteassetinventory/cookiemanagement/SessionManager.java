package com.umt.siteassetinventory.cookiemanagement;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.bean.UserInfoBean;
import com.umt.siteassetinventory.utility.AESEncryptionUtility;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinServletRequest;

public class SessionManager implements Serializable {
	private static final long serialVersionUID = 1L;

	public static Cookie getCookieByName(String name, HttpServletRequest request) {
		// Fetch all cookies from the request
		Cookie[] cookies = request.getCookies(); // VaadinService.getCurrentRequest().getCookies();

		if (cookies == null) {
			return null;
		}

		// Iterate to find cookie by its name
		for (Cookie cookie : cookies) {
			if (name.equals(cookie.getName())) {
				return cookie;
			}
		}

		return null;
	}

	public static void addCookieByName(String name, String value, int expiry, HttpServletResponse response) {
		// HttpServletResponse response = (HttpServletResponse)
		// VaadinResponse.getCurrent();

		Cookie cookie = new Cookie(name, value);
		cookie.setMaxAge(expiry);
		cookie.setHttpOnly(true);
		cookie.setPath("/");
		String enableCookieSecureFlag = ApplicationConfiguration.getConfigurationValue("ENABLE_COOKIE_SECURE_FLAG");
		if(enableCookieSecureFlag != null && enableCookieSecureFlag.trim().equals("1")) {
			cookie.setSecure(true);
		}
		response.addCookie(cookie);
		//System.out.println(name+" set as "+value+" for "+response.toString());
	}

	public static UserInfoBean getUserInfoFromCookie(HttpServletRequest request) {
		UserInfoBean userInfo = new UserInfoBean();

		Cookie cookie = getCookieByName("truebyl_token", request);

		if (cookie != null) {
			String token = cookie.getValue();
			if (token != null && token.trim().length() > 0) {
				userInfo.setToken(token);

				cookie = getCookieByName("___partner_portal_usr", request);

				if(cookie == null) {
					return null;
				}

				String encryptedValue = cookie.getValue();
				if(encryptedValue != null) {
					AESEncryptionUtility encryptionUtil = new AESEncryptionUtility();
					String decryptedValue = encryptionUtil.decrypt(encryptedValue, "dpgodrejtowerone");
					try {
						JSONObject userInfoJSON = new JSONObject(decryptedValue);
						userInfo.setEmailId(userInfoJSON.getString("partner_portal_emailid"));
						userInfo.setUserType(userInfoJSON.getString("partner_portal_usertype"));
						try {
							//Date loginDateTime = new Date();
							//loginDateTime.setTime(Long.parseLong(userInfoJSON.getString("partner_portal_logindatetime")));
							//System.out.println("userInfoJSON.getString(\"partner_portal_logindatetime\")="+userInfoJSON.getString("partner_portal_logindatetime"));

							LocalDateTime ldt = Instant.ofEpochMilli(Long.parseLong(userInfoJSON.getString("partner_portal_logindatetime"))).atZone(ZoneId.systemDefault()).
									toLocalDateTime();
							//System.out.println(ldt);
							Date in = new Date();
							Date out = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
							// System.out.println(out);
							userInfo.setLoginDateTime(out);
							//userInfo.setLoginDateTimeStr(formatted);
						} catch (Exception ex) {
							ex.printStackTrace();
							System.out.println("new Date()="+new Date());
							userInfo.setLoginDateTime(new Date());
						}

						userInfo.setLoginMedia(userInfoJSON.getString("partner_portal_loginmethod"));
						userInfo.setPartnerCode(userInfoJSON.getString("partner_portal_code"));

					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				return userInfo;
			}
		}

		return null;
	}

	public static void storeUserInfoInCookie(UserInfoBean userInfo, int expiry, HttpServletRequest request,
			HttpServletResponse response) {
		JSONObject userInfoJSON = new JSONObject();
		try {
			// userInfoJSON.put("partner_portal_token", userInfo.getToken());
			userInfoJSON.put("partner_portal_emailid", userInfo.getEmailId());
			userInfoJSON.put("partner_portal_usertype", userInfo.getUserType());
			userInfoJSON.put("partner_portal_logindatetime", userInfo.getLoginDateTime().getTime() + "");
			userInfoJSON.put("partner_portal_loginmethod", userInfo.getLoginMedia());
			userInfoJSON.put("partner_portal_code", userInfo.getPartnerCode());
			AESEncryptionUtility encryptionUtil = new AESEncryptionUtility();
			String encryptedValue = encryptionUtil.encrypt(userInfoJSON.toString(), "dpgodrejtowerone");

			addCookieByName("___partner_portal_usr", encryptedValue, expiry, response);
		} catch (JSONException e) { 
			e.printStackTrace();
		}
	}	 

	public static void clearUserInfoInCookie(HttpServletResponse response) {
		addCookieByName("___partner_portal_usr", "", 0, response);
		addCookieByName("truebyl_token", "", 0, response);
	}

	public static void handleTokenExpiry() {
		if (UI.getCurrent() == null) {
			return;
		}
		clearUserInfoInCookie((HttpServletResponse) VaadinResponse.getCurrent());
		SiteAssetInventoryUIFramework.getFramework().setUserInfo(null);
		HttpServletRequest request = VaadinServletRequest.getCurrent().getHttpServletRequest();
		String loginURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
		+ request.getContextPath() + "/authreq/";
		//System.out.println(loginURL);
		UI.getCurrent().getPage().setLocation(loginURL);
	}

	private static Date getConvertedDate(LocalDateTime ldt) {
		Date retVal = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
		return retVal;
	}
}
