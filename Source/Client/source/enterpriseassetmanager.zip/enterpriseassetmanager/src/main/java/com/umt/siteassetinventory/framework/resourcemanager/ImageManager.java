package com.umt.siteassetinventory.framework.resourcemanager;

import java.io.Serializable;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ImageManager implements Serializable 
{
	private static final long serialVersionUID = 1L;

	protected final String RESOURCE_PATH = "com.umt.siteassetinventory.framework.resourcemanager.Images";
	
	public String getImageConfiguration(String screencd, String imagecd) 
	{
		if(screencd == null || screencd.trim().length() == 0 
				|| imagecd == null || imagecd.trim().length() == 0)
		{
			return "";
		}
		String l_strKey = screencd.toUpperCase() + "." + imagecd.toUpperCase();
		try
		{
			String l_strBundleName = RESOURCE_PATH + ".images";
			ResourceBundle l_objResourceBundle = ResourceBundle.getBundle(l_strBundleName, Locale.getDefault());
			return l_objResourceBundle.getString(l_strKey);
		}
		catch (MissingResourceException exMissingResource) 
		{
			return l_strKey;
		}
	}
}
