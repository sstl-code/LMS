package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/vendor_master-styles.css")
public class VendorMasterDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "VENDOR_MASTER_DATA_BEAN";
	private long vendorId;
	private String vendorName, desc, address;
	private int status;
	private VendorMaster parent;
	private Div eachrowDiv;
	//private Button editBtn, deactivateBtn;
	private Div editDiv, deactivateDiv;
	//private boolean selected = false;


	public VendorMasterDataBean(long vendorId, String vendorName, String description, String address, int status, VendorMaster vendorMaster, boolean vendorOrOperator) 
	{
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.desc = description;
		this.address = address;
		this.status = status;
		this.parent = vendorMaster;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");


		Label vendorIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL1");
		vendorIdVal.setText(vendorId+"");
		eachdataDiv1.add(vendorIdVal);

		Label vendorNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL2");
		vendorNameVal.setText(vendorName);
		eachdataDiv2.add(vendorNameVal);

		Label descVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL3");
		descVal.setText(desc);
		eachdataDiv3.add(descVal);

		Label addressVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL4");
		addressVal.setText(address);
		eachdataDiv4.add(addressVal);

		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL5");
		statusVal.setText(CommonUtils.getStatusCd(status));
		eachdataDiv5.add(statusVal);
		
//		editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
//		deactivateBtn = UIFieldFactory.createButton(SCREENCD, "DEACTIVATE_BTN");
		
		editDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EDIT_DIV");
		Image editIcon = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
		//Icon editIcon = VaadinIcon.PENCIL.create();
		editDiv.add(editIcon);
		
		deactivateDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DEACTIVATE_DIV");
		Icon deactivateIcon = VaadinIcon.TRASH.create();
		deactivateDiv.add(deactivateIcon);

		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3,eachdataDiv4,eachdataDiv5,editDiv/*,deactivateDiv*/);
		add(eachrowDiv);

		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//selectedRowChangeHandler();
			}
		});
		
		editDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> arg0) {
				editDialog(false, vendorOrOperator);
			}
		});
	}
	
	private void editDialog(boolean addOrEdit, boolean vendorOrOperator)
	{
		//System.out.println("Working");
		AddOrEditVendor editVendor = new AddOrEditVendor(parent, this, vendorId, vendorName, desc, address, 
				CommonUtils.getStatusCd(status), vendorOrOperator);
	}
	
//	private void selectedRowChangeHandler()
//	{
//		selectDeselect(selected);
//		parent.selectedRowChangeHandler(this);
//	}
	
//	protected void selectDeselect(boolean selectedOrDeselected)
//	{
//		if (selectedOrDeselected) {
//			selected = false;
//			eachrowDiv.removeClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//		else
//		{
//			selected = true;
//			eachrowDiv.addClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//	}

	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	public Long getVendorId() {
		return vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public String getDesc() {
		return desc;
	}

	public String getAddress() {
		return address;
	}

	public String getStatus() {
		return CommonUtils.getStatusCd(status);
	}

//	public boolean isSelected() {
//		return selected;
//	}

}
