package com.umt.siteassetinventory.landlord;

import java.util.Iterator;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/view_payment_details-styles.css")
public class ViewPaymentDetails extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "VIEW_PAYMENT_DETAILS";
	private Div eachRow;

/*	public ViewPaymentDetails(String paymentDetails) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		try {
		//	System.out.println("paymentDetails=="+paymentDetails);
			String paymentDetails2="{\r\n" + 
					"	\"invoiceno\": \"abcd_1256\",\r\n" + 
					"	\"sitecode\": \"test01\",\r\n" + 
					"	\"circle\": \"Delhi\",\r\n" + 
					"	\"sitename\": \"North Rd Site\",\r\n" + 
					"	\"landlordid\": 1,\r\n" + 
					"	\"sapvendorcode\": \"\",\r\n" + 
					"	\"landlordname\": \"Test Landlord\",\r\n" + 
					"	\"rentshare\": 85,\r\n" + 
					"	\"solutiontype\": \"OD\",\r\n" + 
					"	\"billingtype\": 2,\r\n" + 
					"	\"rentstatus\": \"All Operator\",\r\n" + 
					"	\"invoicetype\": 15,\r\n" + 
					"	\"invoicedate\": \"13\\/03\\/2023\",\r\n" + 
					"	\"dueon\": \"2\",\r\n" + 
					"	\"billingcycle\": \"Monthly\",\r\n" + 
					"	\"period_startdate\": \"13\\/03\\/2023\",\r\n" + 
					"	\"period_enddate\": \"31\\/03\\/2023\",\r\n" + 
					"	\"grossinvoiceamount\": 25000,\r\n" + 
					"	\"gst_rate\": 10,\r\n" + 
					"	\"invoiceamount\": 2500,\r\n" + 
					"	\"billforoperator\": \"\",\r\n" + 
					"	\"invoicearrears\": 0,\r\n" + 
					"	\"submissiondate\": \"13\\/03\\/2023\",\r\n" + 
					"	\"receiveddate\": \"13\\/03\\/2023\",\r\n" + 
					"	\"duedate\": \"13\\/03\\/2023\",\r\n" + 
					"	\"remarks\": \"\",\r\n" + 
					"	\"usage_details\": {\r\n" + 
					"		\"meterserialno\": \"1\",\r\n" + 
					"		\"consumerno\": \"1\",\r\n" + 
					"		\"metertype\": 1,\r\n" + 
					"		\"sanctionload\": \"test\",\r\n" + 
					"		\"noofdays\": 19,\r\n" + 
					"		\"opening_reading\": 0,\r\n" + 
					"		\"closing_reading\": 0,\r\n" + 
					"		\"calculated_consumption\": 0,\r\n" + 
					"		\"manual_consumption\": 0,\r\n" + 
					"		\"per_day_consumption\": 0,\r\n" + 
					"		\"eb_amount\": 0,\r\n" + 
					"		\"unit_rate\": 0,\r\n" + 
					"		\"fix_load_charge\": 0,\r\n" + 
					"		\"dg_charge\": 0,\r\n" + 
					"		\"fcu_charge\": 0,\r\n" + 
					"		\"late_payment_service_charge\": 0,\r\n" + 
					"		\"othercharges\": 0,\r\n" + 
					"		\"lpsc_payable\": 1,\r\n" + 
					"		\"final_payable_amount\": 0\r\n" + 
					"	}\r\n" + 
					"}";
			JSONObject paymentDetailsJson = new JSONObject(paymentDetails);
			Iterator<String> detailsKeys = paymentDetailsJson.keys();
			double totalAmt = 0.00;
			while (detailsKeys.hasNext()) {
				try {
				String key = detailsKeys.next();
				Div detailKeyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_KEY_DIV");
				Label detailKeyLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_KEY_LBL");
				detailKeyLbl.setText(key);
				detailKeyDiv.add(detailKeyLbl);
				
				Div detailValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_VAL_DIV");
				Label detailValLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_VAL_LBL");
			//	detailValLbl.setText(CommonUtils.roundValue(paymentDetailsJson.getString(key), 2));
				detailValLbl.setText((paymentDetailsJson.getString(key)));
				detailValDiv.add(detailValLbl); 
				
			//	totalAmt+= Double.parseDouble(detailValLbl.getText());
				
				Div eachRow = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
				eachRow.add(detailKeyDiv, detailValDiv);
				add(eachRow);
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
//			Hr hr = new Hr();
//			hr.addClassName(SCREENCD+"_HR");
			Div finalRow = UIHtmlFieldFactory.createDiv(SCREENCD, "FINAL_ROW_DIV");
			Div totalAmtKeyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TOTAL_AMT_KEY_DIV");
			Label totalAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TOTAL_AMT_LBL");
			Div totalAmtValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TOTAL_AMT_VAL_DIV");
			Label totalAmtValLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TOTAL_AMT_VAL_LBL");
			totalAmtValLbl.setText(CommonUtils.roundValue(totalAmt, 2));
			totalAmtKeyDiv.add(totalAmtLbl);
			totalAmtValDiv.add(totalAmtValLbl);
			finalRow.add(totalAmtKeyDiv, totalAmtValDiv);
			add(finalRow);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ViewPaymentDetailsPopUp popup = new ViewPaymentDetailsPopUp("Payment Details", this);
	}*/
	public ViewPaymentDetails(String paymentDetails) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		setWidth("800px");
		try {
			if(paymentDetails!=null || paymentDetails.length()>0) {
				String details="["+paymentDetails+"]";
			JSONArray jsarr = null;
			try {
				jsarr=new JSONArray(details);
			}catch(Exception e) {
				e.printStackTrace();
			}
			
	//		System.out.println("jsarr=="+jsarr);
			if(jsarr.length()>0) {
				for(int i=0;i<jsarr.length();i++) {
					JSONObject js=jsarr.getJSONObject(i);
					//String usage_js=jsarr.getJSONObject(i).getString("usage_details");
					Iterator<String> jsKeys = js.keys();
					int c=0;
					do {
						String key = jsKeys.next();
						Div detailKeyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_KEY_DIV");
						Label detailKeyLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_KEY_LBL");
						detailKeyLbl.setText(key);
						detailKeyDiv.add(detailKeyLbl);
						
						Div detailValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_VAL_DIV");
						Label detailValLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_VAL_LBL");
						detailValLbl.setText(js.getString(key));
						detailValDiv.add(detailValLbl); 
						

						
						if(c % 3==0) {
							eachRow = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
							Div keyValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "KEY_VAL_DIV");
							keyValDiv.add(detailKeyDiv, detailValDiv);
							eachRow.add(keyValDiv);
						}else {
							Div keyValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "KEY_VAL_DIV");
							keyValDiv.add(detailKeyDiv, detailValDiv);
							eachRow.add(keyValDiv);
						}
						add(eachRow);
			          c++;
			        } while (c <= js.length()-1);
					
			/*		if(usage_js!=null || usage_js.length()>0) {
						JSONObject usagejsobj=new JSONObject(usage_js);
						if(usagejsobj.length()>0) {
							Iterator<String> jsKeys1 = usagejsobj.keys();
							int j=0;
							while(jsKeys1.hasNext()) {
								String key = jsKeys1.next();
								Div detailKeyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_KEY_DIV");
								Label detailKeyLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_KEY_LBL");
								detailKeyLbl.setText(key);
								detailKeyDiv.add(detailKeyLbl);
								
								Div detailValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAIL_VAL_DIV");
								Label detailValLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAIL_VAL_LBL");
								detailValLbl.setText(usagejsobj.getString(key));
								detailValDiv.add(detailValLbl); 
								
								if(j % 3==0) {
									eachRow = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
									Div keyValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "KEY_VAL_DIV");
									keyValDiv.add(detailKeyDiv, detailValDiv);
									eachRow.add(keyValDiv);
								}else {
									Div keyValDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "KEY_VAL_DIV");
									keyValDiv.add(detailKeyDiv, detailValDiv);
									eachRow.add(keyValDiv);
								}
								add(eachRow);
					          j++;
							}
							
						}
					}*/
				}
			}
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Payment details not available",ApplicationConstants.DialogTypes.INFO);
			}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ViewPaymentDetailsPopUp popup = new ViewPaymentDetailsPopUp("Details", this);
	}
}
