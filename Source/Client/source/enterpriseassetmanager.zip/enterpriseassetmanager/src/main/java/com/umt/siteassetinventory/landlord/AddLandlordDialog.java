package com.umt.siteassetinventory.landlord;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.framework.componentfactory.UploadDialog;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.FileTypeAttributeUploadDialog;
import com.umt.siteassetinventory.utility.LocalStorage;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasEnabled;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.dom.Element;
import com.vaadin.flow.server.InputStreamFactory;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.component.checkbox.Checkbox;

@CssImport("./styles/landlord-view.css")
public class AddLandlordDialog extends Dialog{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_LANDLORD_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv,additionalAttrDiv;
	private Div mainLayout,closeBtnDiv;
	private Button saveBtn,cancelBtn;
	
	private TextField idField,nameField,emailField,addressField,/*regionField,*/contactField;
	private NumberField latitudeField,longitudeField;
	private Div row4;
	
	private HashMap<String, List<Object>> dynamicAttributesMap;
	private String attrname;
	private Div col1Div,col2Div;
	private String mandatoryFlag;
	private String attributeDatatype;
	private boolean isSuccess=false;
	private Div row3Div;
	private String base64EncodedFileContent="";
	private Upload uploadDoc;
	private Image fileImage;
	private Div uploadpicDiv;
	private String base64EncodedFileContent1="";
	private String base64EncodedFileContent2="";
	private Map<String, JSONObject> fileAttributeMap = new HashMap<String, JSONObject>();
	private HashMap<String, List<Object>> updateddynamicSiteAttributesMap;
	private Div eachAttributeDiv;
	private ComboBox<String> regionField;
	private List<String> circleList=new ArrayList<String>();
	private Div row4Div,row5Div;
	
	public Button saveAsDraft_btn,clearDraft_btn;
	private JSONObject  temp_agreementAttributesJson;
	private String KEY_NAME = "ADD_LANDLORD_FORMVALUE";
	private JSONObject filecontentJson=new JSONObject();
	
	public AddLandlordDialog() 
	{
		 
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl,closeBtnDiv);
		
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		saveBtn.setDisableOnClick(true);
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		
		saveAsDraft_btn = UIFieldFactory.createButton(SCREENCD, "SAVE_DRAFT_BTN");
		clearDraft_btn = UIFieldFactory.createButton(SCREENCD, "CLEAR_DRAFT_BTN");
		
		buttonBar.add(saveAsDraft_btn,clearDraft_btn,saveBtn,cancelBtn);
		
		
//		generateFieldNameValuePair2();
		generateFieldNameValuePair3();
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();
		
		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
	
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveData();
			}
		});
		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});
		
		saveAsDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveAsDraft();
			}
		});

		clearDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				clearDraft();
			}
		});
		
		setFormValue();//save as draft
		
	}
	private void saveAsDraft() {
		try {
			JSONObject formvalue=new JSONObject();

			getFormValues();
			
			
			JSONObject saveobjJson=new JSONObject();
			
			saveobjJson.put("Name",nameField.getValue());
			saveobjJson.put("Address",addressField.getValue());
			saveobjJson.put("ContactNo",contactField.getValue());
			saveobjJson.put("Email",emailField.getValue());
			saveobjJson.put("Photo","");
		/*	if(filecontentJson.length()>0 && filecontentJson.has("filecontent")) {
				saveobjJson.put("Photo",filecontentJson.getString("filecontent"));
			}else {
				saveobjJson.put("Photo","");
			}*/
			
			
			
			formvalue.put("LandlordDetails",saveobjJson);
			formvalue.put("LandlordAttribute",temp_agreementAttributesJson);
			
			
		/*	LocalStorage.setItem(KEY_NAME,formvalue.toString());//set in localStorage
			LocalStorage.showStoredValue(KEY_NAME);
			SiteAssetInventoryUIFramework.getFramework().showMessage("Landlord saved as draft", ApplicationConstants.DialogTypes.INFO);*/
			
			formvalue.put("LandlordDetails",saveobjJson);
			formvalue.put("LandlordAttribute",temp_agreementAttributesJson);
			CommonUtils.insertDraftData("1", formvalue.toString(), "Landlord details saved as draft");
			System.out.println("saveAsDraft Landlord::::::::::"+formvalue);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	private void clearDraft() {
	//	LocalStorage.removeItem(KEY_NAME);
	//	LocalStorage.showStoredValue(KEY_NAME);
		CommonUtils.resetDraftData("1", "Landlord details reset successfully");
		resetFormValue();
	}
	
	
	protected void saveData() 
	{
		try
		{
			
			if((nameField.getValue().length()<=0) || (addressField.getValue().length()<=0))
//					||(emailField.getValue().length()<=0)||(contactField.getValue()==null
			//		|| (regionField.getValue()==null))
					//|| (regionField.getValue().length()<=0))
			{
				
				if(nameField.getValue().length()<=0)
				{
					nameField.setInvalid(true);
					nameField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(addressField.getValue().length()<=0)
				{
					addressField.setInvalid(true);
					addressField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(!CommonUtils.isEmailAddress(emailField.getValue()))
				{
					emailField.setInvalid(true);
					emailField.setErrorMessage("Please enter a valid email.");
					return;
				}
				/*		if(emailField.getValue().length()<=0)
				{
					emailField.setInvalid(true);
					emailField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(contactField.getValue().length()<=0)
				{
					contactField.setInvalid(true);
					contactField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				
				
				if(regionField.getValue().length()<=0)
				{
					regionField.setInvalid(true);
					regionField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}	*/
				
			}
			if((nameField.getValue().length()>0) && (addressField.getValue().length()>0))
	//				&&(contactField.getValue().length()>0)&&(emailField.getValue().length()>0)
		//			&&(regionField.getValue()!=null))
					//&&(regionField.getValue().length()>0))
			{
				
				JSONObject saveobjJson=new JSONObject();
				
				saveobjJson.put("Name",nameField.getValue());
				saveobjJson.put("Address",addressField.getValue());
				saveobjJson.put("ContactNo",contactField.getValue());
				saveobjJson.put("Email",emailField.getValue());
		//		saveobjJson.put("Region",regionField.getValue());
				saveobjJson.put("Photo",base64EncodedFileContent);
				
				
				JSONObject otherinfoJson=new JSONObject();
				
		/*		if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
				{	
				Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();
				
					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=dynamicAttributesMap.get(key);
						
						if(value.size()>0)	
						{	
							String datatype=dynamicAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=dynamicAttributesMap.get(key).get(2).toString();
							switch(datatype)
							 {
								 case "FLOV":
									// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
									 if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()==null)			
									 {
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
									 }
									 if(((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()!=null)			
									 {
										 otherinfoJson.put(key, ((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue());
									 }
									 break;
								 case "NUMERIC":
									 if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
										{
											 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
											 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
											 return;
										}
										if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
										{
											otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
										}
									 break;
								 case "ALPHANUMERIC":
									 if(mandatory.equalsIgnoreCase("1")&&((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
									 {
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
									 }
									 if(((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
									{
										 otherinfoJson.put(key, ((TextField)dynamicAttributesMap.get(key).get(1)).getValue());
									}
									 break;
								 case "DATE":
									 if (mandatory.equalsIgnoreCase("1")&&((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()==null)
										{
											 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
											 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
											 return;
	
										}
										if (((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()!=null)
										{
											otherinfoJson.put(key, CommonUtils.convertLocalDateToString(
													((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()));
										}
									 break;
								 case "FREEFLOW":
									 if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).toString().length()<=0)
										{
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
										}
										if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
										{
											otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
										}
									 break;
									 
									case "BOOLEAN"://AbhraC
										otherinfoJson.put(key,
												((Checkbox) dynamicAttributesMap.get(key).get(1)).getValue().toString());
										break;
									case "MULTIPLE SELECTION":
										CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) dynamicAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
											SiteAssetInventoryUIFramework.getFramework().showMessage(
													"Please select atleast one option for " + key, DialogTypes.INFO);
											return;
										}
										if (!checkboxGroup.isEmpty()) {
											otherinfoJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
										}
										break;
									case "IMAGE FILE":
										if (mandatory.equalsIgnoreCase("1") && fileAttributeMap.get(key) == null) {
											SiteAssetInventoryUIFramework.getFramework()
													.showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttributeMap.get(key) != null) {
											otherinfoJson.put(key, fileAttributeMap.get(key));
										}
										break;
									case "TEXT FILE":
										if (mandatory.equalsIgnoreCase("1") && fileAttributeMap.get(key) == null) {
											SiteAssetInventoryUIFramework.getFramework()
													.showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttributeMap.get(key) != null) {
											otherinfoJson.put(key, fileAttributeMap.get(key));
										}
										break;
									case "CUSTOM FILE":
										if (mandatory.equalsIgnoreCase("1") && fileAttributeMap.get(key) == null) {
											SiteAssetInventoryUIFramework.getFramework()
													.showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttributeMap.get(key) != null) {
											otherinfoJson.put(key, fileAttributeMap.get(key));
										}
										break;
							 }
						}	
					
				}
				}*/
				UIFileAttributeComponent fileAttribComp = null;
			//	System.out.println(updateddynamicSiteAttributesMap);
				if(updateddynamicSiteAttributesMap!=null && updateddynamicSiteAttributesMap.size()>0)
				{	
				Iterator<String> itrKeys = updateddynamicSiteAttributesMap.keySet().iterator();
				
					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=updateddynamicSiteAttributesMap.get(key);
						
						if(value.size()>0)	
						{	
							String datatype=updateddynamicSiteAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=updateddynamicSiteAttributesMap.get(key).get(2).toString();
							switch(datatype)
							 {
								 case "FLOV":
									// if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)			
									 if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue()==null)			
									 {
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
									 }
									 if(((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)			
									 {
										 otherinfoJson.put(key, ((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
									 }
									 break;
								 case "NUMERIC":
									 if (mandatory.equalsIgnoreCase("1")&&((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()==null)
										{
											 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
											 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
											 return;
										}
										if (((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
										{
											otherinfoJson.put(key, ((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
										}
									 break;
								 case "ALPHANUMERIC":
									 if(key.equalsIgnoreCase("PAN") && mandatory.equalsIgnoreCase("1") && 
											 ((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()!=10)
									 {
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage("PAN No must be 10 alphanumeric");
										 return;
									 }
									 if(mandatory.equalsIgnoreCase("1")&&((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
									 {
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
									 }
									 
									 if(((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
									{
										 otherinfoJson.put(key, ((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
									}
									 break;
								 case "DATE":
									 if (mandatory.equalsIgnoreCase("1")&&((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()==null)
										{
											 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
											 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"DATE_VALUE_MANDATORY"));
											 return;
	
										}
										if (((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
										{
											otherinfoJson.put(key, CommonUtils.convertLocalDateToString(
													((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()));
										}
									 break;
								 case "FREEFLOW":
									 if(key.equalsIgnoreCase("PIN") && mandatory.equalsIgnoreCase("1") && 
											 ((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()!=6)
									 {
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage("PIN must be 6 digits");
										 return;
									 }
									 if (mandatory.equalsIgnoreCase("1")&&((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
										{
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setInvalid(true);
										 ((HasValidation) updateddynamicSiteAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
										 return;
										}
										if (((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
										{
											otherinfoJson.put(key, ((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
										}
									 break;
									 
									case "BOOLEAN"://AbhraC
										otherinfoJson.put(key,
												((Checkbox) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString());
										break;
									case "MULTIPLE SELECTION":
										CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
											SiteAssetInventoryUIFramework.getFramework().showMessage(
													"Please select atleast one option for " + key, DialogTypes.INFO);
											return;
										}
										if (!checkboxGroup.isEmpty()) {
											otherinfoJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
										}
										break;
									case "IMAGE FILE":
										fileAttribComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && fileAttribComp.getFileJSON() == null) {
											SiteAssetInventoryUIFramework.getFramework()
													.showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttribComp.getFileJSON() != null) {
											otherinfoJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
									case "TEXT FILE":
										fileAttribComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && fileAttribComp.getFileJSON() == null) {
											SiteAssetInventoryUIFramework.getFramework().showMessage(
													"Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttribComp.getFileJSON() != null) {
											otherinfoJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
									case "CUSTOM FILE":
										fileAttribComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && fileAttribComp.getFileJSON() == null) {
											SiteAssetInventoryUIFramework.getFramework().showMessage(
													"Please upload a file for attribute " + key, DialogTypes.INFO);
											return;
										}
										if (fileAttribComp.getFileJSON() != null) {
											otherinfoJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
							 }
						}	
					
				}
				}
				
				saveobjJson.put("OtherInfo",otherinfoJson);
			//	System.out.println("saveobjJson="+saveobjJson);
				
				Form form =new Form();
				form.add("landlordDetails",saveobjJson);
				//System.out.println("form="+form);
				
				String url=ApplicationConfiguration.getServiceEndpoint("ADDLANDLORD");
		//		System.out.println("url="+url);
				RestServiceHandler.createJSON_POST(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				saveBtn.setEnabled(false);
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
				CommonUtils.resetDraftData("1", "none");
				isSuccess=true;
				close();
				
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			isSuccess=false;
	//		saveBtn.setEnabled(true);
		}
		finally {  
			saveBtn.setEnabled(true);  
		}    
		
	}
	public String getMultiSelectValue(Set<String> selectedItems) throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachVal = iterator.next();
			jsonArray.put(eachVal);
		}

		retVal.put("MultiSelectValue", jsonArray.toString());

		return retVal.toString();
	}
	private void generateFieldNameValuePair() 
	{
	try {	
		Div row1=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row2=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row3=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row4=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		
		Div eachDataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv7=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachDataDiv8=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		
		
		idField= UIFieldFactory.createTextField("", true, SCREENCD,"ID_FIELD");
		nameField= UIFieldFactory.createTextField("", true, SCREENCD,"NAME_FIELD");
		emailField= UIFieldFactory.createTextField("", false, SCREENCD,"EMAIL_FIELD");
		addressField= UIFieldFactory.createTextField("", true, SCREENCD,"ADDRESS_FIELD");
	//	regionField= UIFieldFactory.createTextField("", true, SCREENCD,"REGION_FIELD");
		regionField = UIFieldFactory.createComboBox(circleList, true,SCREENCD, "REGION_FIELD");
		populateCircleList();
				
		
		contactField= UIFieldFactory.createTextField("", false, SCREENCD,"CONTACT_FIELD");
		contactField.setPattern("[0-9]+");
		contactField.setPreventInvalidInput(true);
		
		latitudeField= UIFieldFactory.createNumberField(true, SCREENCD, "LATITUDE_FIELD");
		longitudeField=UIFieldFactory.createNumberField(true, SCREENCD, "LONGITUDE_FIELD");
		
		additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
	
		/*	Div additionalAttrheaderDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_HEADER_DIV");
		Label additionalAttr = UIHtmlFieldFactory.createLabel(SCREENCD, "ADDITIONAL_ATTR");
		additionalAttrheaderDiv.add(additionalAttr);
		additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
		col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
		col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
		Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
		colRowDiv.add(col1Div,col2Div);
		additionalAttrDiv.add(additionalAttrheaderDiv,colRowDiv);*/
		
		
		eachDataDiv1.add(idField);
		eachDataDiv2.add(nameField);
		eachDataDiv3.add(regionField);
		eachDataDiv4.add(emailField);
		eachDataDiv5.add(latitudeField);
		eachDataDiv6.add(longitudeField);
		eachDataDiv7.add(addressField);
		eachDataDiv8.add(contactField);
		
		
		
		row1.add(eachDataDiv1,eachDataDiv2);
		row2.add(eachDataDiv3,eachDataDiv7);
		row3.add(eachDataDiv4,eachDataDiv8);
		row4.add(eachDataDiv5,eachDataDiv6);
		bodyDiv.add(row1,row2,row3,row4,additionalAttrDiv);
		
		
		/***additional attr****/
		
		Map<String, JSONArray> attributeMap=retrieveLandlordLevelAttributes();
		JSONArray mapvalueArr=attributeMap.get("LANDLORD ATTRIBUTES");
		Div attrrow=null;
		dynamicAttributesMap = new HashMap<>();
		for(int i=0;i<mapvalueArr.length();i++)
		{
			
				JSONObject js=mapvalueArr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				Iterator<String> keys = js.keys();
				Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
				
				if((i%2)==0)
				{
					attrrow=UIHtmlFieldFactory.createDiv(SCREENCD, "ATTR_ROW_DIV");
				}
				
				    
				    attrname=js.getString("AttributeName");
				    String defaultval= "";
					if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
						defaultval=js.getString("DefaultValue");
					}
				    mandatoryFlag=js.getString("Mandatory").toString();
				    attributeDatatype=js.getString("AttributeDatatype");
				    
				    switch(attributeDatatype.toString())
				    {
				    case "5":
				    	String datatype="FLOV";
				    	List<String> choiceList=new ArrayList<String>();
				    	String str=js.getString("FLOV");
				    	String flovVal[]=str.split(",");
				    	choiceList.clear();
				    	for(String s:flovVal)
				    	{
				    		choiceList.add(s);
				    	}
				    	ComboBox<String> valueCombo = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "VALUE");
				    	valueCombo.setLabel(attrname);
				    	valueCombo.setInvalid(false);
				    	valueCombo.setValue(defaultval);
				    //	attrrow.add(valueCombo);
				    	
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(valueCombo);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    //	additionalAttrDiv.add(valueCombo);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		
				    		valueCombo.setRequired(true);
				    		valueCombo.setInvalid(false);
				    		valueCombo.setRequiredIndicatorVisible(true);
				    		valueCombo.setErrorMessage("");
				    	}
				    	
				    	eachDataDiv.add(valueCombo);
				    	attrrow.add(eachDataDiv);
				    	
				    	
				    	break;
				    case "1":
				    	datatype="NUMERIC";
				    	TextField numberTextField=UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
				    	numberTextField.setLabel(attrname);
				    	if(defaultval!=null && defaultval.length()>0)
						{
							numberTextField.setValue(defaultval);
						}
				  
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(numberTextField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		numberTextField.setRequiredIndicatorVisible(true);
				    	}
				    	numberTextField.setValueChangeMode(ValueChangeMode.EAGER);
						numberTextField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<?> arg0) {

								if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
								{
									numberTextField.setValue(arg0.getOldValue().toString());
								}
								if(!arg0.getValue().toString().matches("^\\w*$"))
								{
									numberTextField.setValue(arg0.getOldValue().toString());
								}
							}
						});
				    	eachDataDiv.add(numberTextField);
						attrrow.add(eachDataDiv);
				        break;
				    case "4":
				    	datatype="DATE";
				    	DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
				    	ValueDateField.setLabel(attrname);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(ValueDateField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(defaultval.length()>0)
				    	{
				    		ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
				    	}
				    	if(mandatoryFlag=="1")
				    	{
				    		ValueDateField.setRequired(true);
				    		ValueDateField.setRequiredIndicatorVisible(true);
				    	}
				    	eachDataDiv.add(ValueDateField);
						attrrow.add(eachDataDiv);
				    	
				        break; 
				    case "3":
				    	datatype="FREEFLOW";
				    	TextField textField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
				    	textField.setLabel(attrname);
				    	textField.setValue(defaultval);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(textField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		textField.setRequired(true);
				    		textField.setRequiredIndicatorVisible(true);
				    	}
				    	eachDataDiv.add(textField);
						attrrow.add(eachDataDiv);
				    	break;
				    case "2":
				    	datatype="ALPHANUMERIC";
				    	TextField alphanumericField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
				    	alphanumericField.setLabel(attrname);
				    	alphanumericField.setValue(defaultval);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(alphanumericField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		alphanumericField.setRequired(true);
				    		alphanumericField.setRequiredIndicatorVisible(true);
				    	}
				    	alphanumericField.setValueChangeMode(ValueChangeMode.EAGER);
						alphanumericField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<?> arg0) {

								if (! arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_")) {
									alphanumericField.setValue(arg0.getOldValue().toString());
								}
							}
						});
				    	eachDataDiv.add(alphanumericField);
						attrrow.add(eachDataDiv);
				    	break;
				    	
				   
				    default:
						break;   
				    }
				    dynamicAttributesMap.put(attrname,dataTypeList);
				additionalAttrDiv.add(attrrow);
			
		}
	}catch(Exception e)
	{
		e.printStackTrace();
	}	
		
	}
	
	private void populateCircleList() {
		circleList.clear();
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETCIRCLELIST");
			String resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
	
			
			if(resp!=null || resp.length()>0) {
				JSONArray ja = new JSONArray(resp);
				if(ja.length()>0) {
					for (int i = 0; i < ja.length(); i++) {
						JSONObject jo = ja.getJSONObject(i);
						circleList.add(jo.getString("CircleName"));
					}
					regionField.setItems(circleList);
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			
		}		
		
	}
	private Map<String, JSONArray>   retrieveLandlordLevelAttributes()
	{
		
		Map<String, JSONArray> attributeListMap= new LinkedHashMap<String, JSONArray>();
		String attributeType;

		String res = "",res1="";
		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");
			
			res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
		//	System.out.println(res);
			
		
		} 
		catch (Exception e) {
			
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			return null;
			
		}

		try {
			if (res != null) {
				JSONArray ja = new JSONArray(res);
				List<String> attributeNameListAccount = new ArrayList<String>();
			//	JSONObject eachjsobj=new JSONObject();
				JSONArray eachjsarr=new JSONArray();
				for (int i = 0; i < ja.length(); i++) {

					switch (ja.getJSONObject(i).getInt("AttributeType")) {
					case 8:
						eachjsarr.put(ja.getJSONObject(i));
						break;
					default:
						break;
					}
				}
				attributeListMap.put("LANDLORD ATTRIBUTES", eachjsarr);
				System.out.println("lanlordMap="+attributeListMap);
			}
		}catch(JSONException ex)
		{
			ex.printStackTrace();	
		}
		return attributeListMap;
		
	}
	public boolean isSuccess()
	{
		return isSuccess;
		
	}
	private void generateFieldNameValuePair3()
	{
		Div row1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV1");
		
		uploadpicDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOAD_PIC_DIV");
		Image defaultImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
		uploadpicDiv.add(defaultImage);
		Div cameraIcondiv=UIHtmlFieldFactory.createDiv(SCREENCD, "CAMERA_ICON_DIV");
		Icon imgUploadIcon = FontAwesome.Solid.CAMERA.create();
		imgUploadIcon.addClassName(SCREENCD+"_CAMERA_ICON");
		cameraIcondiv.add(imgUploadIcon);
		
		VerticalLayout imageLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "IMG_LAYOUT_VL");
		imageLayoutVL.add(uploadpicDiv,cameraIcondiv);
		
		VerticalLayout fieldLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "FIELD_LAYOUT_VL");
		
		nameField= UIFieldFactory.createTextField("", true, SCREENCD,"NAME_FIELD");
		addressField= UIFieldFactory.createTextField("", true, SCREENCD,"ADDRESS_FIELD");
		
		fieldLayoutVL.add(nameField,addressField);
		row1Div.add(imageLayoutVL,fieldLayoutVL);
		
		emailField= UIFieldFactory.createTextField("", false, SCREENCD,"EMAIL_FIELD");
		emailField.setValueChangeMode(ValueChangeMode.EAGER);
	
		
	//	regionField = UIFieldFactory.createComboBox(circleList, true,SCREENCD, "REGION_FIELD");
	//	populateCircleList();
		contactField= UIFieldFactory.createTextField("", false, SCREENCD,"CONTACT_FIELD");
		contactField.setPattern("[0-9]+");
		contactField.setPreventInvalidInput(true);
		
		Div row2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV2");
		row3Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV3");
		
		row2Div.add(emailField,contactField);
	//	row3Div.add(regionField);
		
		additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
		col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
		col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
		Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
		colRowDiv.add(col1Div,col2Div);
	//	additionalAttrDiv.add(colRowDiv);
		
		row4Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV3");
		row5Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV3");
		
		bodyDiv.removeAll();
		bodyDiv.add(row1Div,row4Div,row5Div,row2Div,/*row3Div,*/additionalAttrDiv);
		
		emailField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0 && !CommonUtils.isEmailAddress(emailField.getValue()))
				{
					emailField.setInvalid(true);
					emailField.setErrorMessage("Please enter a valid email.");
					
				}else if(value.length()>0 && CommonUtils.isEmailAddress(emailField.getValue())){
					emailField.setInvalid(false);
					emailField.setErrorMessage("");
				}else {
					emailField.setInvalid(false);
					emailField.setErrorMessage("");
				}


			}
		});
		
		cameraIcondiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>(){
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				
				UploadDocumentDialog dlg =new UploadDocumentDialog("Image",base64EncodedFileContent1);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						UploadDocumentDialog srcDlg = (UploadDocumentDialog)event.getSource();
						
						if(!srcDlg.isOpened()&&(srcDlg.isGetDocUploadStatus()==true))
						{
							base64EncodedFileContent = srcDlg.getFileContent();
							populateImgPreviewDiv(base64EncodedFileContent);
							try {
								filecontentJson.put("filecontent", srcDlg.getFileContent());
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

				});

			}
		});
		
		
		
		Map<String, JSONArray> attributeMap=retrieveLandlordLevelAttributes();
		JSONArray mapvalueArr=attributeMap.get("LANDLORD ATTRIBUTES");
		Div attrrow=null;
		dynamicAttributesMap = new HashMap<>();
		updateddynamicSiteAttributesMap=new HashMap<>();
		fileAttributeMap.clear();
		Div fileAttribComp;
		
		try {
			eachAttributeDiv = null;
			for(int i=0; i<mapvalueArr.length(); i++)
			{
				JSONObject js=mapvalueArr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
				//Iterator<String> keys = js.keys();
				//Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ATTR_DATA_DIV");


				String attrname=js.getString("AttributeName");
				String defaultval= "";
				if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
					defaultval=js.getString("DefaultValue");
				}
				String mandatoryFlag=js.getString("Mandatory").toString();
				String attributeDatatype=js.getString("AttributeDatatype");
				
				eachAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ATTRIBUTE_FLD_DIV");

				switch(attributeDatatype.toString()/*key.toUpperCase()*/)
				{
				case "5":
					String datatype="FLOV";
					List<String> choiceList=new ArrayList<String>();
					String str=js.getString("FLOV");
					String flovVal[]=str.split(",");
					choiceList.clear();
					for(String s:flovVal)
					{
						choiceList.add(s);
					}
					ComboBox<String> attributeComboBox = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "ATTRIBUTE_COMBO_FIELD");
					attributeComboBox.setLabel(attrname);
					//attributeComboBox.setInvalid(false);
					if(defaultval.length()>0)
					{
						attributeComboBox.setValue(defaultval);
					}
					//	attrrow.add(attributeComboBox);

					dataTypeList.add(datatype);
					dataTypeList.add(attributeComboBox);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					//	additionalAttrDiv.add(attributeComboBox);
					if(mandatoryFlag.equals("1"))
					{

						attributeComboBox.setRequired(true);
						attributeComboBox.setErrorMessage("");
						attributeComboBox.setRequiredIndicatorVisible(true);
						
						attributeComboBox.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
							
							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<String> event) {
								String value = event.getValue();
								if (value != null) {
									attributeComboBox.setInvalid(false);
									attributeComboBox.setErrorMessage("");
								}else {
									attributeComboBox.setInvalid(true);
									attributeComboBox.focus();
									attributeComboBox.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
								}

							}
						});
					}
				//	detailsTabVL.add(attributeComboBox);
					
					if(attrname.equalsIgnoreCase("State")) {
						eachAttributeDiv.getStyle().set("display", "none");
						row4Div.add(attributeComboBox);
						attributeComboBox.getStyle().set("width", "48%");
					}else {
						eachAttributeDiv.getStyle().set("display", "flex");
						eachAttributeDiv.add(attributeComboBox);
					}
					
					break;
				case "1":
			/*		datatype="NUMERIC";
			  		TextField attributeNumberTxtFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					//	numberField.getStyle().set("width", "48.2%");
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(defaultval);
					}
					//	additionalAttrDiv.add(numberField);
					// 	attrrow.add(numberField);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					attributeNumberTxtFld.setValueChangeMode(ValueChangeMode.EAGER);
			//		attributeNumberTxtFld.setPattern("^\\d+(\\.\\d)?\\d*$");
			//		attributeNumberTxtFld.setPreventInvalidInput(true);
					attributeNumberTxtFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

						//	if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
							if(!arg0.getValue().toString().matches("[0-9.{0,1}]+") && !arg0.getValue().toString().matches(""))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
							if(!arg0.getValue().toString().matches("^\\w*$"))
							{
								attributeNumberTxtFld.setValue(arg0.getOldValue().toString());
							}
						}
					});*/
				//	detailsTabVL.add(attributeNumberTxtFld);
					datatype="NUMERIC";
					NumberField attributeNumberTxtFld = UIFieldFactory.createNumberField(false, SCREENCD, "ATTRIBUTE_NUMBER_FIELD");
					attributeNumberTxtFld.setLabel(attrname);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeNumberTxtFld.setValue(Double.parseDouble(defaultval));
					}
					dataTypeList.add(datatype);
					dataTypeList.add(attributeNumberTxtFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeNumberTxtFld.setRequiredIndicatorVisible(true);

					}
					eachAttributeDiv.add(attributeNumberTxtFld);
//					if(attrname.equalsIgnoreCase("PIN")) {
//						eachAttributeDiv.getStyle().set("display", "none");
//						row5Div.add(attributeNumberTxtFld/*,regionField*/);
//						attributeNumberTxtFld.getStyle().set("width","48%");
//						
//						validatePINField(attributeNumberTxtFld);
//					}else {
//						eachAttributeDiv.getStyle().set("display", "flex");
//						eachAttributeDiv.add(attributeNumberTxtFld);
//					}
					break;
				case "4":
					datatype="DATE";
					DatePicker attributeDateFld = UIFieldFactory.createDatePicker(false, SCREENCD, "ATTRIBUTE_DATE_FIELD");
					attributeDateFld.setLabel(attrname);
					//	attributeDateFld.getStyle().set("width", "48.2%");
					//	additionalAttrDiv.add(attributeDateFld);
					//	attrrow.add(attributeDateFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeDateFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(defaultval!=null && defaultval.length()>0)
					{
						attributeDateFld.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
					}
					if(mandatoryFlag=="1")
					{
						attributeDateFld.setRequired(true);
						attributeDateFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeDateFld);
					eachAttributeDiv.add(attributeDateFld);
					break; 
				case "3":
					datatype="FREEFLOW";
					TextField attributeFreeflowFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeFreeflowFld.setLabel(attrname);
					//	attributeFreeflowFld.getStyle().set("width", "48.2%");
					attributeFreeflowFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeFreeflowFld);
					//	attrrow.add(attributeFreeflowFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeFreeflowFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeFreeflowFld.setRequired(true);
						attributeFreeflowFld.setRequiredIndicatorVisible(true);
					}
					//detailsTabVL.add(attributeFreeflowFld);
				//	eachAttributeDiv.add(attributeFreeflowFld);
					if(attrname.equalsIgnoreCase("PIN")) {
						eachAttributeDiv.getStyle().set("display", "none");
						row5Div.add(attributeFreeflowFld);
						attributeFreeflowFld.getStyle().set("width","48%");
						
						validatePINField(attributeFreeflowFld);
					}
					else if(attrname.equalsIgnoreCase("Landlord City")) {
						eachAttributeDiv.getStyle().set("display", "none");
						row4Div.add(attributeFreeflowFld);
						attributeFreeflowFld.getStyle().set("width", "48%");
					}else {
						eachAttributeDiv.getStyle().set("display", "flex");
						eachAttributeDiv.add(attributeFreeflowFld);
					}
					break;
				case "2":
					datatype="ALPHANUMERIC";
					TextField attributeAlphanumericFld = UIFieldFactory.createTextField("", false, SCREENCD, "ATTRIBUTE_TEXT_FIELD");
					attributeAlphanumericFld.setLabel(attrname);
					//	attributeAlphanumericFld.getStyle().set("width", "48.2%");
					attributeAlphanumericFld.setValue(defaultval);
					//	additionalAttrDiv.add(attributeAlphanumericFld);
					//	attrrow.add(attributeAlphanumericFld);
					dataTypeList.add(datatype);
					dataTypeList.add(attributeAlphanumericFld);
					dataTypeList.add(mandatoryFlag);
					dataTypeList.add(eachAttributeDiv);
					if(mandatoryFlag.equals("1"))
					{
						attributeAlphanumericFld.setRequired(true);
						attributeAlphanumericFld.setRequiredIndicatorVisible(true);
					}
					attributeAlphanumericFld.setValueChangeMode(ValueChangeMode.EAGER);
					attributeAlphanumericFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
							{
								attributeAlphanumericFld.setValue(arg0.getOldValue().toString());
							}
						}
					});
					if(attrname.equalsIgnoreCase("PAN")) {
						validatePANField(attributeAlphanumericFld);
					}
					//detailsTabVL.add(attributeAlphanumericFld);
					eachAttributeDiv.add(attributeAlphanumericFld);
					break;
				case "6":
					datatype = "BOOLEAN";
					Checkbox booleanFld=UIFieldFactory.createCheckbox(false,false, SCREENCD, "VALUE");
					booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
					booleanFld.addClassName(SCREENCD + "_VALUE");
					booleanFld.setLabel(attrname);
					if(defaultval != null && defaultval.trim().toLowerCase().equals("true")) {
						booleanFld.setValue(true);
					} else {
						booleanFld.setValue(false);
					}
					
					dataTypeList.add(datatype);
					dataTypeList.add(booleanFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(booleanFld);
					eachAttributeDiv.add(booleanFld);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "7":
					datatype = "MULTIPLE SELECTION";
					CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
					multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
					multiSelectFld.addClassName(SCREENCD + "_VALUE");
					multiSelectFld.setLabel(attrname);
					String possibleValues = js.getString("FLOV");
					renderMultiSelectField(multiSelectFld, possibleValues, defaultval);
										
					dataTypeList.add(datatype);
					dataTypeList.add(multiSelectFld);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(multiSelectFld);
					eachAttributeDiv.add(multiSelectFld);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "8":
					datatype = "IMAGE FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 8);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "9":
					datatype = "TEXT FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 9);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				case "10":
					datatype = "CUSTOM FILE";
					//fileAttribComp = renderFileUploadComponent(attrname, 10);
					fileAttribComp = new UIFileAttributeComponent(attrname, Integer.parseInt(attributeDatatype), mandatoryFlag, "File Attribute");
					fileAttribComp.addClassName(SCREENCD + "_VALUE");
					dataTypeList.add(datatype);
					dataTypeList.add(fileAttribComp);
					dataTypeList.add(mandatoryFlag);
					//detailsTabVL.add(fileAttribComp);
					eachAttributeDiv.add(fileAttribComp);
					dataTypeList.add(eachAttributeDiv);
					break;
				default:
					break;   
				}
				additionalAttrDiv.add(eachAttributeDiv);
				dynamicAttributesMap.put(attrname,dataTypeList);
				updateddynamicSiteAttributesMap.put(attrname,dataTypeList);
				
				if(attrname.equalsIgnoreCase("SAP Vendor Code")) {
					((HasEnabled) dataTypeList.get(1)).setEnabled(false);
				}

			}
			
			attributeUIOrchestration();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void validatePINField(TextField attributeFreeflowFld) {
		attributeFreeflowFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		attributeFreeflowFld.setPattern("([0-9]{0,6})");//allows  6digit only 
		attributeFreeflowFld.setPreventInvalidInput(true);
		
		attributeFreeflowFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0) {
					 if(attributeFreeflowFld.getValue().length()!=6) {
						 attributeFreeflowFld.setInvalid(true);
						 attributeFreeflowFld.setErrorMessage("PIN must be 6 digits");
					}
					else {
						attributeFreeflowFld.setInvalid(false);
						attributeFreeflowFld.setErrorMessage("");
					}

				}


			}
		});
			

		
	}
	private void validatePANField(TextField attributeAlphanumericFld) {
		attributeAlphanumericFld.setValueChangeMode(ValueChangeMode.EAGER);
		attributeAlphanumericFld.setPattern("([a-zA-Z0-9]{0,10})");//allows  10digit only caps
		attributeAlphanumericFld.setPreventInvalidInput(true);
		
		attributeAlphanumericFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				
				if(value.length()>0) {
					 if(attributeAlphanumericFld.getValue().length()!=10) {
						attributeAlphanumericFld.setInvalid(true);
						attributeAlphanumericFld.setErrorMessage("PAN No must be 10 alphanumeric.");
					}
					else {
						attributeAlphanumericFld.setInvalid(false);
						attributeAlphanumericFld.setErrorMessage("");
					}
					 attributeAlphanumericFld.setValue(event.getValue().toUpperCase());

				}


			}
		});
		
	}
	private void generateFieldNameValuePair2() 
	{
	try
	{
		Div row1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV1");
		
		uploadpicDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOAD_PIC_DIV");
		Image defaultImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
		uploadpicDiv.add(defaultImage);
		Div cameraIcondiv=UIHtmlFieldFactory.createDiv(SCREENCD, "CAMERA_ICON_DIV");
		Icon imgUploadIcon = FontAwesome.Solid.CAMERA.create();
		imgUploadIcon.addClassName(SCREENCD+"_CAMERA_ICON");
		cameraIcondiv.add(imgUploadIcon);
		
		VerticalLayout imageLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "IMG_LAYOUT_VL");
		imageLayoutVL.add(uploadpicDiv,cameraIcondiv);
		
		VerticalLayout fieldLayoutVL= UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "FIELD_LAYOUT_VL");
		
		nameField= UIFieldFactory.createTextField("", true, SCREENCD,"NAME_FIELD");
		addressField= UIFieldFactory.createTextField("", true, SCREENCD,"ADDRESS_FIELD");
		
		fieldLayoutVL.add(nameField,addressField);
		row1Div.add(imageLayoutVL,fieldLayoutVL);
		
		emailField= UIFieldFactory.createTextField("", false, SCREENCD,"EMAIL_FIELD");
	//	regionField= UIFieldFactory.createTextField("", true, SCREENCD,"REGION_FIELD");
		regionField = UIFieldFactory.createComboBox(circleList, true,SCREENCD, "REGION_FIELD");
		populateCircleList();
		contactField= UIFieldFactory.createTextField("", false, SCREENCD,"CONTACT_FIELD");
		contactField.setPattern("[0-9]+");
		contactField.setPreventInvalidInput(true);
		
		Div row2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV2");
		row3Div=UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROWDIV3");
		
		row2Div.add(emailField,contactField);
		row3Div.add(regionField);
		
		additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
		col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
		col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
		Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
		colRowDiv.add(col1Div,col2Div);
		additionalAttrDiv.add(colRowDiv);
		
		bodyDiv.add(row1Div,row2Div,row3Div,additionalAttrDiv);
		
		
		
	/*	UploadDialog uploadDlg = new UploadDialog("Image");
		String[] acceptedFileTypes = {".png", ".jpg", ".jpeg", ".gif"};
		int maxfilesize=Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDlg.setAcceptedFileTypes(acceptedFileTypes);
		uploadDlg.setMaxFileSize(maxfilesize*1000);
		
		
		cameraIcondiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>(){
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				
				uploadDlg.open();
				uploadDoc = uploadDlg.getUpload();

			}
		});*/
		
	/*	uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
				if(!event.isOpened()) {
					if(event.getSource() instanceof UploadDialog) {
						UploadDialog eventSrcDlg = (UploadDialog)event.getSource();
						if(eventSrcDlg.isDoneClicked()) {
							InputStream inputStream = eventSrcDlg.getInputStream();

							String fileExtension = eventSrcDlg.getFileExtension();

							try {
								if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) {
									BufferedImage image = ImageIO.read(inputStream);
									ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
									ImageIO.write(image, fileExtension, outputStream);
									base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
									populateImgPreviewDiv(base64EncodedFileContent);
								}
								
							} catch (Exception ex) {
								base64EncodedFileContent = "";
							}
						}
					/*	if(eventSrcDlg.isUploadFailed()) {
							SiteAssetInventoryUIFramework.getFramework().showMessage
							(eventSrcDlg.getFailedEvent().getReason().getMessage(), DialogTypes.ERROR);
							eventSrcDlg.getFailedEvent().getUpload().interruptUpload();
						}
						if(eventSrcDlg.isUploadRejected()) {
							SiteAssetInventoryUIFramework.getFramework().
							showMessage(eventSrcDlg.getRejectedEvent().getErrorMessage(), DialogTypes.ERROR);
						}*/
				//	}
			//	}
	//		}
	//	});*/
		
	/*	uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {
				System.out.println("Error");
				SiteAssetInventoryUIFramework.getFramework().
				showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().
				showMessage(event.getErrorMessage(), DialogTypes.ERROR);
			}
		});*/
		
		cameraIcondiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>(){
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				
				UploadDocumentDialog dlg =new UploadDocumentDialog("Image",base64EncodedFileContent1);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						UploadDocumentDialog srcDlg = (UploadDocumentDialog)event.getSource();
						
						if(!srcDlg.isOpened()&&(srcDlg.isGetDocUploadStatus()==true))
						{
							base64EncodedFileContent = srcDlg.getFileContent();
							populateImgPreviewDiv(base64EncodedFileContent);
						}
					}

				});

			}
		});
		
		
		
		
		
		
		Map<String, JSONArray> attributeMap=retrieveLandlordLevelAttributes();
		JSONArray mapvalueArr=attributeMap.get("LANDLORD ATTRIBUTES");
		Div attrrow=null;
		dynamicAttributesMap = new HashMap<>();
		updateddynamicSiteAttributesMap=new HashMap<>();
		fileAttributeMap.clear();
		UIFileAttributeComponent fileAttribComp = null;
		
		
		for(int i=0;i<mapvalueArr.length();i++)
		{
			
				JSONObject js=mapvalueArr.getJSONObject(i);
				List<Object> dataTypeList = new ArrayList<>();
			//	Iterator<String> keys = js.keys();
				Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
				
				    attrname=js.getString("AttributeName");
				    String defaultval= "";
					if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
						defaultval=js.getString("DefaultValue");
					}
				    mandatoryFlag=js.getString("Mandatory").toString();
				    attributeDatatype=js.getString("AttributeDatatype");
				    
				    switch(attributeDatatype.toString())
				    {
				    case "5":
				    	String datatype="FLOV";
				    	List<String> choiceList=new ArrayList<String>();
				    	String str=js.getString("FLOV");
				    	String flovVal[]=str.split(",");
				    	choiceList.clear();
				    	for(String s:flovVal)
				    	{
				    		choiceList.add(s);
				    	}
				    	ComboBox<String> valueCombo = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "VALUE");
				    	valueCombo.setLabel(attrname);
				    	valueCombo.setInvalid(false);
				    	valueCombo.setValue(defaultval);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(valueCombo);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		
				    		valueCombo.setRequired(true);
				    		valueCombo.setErrorMessage("");
				    		valueCombo.setRequiredIndicatorVisible(true);
				    	}
				    	if(i==0)
				    	{
				    		valueCombo.getStyle().set("width", "49%");
				    		row3Div.add(valueCombo);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(valueCombo);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(valueCombo);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}    	
				    	
				    	break;
				    case "1":
				    	datatype="NUMERIC";
				    	TextField numberTextField = UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
				    	numberTextField.setLabel(attrname);
				    	if (defaultval.length()>0) {
				    		numberTextField.setValue(defaultval);
						}
				    	
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(numberTextField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		numberTextField.setRequiredIndicatorVisible(true);
				    		
				    	}
				    	numberTextField.setValueChangeMode(ValueChangeMode.EAGER);
						numberTextField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<?> arg0) {

								if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
								{
									numberTextField.setValue(arg0.getOldValue().toString());
								}
								if(!arg0.getValue().toString().matches("^\\w*$"))
								{
									numberTextField.setValue(arg0.getOldValue().toString());
								}
							}
						});
				    	if(i==0)
				    	{
				   // 		attrrow.remove(numberField);
				    		numberTextField.getStyle().set("width", "49%");
				    		row3Div.add(numberTextField);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(numberTextField);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(numberTextField);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}    	
				        break;
				    case "4":
				    	datatype="DATE";
				    	DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
				    	ValueDateField.setLabel(attrname);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(ValueDateField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(defaultval.length()>0)
				    	{
				    		ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
				    	}
				    	if(mandatoryFlag=="1")
				    	{
				    		ValueDateField.setRequired(true);
				    		ValueDateField.setRequiredIndicatorVisible(true);
				    	}
				    	if(i==0)
				    	{
				    	//	attrrow.remove(ValueDateField);
				    		ValueDateField.getStyle().set("width", "49%");
				    		row3Div.add(ValueDateField);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(ValueDateField);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(ValueDateField);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}   
				    	
				        break; 
				    case "3":
				    	datatype="FREEFLOW";
				    	TextField textField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
				    	textField.setLabel(attrname);
				    	textField.setValue(defaultval);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(textField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		textField.setRequired(true);
				    		textField.setRequiredIndicatorVisible(true);
				    	}
				    	if(i==0)
				    	{
				   // 		attrrow.remove(textField);
				    		textField.getStyle().set("width", "49%");
				    		row3Div.add(textField);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(textField);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(textField);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}   
				    	
				    	break;
				    case "2":
				    	datatype="ALPHANUMERIC";
				    	TextField alphanumericField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
				    	alphanumericField.setLabel(attrname);
				    	alphanumericField.setValue(defaultval);
				    	dataTypeList.add(datatype);
				    	dataTypeList.add(alphanumericField);
				    	dataTypeList.add(mandatoryFlag);
				    	dataTypeList.add(eachDataDiv);
				    	if(mandatoryFlag.equals("1"))
				    	{
				    		alphanumericField.setRequired(true);
				    		alphanumericField.setRequiredIndicatorVisible(true);
				    	}
				    	alphanumericField.setValueChangeMode(ValueChangeMode.EAGER);
						alphanumericField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

							private static final long serialVersionUID = 1L;

							@Override
							public void valueChanged(ValueChangeEvent<?> arg0) {

								if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
								{
									alphanumericField.setValue(arg0.getOldValue().toString());
								}
							}
						});
				    	if(i==0)
				    	{
				    //		attrrow.remove(alphanumericField);
				    		alphanumericField.getStyle().set("width", "49%");
				    		row3Div.add(alphanumericField);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(alphanumericField);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(alphanumericField);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}   
				    	
				    	break;
				    	
				/*    case "6":
				    	datatype="FILE";
				    	Button uploadBtn = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BUTTON");
				    	UploadDialog uploadDlg = new UploadDialog("Company Profile Logo");
						
						String[] acceptedFileTypes = {".png", ".jpg", ".jpeg", ".gif", ".bmp",".pdf",".docx",".doc",".txt"};
						uploadDlg.setAcceptedFileTypes(acceptedFileTypes);
						
						Div uploadbtnrowdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOAD_BTN_ROW_DIV");
						Div previewdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PREVIEW_DIV");
						uploadbtnrowdiv.add(uploadBtn,previewdiv);
						
						dataTypeList.add(datatype);
				    	dataTypeList.add(uploadbtnrowdiv);
				    	dataTypeList.add(mandatoryFlag);
						
						uploadBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onComponentEvent(ClickEvent<Button> event) {
								uploadDlg.open();
							}
						});
						
						uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
								if(!event.isOpened()) {
									if(event.getSource() instanceof UploadDialog) {
										UploadDialog eventSrcDlg = (UploadDialog)event.getSource();
										if(eventSrcDlg.isDoneClicked()) {
											InputStream inputStream = eventSrcDlg.getInputStream();
											// FileInputStream uploadedFileInputStream = new
											// FileInputStream(fileBuffer.getFileDescriptor());

											String fileExtension = eventSrcDlg.getFileExtension();
											//fileUploadSuccessful = true;
											try {
												BufferedImage image = ImageIO.read(inputStream);
												ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
												ImageIO.write(image, fileExtension, outputStream);
												base64EncodedFileContent2 = Base64.getEncoder().encodeToString(outputStream.toByteArray());
												if(eventSrcDlg.isUploadFailed()) {
												//	fileUploadSuccessful = false;
													base64EncodedFileContent2 = "";
												}
												if(eventSrcDlg.isUploadRejected()) {
													//row7.remove(previewLogoImgDiv);
												}
												populateDocumentPreview(base64EncodedFileContent2,previewdiv);
											} catch (Exception ex) {
												//	ex.printStackTrace();
												base64EncodedFileContent2 = "";
											}
										}
										else
											if(eventSrcDlg.isCancelClicked()) {
												base64EncodedFileContent2 = "";
											}
										

									}
								}
							}
						});
						
						

						if(i==0)
				    	{
							//uploadBtn.getStyle().set("width", "49%");
				    		row3Div.add(uploadBtn);
				    	}
				    	if(i!=0)
				    	{
				    		if(i%2!=0)
				    		{
				    			eachDataDiv.add(uploadbtnrowdiv);
				    			col1Div.add(eachDataDiv);
				    		}	
				    		if(i%2==0)
				    		{
				    			eachDataDiv.add(uploadbtnrowdiv);
				    			col2Div.add(eachDataDiv);
				    		}	
				    	}   
				    	
				    	break;*/
				    	
					case "6":
						datatype = "BOOLEAN";
						Checkbox booleanFld = UIFieldFactory.createCheckbox(false, false, SCREENCD, "VALUE");
						booleanFld.addClassName(SCREENCD + "_BOOLEAN_VALUE");
						booleanFld.setLabel(attrname);
						// alphanumericField.getStyle().set("width", "48.2%");
						if (defaultval.trim().toLowerCase().equals("true")) {
							booleanFld.setValue(true);
						}

						dataTypeList.add(datatype);
						dataTypeList.add(booleanFld);
						dataTypeList.add(mandatoryFlag);
						dataTypeList.add(eachDataDiv);

						if (i == 0) {
							// attrrow.remove(textField);
							booleanFld.getStyle().set("width", "49%");
							row3Div.add(booleanFld);
						}
						if (i != 0) {
							if (i % 2 != 0) {
								eachDataDiv.add(booleanFld);
								col1Div.add(eachDataDiv);
							}
							if (i % 2 == 0) {
								eachDataDiv.add(booleanFld);
								col2Div.add(eachDataDiv);
							}
						}

						break;

					case "7":
						datatype = "MULTIPLE SELECTION";
						CheckboxGroup<String> multiSelectFld = new CheckboxGroup<String>();
						multiSelectFld.addClassName(SCREENCD + "_MULTI_SELECT_VALUE_FLD");
						multiSelectFld.setLabel(attrname);
						String possibleValues = js.getString("FLOV");
						renderMultiSelectField(multiSelectFld, possibleValues, defaultval);

						dataTypeList.add(datatype);
						dataTypeList.add(multiSelectFld);
						dataTypeList.add(mandatoryFlag);
						dataTypeList.add(eachDataDiv);

						if (i == 0) {
							// attrrow.remove(textField);
							multiSelectFld.getStyle().set("width", "49%");
							row3Div.add(multiSelectFld);
						}
						if (i != 0) {
							if (i % 2 != 0) {
								eachDataDiv.add(multiSelectFld);
								col1Div.add(eachDataDiv);
							}
							if (i % 2 == 0) {
								eachDataDiv.add(multiSelectFld);
								col2Div.add(eachDataDiv);
							}
						}

						break;

					case "8":
						datatype = "IMAGE FILE";
						//fileAttribComp = renderFileUploadComponent(attrname, 8);
						fileAttribComp = new UIFileAttributeComponent(attrname, 8, mandatoryFlag, "File Attribute");
						dataTypeList.add(datatype);
						dataTypeList.add(fileAttribComp);
						dataTypeList.add(mandatoryFlag);
						dataTypeList.add(eachDataDiv);
						if (i == 0) {
							// attrrow.remove(textField);
							fileAttribComp.getStyle().set("width", "49%");
							row3Div.add(fileAttribComp);
						}
						if (i != 0) {
							if (i % 2 != 0) {
								eachDataDiv.add(fileAttribComp);
								col1Div.add(eachDataDiv);
							}
							if (i % 2 == 0) {
								eachDataDiv.add(fileAttribComp);
								col2Div.add(eachDataDiv);
							}
						}
						break;

					case "9":
						datatype = "TEXT FILE";
						//fileAttribComp = renderFileUploadComponent(attrname, 9);
						fileAttribComp = new UIFileAttributeComponent(attrname, 9, mandatoryFlag, "File Attribute");
						dataTypeList.add(datatype);
						dataTypeList.add(fileAttribComp);
						dataTypeList.add(mandatoryFlag);
						dataTypeList.add(eachDataDiv);
						if (i == 0) {
							// attrrow.remove(textField);
							fileAttribComp.getStyle().set("width", "49%");
							row3Div.add(fileAttribComp);
						}
						if (i != 0) {
							if (i % 2 != 0) {
								eachDataDiv.add(fileAttribComp);
								col1Div.add(eachDataDiv);
							}
							if (i % 2 == 0) {
								eachDataDiv.add(fileAttribComp);
								col2Div.add(eachDataDiv);
							}
						}
						break;

					case "10":
						datatype = "CUSTOM FILE";
						//fileAttribComp = renderFileUploadComponent(attrname, 10);
						fileAttribComp = new UIFileAttributeComponent(attrname, 10, mandatoryFlag, "File Attribute");
						dataTypeList.add(datatype);
						dataTypeList.add(fileAttribComp);
						dataTypeList.add(mandatoryFlag);
						dataTypeList.add(eachDataDiv);
						if (i == 0) {
							// attrrow.remove(textField);
							fileAttribComp.getStyle().set("width", "49%");
							row3Div.add(fileAttribComp);
						}
						if (i != 0) {
							if (i % 2 != 0) {
								eachDataDiv.add(fileAttribComp);
								col1Div.add(eachDataDiv);
							}
							if (i % 2 == 0) {
								eachDataDiv.add(fileAttribComp);
								col2Div.add(eachDataDiv);
							}
						}
						break;
				    default:
						break;   
				    }
				    dynamicAttributesMap.put(attrname,dataTypeList);
				    updateddynamicSiteAttributesMap.put(attrname,dataTypeList);
			
		}
		
		attributeUIOrchestration();
		
		
		
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	
	protected Div renderFileUploadComponent(String aname, int adatatype) {
		Div fileAttributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ATTRIB_DIV");
		Button fileAttributeBtn = UIFieldFactory.createButton(SCREENCD, "FILE_ATTRIB_BTN");
		fileAttributeBtn.setText(SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "FILE_ATTRIB_BTN"));
		
		fileAttributeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				String [] acceptedFileTypes = null;
				if(adatatype == 8) {
					acceptedFileTypes = ".png,.jpg,.jpeg,.gif,.bmp".split("[,]");
				} else if(adatatype == 9) {
					acceptedFileTypes = ".txt".split("[,]");
					//uploadDoc.setAcceptedFileTypes(".txt");
				} else if(adatatype == 10) {
					//uploadDoc.setAcceptedFileTypes(".pdf",".doc", ".docx", ".txt",".png", ".jpg", ".jpeg", ".gif",".bmp",".xls",".xlsx");
					acceptedFileTypes = ".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.bmp,.xls,.xlsx".split("[,]");
				}

				FileTypeAttributeUploadDialog uploadDlg = new FileTypeAttributeUploadDialog(aname, "Landlord File Attribute", acceptedFileTypes);
				uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						FileTypeAttributeUploadDialog dlg = (FileTypeAttributeUploadDialog)event.getSource();
						if(!dlg.isOpened()) {
							if(dlg.isGetDocUploadStatus()) {
								JSONObject fileDetailJSON = dlg.getFileDetail();
								if(fileDetailJSON != null && fileDetailJSON.length() > 0) {
									fileAttributeMap.put(aname, fileDetailJSON);
								}
								else {
									fileAttributeMap.remove(aname);
								}
							}
							else {
								fileAttributeMap.remove(aname);
							}
						}
					}
				});
			}
		});
		
		Label fileAttributeLbl = UIHtmlFieldFactory.createLabel(aname, SCREENCD, "FILE_ATTRIB_LBL");
		fileAttributeDiv.add(fileAttributeLbl, fileAttributeBtn);
		return fileAttributeDiv;
	}
		
	protected void renderMultiSelectField(CheckboxGroup<String> multiSelectFld, String possibleValues, String defaultValue) {
		try {
			JSONObject json = new JSONObject(possibleValues);
			JSONArray jsonArray = new JSONArray(json.getString("MultiSelectOptions"));

			List<String> possibleValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				possibleValuesList.add(jsonArray.getString(i));
			}
			
			json = new JSONObject(defaultValue);

			jsonArray = new JSONArray(json.getString("MultiSelectDefaultValue"));

			List<String> defaultValuesList = new ArrayList<String>();
			for (int i = 0; i < jsonArray.length(); i++) {
				defaultValuesList.add(jsonArray.getString(i));
			}
			
			multiSelectFld.setItems(possibleValuesList);
			multiSelectFld.select(defaultValuesList);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	protected void populateDocumentPreview(String base64EncodedFileContent2, Div previewdiv) {
		byte[] imageFileContent = Base64.getDecoder().decode(base64EncodedFileContent2);
		StreamResource fileStreamResource = new StreamResource("Logo", new InputStreamFactory() {
			private static final long serialVersionUID = 1L;

			@Override
			public InputStream createInputStream() {

				return new ByteArrayInputStream(imageFileContent);
			}
		});
		
		Image previewLogoImg = new Image(fileStreamResource, "Preview_logo");
		previewLogoImg.addClassName(SCREENCD + "_LOGO_IMG");
		previewdiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PREVIEW_LOGO_IMG_DIV");
		previewdiv.add(previewLogoImg);
		//row7.addComponentAtIndex(1,previewdiv);
		
	}
	protected void populateImgPreviewDiv(String base64EncodedFileContent2) {
		
		if(base64EncodedFileContent2 != null && base64EncodedFileContent2.trim().length() > 0) 
		{
			base64EncodedFileContent1=base64EncodedFileContent2;
			byte[] imageFileContent = Base64.getDecoder().decode(base64EncodedFileContent2);
			StreamResource fileStreamResource = new StreamResource("FILE_IMAGE", new InputStreamFactory() {
				private static final long serialVersionUID = 1L;

				@Override
				public InputStream createInputStream() {

					return new ByteArrayInputStream(imageFileContent);
				}
			});

			fileImage = new Image(fileStreamResource, "NEW_FILE_IMAGE1");
			fileImage.addClassName(SCREENCD + "_NEW_FILE_IMAGE1");
		}
		else {
			fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");

		}
		 uploadpicDiv.removeAll();
		 uploadpicDiv.add(fileImage);

	}
	
	
	
	@SuppressWarnings("unchecked")
	private void attributeUIOrchestration() {
		
	//		System.out.println("dynamicAttributesMap="+dynamicAttributesMap.toString());
			if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAttributesMap.get(key);
					if(key.equalsIgnoreCase("PAN Status") || key.equalsIgnoreCase("MSME Status") || key.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0)	//value obj
						{	
							String datatype=keyvalue.get(0).toString().toUpperCase();
							switch(datatype)
							{
							case "FLOV":
								if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
									attributeVisibility(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(), key);
								}
								((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
									private static final long serialVersionUID = 1L;
			
									@Override
									public void valueChanged(ValueChangeEvent<?> event) {
										if (event.getValue() != null) {
											attributeVisibility(event.getValue().toString().trim(),key);
										}
									}
								});
								
								break;
							}
						}
					}
					if(key.equalsIgnoreCase("Additional Bank Required")) {
						if(keyvalue.size()>0)	//value obj
						{	
							String datatype=keyvalue.get(0).toString().toUpperCase();
							switch(datatype)
							{
							case "FLOV":
								if(((ComboBox<Object>)keyvalue.get(1)).getValue()!=null) {
									attributeVisibility(((ComboBox<Object>)keyvalue.get(1)).getValue().toString().trim(), key);
								}
								((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
									private static final long serialVersionUID = 1L;
			
									@Override
									public void valueChanged(ValueChangeEvent<?> event) {
										if (event.getValue() != null) {
											attributeVisibility(event.getValue().toString().trim(),key);
										}
									}
								});
								
								break;
							}
						}
					}

			
				}
				
			}		
			
		}
	protected void attributeVisibility(String combovalue, String keyName) {
		if(combovalue.equalsIgnoreCase("Available")) {
			if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAttributesMap.get(key);
					
					if(key.equalsIgnoreCase("PAN") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("PAN Document") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
				/*	else if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}*/
					else if(key.equalsIgnoreCase("GST RC Document") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					else if(key.equalsIgnoreCase("GST Number") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							mandatoryFields(datatype,keyvalue);
							keyvalue.set(2,"1");
							updateddynamicSiteAttributesMap.put(key,keyvalue);
						}
						
					}
					
				}
			}
		}else if(combovalue.equalsIgnoreCase("Not Available")) {
			if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
			{	
				Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

				while (itrKeys.hasNext()) 
				{
					String key = itrKeys.next();
					List<Object> keyvalue=dynamicAttributesMap.get(key);
					
					if(key.equalsIgnoreCase("PAN") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("PAN Document") && keyName.equalsIgnoreCase("PAN Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
			/*		else if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}*/
					else if(key.equalsIgnoreCase("GST RC Document") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
					else if(key.equalsIgnoreCase("GST Number") && keyName.equalsIgnoreCase("GST Status")) {
						if(keyvalue.size()>0) {
							String datatype=keyvalue.get(0).toString().toUpperCase();
							nonmandatoryFields(datatype,keyvalue);
							if(updateddynamicSiteAttributesMap.containsKey(key)) {
								updateddynamicSiteAttributesMap.remove(key);
							}
						}
						
					}
					

				}
			}
			
		}else if(combovalue.equalsIgnoreCase("Yes")){
			Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAttributesMap.get(key);
			if(key.equalsIgnoreCase("Beneficiary Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("Bank Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}
			else if(key.equalsIgnoreCase("Bank Account Number EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("IFSC Code EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}/*else if(key.equalsIgnoreCase("Cancelled Cheque Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}*/
			else if(key.trim().equalsIgnoreCase("Cancelled Cheque EB Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}
			}
			
		}else if(combovalue.equalsIgnoreCase("No")){
			Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAttributesMap.get(key);
			if(key.equalsIgnoreCase("Beneficiary Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}else if(key.equalsIgnoreCase("Bank Name EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}
			else if(key.equalsIgnoreCase("Bank Account Number EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}else if(key.equalsIgnoreCase("IFSC Code EB") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}
			/*else if(key.equalsIgnoreCase("Cancelled Cheque Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}*/
			else if(key.trim().equalsIgnoreCase("Cancelled Cheque EB Document") && keyName.equalsIgnoreCase("Additional Bank Required")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					nonmandatoryFields(datatype,keyvalue);
					if(updateddynamicSiteAttributesMap.containsKey(key)) {
						updateddynamicSiteAttributesMap.remove(key);
					}
				}
				
			}
			}
			
		}else if(combovalue.equalsIgnoreCase("Applicable")) {
			
			
			Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();

			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAttributesMap.get(key);
				 if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
				if(keyvalue.size()>0) {
					String datatype=keyvalue.get(0).toString().toUpperCase();
					mandatoryFields(datatype,keyvalue);
					keyvalue.set(2,"1");
					updateddynamicSiteAttributesMap.put(key,keyvalue);
				}
				
			}
			}
			
		}else if(combovalue.equalsIgnoreCase("Not Applicable")) {

			Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();
			while (itrKeys.hasNext()) 
			{
				String key = itrKeys.next();
				List<Object> keyvalue=dynamicAttributesMap.get(key);
				 if(key.equalsIgnoreCase("MSME") && keyName.equalsIgnoreCase("MSME Status")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicSiteAttributesMap.containsKey(key)) {
							updateddynamicSiteAttributesMap.remove(key);
						}
					}
					
				}else if(key.equalsIgnoreCase("MSME Document") && keyName.equalsIgnoreCase("MSME Status")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicSiteAttributesMap.containsKey(key)) {
							updateddynamicSiteAttributesMap.remove(key);
						}
					}
					
				}else if(key.equalsIgnoreCase("MSME Registration Number") && keyName.equalsIgnoreCase("MSME Status")) {
					if(keyvalue.size()>0) {
						String datatype=keyvalue.get(0).toString().toUpperCase();
						nonmandatoryFields(datatype,keyvalue);
						if(updateddynamicSiteAttributesMap.containsKey(key)) {
							updateddynamicSiteAttributesMap.remove(key);
						}
					}
					
				}
			}	

		}
		else {
			
		}
		
	}
		
		private void nonmandatoryFields(String datatype, List<Object> keyvalue) {
			switch(datatype)
			{
			case "FLOV":
				((ComboBox<Object>)keyvalue.get(1)).setVisible(false);
				((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "NUMERIC":
//				((TextField)keyvalue.get(1)).setVisible(false);
//				((TextField)keyvalue.get(1)).setInvalid(false);
//				((Div) keyvalue.get(3)).setVisible(false);
				((NumberField)keyvalue.get(1)).setVisible(false);
				((NumberField)keyvalue.get(1)).setInvalid(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "ALPHANUMERIC":
				((TextField)keyvalue.get(1)).setVisible(false);
				((TextField)keyvalue.get(1)).setInvalid(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "DATE":
				((DatePicker)keyvalue.get(1)).setVisible(false);
				((DatePicker)keyvalue.get(1)).setInvalid(false);
				((Div) keyvalue.get(3)).setVisible(false);
				
				break;
			case "FREEFLOW":
				((TextField)keyvalue.get(1)).setVisible(false);
				((TextField)keyvalue.get(1)).setInvalid(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			
			case "BOOLEAN":
				datatype = "BOOLEAN";
				((Checkbox) keyvalue.get(1)).setVisible(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "MULTIPLE SELECTION":
				((CheckboxGroup) keyvalue.get(1)).setVisible(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "IMAGE FILE":
				((Div) keyvalue.get(1)).setVisible(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "TEXT FILE":
				((Div) keyvalue.get(1)).setVisible(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			case "CUSTOM FILE":
				((Div) keyvalue.get(1)).setVisible(false);
				((Div) keyvalue.get(3)).setVisible(false);
				break;
			}

			
		}

		private void mandatoryFields(String datatype, List<Object> keyvalue) {
			switch (datatype) {
			case "FLOV":
				((ComboBox<Object>) keyvalue.get(1)).setVisible(true);
				((ComboBox<Object>) keyvalue.get(1)).setRequired(true);
				((ComboBox<Object>) keyvalue.get(1)).setRequiredIndicatorVisible(true);
				// ((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				
				
				((ComboBox<Object>)keyvalue.get(1)).addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void valueChanged(ValueChangeEvent<?> event) {
						if (event.getValue() == null) {
						
							((ComboBox<Object>)keyvalue.get(1)).setInvalid(true);
							((ComboBox<Object>)keyvalue.get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
							
						}else {
							((ComboBox<Object>)keyvalue.get(1)).setInvalid(false);
							((ComboBox<Object>)keyvalue.get(1)).setErrorMessage("");
						}
					}
				});
				break;
			case "NUMERIC":
//				((TextField)keyvalue.get(1)).setVisible(true);
//				((TextField)keyvalue.get(1)).setRequired(true);
//				((TextField)keyvalue.get(1)).setRequiredIndicatorVisible(true);
//				//((TextField)keyvalue.get(1)).setInvalid(true);
//				((Div) keyvalue.get(3)).setVisible(true);
				((NumberField) keyvalue.get(1)).setVisible(true);
				// ((NumberField)keyvalue.get(1)).setRequired(true);
				((NumberField) keyvalue.get(1)).setRequiredIndicatorVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "ALPHANUMERIC":
				((TextField) keyvalue.get(1)).setVisible(true);
				((TextField) keyvalue.get(1)).setRequired(true);
				((TextField) keyvalue.get(1)).setRequiredIndicatorVisible(true);
				// ((TextField)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "DATE":
				((DatePicker) keyvalue.get(1)).setVisible(true);
				((DatePicker) keyvalue.get(1)).setRequired(true);
				((DatePicker) keyvalue.get(1)).setRequiredIndicatorVisible(true);
				// ((DatePicker)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);

				break;
			case "FREEFLOW":
				((TextField) keyvalue.get(1)).setVisible(true);
				((TextField) keyvalue.get(1)).setRequired(true);
				((TextField) keyvalue.get(1)).setRequiredIndicatorVisible(true);
				// ((TextField)keyvalue.get(1)).setInvalid(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "BOOLEAN":
				datatype = "BOOLEAN";
				((Checkbox) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "MULTIPLE SELECTION":
				((CheckboxGroup) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "IMAGE FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "TEXT FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			case "CUSTOM FILE":
				((Div) keyvalue.get(1)).setVisible(true);
				((Div) keyvalue.get(3)).setVisible(true);
				break;
			}
		}
		
		private void setMultiSelectValue(CheckboxGroup<String> field, String multiSelectValue) {
			if(multiSelectValue == null || multiSelectValue.trim().length() == 0) {
				return;
			}
			try {
				JSONObject json = new JSONObject(multiSelectValue);
				JSONArray jsonArray = new JSONArray(json.getString("MultiSelectValue"));
				List<String> attributeValuesList = new ArrayList<String>();
				for (int i = 0; i < jsonArray.length(); i++) {
					attributeValuesList.add(jsonArray.getString(i));
				}
				field.select(attributeValuesList);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		
		public void getFormValues() {

			temp_agreementAttributesJson=new JSONObject();

			if(updateddynamicSiteAttributesMap==null || updateddynamicSiteAttributesMap.size()<=0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage("Please fill up the Agreement Details", ApplicationConstants.DialogTypes.ERROR);
				return ;
			}
			Iterator<String> itrKeys = updateddynamicSiteAttributesMap.keySet().iterator();
			UIFileAttributeComponent fileAttribComp = null;
		
			try {
				if(updateddynamicSiteAttributesMap!=null && updateddynamicSiteAttributesMap.size()>0)
				{	
					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=updateddynamicSiteAttributesMap.get(key);
						
						if(value.size()>0)	
						{	
							String datatype=updateddynamicSiteAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=updateddynamicSiteAttributesMap.get(key).get(2).toString();
							switch(datatype)
							 {
								 case "FLOV":			
									 
									 if(((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)			
									 {
										 temp_agreementAttributesJson.put(key, ((ComboBox<Object>)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
									 }
									 break;
								 case "NUMERIC":
									 
										if (((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
										{
											temp_agreementAttributesJson.put(key, ((NumberField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
										}
									 break;
								 case "ALPHANUMERIC":
									 if(((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
									{
										 temp_agreementAttributesJson.put(key, ((TextField)updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
									}
									 break;
								 case "DATE":
									 
										if (((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()!=null)
										{
											temp_agreementAttributesJson.put(key, CommonUtils.convertLocalDateToString(
													((DatePicker) updateddynamicSiteAttributesMap.get(key).get(1)).getValue()));
										}
									 break;
								 case "FREEFLOW":
									
										if (((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString().length()>0)
										{
											temp_agreementAttributesJson.put(key, ((TextField) updateddynamicSiteAttributesMap.get(key).get(1)).getValue());
										}
									 break;
									 
									case "BOOLEAN":
										temp_agreementAttributesJson.put(key,
												((Checkbox) updateddynamicSiteAttributesMap.get(key).get(1)).getValue().toString());
										break;
									case "MULTIPLE SELECTION":
										CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (mandatory.equalsIgnoreCase("1") && checkboxGroup.isEmpty()) {
											SiteAssetInventoryUIFramework.getFramework().showMessage(
													"Please select atleast one option for " + key, DialogTypes.INFO);
											return;
										}
										if (!checkboxGroup.isEmpty()) {
											temp_agreementAttributesJson.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
										}
										break;
									case "IMAGE FILE":
										if (fileAttribComp.getFileJSON() != null) {
											temp_agreementAttributesJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
									case "TEXT FILE":
										fileAttribComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap
												.get(key).get(1);
										if (fileAttribComp.getFileJSON() != null) {
											temp_agreementAttributesJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
									case "CUSTOM FILE":
										fileAttribComp = (UIFileAttributeComponent) updateddynamicSiteAttributesMap
												.get(key).get(1);
										
										if (fileAttribComp.getFileJSON() != null) {
											temp_agreementAttributesJson.put(key, fileAttribComp.getFileJSON());
										}
										break;
							 }
						}	
					
				}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		
		public void setFormValue()
		{
			try {
				
		//		String formvalue=LocalStorage.showStoredValue(KEY_NAME);

		//		System.out.println("formvalue:=="+formvalue);
				
		/*		LocalStorage.getItem(
						KEY_NAME,
			            value -> {
			            	System.out.println("Stored value::=="+value);
			            	Landlordform(value);
			            }
			     );	
			*/
				
				String resp=CommonUtils.getDraftData("1");
				Landlordform(resp);
				
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		
		private void Landlordform(String formvalue) {
			try {
				System.out.println("formvalue:=="+formvalue);
				if (formvalue!=null) {
					JSONObject js = new JSONObject(formvalue);

					JSONObject landlordDetails = js.getJSONObject("LandlordDetails");
					

					nameField.setValue(landlordDetails.getString("Name"));
					addressField.setValue(landlordDetails.getString("Address"));
					emailField.setValue(landlordDetails.getString("Email"));
					contactField.setValue(landlordDetails.getString("ContactNo"));
		//			populateImgPreviewDiv(landlordDetails.getString("Photo"));

					JSONObject AgreementAttribute = js.getJSONObject("LandlordAttribute");
					Iterator<String> attributeNames = AgreementAttribute.keys();

					while (attributeNames.hasNext()) {
						String attributeName = (String) attributeNames.next();
						if (dynamicAttributesMap != null && dynamicAttributesMap.size() > 0) {
							Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();
							while (itrKeys.hasNext()) {
								String key = (String) itrKeys.next();
								if (attributeName.equals(key)) {
									List<Object> value = dynamicAttributesMap.get(key);
									if (value.size() > 0) {
										String datatype = dynamicAttributesMap.get(key).get(0).toString()
												.toUpperCase();

										switch (datatype) {
										case "FLOV":
											((ComboBox<Object>) dynamicAttributesMap.get(key).get(1))
													.setValue(AgreementAttribute.getString(attributeName));
											break;
										case "NUMERIC":
											((NumberField) dynamicAttributesMap.get(key).get(1)).setValue(
													Double.parseDouble(AgreementAttribute.getString(attributeName)));
											break;
										case "ALPHANUMERIC":
											((TextField) dynamicAttributesMap.get(key).get(1))
													.setValue(AgreementAttribute.getString(attributeName));
											break;
										case "DATE":
											((DatePicker) dynamicAttributesMap.get(key).get(1))
													.setValue(CommonUtils.convertStringToLocalDate(
															AgreementAttribute.getString(attributeName), "dd/MM/yyyy"));
											break;
										case "FREEFLOW":
											((TextField) dynamicAttributesMap.get(key).get(1))
													.setValue(AgreementAttribute.getString(attributeName));
											break;
										case "BOOLEAN":
											String boolValue = AgreementAttribute.getString(attributeName);
											if (boolValue != null && boolValue.trim().length() > 0
													&& boolValue.trim().equalsIgnoreCase("true")) {
												((Checkbox) dynamicAttributesMap.get(key).get(1))
														.setValue(true);
											} else {
												((Checkbox) dynamicAttributesMap.get(key).get(1))
														.setValue(false);
											}
											break;
										case "MULTIPLE SELECTION":
											String multiSelectValue = AgreementAttribute.getString(attributeName);
											setMultiSelectValue(((CheckboxGroup<String>) dynamicAttributesMap
													.get(key).get(1)), multiSelectValue);
											break;
										case "IMAGE FILE":
//											setFileAttributeValue(
//													((UIFileAttributeComponent) dynamicAttributesMap.get(key)
//															.get(1)),
//													AgreementAttribute.getString(attributeName));
											break;
										case "TEXT FILE":
//											setFileAttributeValue(
//													((UIFileAttributeComponent) dynamicAttributesMap.get(key)
//															.get(1)),
//													AgreementAttribute.getString(attributeName));
											break;
										case "CUSTOM FILE":
//											setFileAttributeValue(
//													((UIFileAttributeComponent) dynamicAttributesMap.get(key)
//															.get(1)),
//													AgreementAttribute.getString(attributeName));
											break;
										default:

										}
									}
									break;
								}
							}
						}
					}

				}
					
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		
		private void resetFormValue() {
			nameField.clear();
			addressField.clear();
			emailField.clear();
			contactField.clear();
			nameField.setInvalid(false);
			addressField.setInvalid(false);
			contactField.setInvalid(false);
			emailField.setInvalid(false);
			uploadpicDiv.removeAll();
			temp_agreementAttributesJson=new JSONObject();
			generateFieldNameValuePair3();
			
		}

}



		
	
	


