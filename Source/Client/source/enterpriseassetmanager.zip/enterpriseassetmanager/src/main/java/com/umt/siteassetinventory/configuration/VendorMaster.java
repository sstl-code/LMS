package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/vendor_master-styles.css")
public class VendorMaster extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "VENDOR_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<VendorMasterDataBean> vendorMasterDataBeanList;
	private ConfigView parent;
	private boolean vendorOrOperator, itemAdded = false;
	//private Label lbl1, lbl2, lbl3, lbl4, lbl5;
	//private String siteCode;

	public VendorMaster(ConfigView parent, boolean vendorOrOperator) {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;
		this.vendorOrOperator = vendorOrOperator;
		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");

		if (vendorOrOperator) {
			filterFld.setPlaceholder("Filter Vendors");
		}
		else
		{
			addBtn.setText("Add Operator");
			filterFld.setPlaceholder("Filter Operators");
			eachrowDiv2.setWidth("20%");
			eachrowDiv4.setWidth("28.5%");
		}

		//		for (int i = 0; i < fieldCounts; i++) {
		//			Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV");
		//			Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL");
		//			eachrowDiv.add(lbl);
		//			tableHeaderDiv.add(eachrowDiv);
		//		}
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5);

		filterDiv.add(filterFld , addBtn);

		//AddSiteAssetPopup popup = new AddSiteAssetPopup("Add " + assetParam + " Asset", this, siteAssetsTab, SCREENCD);

		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				addDialog(true);
			}
		});

		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				vendorMasterDataBeanList.stream().filter(new Predicate<VendorMasterDataBean>() {

					@Override
					public boolean test(VendorMasterDataBean t) {
						String filterTxt = filterFld.getValue();
						if (filterTxt == null || filterTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if (StringUtils.containsIgnoreCase(t.getVendorId()+"", filterTxt)
								|| StringUtils.containsIgnoreCase(t.getVendorName(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getDesc(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getAddress(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getStatus(), filterTxt)) {
							t.setVisible(true);
							return true;
						}
						t.setVisible(false);
						return false;
					}
				}).collect(Collectors.toList());
			}
		});

		filterFld.setValueChangeMode(ValueChangeMode.EAGER);


		populateData();
	}

	protected void populateData() {
		tableContainerDiv.removeAll();
		vendorMasterDataBeanList = new ArrayList<>();
		/*if (vendorOrOperator) {*/
		parent.vendorMap = new HashMap<>();
		/*}else {*/
		parent.operatorMap = new HashMap<>();
		/*}*/
		String response = "";
		if (vendorOrOperator || isItemAdded()) {
			response = getVendors();
			parent.setVendorsResponse(response);
		} else {
			response = parent.getVendorsResponse();
		}

		//				"[{\"Id\":1,\"Name\":\"Mitsubishi\",\"Description\":\"Rectifier Provider\",\"Address\":\"Kolkata, "
		//				+ "700198\",\"Status\":\"Active\"},{\"Id\":2,\"Name\":\"Daikin Services\",\"Description\":\"AC Provider\","
		//				+ "\"Address\":\"Kolkata, 700198\",\"Status\":\"Active\"}]";
		try {
			JSONArray ja = new JSONArray(response);
			for (int i = 0; i < ja.length(); i++) {
				JSONObject jo = ja.getJSONObject(i);
				String vendorName = "", desc = "", address = "";
				if (jo.getString("VendorName")!=null) {
					vendorName = jo.getString("VendorName");
				}
				if (jo.getString("Description")!=null) {
					desc = jo.getString("Description");
				}
				if (jo.getString("Address")!=null) {
					address = jo.getString("Address");
				}
				int vendorType = jo.getInt("VendorType");
				if (vendorType==1) {
					if (jo.getInt("Status")==1) {
						parent.operatorMap.put(jo.getLong("VendorId"), vendorName);
					}	
					if (!vendorOrOperator) {
						VendorMasterDataBean bean = new VendorMasterDataBean(jo.getLong("VendorId"), vendorName, desc, address, 
								jo.getInt("Status"), this, vendorOrOperator);
						vendorMasterDataBeanList.add(bean);
						tableContainerDiv.add(bean);
					}
				} else if (vendorType==0) {
					if (jo.getInt("Status")==1) {
						parent.vendorMap.put(jo.getLong("VendorId"), vendorName);
					}
					if (vendorOrOperator) {
						VendorMasterDataBean bean = new VendorMasterDataBean(jo.getLong("VendorId"), vendorName, desc, address, 
								jo.getInt("Status"), this, vendorOrOperator);
						vendorMasterDataBeanList.add(bean);
						tableContainerDiv.add(bean);
					}
				}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void addDialog(boolean addOrEdit)
	{
		//System.out.println("Working");
		AddOrEditVendor addVendor = new AddOrEditVendor(this, vendorOrOperator);
	}

	private String getVendors()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETALLVENDORS");
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	public boolean isItemAdded() {
		return itemAdded;
	}

	public void setItemAdded(boolean itemAdded) {
		this.itemAdded = itemAdded;
	}

}
