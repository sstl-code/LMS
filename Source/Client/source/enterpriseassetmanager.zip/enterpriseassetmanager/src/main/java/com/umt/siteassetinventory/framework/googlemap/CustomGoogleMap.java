package com.umt.siteassetinventory.framework.googlemap;

import java.io.Serializable;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.JavaScript;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.dom.DomEvent;
import com.vaadin.flow.dom.DomEventListener;

@JavaScript("./src/GMap.js")
public class CustomGoogleMap extends Div {
	private static final long serialVersionUID = 1L;
	
	private CustomGoogleMapMarkerClickListener mapMarkerClickListener;
	
	@SuppressWarnings("deprecation")
	public CustomGoogleMap(String apiKey, String centerLat, String centerLng, int locationType,String mapid) throws Exception {
	//	setId("custom-google-map");
		
		setId(mapid);
		
		if(apiKey == null || apiKey.trim().length() == 0) {
			throw new Exception("Api key is mandatory.");
		}
		
		UI.getCurrent().getPage().addJavaScript("https://maps.googleapis.com/maps/api/js?key=" + apiKey + "&libraries=geometry");
		String center = "{lat:" + centerLat + ",lng:" + centerLng + "}";
		System.out.println("mapid::"+mapid);
		System.out.println("loadMap(" + center + ", " + locationType +", "+ mapid+")");
		UI.getCurrent().getPage().executeJavaScript("loadMap(" + center + ", " + locationType +", \""+ mapid+"\")");
		setHeightFull();
		setWidthFull();
		
		getElement().addEventListener("custom-gmap-marker-click", new DomEventListener() {
			private static final long serialVersionUID = 1L;

			@Override
			public void handleEvent(DomEvent event) {
				if(mapMarkerClickListener != null) {
					mapMarkerClickListener.onMapMarkerClick(event.getEventData().toJson());
				}
			}
		}).addEventData("event.detail");
	}
	
	public void populateMarker(JSONArray markerData) throws Exception {
		if (markerData == null || markerData.length() == 0) {
			throw new Exception("No marker data has been provided.");
		}
		
		for (int i = 0; i < markerData.length(); i++) {
			JSONObject eachMarker = markerData.getJSONObject(i);
			
			if(eachMarker == null) {
				throw new Exception("Null markers are not allowed.");
			}
			
			if(!eachMarker.has("uniqueId")) {
				throw new Exception("Each marker must have a unique identifier with key 'uniqueId'.");
			}
		}
		
		UI.getCurrent().getPage().executeJavaScript("populateMarkers(" + markerData.toString() + ")");
	}
	
	public void clearMapMarker() {
		UI.getCurrent().getPage().executeJavaScript("clearMarkers()");
	}
	
	public void applyGeoFence(double radius) throws Exception {
		if(radius <= 0) {
			throw new Exception("Radius cannot be negative or 0.");
		}
		
		UI.getCurrent().getPage().executeJavaScript("applyGeofence(" + radius + ")");
	}
	
	public void clearGeoFence() {
		UI.getCurrent().getPage().executeJavaScript("clearGeofence()");
	}
	
	public void addMapMarkerClickListener(CustomGoogleMapMarkerClickListener listener) {
		mapMarkerClickListener = listener;
	}
	
	public void removeMapMarkerClickListener() {
		mapMarkerClickListener = null;
	}
	
	@SuppressWarnings("deprecation")
	public void openInfoWindow(String uniqueId) throws Exception {
		if(uniqueId == null || uniqueId.trim().length() == 0) {
			throw new Exception("UniqueId is mandatory.");
		}
		
		UI.getCurrent().getPage().executeJavaScript("displayInfoWindow(" + uniqueId + ")");
		
	}
	
	public void openInfoWindow2(String uniqueId) throws Exception {
		if(uniqueId == null || uniqueId.trim().length() == 0) {
			throw new Exception("UniqueId is mandatory.");
		}
		
	//	System.out.println("uniqueId2="+uniqueId);
		
		JSONArray uid_arr2=new JSONArray();
		JSONObject js=new JSONObject();
		js.put("UID", uniqueId);
		uid_arr2.put(js);
	//	System.out.println("uid_arr2="+uid_arr2);
		
		UI.getCurrent().getPage().executeJavaScript("displayMarkerInfoWindow(" + uid_arr2.toString() + ")");
	}
	
	

	public interface CustomGoogleMapMarkerClickListener extends Serializable{
		public void onMapMarkerClick(String eventData);
	}
}	
