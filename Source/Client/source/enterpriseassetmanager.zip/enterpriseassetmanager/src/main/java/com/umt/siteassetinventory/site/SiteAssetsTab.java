package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/site-assets-styles.css")
public class SiteAssetsTab extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_ASSETS_TAB";
	private String siteCode;
	private ComboBox<String> filterCombo;
	private Div containerDiv;
	private Map<String, String> tenancyNameIdMap;
	private Map<String, String> activeEquipmentNameIdMap;
	private Map<String, String> passiveEquipmentNameIdMap;

	private boolean activeOrPassive;

	public SiteAssetsTab(boolean activeOrPassive) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.activeOrPassive = activeOrPassive;
		Label filterLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILTER_LBL");
		filterCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), false, SCREENCD, "FILTER_COMBO");
		filterCombo.setPreventInvalidInput(true);
		Button addAssetButton = UIFieldFactory.createButton(SCREENCD, "ADD_ASSET_BTN");
		if(activeOrPassive)
		{
			filterLbl.setText("Tenancies");
			filterCombo.setPlaceholder("Select tenancies");
			addAssetButton.setText("Add Active Asset");
		}
		else
		{
			filterLbl.setText("Asset Type");
			filterCombo.setPlaceholder("Select asset type");
			addAssetButton.setText("Add Passive Asset");
		}

		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");	
		filterDiv.add(filterLbl, filterCombo, addAssetButton);
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		add(filterDiv, containerDiv);

		filterCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event)
			{ 
				if (event.isFromClient()) {
					loadAssets(activeOrPassive);	
				}
			}
		});

		addAssetButton.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				// TODO Auto-generated method stub
				openAddDialog();
			}
		});
	}

	private void openAddDialog()
	{
		if (activeOrPassive) {
			loadEquipmentNameIdMap();
			AddSiteAsset addSiteAsset = new AddSiteAsset(activeOrPassive, activeEquipmentNameIdMap, this);
			addSiteAsset.setSiteCode(getSiteCode());
		} else {
			AddSiteAsset addSiteAsset = new AddSiteAsset(activeOrPassive, passiveEquipmentNameIdMap, this);
			addSiteAsset.setSiteCode(getSiteCode());
		}
	}

	private String getSiteTenancies()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITETENANCIES");
			String response = RestServiceHandler.retriveJSON_GET(url + "?SiteCode=" + URLEncoder.encode(getSiteCode()), SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + "?SiteCode=" + getSiteCode()+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getEquipmentType()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPE");
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getEquipments(String tenancyId, String equipmentTypeId)
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url = url + "?StoreSerialNo=-1&StoreId=9996&StatusId=-1&VendorId=" + tenancyId + "&EquipmentTypeId=" 
					+ equipmentTypeId + "&StoreLocId=" + URLEncoder.encode(getSiteCode()) + "&EquipmentSerialNo=-1";
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
		//	System.out.println(url);
		//	System.out.println("response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private void loadFilterCombo(boolean activeOrPassive)
	{
		try {
			List<String> filterComboItems = new ArrayList<>();
			tenancyNameIdMap = new HashedMap<>();
			filterComboItems.add("<All>");
			if (activeOrPassive) {
				String siteTenancies = getSiteTenancies();
				JSONArray  siteTenanciesJA = new JSONArray(siteTenancies);
				for (int i = 0; i < siteTenanciesJA.length(); i++) {
					JSONObject siteTenanciesJson = siteTenanciesJA.getJSONObject(i);
					tenancyNameIdMap.put(siteTenanciesJson.getString("TenancyName"), siteTenanciesJson.getString("TenancyId"));
				}
				tenancyNameIdMap.forEach((k,v) -> {
					filterComboItems.add(k);
				});
				//System.out.println("filterComboItems="+filterComboItems.toString());
				filterCombo.setItems(filterComboItems);
				//filterComboVal = tenancyNameIdMap.keySet().iterator().next();
			}
			else
			{
				loadEquipmentNameIdMap();
				passiveEquipmentNameIdMap.forEach((k,v) -> {
					filterComboItems.add(k);
				});
				filterCombo.setItems(filterComboItems);
				//filterComboVal = passiveEquipmentNameIdMap.keySet().iterator().next();
			}	
			filterCombo.setValue("<All>");
		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void loadEquipmentNameIdMap()
	{
		try {
			String equipmentTypes = getEquipmentType();
			JSONArray  equipmentTypesJA = new JSONArray(equipmentTypes);
			activeEquipmentNameIdMap = new HashedMap<>();
			passiveEquipmentNameIdMap = new HashedMap<>();
			for (int i = 0; i < equipmentTypesJA.length(); i++) {
				JSONObject equipmentTypesJson = equipmentTypesJA.getJSONObject(i);
				if (equipmentTypesJson.getInt("ServiceType")==0 && !activeOrPassive)
					passiveEquipmentNameIdMap.put(equipmentTypesJson.getString("EquipmentType"), equipmentTypesJson.getString("EquipmentTypeId"));
				else if (equipmentTypesJson.getInt("ServiceType")==1 && activeOrPassive)
					activeEquipmentNameIdMap.put(equipmentTypesJson.getString("EquipmentType"), equipmentTypesJson.getString("EquipmentTypeId"));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void loadAssets(boolean activeOrPassive)
	{
		containerDiv.removeAll();
		try {
			JSONArray allAssetsJA;
			JSONArray assetsJA = new JSONArray();
			String equipments = "";
			
			System.out.println("activeOrPassive="+activeOrPassive);

			if (activeOrPassive)
			{ 
				String tenancyId = "";
				if (filterCombo.getValue()!=null && filterCombo.getValue().trim().length()>0 && !filterCombo.getValue().trim().equalsIgnoreCase("<All>") && tenancyNameIdMap.size()>0 && 
						tenancyNameIdMap.get(filterCombo.getValue())!=null) {
					tenancyId = tenancyNameIdMap.get(filterCombo.getValue());
				}
				else
				{
					tenancyId = "-1";
				}
				equipments = getEquipments(tenancyId, "-1");
				allAssetsJA = new JSONArray(equipments);
				for (int i = 0; i < allAssetsJA.length(); i++) {
					JSONObject allAssetJson = allAssetsJA.getJSONObject(i);
					if (allAssetJson.getInt("ServiceType")==1) {
						assetsJA.put(allAssetJson);
					}
				}
			}
			else
			{
				String equipmentId = "";
				if (filterCombo.getValue()!=null && filterCombo.getValue().trim().length()>0 && !filterCombo.getValue().trim().equalsIgnoreCase("<All>") && passiveEquipmentNameIdMap.size()>0 && 
						passiveEquipmentNameIdMap.get(filterCombo.getValue())!=null) {
					equipmentId = passiveEquipmentNameIdMap.get(filterCombo.getValue());
				}
				else
				{
					equipmentId = "-1";
				}
				equipments = getEquipments("-1", equipmentId);
				allAssetsJA = new JSONArray(equipments);
				for (int i = 0; i < allAssetsJA.length(); i++) {
					JSONObject allAssetJson = allAssetsJA.getJSONObject(i);
					if (allAssetJson.getInt("ServiceType")==0) {
						assetsJA.put(allAssetJson);
					}
				}
			}
			/*SiteAssetDetailBean bean1 = new SiteAssetDetailBean("998777", "Radio Antenna", "North Radio", "9987456321", "12-03-2022", "Active");
			containerDiv.add(bean1);
			SiteAssetDetailBean bean2 = new SiteAssetDetailBean("998777", "Radio Antenna", "North Radio", "9987456321", "12-03-2022", "Active");
			containerDiv.add(bean2);*/
			if (assetsJA.length()==0) {
				if (activeOrPassive) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "ACTIVE_NO_RECORD", ApplicationConstants.DialogTypes.INFO);
				}
				else {
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "PASSIVE_NO_RECORD", ApplicationConstants.DialogTypes.INFO);
				}
			}
			for (int i = 0; i < assetsJA.length(); i++) {
				JSONObject assetJson = assetsJA.getJSONObject(i);
				SiteAssetDetailBean bean = new SiteAssetDetailBean(assetJson.getString("StoreSerialNo"), assetJson.getString("EquipmentType"), 
						assetJson.getString("Description"), assetJson.getString("EquipmentSerialNo"), assetJson.getString("CreationDate"), assetJson.getString("VendorName"), assetJson.getString("StatusCode"), this);
				containerDiv.add(bean);
			}

		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setSiteCode(String selectedsiteCode) 
	{
		//System.out.println("selectedsiteCode="+selectedsiteCode);
		this.siteCode = selectedsiteCode;
		refreshData();
	}

	public void refreshData()
	{
		loadFilterCombo(activeOrPassive);
		loadAssets(activeOrPassive);
	}

	public String getSiteCode() 
	{
		return siteCode;
	}

	public boolean isActiveOrPassive() {
		return activeOrPassive;
	}


}
