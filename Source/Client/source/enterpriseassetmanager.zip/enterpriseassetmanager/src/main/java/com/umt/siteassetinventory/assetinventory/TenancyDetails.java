package com.umt.siteassetinventory.assetinventory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class TenancyDetails extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "TENANCY_DETAILS";
	
	private Div tenancyNamesDiv;
	private Div tenancyDetailsDiv;
	private Div tenancyEquipmentsDiv;
	private SiteMaster parent;
	private HashMap<Div, String> operatorMap = new HashMap<Div, String>();
	private HashMap<Div, JSONObject> tenancyEquipmentMap = new HashMap<Div, JSONObject>();
	
	public TenancyDetails(SiteMaster parent) {
		this.parent = parent;
		tenancyNamesDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_NAMES_DIV");
		tenancyDetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_DETAILS_DIV");
		tenancyEquipmentsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_EQUIPMENTS_DIV");
		
		add(tenancyNamesDiv, tenancyDetailsDiv, tenancyEquipmentsDiv);
		addClassName(SCREENCD + "_MAIN_LAYOUT");
	}
	
	public void loadData() {
		populateTenancyNames(parent.getSelectedSiteCode());
	}
	
	private void populateTenancyNames(String siteCode) {
		tenancyNamesDiv.removeAll();
		operatorMap.clear();
		tenancyDetailsDiv.removeAll();
		tenancyEquipmentsDiv.removeAll();
		tenancyEquipmentMap.clear();
		
		Div operatorHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "OPEARTOR_HEADER_DIV");
		Label operatorHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "OPERATOR_HEADER_LBL");
		operatorHeaderDiv.add(operatorHeaderLbl);
		tenancyNamesDiv.add(operatorHeaderDiv);
		
		Div tenancyDetailsHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_DETAILS_HEADER_DIV");
		Label attributeNameHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRIBUTE_NAME_HEADER_LBL");
		Label attributeValueHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRIBUTE_VALUE_HEADER_LBL");
		tenancyDetailsHeaderDiv.add(attributeNameHeaderLbl, attributeValueHeaderLbl);
		tenancyDetailsDiv.add(tenancyDetailsHeaderDiv);
		
		Div tenancyEquipmentHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_EQUIPMENT_HEADER_DIV");
		Label tenancyEquipmentHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TENANCY_EQUIPMENT_HEADER_LBL");
		tenancyEquipmentHeaderDiv.add(tenancyEquipmentHeaderLbl);
		tenancyEquipmentsDiv.add(tenancyEquipmentHeaderDiv);
		
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("SEARCH");

			JSONObject paramJSON = new JSONObject();
			paramJSON.put("CIN", "");
			paramJSON.put("CustomerName", siteCode);
			paramJSON.put("CustomerType", "");
			paramJSON.put("BillingFrequency", "");
			paramJSON.put("ContactEmail", "");
			paramJSON.put("ContactNo", "");
			paramJSON.put("IdentificationNo", "");

			String encodedSearchParam = CommonUtils.getEncodedText(paramJSON.toString());
			url = url + "?AdvanceFlag=1&Option=1&CustomerParameters=" + encodedSearchParam;
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			String email = "";
			JSONObject searchJSON = new JSONObject(response);
			JSONArray searchJSONArray = searchJSON.getJSONArray("SearchResult");
			for(int i = 0; i < searchJSONArray.length(); i++) {
				JSONObject eachJSON = searchJSONArray.getJSONObject(i);
				if(eachJSON.has("Customer")) {
					JSONArray customerJSONArray = eachJSON.getJSONArray("Customer");
					if(customerJSONArray.length() > 0) {
						JSONObject custJSON = customerJSONArray.getJSONObject(0);
						email = custJSON.getString("EmailId") + "";
					}
					break;
				}
			}
			
			url = ApplicationConfiguration.getServiceEndpoint("GETACCOUNTSFORCIN");	
			url = url + "?EmailId=" + CommonUtils.getEncodedText(email);
			response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			JSONArray accountsArray = new JSONArray(response) ;
			String siteAccountNo = "";
			if(accountsArray.length() > 0) {
				siteAccountNo = accountsArray.getJSONObject(0).getString("AccountNo");
			}
			//System.out.println("SiteAccountNo - " + siteAccountNo);
			
			url = ApplicationConfiguration.getServiceEndpoint("GETCHILDACCOUNTS");	
			url = url + "?AccountNo=" + siteAccountNo;
			response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			
			JSONArray childAccountArray = new JSONArray(response);
			
			for (int i = 0; i < childAccountArray.length(); i++) {
				JSONObject eachAccountJSON = childAccountArray.getJSONObject(i);
				String accntnum = eachAccountJSON.getString("AccountNo");
				String demographic = eachAccountJSON.getString("Demographic");
				JSONObject demographicJSON = new JSONObject(demographic);
				String accntName = demographicJSON.getString("CustomerName");
				
				Div operatorRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "OPERATOR_ROW_DIV");
				Label operatorNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "OPERATOR_NAME_LBL");
				operatorNameLbl.setText(accntName);
				operatorRowDiv.add(operatorNameLbl);
				
				tenancyNamesDiv.add(operatorRowDiv);
				operatorMap.put(operatorRowDiv, accntnum);
				
				operatorRowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Div> event) {
						operatorSelectionChangeHandler(event.getSource());
					}
				});
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void operatorSelectionChangeHandler(Div selectedRow) {
		String accountNo = operatorMap.get(selectedRow);
		if(accountNo != null && accountNo.trim().length() > 0) {
			populateTenancyAttribute(accountNo);
			populateTenancyEquipments(accountNo);
		}
		
		Iterator<Div> iterator = operatorMap.keySet().iterator();
		while (iterator.hasNext()) {
			Div eachDiv = iterator.next();
			if(!eachDiv.equals(selectedRow)) {
				eachDiv.removeClassName("TENANCY_DETAILS_OPERATOR_ROW_DIV_SELECTED");
			}
		}
		
		selectedRow.addClassName("TENANCY_DETAILS_OPERATOR_ROW_DIV_SELECTED");
	}
	
	private void populateTenancyAttribute(String accountNo) {
		tenancyDetailsDiv.removeAll();
		Div tenancyDetailsHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_DETAILS_HEADER_DIV");
		Label attributeNameHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRIBUTE_NAME_HEADER_LBL");
		Label attributeValueHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRIBUTE_VALUE_HEADER_LBL");
		tenancyDetailsHeaderDiv.add(attributeNameHeaderLbl, attributeValueHeaderLbl);
		tenancyDetailsDiv.add(tenancyDetailsHeaderDiv);
		
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETACCOUNTATTRIBUTE");	
			url = url + "?AccountNo=" + accountNo;
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(response);
			
			JSONObject attributeJSON = new JSONObject(response);
			Iterator iterator = attributeJSON.keys();
			
			while(iterator.hasNext()) {
				String key = (String)iterator.next();
				String value = (String)attributeJSON.get(key);
				Div tenancyDetailsRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_DETAILS_ROW_DIV");
				Label attributeNameLbl = UIHtmlFieldFactory.createLabel(key, SCREENCD, "ATTRIBUTE_NAME_LBL");
				Label attributeValueLbl = UIHtmlFieldFactory.createLabel(value, SCREENCD, "ATTRIBUTE_VALUE_LBL");
				tenancyDetailsRowDiv.add(attributeNameLbl, attributeValueLbl);
				tenancyDetailsDiv.add(tenancyDetailsRowDiv);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void populateTenancyEquipments(String accountNo) {
		tenancyEquipmentsDiv.removeAll();
		tenancyEquipmentMap.clear();
		Div tenancyEquipmentHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TENANCY_EQUIPMENT_HEADER_DIV");
		Label tenancyEquipmentHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TENANCY_EQUIPMENT_HEADER_LBL");
		tenancyEquipmentHeaderDiv.add(tenancyEquipmentHeaderLbl);
		tenancyEquipmentsDiv.add(tenancyEquipmentHeaderDiv);
		
		String rejectEquipments = ApplicationConfiguration.getConfigurationValue("IGNORE_EQUIPMENTS");
		String [] rejectEquipmentsArray = rejectEquipments.split("[,]");
		HashMap<String, String> rejectedEquipmentsMap = new HashMap<String, String>();
		for(int i = 0; i < rejectEquipmentsArray.length; i++) {
			if(rejectEquipmentsArray[i] != null && rejectEquipmentsArray[i].trim().length() > 0) {
				rejectedEquipmentsMap.put(rejectEquipmentsArray[i].trim().toUpperCase(), "1");
			}
		}
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETCUSTOMEROFFERING");	
			url = url + "?AccountNo=" + accountNo;
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(response);
			JSONArray equipmentsArray = new JSONArray(response);
			for(int i = 0; i < equipmentsArray.length(); i++) {
				JSONObject eachEquipment = equipmentsArray.getJSONObject(i);
				
				String offrName = eachEquipment.getString("OfferingName");
				
				if(rejectedEquipmentsMap.get(offrName.trim().toUpperCase()) != null) {
					continue;
				}
				
				Div equipmentRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EQUIPMENT_ROW_DIV");
				
				Label equipmentLbl = UIHtmlFieldFactory.createLabel(offrName, SCREENCD, "EQUIPMENT_LBL");
				equipmentRowDiv.add(equipmentLbl);
				tenancyEquipmentsDiv.add(equipmentRowDiv);
				tenancyEquipmentMap.put(equipmentRowDiv, eachEquipment);
				
				equipmentRowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Div> event) {
						displayEquipmentDetails(event.getSource());
					}
				});
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void displayEquipmentDetails(Div selectedRow) {
		EquipmentDetailsDialog dlg = new EquipmentDetailsDialog("Equipment Detail", new LinkedHashMap<String, String>(), tenancyEquipmentMap.get(selectedRow));
	}
}
