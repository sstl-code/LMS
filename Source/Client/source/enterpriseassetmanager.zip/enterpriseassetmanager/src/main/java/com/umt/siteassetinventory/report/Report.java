package com.umt.siteassetinventory.report;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.IFrame;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinServletRequest;

@Route(value = "report", layout = MainView.class)
@CssImport("./styles/report-styles.css")
public class Report extends VerticalLayout{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String SCREENCD = "REPORT";


	public Report() {

		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Report");
		String report_iframeSrc = VaadinServletRequest.getCurrent().getScheme() 
				+ "://" + VaadinServletRequest.getCurrent().getServerName() 
				+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
				+"/reports/" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

		//String report_iframeSrc2="https://172.18.0.11:7004"+"/reports/" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

		//System.out.println("auditTrail_iframeSrc= "+report_iframeSrc2);
		IFrame iframe = new IFrame(report_iframeSrc);
		iframe.addClassName(SCREENCD + "_IFRAME");
		add(iframe);

	}
}
