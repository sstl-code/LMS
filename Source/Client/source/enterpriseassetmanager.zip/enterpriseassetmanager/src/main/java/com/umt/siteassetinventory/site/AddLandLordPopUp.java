package com.umt.siteassetinventory.site;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;

public class AddLandLordPopUp extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddLandLord parent;
	private String siteCode, payOutFreq, payoutAmt;
	private SiteView siteView;

	public AddLandLordPopUp(String title, Component component, String siteCode, SiteView siteView) {
		super(title, component);
		setButtonText("Add");
	 this.parent = (AddLandLord) component;
	 this.siteCode =siteCode;
	 this.siteView = siteView;
	 this.payoutAmt = payoutAmt;
	}

	@Override
	public void saveOperartion() {
		
		try {
		if(parent.getLandLordId() == null ) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please Select the Landlord!", ApplicationConstants.DialogTypes.ERROR);
			//System.out.println("erroe_1");
			
		}else if(parent.getPayAmt() == null) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please put the Pay out Share!", ApplicationConstants.DialogTypes.ERROR);
		}
		else {
			String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDLANDLORDSTOSITE");
			
			Form formData = new Form();
			formData.add("SiteCode",siteCode);
			formData.add("LandlordId",parent.getLandLordId());
			
			formData.add("PayOutAmount",parent.getPayAmt());
			
		
	//			save_btn.setEnabled(false);
				String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
				
				//System.out.println(base_URL+" input: " + formData.toString());
				siteView.addlandlordTab(siteCode);
				SiteAssetInventoryUIFramework.getFramework().showMessage("Successfully Added!", ApplicationConstants.DialogTypes.INFO);
				closeDialog();
			
			
//			closeDialog();
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			if(e.getMessage() != null) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				
			}
			e.printStackTrace();
			save_btn.setEnabled(true);
		}
		finally {
			save_btn.setEnabled(true);
		}

		
		
	}

}
