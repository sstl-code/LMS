package com.umt.siteassetinventory.framework.resourcemanager;

import java.io.Serializable;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class LabelManager implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	protected final String RESOURCE_PATH = "com.umt.siteassetinventory.framework.resourcemanager.Labels";
	
	public String getLabel(String screencd, String componentcd) 
	{
		if(screencd == null || screencd.trim().length() == 0 
				|| componentcd == null || componentcd.trim().length() == 0)
		{
			return "";
		}
		String l_strKey = screencd.toUpperCase() + "." + componentcd.toUpperCase();
		try
		{
			String l_strBundleName = RESOURCE_PATH + ".labels";
			ResourceBundle l_objResourceBundle = ResourceBundle.getBundle(l_strBundleName, Locale.getDefault());
			return l_objResourceBundle.getString(l_strKey);
		}
		catch (MissingResourceException exMissingResource) 
		{
			return l_strKey;
		}
	}
}
