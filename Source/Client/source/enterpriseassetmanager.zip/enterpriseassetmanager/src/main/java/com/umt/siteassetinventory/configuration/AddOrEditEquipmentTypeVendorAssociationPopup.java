package com.umt.siteassetinventory.configuration;


import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditEquipmentTypeVendorAssociationPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditEquipmentTypeVendorAssociation addOrEditEquipmentTypeVendorAssociation;
	private String screencd;
	private boolean dataSaved;
	private EquipmentTypeVendorAssociationMaster viewEquipmentTypeVendorAssociationMaster;
	private boolean addOrEdit, vendorOrOperator;


	public AddOrEditEquipmentTypeVendorAssociationPopup(String title, boolean addOrEdit, boolean vendorOrOperator, Component component, EquipmentTypeVendorAssociationMaster master, String screencd) {

		super(title, component);
		setWidth("500px");
		//System.out.println(title);
		this.addOrEditEquipmentTypeVendorAssociation = (AddOrEditEquipmentTypeVendorAssociation) component;
		this.viewEquipmentTypeVendorAssociationMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
		this.vendorOrOperator = vendorOrOperator;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditEquipmentTypeVendorAssociation.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDEQUIPMENTVENDOR");
					JSONObject vendorInfoJson = new JSONObject();
					vendorInfoJson.put("VendorId", addOrEditEquipmentTypeVendorAssociation.getVendorId());
					vendorInfoJson.put("EquipmentTypeId", addOrEditEquipmentTypeVendorAssociation.getEquipmentTypeId());
					if (vendorOrOperator) {
						vendorInfoJson.put("ServiceAgent", addOrEditEquipmentTypeVendorAssociation.getServiceAgent());
						vendorInfoJson.put("InputFileFormat", addOrEditEquipmentTypeVendorAssociation.getInputFileFormat());
						vendorInfoJson.put("OutputFileFormat", addOrEditEquipmentTypeVendorAssociation.getOutputFileFormat());
					}
				
					Form formData = new Form();
					formData.add("VendorInfo", vendorInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					if (vendorOrOperator) {
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_VENDOR_ASSOCIATION_SAVE_SUCCESSFUL");
					} else {
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_OPERATOR_ASSOCIATION_SAVE_SUCCESSFUL");
					}
						
				}
				else
				{
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEEQUIPMENTVENDOR");
					
					JSONObject vendorInfoJson = new JSONObject();
					vendorInfoJson.put("VendorId", addOrEditEquipmentTypeVendorAssociation.getVendorId());
					vendorInfoJson.put("EquipmentTypeId", addOrEditEquipmentTypeVendorAssociation.getEquipmentTypeId());
					if (vendorOrOperator) {
						vendorInfoJson.put("ServiceAgent", addOrEditEquipmentTypeVendorAssociation.getServiceAgent());
						vendorInfoJson.put("InputFileFormat", addOrEditEquipmentTypeVendorAssociation.getInputFileFormat());
						vendorInfoJson.put("OutputFileFormat", addOrEditEquipmentTypeVendorAssociation.getOutputFileFormat());
					}

					Form formData = new Form();
					formData.add("VendorInfo", vendorInfoJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					if (vendorOrOperator) {
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_VENDOR_ASSOCIATION_UPDATE_SUCCESSFUL");
					} else {
						msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_TYPE_OPERATOR_ASSOCIATION_UPDATE_SUCCESSFUL");
					}	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewEquipmentTypeVendorAssociationMaster.populateData();
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
