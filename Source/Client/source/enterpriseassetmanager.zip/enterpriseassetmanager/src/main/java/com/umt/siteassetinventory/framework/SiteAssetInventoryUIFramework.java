package com.umt.siteassetinventory.framework;

import java.io.Serializable;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.SiteAssetInventoryUIMain;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.Menu;
import com.umt.siteassetinventory.framework.bean.CompanyProfileBean;
import com.umt.siteassetinventory.framework.bean.UserInfoBean;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.resourcemanager.ImageManager;
import com.umt.siteassetinventory.framework.resourcemanager.LabelManager;
import com.umt.siteassetinventory.framework.resourcemanager.MessageManager;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.QueryParameters;

public class SiteAssetInventoryUIFramework implements Serializable{
	private static final long serialVersionUID = 1L;

	protected UserInfoBean i_objUserInfo = null;

	protected LabelManager i_objLabelManager = null;

	protected MessageManager i_objMessageManager = null;

	protected ImageManager i_objImageManager = null;

	private CompanyProfileBean i_objPartnerProfile = null;

	private String i_objCurrentPath = null;
	
	private String currentLocation = null;

	private QueryParameters i_objCurrentPathParam = null;

	private int i_iRoundPrecision = 2;

	private Boolean isOpenMenubar = true;

	protected MainView i_objApplicationMainView = null;
	
	private boolean mobileView = false;

	public SiteAssetInventoryUIFramework() {
		i_objLabelManager = new LabelManager();
		i_objMessageManager = new MessageManager();
		i_objImageManager = new ImageManager();
	}

	public QueryParameters getCurrentPathParam() {
		return i_objCurrentPathParam;
	}

	public void setCurrentPathParam(QueryParameters currentPathParam) {
		this.i_objCurrentPathParam = currentPathParam;
	}

	public String getCurrentPath() {
		return i_objCurrentPath;
	}
	
	public String getRouteLocation() {
		return currentLocation;
		
	}
	public void setRouteLocation(String value) {
		currentLocation = value;
		
	}

	public void setCurrentPath(String currentPath) {
		this.i_objCurrentPath = currentPath;
	}

	
	public void updateMenuBar(Menu selectedMenu) {
		i_objApplicationMainView.updateMenuBar(selectedMenu);
	}
	
	
	public void setUserInfo(UserInfoBean p_objUserInfoBean) {
		i_objUserInfo = p_objUserInfoBean;		
	}
	
	
	public void showVerticalMenuBar(boolean show) {
		i_objApplicationMainView.showVerticalMenuBar(show);
		isOpenMenubar = show;
	} 
	
	public Boolean getOpenMenubar() {
		return isOpenMenubar;
	}

	public UserInfoBean getUserInfo() {
		return i_objUserInfo;
	}

	public boolean isUserLoggedIn() {
		if (i_objUserInfo != null) {
			return true;
		}
		return false;
	}

	public String getToken() {
		String token = "";
		if (i_objUserInfo != null) {
			/*
			 * if (i_objUserInfo.getLoginMedia().equals("AZUREAD") &&
			 * i_objUserInfo.getToken() != null && i_objUserInfo.getToken().trim().length()
			 * > 0) { SessionManager.refreshAzureADTokenIfExpired(i_objUserInfo.getToken());
			 * }
			 */
			token = i_objUserInfo.getToken();
		}

		return token;
	}	 

	public String getEmail() {
		if(isUserLoggedIn()) {
			return getUserInfo().getEmailId();
		}
		return "";
	}

	public String getPartnerCode() {
		if(isUserLoggedIn()) {
			return getUserInfo().getPartnerCode();
		}
		return "";
	}

	public String getLoginDateTime() {
		if(isUserLoggedIn()) {
			return getUserInfo().getStringifiedLoginDateTime();
		}
		return "";
	}

	public String getLabel(String screencd, String componentcd) {
		return i_objLabelManager.getLabel(screencd, componentcd);
	}

	public String getMessage(String screencd, String messagecd) {
		return i_objMessageManager.getMessage(screencd, messagecd);
	}

	public String getImageConfiguration(String screencd, String componentcd) {
		return i_objImageManager.getImageConfiguration(screencd, componentcd);
	}

	public static SiteAssetInventoryUIFramework getFramework() {
		return ((SiteAssetInventoryUIMain) (UI.getCurrent())).getFramework();
	}

	public CompanyProfileBean getPartnerProfile() {
		return i_objPartnerProfile;
	}

	public void setPartnerProfile(CompanyProfileBean partnerProfile) {
		i_objPartnerProfile = partnerProfile;
	}

	public void setRoundPrecision(int roundPrecision) {
		i_iRoundPrecision = roundPrecision;
	}

	public int getRoundPrecision() {
		return i_iRoundPrecision;
	}

	public String getCurrency() {
		if(i_objPartnerProfile != null) {
			return i_objPartnerProfile.getCurrency();
		}
		return "";
	}

	public Dialog showMessage(String screencd, String messagecd, ApplicationConstants.DialogTypes type) {
		Dialog dialog = new Dialog();
		String message = this.getMessage(screencd, messagecd);

		Label dialogtxt = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TXT");
		Button okBtn = UIFieldFactory.createButton("COMMON", "DIALOG_OK_BTN");
		okBtn.addClickShortcut(Key.ENTER);
		VerticalLayout dialogMainLayout = UIOrderedLayoutFactory.createVerticalLayout("COMMON", "DIALOG_MAIN_LAYOUT");
		dialogtxt.setText(message);

		dialog.setCloseOnOutsideClick(false);
		okBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				dialog.close();
			}
		});

		HorizontalLayout buttonBar = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_BUTTON_BAR");
		buttonBar.add(okBtn);
		Label dialogTitleLbl = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TITLE");
		if (CommonUtils.getClientView()) {
			 dialogTitleLbl.getStyle().set("width", "313px");
		 }
		String title = "";
		if(ApplicationConstants.DialogTypes.INFO == type) {
			title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_INFO");
		}
		else {
			title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_ERROR");
		}
		dialogTitleLbl.setText(title);
		HorizontalLayout dialogContentHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_CONTENT_HL");
		HorizontalLayout iconHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "ICON_HL");
		FontAwesome.Solid.Icon icon = null;
		if(ApplicationConstants.DialogTypes.INFO == type) {
			icon = FontAwesome.Solid.INFO_CIRCLE.create();
			icon.addClassName("COMMON_DIALOG_INFO_ICON");
		}
		else {
			icon = FontAwesome.Solid.TIMES_CIRCLE.create();
			icon.addClassName("COMMON_DIALOG_ERROR_ICON");
		}
		iconHL.add(icon);
		dialogContentHL.add(iconHL, dialogtxt);
		dialogMainLayout.add(dialogTitleLbl, dialogContentHL, buttonBar);

		dialog.add(dialogMainLayout);
		dialog.open();
		return dialog;
	}

	public Dialog showMessage(String message, ApplicationConstants.DialogTypes type) {
		Dialog dialog = new Dialog();
		Label dialogtxt = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TXT");
		Button okBtn = UIFieldFactory.createButton("COMMON", "DIALOG_OK_BTN");
		okBtn.addClickShortcut(Key.ENTER);
		message = CommonUtils.getErrorMessage(message);
		
		System.out.println("message==="+message);
		
		if(message.indexOf("AuthorizationException") >= 0) {
			message = getMessage("COMMON", "GENERIC_AUTH_ERROR_MSG");
		} else if (message.indexOf("Exception") >= 0) {
			message = getMessage("COMMON", "ERROR_MSG");
		}else {
			message = CommonUtils.getErrorMessage(message);
		}

		/*
		 * if (message.indexOf("AuthorizationException") < 0 &&
		 * message.indexOf("Exception") >= 0) { message = getMessage("COMMON",
		 * "ERROR_MSG"); }
		 */
		dialogtxt.setText(message);
		VerticalLayout dialogMainLayout = UIOrderedLayoutFactory.createVerticalLayout("COMMON", "DIALOG_MAIN_LAYOUT");
		/*
		 * dialog.setWidth("400px"); dialog.setHeight("150px");
		 */ dialog.setCloseOnOutsideClick(false);
		 okBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			 private static final long serialVersionUID = 1L;

			 @Override
			 public void onComponentEvent(ClickEvent<Button> event) {
				 dialog.close();
			 }
		 });

		 HorizontalLayout buttonBar = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_BUTTON_BAR");
		 buttonBar.add(okBtn);
		 Label dialogTitleLbl = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TITLE");
		 if (CommonUtils.getClientView()) {
			 dialogTitleLbl.getStyle().set("width", "313px");
		 }
		 String title = "";
		 if(ApplicationConstants.DialogTypes.INFO == type) {
			 title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_INFO");
		 }
		 else {
			 title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_ERROR");
		 }
		 dialogTitleLbl.setText(title);
		 HorizontalLayout dialogContentHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_CONTENT_HL");
		 HorizontalLayout iconHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "ICON_HL");
		 FontAwesome.Solid.Icon icon = null;
		 if(ApplicationConstants.DialogTypes.INFO == type) {
			 icon = FontAwesome.Solid.INFO_CIRCLE.create();
			 icon.addClassName("COMMON_DIALOG_INFO_ICON");
		 }
		 else {
			 icon = FontAwesome.Solid.TIMES_CIRCLE.create();
			 icon.addClassName("COMMON_DIALOG_ERROR_ICON");
		 }
		 iconHL.add(icon);
		 dialogContentHL.add(iconHL, dialogtxt);
		 dialogMainLayout.add(dialogTitleLbl, dialogContentHL, buttonBar);

		 //dialogMainLayout.add(dialogtxt, okBtn);
		 dialog.add(dialogMainLayout);
		 dialog.open();
		 return dialog;
	}

	public Dialog showWarningMessage(String screencd, String messagecd, String title) {
		String message = this.getMessage(screencd, messagecd);
		return this.showWarningMessage(message, title);
	}

	public Dialog showWarningMessage(String message, String title) {
		Dialog dialog = new Dialog();

		Label dialogtxt = UIHtmlFieldFactory.createLabel("COMMON", "WARNING_DIALOG_TXT");
		Button noBtn = UIFieldFactory.createButton("COMMON", "WARNING_DIALOG_NO_BTN");
		Button yesBtn = UIFieldFactory.createButton("COMMON", "WARNING_DIALOG_YES_BTN");
		yesBtn.addClickShortcut(Key.ENTER);
		VerticalLayout dialogMainLayout = UIOrderedLayoutFactory.createVerticalLayout("COMMON", "WARNING_DIALOG_MAIN_LAYOUT");
		dialogtxt.setText(message);

		dialog.setCloseOnOutsideClick(false);
		yesBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				dialog.setId("9999");
				dialog.close();
			}
		});

		noBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				dialog.setId("-9999");
				dialog.close();
			}
		});

		HorizontalLayout buttonBar = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "WARNING_DIALOG_BUTTON_BAR");
		buttonBar.add(yesBtn, noBtn);
		Label warningDialogLbl = UIHtmlFieldFactory.createLabel("COMMON", "WARNING_DIALOG_TITLE");
		if (CommonUtils.getClientView()) {
			warningDialogLbl.getStyle().set("width", "313px");
		 }

		if(title != null && title.trim().length() > 0) {
			warningDialogLbl.setText(title);
		}

		HorizontalLayout warningDlgContentHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "WARNING_DIALOG_CONTENT_HL");
		HorizontalLayout iconHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "ICON_HL");
		FontAwesome.Solid.Icon icon = FontAwesome.Solid.EXCLAMATION_TRIANGLE.create();
		iconHL.add(icon);
		icon.addClassName("COMMON_WARNING_DIALOG_EXCLAMATION_ICON");
		warningDlgContentHL.add(iconHL, dialogtxt);
		dialogMainLayout.add(warningDialogLbl, warningDlgContentHL, buttonBar);
		dialog.add(dialogMainLayout);
		dialog.open();
		return dialog;
	}
	
	
	public Dialog showApiErrorMessage(String inputmsg, ApplicationConstants.DialogTypes type) {
		Dialog dialog = new Dialog();
		Label dialogtxt = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TXT");
		Button okBtn = UIFieldFactory.createButton("COMMON", "DIALOG_OK_BTN");
		okBtn.addClickShortcut(Key.ENTER);
		String message = "";
		
		if (inputmsg != null || inputmsg.trim().length() > 0) {
			JSONObject js;
			try {
				js = new JSONObject(inputmsg);
				message=js.getString("message");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				message="";
			}
		}
		

		
		dialogtxt.setText(message);
		VerticalLayout dialogMainLayout = UIOrderedLayoutFactory.createVerticalLayout("COMMON", "DIALOG_MAIN_LAYOUT");
	     dialog.setCloseOnOutsideClick(false);
		 okBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			 private static final long serialVersionUID = 1L;

			 @Override
			 public void onComponentEvent(ClickEvent<Button> event) {
				 dialog.close();
			 }
		 });

		 HorizontalLayout buttonBar = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_BUTTON_BAR");
		 buttonBar.add(okBtn);
		 Label dialogTitleLbl = UIHtmlFieldFactory.createLabel("COMMON", "DIALOG_TITLE");
		 if (CommonUtils.getClientView()) {
			 dialogTitleLbl.getStyle().set("width", "313px");
		 }
		 String title = "";
		 if(ApplicationConstants.DialogTypes.INFO == type) {
			 title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_INFO");
		 }
		 else {
			 title = SiteAssetInventoryUIFramework.getFramework().getLabel("COMMON", "DIALOG_TITLE_ERROR");
		 }
		 dialogTitleLbl.setText(title);
		 HorizontalLayout dialogContentHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "DIALOG_CONTENT_HL");
		 HorizontalLayout iconHL = UIOrderedLayoutFactory.createHorizontalLayout("COMMON", "ICON_HL");
		 FontAwesome.Solid.Icon icon = null;
		 if(ApplicationConstants.DialogTypes.INFO == type) {
			 icon = FontAwesome.Solid.INFO_CIRCLE.create();
			 icon.addClassName("COMMON_DIALOG_INFO_ICON");
		 }
		 else {
			 icon = FontAwesome.Solid.TIMES_CIRCLE.create();
			 icon.addClassName("COMMON_DIALOG_ERROR_ICON");
		 }
		 iconHL.add(icon);
		 dialogContentHL.add(iconHL, dialogtxt);
		 dialogMainLayout.add(dialogTitleLbl, dialogContentHL, buttonBar);

		 dialog.add(dialogMainLayout);
		 dialog.open();
		 return dialog;
	}

	public MainView getApplicationMainView() {
		return i_objApplicationMainView;
	}

	public void setApplicationMainView(MainView applicationMainView) {
		this.i_objApplicationMainView = applicationMainView;
	}
	
	public boolean isMobileView() {
		return mobileView;
	}

	public void setMobileView(boolean mobileView) {
		this.mobileView = mobileView;
	}
}
