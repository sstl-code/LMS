package com.umt.siteassetinventory.landlord;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;

public class EditLandLordDetailsPopUp extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private LandlordView landLordView;
	private String landLordID;
	private EditLandLordDetails parent;

	public EditLandLordDetailsPopUp(String title, Component component, String landLordID, LandlordView landLordView) {
		super(title, component);
		this.parent = (EditLandLordDetails) component;
		this.landLordID = landLordID;
		this.landLordView = landLordView;
		
	}

	@Override
	public void saveOperartion() {
		
		
		boolean isvalid=validity();
		if(!isvalid) {
			return;
		}else {
		
		String url = ApplicationConfiguration.getServiceEndpoint("UPDATELANDLORDDETAILS");
		
		JSONObject json = new JSONObject();
		try {
			json.put("Name", parent.getName());
			json.put("Address", parent.getAddress());
			json.put("ContactNo", parent.getContact());
			json.put("Email",parent.getEmail());
		//	json.put("Region", parent.getRegion());
			json.put("Photo", parent.getBase64());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("json:: " + json);
		
		Form formData = new Form();
		formData.add("LandlordId", landLordID);
		formData.add("landlordDetails", json);
		
		try {
		//	save_btn.setEnabled(false);
			String response = RestServiceHandler.updateJSON_PUT(url, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage("Successfully Saved!", ApplicationConstants.DialogTypes.INFO);
			closeDialog();
			landLordView.addDetailsLandlord(landLordID);
		} catch (Exception e) {
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
	//		save_btn.setEnabled(true);
		} 
		finally {  
			save_btn.setEnabled(true);
		}   
		}
			
		
	}

	private boolean validity() {
		boolean isvalid=true;
	
			if(parent.getNameField().getValue().length()<=0)
			{
				parent.getNameField().setInvalid(true);
				parent.getNameField().setErrorMessage("Please fill up this field");
				isvalid=false;
				return isvalid;
			}
			if(parent.getAddressField().getValue().length()<=0)
			{
				parent.getAddressField().setInvalid(true);
				parent.getAddressField().setErrorMessage("Please fill up this field");
				isvalid=false;
				return isvalid;
			}
			if(parent.getEmailField().getValue()!=null && parent.getEmailField().getValue().length()>0 && !CommonUtils.isEmailAddress(parent.getEmailField().getValue())) // changed by DebleenaC 15-07-2023
			{
				parent.getEmailField().setInvalid(true);
				parent.getEmailField().setErrorMessage("Please enter a valid email.");
				isvalid=false;
				return isvalid;
			}
			
			//if(parent.getRegionField().getValue().length()<=0)
			if(parent.getRegionField().getValue()==null)
			{
				parent.getRegionField().setInvalid(true);
				parent.getRegionField().setErrorMessage("Please fill up this field");
				isvalid=false;
				return isvalid;
			}	
			
		
		return isvalid;
	}

}
