package com.umt.siteassetinventory.landlord;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Base64;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;
import com.umt.siteassetinventory.framework.bean.UserInfoBean;
import com.umt.siteassetinventory.utility.RestServiceHandler;

@WebServlet("/landlordviewworkflowparamfile/*")
public class ViewWorkflowdetailParamFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public ViewWorkflowdetailParamFile() {
		super();
	}

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String landlordIdParam = request.getParameter("LandlordId");	
		String instanceIdParam = request.getParameter("InstanceId");
		String statusParam = request.getParameter("Status");
		String fileNameParam = request.getParameter("Filename");
		String strJsonWorkflow = "" ;
		String fileName = "";
		String fileContent = "";
		//System.out.println("ViewWorkflowdetailParamFile = statusParam-" + statusParam+" landlordIdParam="+landlordIdParam+" instanceIdParam="+instanceIdParam+" fileNameParam="+fileNameParam);
		try {
			UserInfoBean userInfo = SessionManager.getUserInfoFromCookie(request);
			if (statusParam.equalsIgnoreCase("1")) {
				String ServiceEndpoint = ApplicationConfiguration.getServiceEndpoint("GET_WORKFLOWSDETAILS");
				strJsonWorkflow = RestServiceHandler.retriveJSON_GET(ServiceEndpoint+instanceIdParam, userInfo.getToken());
				//System.out.println("ServiceEndpoint>>>>"+ServiceEndpoint+" ? "+instanceIdParam+" ::::: "+strJsonWorkflow);		
			}
			else {				
				String workflowEndpoint = ApplicationConfiguration.getServiceEndpoint("GETLANDLORDWORKORDERS");
				workflowEndpoint = workflowEndpoint + "?LandlordId=" + landlordIdParam;
				String workflowDetails = RestServiceHandler.retriveJSON_GET(workflowEndpoint, userInfo.getToken());
				//System.out.println("workflowDetails  "+workflowDetails);
				JSONArray allWorkflows = new JSONArray(workflowDetails);
				for (int j = 0; j < allWorkflows.length(); j++) {
					JSONObject eachWorkflow = allWorkflows.getJSONObject(j);
					//System.out.println("eachWorkflow  "+eachWorkflow);
					if (eachWorkflow.getString("instanceid").equalsIgnoreCase(instanceIdParam))
					{
						JSONObject wfmDataJson = new JSONObject(eachWorkflow.getString("WFMData"));
						//System.out.println("WFMData:::"+instanceIdParam+" ::::: "+wfmDataJson);
						JSONObject resultJson = new JSONObject(wfmDataJson.getString("result"));
						strJsonWorkflow = resultJson.getString("instance");
						//System.out.println("Workflow:::"+instanceIdParam+" ::::: "+strJsonWorkflow);
					}
				} 	
			}


			JSONObject j_ObjworkflowJSON = new JSONObject(strJsonWorkflow);
			JSONObject jaDataTemplate = j_ObjworkflowJSON.getJSONObject("dataTemplate");
			Iterator<String> paramKeysIterator = jaDataTemplate.keys();
			//System.out.println("jaDataTemplate="+jaDataTemplate.toString());
			while (paramKeysIterator.hasNext()) {

				String paramKey = paramKeysIterator.next();
				//System.out.println("paramKey="+paramKey);
				JSONObject paramValJson = jaDataTemplate.getJSONObject(paramKey);
				String valueString = paramValJson.getString("valueString");
				if (paramValJson.has("contentType") && paramValJson.getString("contentType")!=null && paramValJson.getString("contentType").length()>0 &&
						paramValJson.getString("contentType").trim().equalsIgnoreCase("File") && valueString.startsWith("{")) {
					JSONObject valueStringJson = new JSONObject(valueString);
					//System.out.println("valueStringJson="+valueStringJson.toString());
					if (valueStringJson!=null && valueStringJson.length()>0 && valueStringJson.has("filename") && valueStringJson.getString("filename")!=null && valueStringJson.getString("filename").trim().length()>0) {
						if (valueStringJson.getString("filename").trim().equals(fileNameParam)) {
							fileName = valueStringJson.getString("filename");
							fileContent = valueStringJson.getString("content");
						}
					}
				} 
			}

			if(fileContent != null && fileContent.trim().length() > 0) {
				exportDocument(fileName, fileContent, response);
			}
			else {
				PrintWriter out = response.getWriter();
				out.println("Document not available.");
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	protected void exportDocument(String documentName, String documentContent, HttpServletResponse response) {
		OutputStream outputStream = null;
		try {
			byte[] fileContent = Base64.getDecoder().decode(documentContent);
			outputStream = response.getOutputStream();
			String fileFormat = "";
			String fileExtension = documentName.substring(documentName.lastIndexOf(".") + 1);
			////System.out.println("ViewWorkflowdetailParamFile document Type : " + format);

			//if (format.equalsIgnoreCase("jpg") || format.equalsIgnoreCase("jpeg") || format.equalsIgnoreCase("png") || format.equalsIgnoreCase("gif") || format.equalsIgnoreCase("pdf")) 
			//{
			if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("docx") || fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx")) 
			{
				if(fileExtension.equalsIgnoreCase("pdf"))
				{
					fileFormat = "application/pdf";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				}
				if(fileExtension.equalsIgnoreCase("txt"))
				{
					fileFormat = "text/plain";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				}
				if(fileExtension.equalsIgnoreCase("doc"))
				{
					fileFormat = "application/msword";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				}
				if(fileExtension.equalsIgnoreCase("docx"))
				{
					fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				}
				if (fileExtension.equalsIgnoreCase("xls")) {
					fileFormat = "application/vnd.ms-excel";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				} 
				if (fileExtension.equalsIgnoreCase("xlsx")) {
					fileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
					response.setContentType(fileFormat);
					response.setHeader("Content-Disposition","inline; filename="+documentName);
				}
			}
			if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
			{
				fileFormat = "image/"+fileExtension.toLowerCase();
				response.setContentType(fileFormat);
				response.setHeader("Content-Disposition","inline; filename="+documentName);
			}
			/*try {
				response.setContentType(fileFormat);
			}
			catch(Exception e) {
				logger.error(e.getMessage());
			}*/
			//}

			/*else if(format.toUpperCase().equals("XLS")) {
				response.setContentType("application/vnd.ms-excel");
			}*/
			outputStream.write(fileContent);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(outputStream != null) 
			{
				try 
				{
					outputStream.flush();
					outputStream.close();
				} 
				catch(IOException ex) 
				{
					ex.printStackTrace();
				}
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
