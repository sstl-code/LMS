package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/add_edit_vendor-styles.css")
public class AddOrEditVendor extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_VENDOR";

	private TextField vendorNameFld, descFld, addressFld;
	private ComboBox<String> statusCombo;
	//private String siteCode;
	private long vendorId;

	public AddOrEditVendor(VendorMaster vendorMaster, boolean vendorOrOperator) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		vendorNameFld = UIFieldFactory.createTextField("", true, SCREENCD, "VENDOR_NAME_FIELD");
		descFld = UIFieldFactory.createTextField("", true, SCREENCD, "DESC_FIELD");
		addressFld = UIFieldFactory.createTextField("", true, SCREENCD, "ADDRESS_FIELD");

		statusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, SCREENCD, "STATUS_COMBO");
		statusCombo.setValue("Active");
		statusCombo.setEnabled(false);
		String title = "";
		if (vendorOrOperator) {
			title = "Vendor";
		} else {
			title = "Operator";
		}
		AddOrEditVendorPopup popup = new AddOrEditVendorPopup("Add "+title, true, this, vendorMaster, SCREENCD, vendorOrOperator);

		add(vendorNameFld, descFld, addressFld, statusCombo);

	}

	public AddOrEditVendor(VendorMaster vendorMaster, VendorMasterDataBean vendorMasterDataBean, long vendorId, String vendorName, 
			String desc, String address, String status, boolean vendorOrOperator) {
		this.vendorId = vendorId;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		try {
			vendorNameFld = UIFieldFactory.createTextField(vendorName, true, SCREENCD, "VENDOR_NAME_FIELD");
			vendorNameFld.setEnabled(false);
			descFld = UIFieldFactory.createTextField(desc, true, SCREENCD, "DESC_FIELD");
			addressFld = UIFieldFactory.createTextField(address, true, SCREENCD, "ADDRESS_FIELD");

			statusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, SCREENCD, "STATUS_COMBO");
			statusCombo.setValue(status);
			String title = "";
			if (vendorOrOperator) {
				title = "Vendor";
			} else {
				title = "Operator";
			}
			AddOrEditVendorPopup popup = new AddOrEditVendorPopup("Edit "+title, false, this, vendorMaster, SCREENCD, vendorOrOperator);

			add(vendorNameFld, descFld, addressFld, statusCombo);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean validation() {
		vendorNameFld.setInvalid(false);
		descFld.setInvalid(false);
		addressFld.setInvalid(false);
		statusCombo.setInvalid(false);

		if (vendorNameFld.getValue()==null || vendorNameFld.getValue().trim().length()==0) {
			vendorNameFld.setInvalid(true);
			vendorNameFld.setErrorMessage("Please enter "+vendorNameFld.getLabel().toLowerCase());
			return false;
		}

		if (descFld.getValue()==null || descFld.getValue().toString().trim().length()==0) {
			descFld.setInvalid(true);
			descFld.setErrorMessage("Please enter "+descFld.getLabel().toLowerCase());
			return false;
		}

		if (addressFld.getValue()==null || addressFld.getValue().toString().trim().length()==0) {
			addressFld.setInvalid(true);
			addressFld.setErrorMessage("Please enter "+addressFld.getLabel().toLowerCase());
			return false;
		}

		if (statusCombo.getValue()==null || statusCombo.getValue().trim().length()==0) {
			statusCombo.setInvalid(true);
			statusCombo.setErrorMessage("Please enter "+statusCombo.getLabel().toLowerCase());
			return false;
		}
		return true;
	}
	
	
	public long getVendorId() {
		return vendorId;
	}

	public String getVendorName() {
		if (vendorNameFld.getValue()==null)
			return "";
		else
			return vendorNameFld.getValue();
	}

	public String getDesc() {
		if (descFld.getValue()==null)
			return "";
		else
			return descFld.getValue()+"";
	}

	public String getAddress() {
		if (addressFld.getValue()==null)
			return "";
		else
			return addressFld.getValue()+"";
	}

	public String getStatus() {
		if (statusCombo.getValue()==null)
			return "";
		else
			return statusCombo.getValue();
	}


}
