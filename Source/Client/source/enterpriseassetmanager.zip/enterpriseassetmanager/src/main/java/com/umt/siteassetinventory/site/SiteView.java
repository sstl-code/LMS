package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.EventsTab;
import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap.CustomGoogleMapMarkerClickListener;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.router.Route;


@Route(value = "siteview", layout = MainView.class)
@CssImport("./styles/site-view.css")
public class SiteView extends BaseStructure implements AfterNavigationObserver,HasUrlParameter<String>
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_VIEW";
	private Tab detailsTab,attributesTab,LandlordTab,activeAssetTab,passiveAssetTab,agreementsTab,documentTab,TicketsTab,
	electricMeterTab,tenantsTab,eventsTab;
	private SiteDetailsTab siteDetailsTabVL;
	private AttributeParent attributeTabVL;
	private SiteLandLordTab sitelandLordTabVL;
	private SiteAssetsTab siteActiveAssetsTabVL;
	private SiteAssetsTab sitePassiveAssetsTabVL;
	private SiteAgreementsTab siteAgreementsTabVL;
	private SiteDocumentsTab siteDocumentsTabVL;
	private TicketsTab ticketsTabVL;
	private SiteElectricMeterTab siteElectricMeterTabVL;
	private TenantsTab tenantsTabVL;
	private EventsTab eventsTabVL;
	private Checkbox mapViewChk,geoFencingChk;
	private Button addSiteBtn,viewMapBtn,applyBtn,clearMapBtn;
	private TextField searchSiteListField,applyRadiusField;
	private String selectedSitecode;
	private List<SiteViewDataBean> sitebeanList=new ArrayList<SiteViewDataBean>();
	private Div detailsTabHolder, attributesTabHolder, activeAssetsTabHolder, passiveAssetsTabHolder, agreementsTabHolder, landLordTabHolder, documentsTabHolder, 
	ticketsTabHolder, electricMeterTabHolder, tenantsTabHolder, eventsTabHolder;
	private SiteViewDataBean beanobj;
	private Div siteListContainerDiv;
	private SiteView parent;
	private String searchCriteria;
	public String route="";
	public String sitelistresponse="";
	private Map<String, List<String>> parameterMap;
	private String searchcriteria2="";

	private  String siteCode;

	private String paramsiteCode;
	private SiteListMapView mapView;
	private Div mapviewDiv1,mapviewDiv;
	public boolean isMapVisible=false;
	private String mapsitecode1;

	private String str1,str2;
	private JSONArray sortedjsArr;

	private Label col2Lbl1,col2Lbl2;
	private String col2Lbl1Str,col2Lbl2Str;

	private Div idiv1,idiv2;
	private Div idiv3,idiv4;
	private Div idiv5,idiv6;
	private Icon caret_down1,caret_down2,caret_down3;
	private Icon caret_up1,caret_up2,caret_up3;
	private String sortedListResponse;

	private CustomGoogleMap googleMapComponent;
	private JSONArray markerJSONArray = new JSONArray();
	private String lat,longi;
	private ComboBox<String> radiusUnitCombo;
	private Div noRecordDiv,noRecordDiv2;
	private Div recordcontainerDiv;
	private LocalDate date1,date2;
	private Div searchListDiv,headerDiv,searchListRowDiv2;
	private Label headerLbl1;
	
	public boolean mapViewBtnClicked=false;
	private String selectedSiteLatitude,selectedSiteLongitude;
	private String selectedSiteLatitude2,selectedSiteLongitude2;
	private String searchedSiteLatitude="",searchedSiteLongitude="";
	
	JSONObject property_attr_json= new JSONObject() ;

	public SiteView() 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		parent=this;
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Site View");
		//		searchRecords();

		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAIL_TAB_LBL"));
		attributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ATTR_TAB_LBL"));
		LandlordTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "LANDLORD_TAB_LBL"));
		activeAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ACTIVE_ASSET_TAB_LBL"));
		passiveAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PASSIVE_ASSET_TAB_LBL"));
		electricMeterTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ELECTRIC_METER_TAB_LBL"));
		agreementsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "AGREEMENTS_TAB_LBL"));
		documentTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DOCUMENTS_TAB_LBL"));
		TicketsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TICKETS_TAB_LBL"));
		tenantsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TENANTS_LBL"));
		eventsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "EVENTS_LBL"));

		detailsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_TAB_DIV");
		attributesTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTES_TAB_DIV");
		activeAssetsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ACTIVE_ASSETS_TAB_DIV");
		passiveAssetsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "PASSIVE_ASSETS_TAB_DIV");
		electricMeterTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ELECTRIC_METER_TAB_DIV");
		agreementsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "AGREEMENTS_TAB_DIV");
		landLordTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "LANDLORD_TAB_DIV");
		documentsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENTS_TAB_DIV");
		ticketsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "TICKETS_TAB_DIV");
		tenantsTabHolder=UIHtmlFieldFactory.createDiv(SCREENCD, "TENANTS_TAB_DIV");
		eventsTabHolder=UIHtmlFieldFactory.createDiv(SCREENCD, "EVENTS_TAB_DIV");
		//		siteDetailsTabVL=new SiteDetailsTab();
		noRecordDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
		noRecordDiv2.setVisible(false);
		recordcontainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RECORD_DIV");
		recordcontainerDiv.setVisible(true);

		//		siteDetailsTabVL=new SiteDetailsTab();
		//		siteAttributeTabVL=new SiteAttributesTab();
		//		
		//		
		//		siteDocumentsTabVL=new SiteDocumentsTab();
		//		ticketsTabVL=new TicketsTab();

		parentTabs.add(detailsTab,attributesTab,tenantsTab,/*activeAssetTab,passiveAssetTab,*/electricMeterTab,agreementsTab,LandlordTab,documentTab,TicketsTab,eventsTab);
		add(rowDiv);

		col2HeaderDiv1.removeAll();

		createHeader();
		//populateSiteDetailRow(searchcriteria2);
		if (paramsiteCode==null || paramsiteCode.trim().length()==0) 
			populateSiteDetailRow2(searchcriteria2);
		
		generateMarkerData(sitelistresponse);

		parentTabs.setSelectedTab(detailsTab);
		detailsTabHolder.setVisible(true);
		addDetailsTab(siteCode);
		//		siteDetailsTabVL.setSiteCode(getSelectedsitecode());
		//		siteAttributeTabVL.setVisible(false);

		//		siteActiveAssetsTabVL.setVisible(false);
		//		sitePassiveAssetsTabVL.setVisible(false);
		//		siteAgreementsTabVL.setVisible(false);
		//		siteDocumentsTabVL.setVisible(false);
		//		ticketsTabVL.setVisible(false);


		recordcontainerDiv.add(detailsTabHolder, attributesTabHolder,tenantsTabHolder,activeAssetsTabHolder, passiveAssetsTabHolder,electricMeterTabHolder, agreementsTabHolder, landLordTabHolder, 
				documentsTabHolder, ticketsTabHolder, eventsTabHolder);

		col2ValueDiv.add(/*detailsTabHolder, attributesTabHolder, landLordTabHolder, siteActiveAssetsTabVL, sitePassiveAssetsTabVL, siteAgreementsTabVL,
				siteDocumentsTabVL, ticketsTabVL,*/recordcontainerDiv,noRecordDiv2);

		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) {
					detailsTabHolder.setVisible(true);
					addDetailsTab(siteCode);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);			
					//					siteDetailsTabVL.setSiteCode(getSelectedsitecode());
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(attributesTab)) {
					detailsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(true);
					addAttributesTab(siteCode);
					landLordTabHolder.setVisible(false);
					//System.out.println("Code:: " + siteCode);				
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} 
				else if(event.getSelectedTab().equals(tenantsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(true);
					addTenantsTab(siteCode);
					landLordTabHolder.setVisible(false);
					//System.out.println("Code:: " + siteCode);				
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} 
				else if(event.getSelectedTab().equals(LandlordTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(true);
					//System.out.println("Code:: " + siteCode);
					addlandlordTab(siteCode);
					//					siteAttributeTabVL.setSiteCode(getSelectedsitecode());
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				}else if(event.getSelectedTab().equals(activeAssetTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(true);
					addActiveAssetsTab(siteCode);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(passiveAssetTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(true);
					addPassiveAssetsTab(siteCode);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				}else if(event.getSelectedTab().equals(electricMeterTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(true);
					addelectricMeterTab(siteCode);
					agreementsTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(agreementsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(true);
					electricMeterTabHolder.setVisible(false);
					addAgreementsTab(siteCode);
					documentsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(documentTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					documentsTabHolder.setVisible(true);
					addDocumentsTab(siteCode);
					ticketsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(TicketsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(true);
					addTicketsTab(siteCode);
					eventsTabHolder.setVisible(false);
					//ticketsTabVL.displayWorkflows();
				} else if(event.getSelectedTab().equals(eventsTab)) {
					detailsTabHolder.setVisible(false);
					attributesTabHolder.setVisible(false);
					landLordTabHolder.setVisible(false);
					activeAssetsTabHolder.setVisible(false);
					passiveAssetsTabHolder.setVisible(false);
					agreementsTabHolder.setVisible(false);
					electricMeterTabHolder.setVisible(false);
					documentsTabHolder.setVisible(false);
					tenantsTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					eventsTabHolder.setVisible(true);
					addEventsTab(siteCode);
					//ticketsTabVL.displayWorkflows();
				}


			}
		});


	}

	

	


	public void addDetailsTab(String siteCode) {
		detailsTabHolder.removeAll();
		siteDetailsTabVL = new SiteDetailsTab(siteCode, this);
		detailsTabHolder.add(siteDetailsTabVL);


	}
	public void addAttributesTab(String siteCode) {
		//System.out.println("siteCode:::"+siteCode);
		attributesTabHolder.removeAll();
		attributeTabVL = new AttributeParent(siteCode, this);
		attributesTabHolder.add(attributeTabVL);
	}
	protected void addTenantsTab(String siteCode2) {
		tenantsTabHolder.removeAll();
		tenantsTabVL = new TenantsTab(siteCode, this);
		tenantsTabHolder.add(tenantsTabVL);
	}

	public void addlandlordTab(String siteCode) {
		landLordTabHolder.removeAll();
		sitelandLordTabVL = new SiteLandLordTab(siteCode, this);
		landLordTabHolder.add(sitelandLordTabVL);

	}
	public void addActiveAssetsTab(String siteCode) {
		activeAssetsTabHolder.removeAll();
		siteActiveAssetsTabVL=new SiteAssetsTab(true);
		siteActiveAssetsTabVL.setSiteCode(siteCode/*"ep.ID812940DC"*/);
		activeAssetsTabHolder.add(siteActiveAssetsTabVL);

	}
	public void addPassiveAssetsTab(String siteCode) {
		passiveAssetsTabHolder.removeAll();
		sitePassiveAssetsTabVL=new SiteAssetsTab(false);
		sitePassiveAssetsTabVL.setSiteCode(siteCode/*"ep.ID812940DC"*/);
		passiveAssetsTabHolder.add(sitePassiveAssetsTabVL);
		
	}
	protected void addelectricMeterTab(String siteCode2) {
		electricMeterTabHolder.removeAll();
		siteElectricMeterTabVL=new SiteElectricMeterTab(siteCode);
		siteElectricMeterTabVL.setSiteCode(siteCode);
		electricMeterTabHolder.add(siteElectricMeterTabVL);
		
		
	}
	public void addAgreementsTab(String siteCode) {
		agreementsTabHolder.removeAll();
		siteAgreementsTabVL=new SiteAgreementsTab(this,mapViewBtnClicked,selectedSiteLatitude,selectedSiteLongitude);
		siteAgreementsTabVL.setSiteCode(siteCode/*"ep.ID812940DC"*/);
		agreementsTabHolder.add(siteAgreementsTabVL);
		
	}
	public void addDocumentsTab(String siteCode) {
		documentsTabHolder.removeAll();
		siteDocumentsTabVL=new SiteDocumentsTab();
		siteDocumentsTabVL.loadSiteDocumentScreen(siteCode);
		documentsTabHolder.add(siteDocumentsTabVL);
		
	}
	public void addTicketsTab(String siteCode) {
		ticketsTabHolder.removeAll();
		ticketsTabVL=new TicketsTab();
		ticketsTabVL.setSiteCode(siteCode/*"ep.ID812940DC"*/);
		ticketsTabHolder.add(ticketsTabVL);
		
	}
	public void addEventsTab(String siteCode) {
		eventsTabHolder.removeAll();
		eventsTabVL=new EventsTab("SiteCode:"+siteCode, "SiteService");
		eventsTabVL.populateData();
		eventsTabHolder.add(eventsTabVL);
	}

	public void selectedRowChangeHandler(String siteCode) 
	{
		parentTabs.setSelectedTab(detailsTab);
		selectedSitecode=siteCode;
		siteDetailsTabVL.setSiteCode(selectedSitecode);
		
		this.siteCode=selectedSitecode;
		
		generatePropertyAttributes(siteCode);


		//		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(SelectedChangeEvent event) {
		//				if(event.getSelectedTab().equals(detailsTab)) 
		//				{
		////					siteDetailsTabVL.setSiteCode(selectedSitecode);
		//				} else if(event.getSelectedTab().equals(attributesTab)) {
		//					//attributeTabVL.setSiteCode(selectedSitecode);
		//				}
		//			}
		//		});
	}
	public void populateSiteDetailRow(String searchCriteria) 
	{

		try
		{
			String res="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCHSITE");
			url=url+"?searchText="+searchCriteria;
			//	System.out.println("url1="+url);
			res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//	System.out.println("site_search_res="+res);
			sitelistresponse=res;
			//System.out.println("sitelistresponse="+sitelistresponse);

			sitebeanList.clear();
			siteListContainerDiv.removeAll();
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								jsarr.getJSONObject(i).getString("SiteCode"),
								jsarr.getJSONObject(i).getString("Region"),
								jsarr.getJSONObject(i).getString("CreationDate"),
								jsarr.getJSONObject(i).getString("Address"),
								jsarr.getJSONObject(i).getString("Lattitude"),
								jsarr.getJSONObject(i).getString("Longitude"),
								jsarr.getJSONObject(i).getString("SiteName"),
								this);


						//	col1ValueDiv.add(beanobj);
						siteListContainerDiv.add(beanobj);
						sitebeanList.add(beanobj);
						if(i==0 && paramsiteCode==null)
						{
							addDetailsTab(jsarr.getJSONObject(i).getString("SiteCode"));
							siteCode=jsarr.getJSONObject(i).getString("SiteCode");
							beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
							mapsitecode1=jsarr.getJSONObject(i).getString("SiteCode");
							selectedSitecode=siteCode;
							
							selectedSiteLatitude=jsarr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=jsarr.getJSONObject(i).getString("Longitude");
						}

					}
				}

			}
			if(isMapVisible==true)
			{
				//populateMapview(sitelistresponse);
				refreshGoogleMapview(sitelistresponse);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				siteListContainerDiv.setVisible(false);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	private void createHeader() 
	{
		try {
			/*	mapView=new SiteListMapView(this);
		mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");

		mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
		mapviewDiv.add(mapView);
		mapviewDiv1.add(mapviewDiv);
	//	mapView.setVisible(true);
		mapView.setVisible(false);
		mapviewDiv1.setVisible(false);
	//	mapView.populateSiteDetails1(sitelistresponse);*/
			siteListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
			noRecordDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
			noRecordDiv.setVisible(false);
			if (searchedSiteLatitude != null && searchedSiteLongitude != null
					&& searchedSiteLatitude.trim().length() > 0 && searchedSiteLongitude.trim().length() > 0) {
				lat = searchedSiteLatitude;
				longi = searchedSiteLongitude;
			} else {
				lat = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
				longi = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			}

			mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");
			mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
			mapviewDiv1.add(mapviewDiv);
			mapviewDiv1.setVisible(false);

			//	generateMarkerData();
			//	googleMapComponent.populateMarker(markerJSONArray);


			Div eachDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
			Div eachDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
			Div eachDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
			Div eachDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");


			headerLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
			eachDiv1.add(headerLbl1);

			mapViewChk = UIFieldFactory.createCheckbox(false, false, SCREENCD, "MAP_VIEW");
			mapViewChk.setEnabled(false);
			//	eachDiv2.add(mapViewChk);

			//	geoFencingChk= UIFieldFactory.createCheckbox(false, false, SCREENCD, "GEO_FENCING");
			Image viewmapImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_MAP_IMAGE");
			eachDiv3.add(viewmapImg);

			addSiteBtn = UIFieldFactory.createButton(SCREENCD, "ADD_SITE_BTN");
			addSiteBtn.setVisible(false);
			eachDiv4.add(addSiteBtn);

			col1HeaderDiv.add(eachDiv1/*,eachDiv2,eachDiv3*/,eachDiv4);

			headerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_HEADER_DIV");

			Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
			Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
			Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");

			idiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_up1=VaadinIcon.CARET_UP.create();
			caret_up1.addClassName("CARET_UP");
			idiv1.add(caret_up1);
			idiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_down1=VaadinIcon.CARET_DOWN.create();
			caret_down1.addClassName("CARET_DOWN");
			idiv2.add(caret_down1);
			Div IconDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
			IconDiv1.add(idiv1,idiv2);


			idiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_up2=VaadinIcon.CARET_UP.create();
			caret_up2.addClassName("CARET_UP");
			idiv3.add(caret_up2);
			idiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_down2=VaadinIcon.CARET_DOWN.create();
			caret_down2.addClassName("CARET_DOWN");
			idiv4.add(caret_down2);
			Div IconDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
			IconDiv2.add(idiv3,idiv4);

			idiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_up3=VaadinIcon.CARET_UP.create();
			caret_up3.addClassName("CARET_UP");
			idiv5.add(caret_up3);
			idiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
			caret_down3=VaadinIcon.CARET_DOWN.create();
			caret_down3.addClassName("CARET_DOWN");
			idiv6.add(caret_down3);
			Div IconDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
			IconDiv3.add(idiv5,idiv6);

			Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
			eachdataDiv1.add(lbl1,IconDiv1);
			Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
			eachdataDiv2.add(lbl2,IconDiv2);
			Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
			eachdataDiv3.add(lbl3,IconDiv3);
			headerDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3);
			searchSiteListField = UIFieldFactory.createTextField("", false, SCREENCD,"SEARCH_SITE_LIST");
			searchSiteListField.setPlaceholder("Type to filter site List");


			//	Div searchListDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_DIV");
			//	searchListDiv.add(searchSiteListField,headerDiv);

			ArrayList<String> unitList=new ArrayList<String>();
			unitList.clear();
			String units[] = { "m","km","miles"};
			for (int i = 0; i < units.length; i++) {
				unitList.add(units[i]);
			}
			radiusUnitCombo = UIFieldFactory.createComboBox(unitList, false, SCREENCD, "UNIT_COMBO_FIELD");
			radiusUnitCombo.setPlaceholder("units");
			radiusUnitCombo.setEnabled(false);

			searchListDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_DIV");
			Div searchListRowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV1");
			searchListRowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV2");

			viewMapBtn= UIFieldFactory.createButton(SCREENCD, "VIEW_MAP_BTN");
			applyBtn= UIFieldFactory.createButton(SCREENCD, "APPLY_BTN");
			clearMapBtn= UIFieldFactory.createButton(SCREENCD, "CLOSE_BTN");
			applyRadiusField= UIFieldFactory.createTextField("", false, SCREENCD,"APPLY_RADIUS_FIELD");
			applyRadiusField.setPlaceholder("Type radius");
			Div locationimgDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "LOCATION_IMG_DIV");
			Image locationImg = UIHtmlFieldFactory.createImage(SCREENCD, "LOCATION_IMAGE");
			locationimgDiv.add(locationImg);

			Div radiusDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RADIUS_DIV");
			radiusDiv.add(applyRadiusField,radiusUnitCombo);

			searchListRowDiv1.add(mapViewChk,viewMapBtn);
			searchListRowDiv2.add(/*locationimgDiv,*//*applyRadiusField*/radiusDiv,applyBtn,clearMapBtn);
			searchListRowDiv2.setVisible(false);

			searchListDiv.add(searchListRowDiv1,searchListRowDiv2);

			//	siteListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
			col1ValueDiv.add(searchListDiv,mapviewDiv1,/*searchListDiv,*/headerDiv,siteListContainerDiv,noRecordDiv);

			searchSiteListField.setValueChangeMode(ValueChangeMode.EAGER);
			applyRadiusField.setValueChangeMode(ValueChangeMode.EAGER);

			applyRadiusField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<?> event) 
				{
					if (applyRadiusField.getValue() == null || applyRadiusField.getValue().trim().length() <= 0) 
					{
						radiusUnitCombo.setEnabled(false);
					}
					if (applyRadiusField.getValue().trim().length() > 0) 
					{
						radiusUnitCombo.setEnabled(true);
					}
				}
			});


			addSiteBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) 
				{

					AddSiteDialog dlg= new AddSiteDialog();
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;

						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							AddSiteDialog srcDlg = (AddSiteDialog)event.getSource();
							if(!srcDlg.isOpened() && (srcDlg.isSuccess()==true)) 
							{
								populateSiteDetailRow2(searchcriteria2);
							}
						}

					});
				}
			});
			viewMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					/*	mapView.setVisible(true);
				mapView.populateSiteDetails1(sitelistresponse);
				mapView.setSelectedSite(selectedSitecode);
				mapviewDiv.setVisible(true);
				mapviewDiv1.setVisible(true);
				isMapVisible=true;
				searchListDiv.setVisible(true);
				siteListContainerDiv.setVisible(false);
				headerDiv.setVisible(false);
				searchListRowDiv2.setVisible(true);
				headerLbl1.removeAll();
				headerLbl1.setText("Site List-Map View");*/


					try {
						mapViewBtnClicked=true;

						mapviewDiv.setVisible(true);
						mapviewDiv1.setVisible(true);
						isMapVisible=true;
						searchListDiv.setVisible(true);
						siteListContainerDiv.setVisible(false);
						headerDiv.setVisible(false);
						searchListRowDiv2.setVisible(true);
						headerLbl1.removeAll();
						headerLbl1.setText("Site List-Map View");
						mapViewChk.setEnabled(false);
						applyRadiusField.clear();
						radiusUnitCombo.clear();
						noRecordDiv.setVisible(false);
						noRecordDiv2.setVisible(false);
						//	googleMapComponent.clearMapMarker();
				//		if (googleMapComponent == null) {
						if (searchedSiteLatitude != null && searchedSiteLongitude != null
								&& searchedSiteLatitude.trim().length() > 0 && searchedSiteLongitude.trim().length() > 0) {
							lat = searchedSiteLatitude;
							longi = searchedSiteLongitude;
						} else {
							lat = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
							longi = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
						}
						//System.out.println("createHeader lat= "+lat+" long= "+longi);
							googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 1,"sitelistmap");
							mapviewDiv.removeAll();
							mapviewDiv.add(googleMapComponent);

							googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
								private static final long serialVersionUID = 1L;

								@Override
								public void onMapMarkerClick(String eventData) {
									//System.out.println("Event Data -->>" + eventData);
									try {
										JSONObject eventDataJSON = new JSONObject(eventData);
										String uniqueId = eventDataJSON.getString("event.detail");
										selectedRowChangeHandler(uniqueId);
										selectSiteViewNode(uniqueId);
										selectedSitecode = uniqueId;
										addDetailsTab(uniqueId);
										
										setLatLongForGmapMarker(uniqueId);

										generatePropertyAttributes(uniqueId);
										setPropertyTypeForGmapMarker(uniqueId);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							});
				//		}
						googleMapComponent.setVisible(true);
						googleMapComponent.clearMapMarker();
						generateMarkerData(sitelistresponse);
						googleMapComponent.populateMarker(markerJSONArray);
						//	googleMapComponent.openInfoWindow(/*selectedSitecode*/);
						//	System.out.println("SELECTED_ID="+selectedSitecode);
						googleMapComponent.openInfoWindow2(/*"ep.ID539873BB"*/selectedSitecode);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}		

			});
			clearMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					/*	mapView.setVisible(false);
				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				searchListDiv.setVisible(true);
				isMapVisible=false;
				siteListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Site List");*/
					mapViewBtnClicked=false;
					
					mapviewDiv.setVisible(false);
					mapviewDiv1.setVisible(false);
					searchListDiv.setVisible(true);
					isMapVisible=false;
					//	siteListContainerDiv.setVisible(true);
					headerDiv.setVisible(true);
					searchListRowDiv2.setVisible(false);
					headerLbl1.removeAll();
					headerLbl1.setText("Site List");
					mapViewChk.setEnabled(false);
					mapViewChk.setValue(false);
					applyRadiusField.clear();
					radiusUnitCombo.clear();
					//	noRecordDiv.setVisible(false);
					//	noRecordDiv2.setVisible(false);
					if(sitelistresponse!=null || !sitelistresponse.equalsIgnoreCase("[]"))
					{
						siteListContainerDiv.setVisible(true);
						noRecordDiv.setVisible(false);
						noRecordDiv2.setVisible(false);
					}
					if(sitelistresponse==null || sitelistresponse.equalsIgnoreCase("[]"))
					{
						siteListContainerDiv.setVisible(false);
						noRecordDiv.setVisible(true);
						noRecordDiv2.setVisible(true);
						//	col2HeaderDiv1.removeAll();
					}
				}
			});



			applyBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Button> event) {
					try 
					{
						if(applyRadiusField.getValue().toString().length()<=0)
						{
							SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide radius", ApplicationConstants.DialogTypes.ERROR);
							return;
						}
						if (radiusUnitCombo.getValue() == null) 
						{
							SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide units", ApplicationConstants.DialogTypes.ERROR);
							return;
						}
						if(applyRadiusField.getValue().toString().length()<=0 && radiusUnitCombo.getValue() == null)
						{
							SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide both radius and units", ApplicationConstants.DialogTypes.ERROR);
							return;
						}
						if(applyRadiusField.getValue().toString().length()>0 && radiusUnitCombo.getValue() != null)
						{
							String radius=calcRadius(applyRadiusField.getValue(),radiusUnitCombo.getValue());
							googleMapComponent.applyGeoFence(Double.parseDouble(radius));
							mapViewChk.setValue(true);
							mapViewChk.setEnabled(true);
						}

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});

			mapViewChk.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<?> event) 
				{
					if(event.getValue().equals(false))
					{
						googleMapComponent.clearGeoFence();
						mapViewChk.setEnabled(false);
					}

				}
			});


			eachDiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) 
				{

					SiteListMapViewDialog dlg= new SiteListMapViewDialog(parent,selectedSitecode,null,null,"Site_view");
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;

						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							SiteListMapViewDialog srcDlg = (SiteListMapViewDialog)event.getSource();
							if(!srcDlg.isOpened()) 
							{

							}
						}

					});
				}
			});

			idiv1.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortBySiteCode("descending");
					//caret_up1.removeClassName("CARET_UP");
					//caret_up1.addClassName("CARET_UP_SELECTED");
					caret_up1.getStyle().set("color", "#0000ff87");
					caret_down1.getStyle().set("color", "#8080809e");
					//caret_up1.setVisible(false);
					//caret_down1.setVisible(true);
					caret_down2.getStyle().set("color", "#8080809e");
					caret_up2.getStyle().set("color", "#8080809e");
					caret_down3.getStyle().set("color", "#8080809e");
					caret_up3.getStyle().set("color", "#8080809e");
				}
			});
			idiv2.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortBySiteCode("ascending");
					//	caret_down1.removeClassName("CARET_DOWN");
					//	caret_down1.addClassName("CARET_DOWN_SELECTED");
					caret_down1.getStyle().set("color", "#0000ff87");
					caret_up1.getStyle().set("color", "#8080809e");
					//caret_down1.setVisible(false);
					//caret_up1.setVisible(true);
					caret_down2.getStyle().set("color", "#8080809e");
					caret_up2.getStyle().set("color", "#8080809e");
					caret_down3.getStyle().set("color", "#8080809e");
					caret_up3.getStyle().set("color", "#8080809e");
				}
			});

			idiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortByRegion("descending");

					caret_up2.getStyle().set("color", "#0000ff87");
					caret_down2.getStyle().set("color", "#8080809e");

					caret_down1.getStyle().set("color", "#8080809e");
					caret_up1.getStyle().set("color", "#8080809e");
					caret_down3.getStyle().set("color", "#8080809e");
					caret_up3.getStyle().set("color", "#8080809e");

				}
			});
			idiv4.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortByRegion("ascending");

					caret_down2.getStyle().set("color", "#0000ff87");
					caret_up2.getStyle().set("color", "#8080809e");

					caret_down1.getStyle().set("color", "#8080809e");
					caret_up1.getStyle().set("color", "#8080809e");
					caret_down3.getStyle().set("color", "#8080809e");
					caret_up3.getStyle().set("color", "#8080809e");

				}
			});

			idiv5.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortByCreationDate("descending");

					caret_up3.getStyle().set("color", "#0000ff87");
					caret_down3.getStyle().set("color", "#8080809e");

					caret_down1.getStyle().set("color", "#8080809e");
					caret_up1.getStyle().set("color", "#8080809e");
					caret_down2.getStyle().set("color", "#8080809e");
					caret_up2.getStyle().set("color", "#8080809e");

				}
			});
			idiv6.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
					sortByCreationDate("ascending");

					caret_down3.getStyle().set("color", "#0000ff87");
					caret_up3.getStyle().set("color", "#8080809e");

					caret_down1.getStyle().set("color", "#8080809e");
					caret_up1.getStyle().set("color", "#8080809e");
					caret_down2.getStyle().set("color", "#8080809e");
					caret_up2.getStyle().set("color", "#8080809e");

				}
			});

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}	


	protected String calcRadius(String rad, String unit) {

		String val="";
		switch(unit)
		{
		case "m":
			val=rad;
			break;
		case "km":
			double d=Double.parseDouble(rad)*1000;
			val=String.valueOf(d);
			break;
		case "miles":
			double v=Double.parseDouble(rad)*1609.34;
			val=String.valueOf(v);
			break;
		}
		return val;
	}

	public String getSelectedsitecode()
	{
		return selectedSitecode;

	}

	public List<SiteViewDataBean> getSiteBeanList()
	{
		return sitebeanList;
	}

	public void deselectOtherRows(SiteViewDataBean child) 
	{
		for (int i = 0; i < sitebeanList.size(); i++) 
		{
			sitebeanList.get(i).deselectEachDiv(child);
		}

	}
	public void setSelectedSite(String siteCode) 
	{
		//siteMasterComponent.setSelectedSite(siteCode);
	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) 
	{
		//System.out.println("route="+event.getLocation().getPathWithQueryParameters());
		route=event.getLocation().getPathWithQueryParameters();
		if(route.equalsIgnoreCase("siteview") || route.contains("siteview?siteCode="))
		{
			this.searchCriteria=searchcriteria2;
			getSiteViewobj(parent);
			//	populateSiteDetailRow();
		}

	}

	@Override
	public void setParameter(BeforeEvent event, @OptionalParameter String parameter) 
	{
		Location location = event.getLocation();
		QueryParameters queryParameters = location.getQueryParameters();
		parameterMap = queryParameters.getParameters();
		List<String> paramValue = parameterMap.get("siteCode");
		if(parameterMap.size()>0)
		{
			if(paramValue != null && paramValue.size() > 0)
			{
				paramsiteCode = paramValue.get(0);
			}
			//	System.out.println("paramsiteCode::"+paramsiteCode);
			if(paramsiteCode!=null && paramsiteCode.trim().length()>0)
			{
				//	populateSiteDetailRow(paramsiteCode);
				//populateSiteDetailRow1(paramsiteCode);
				populateSiteDetailRow2(paramsiteCode);
				selectSiteViewNode(paramsiteCode);
				selectedSitecode=paramsiteCode;
				//addDetailsTab(paramsiteCode);
			}
		}
	}

	private void populateSiteDetailRow1(String paramsiteCode2) {
		try
		{
			String res="",res1="";

			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEDETAILS");
			url=url+"?SiteCode="+URLEncoder.encode(paramsiteCode2);
			//	System.out.println("url1="+url);
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			res1="["+res+"]";
			//	System.out.println("site_param_res1:::"+res1);
			sitelistresponse=res1;

			sitebeanList.clear();
			siteListContainerDiv.removeAll();
			if(res1!=null && res1.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res1);
				for(int i=0;i<jsarr.length();i++)
				{
					SiteViewDataBean beanobj=new SiteViewDataBean(
							jsarr.getJSONObject(i).getString("SiteCode"),
							jsarr.getJSONObject(i).getString("Region"),
							//	jsarr.getJSONObject(i).getString("CreationDate"),
							jsarr.getJSONObject(i).getString("Startdate"),
							jsarr.getJSONObject(i).getString("Address"),
							jsarr.getJSONObject(i).getString("Lattitude"),
							jsarr.getJSONObject(i).getString("Longitude"),
							jsarr.getJSONObject(i).getString("SiteName"),
							this);

					siteListContainerDiv.add(beanobj);
					sitebeanList.add(beanobj);

				}
				addDetailsTab(paramsiteCode2);

			}
		}catch(Exception e)
		{
			e.printStackTrace();
			UI.getCurrent().navigate("siteview");
		}

	}

	private void selectSiteViewNode(String paramsiteCode2)
	{
		for(int i = 0; i < sitebeanList.size(); i++) {
			sitebeanList.get(i).selectSiteViewBeanNode(paramsiteCode2);
		}

	}

	public void setSelectedsitecode(String sitecode2) {
		siteCode = sitecode2;

	}

	public void addMapMarkerClickHandler(String caption) 
	{
		try
		{
			//System.out.println("SitemapmarkerClicked::"+caption);
			selectedRowChangeHandler(caption);
			selectSiteViewNode(caption);
			selectedSitecode=caption;
			addDetailsTab(caption);

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	private void populateMapview(String sitelistresponse2) 
	{
		//	mapviewDiv.removeAll();
		mapView.populateSiteDetails1(sitelistresponse2);
		mapView.setSelectedSite(mapsitecode1);
		mapviewDiv.setVisible(true);
		mapviewDiv1.setVisible(true);
		mapviewDiv.setVisible(true);
		mapviewDiv1.setVisible(true);

	}
	private void refreshGoogleMapview(String sitelistresponse2) 
	{
		try
		{
			//System.out.println("map refreshed");
			mapviewDiv.setVisible(true);
			mapviewDiv1.setVisible(true);
			//System.out.println("searchedSiteLatitude= "+searchedSiteLatitude+" searchedSiteLongitude= "+searchedSiteLongitude);
			if (searchedSiteLatitude != null && searchedSiteLongitude != null
					&& searchedSiteLatitude.trim().length() > 0 && searchedSiteLongitude.trim().length() > 0) {
				lat = searchedSiteLatitude;
				longi = searchedSiteLongitude;
			} else {
				lat = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
				longi = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			}
	
			googleMapComponent.clearMapMarker();
			if (googleMapComponent == null) {
				googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 1,"sitelistmap");
				mapviewDiv.removeAll();
				mapviewDiv.add(googleMapComponent);

				googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onMapMarkerClick(String eventData) {
						//System.out.println("Event Data -->>" + eventData);
						try {
							JSONObject eventDataJSON = new JSONObject(eventData);
							String uniqueId = eventDataJSON.getString("event.detail");
							selectedRowChangeHandler(uniqueId);
							selectSiteViewNode(uniqueId);
							selectedSitecode = uniqueId;
							addDetailsTab(uniqueId);
							
							setLatLongForGmapMarker(uniqueId);
							
							generatePropertyAttributes(uniqueId);
							setPropertyTypeForGmapMarker(uniqueId);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
			}
			googleMapComponent.setVisible(true);
			generateMarkerData(sitelistresponse2);
			googleMapComponent.populateMarker(markerJSONArray);
			//	System.out.println("mapsitecode1="+mapsitecode1);
			//googleMapComponent.openInfoWindow(/*mapsitecode1*/selectedSitecode);
			googleMapComponent.openInfoWindow2(/*mapsitecode1*/selectedSitecode);
		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	public void populateSiteDetailRow2(String searchCriteria) 
	{

		try
		{
			String res="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCHSITE");
			//	url=url+"?searchText="+searchCriteria;
			url=url+"?searchText="+CommonUtils.getEncodedText(searchCriteria).replaceAll("\\+","%20");
			//System.out.println("url="+url);
			res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" site_search_res="+res);
			if(searchCriteria.contains("Lattitude:"))
				searchedSiteLatitude=searchCriteria.substring(searchCriteria.indexOf("Lattitude:")+10, searchCriteria.indexOf("Longitude:")-1);
			if(searchCriteria.contains("Longitude:"))
				searchedSiteLongitude=searchCriteria.substring(searchCriteria.indexOf("Longitude:")+10, searchCriteria.length());
						

			sortedListResponse=res;
			sitelistresponse=res;

			sitebeanList.clear();
			siteListContainerDiv.removeAll();
			col2HeaderDiv1.removeAll();

			if(sitelistresponse==null || sitelistresponse.trim().length()==0 || sitelistresponse.equals("[]"))
			{
				col2Lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL3");
				col2Lbl1.setText("");
				col2Lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL4");
				col2Lbl2.setText(" ");
				col2HeaderDiv1.removeAll();
				//	col2HeaderDiv1.add(lbl1);
				//col2HeaderDiv1.add(col2Lbl1,col2Lbl2);

				noRecordDiv.setVisible(true);
				noRecordDiv2.setVisible(true);
				siteListContainerDiv.setVisible(false);
				//	detailsTabHolder.setVisible(false);
				//	col2ValueDiv.removeAll();
				recordcontainerDiv.setVisible(false);
				sitebeanList.clear();
				noRecordDiv.removeAll();
				noRecordDiv2.removeAll();
				Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_REC_LBL");
				noRecordDiv.add(lbl);

				//	col2HeaderDiv1.removeAll();
			}

			caret_down1.getStyle().set("color", "#8080809e");
			caret_down2.getStyle().set("color", "#8080809e");
			caret_down3.getStyle().set("color", "#8080809e");
			caret_up1.getStyle().set("color", "#8080809e");
			caret_up2.getStyle().set("color", "#8080809e");
			caret_up3.getStyle().set("color", "#8080809e");	


			sortedjsArr=new JSONArray();
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);			
				System.out.println("jsonArray.length():::"+jsonArray.length());
				if(jsonArray.length()>0 && !sitelistresponse.equals("[]"))
				{
					siteListContainerDiv.setVisible(true);
					recordcontainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					detailsTabHolder.setVisible(true);
					parentTabs.setSelectedTab(detailsTab);
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("CreationDate");
								str2 = jo2.getString("CreationDate");
								date1=CommonUtils.convertStringToLocalDate(str1,"dd-MMM-yyyy");
								date2=CommonUtils.convertStringToLocalDate(str2,"dd-MMM-yyyy");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							//return str1.compareTo(str2);
							return date1.compareTo(date2);
						}
					});

					Collections.reverse(jsonsList);//descending order
					sortedjsArr=new JSONArray(jsonsList);
					//	System.out.println("Sorted JSON Array with dates: " + sortedjsArr);

				}

				if(sortedjsArr!=null && sortedjsArr.length()>0)
				{
					if(sortedjsArr.length()>=50 && searchCriteria.length()<=0 ) {//if more than 50 records & no search string provided
						siteListContainerDiv.removeAll();
						sitebeanList.clear();
						
						for(int i=0;i<sortedjsArr.length();i++)
						{
							SiteViewDataBean beanobj=new SiteViewDataBean(
									sortedjsArr.getJSONObject(i).getString("SiteCode"),
									sortedjsArr.getJSONObject(i).getString("Region"),
									sortedjsArr.getJSONObject(i).getString("CreationDate"),
									sortedjsArr.getJSONObject(i).getString("Address"),
									sortedjsArr.getJSONObject(i).getString("Lattitude"),
									sortedjsArr.getJSONObject(i).getString("Longitude"),
									sortedjsArr.getJSONObject(i).getString("SiteName"),
									this);


						//	col1ValueDiv.add(beanobj);
						siteListContainerDiv.add(beanobj);
						sitebeanList.add(beanobj);
						if(i==0 /*&& paramsiteCode==null*/)
						{
							selectedSitecode=sortedjsArr.getJSONObject(i).getString("SiteCode");
							addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
							siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
							beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
							mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");



								String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
								col2HeaderDiv1.removeAll();
								sendSiteName(sitename,siteCode);
								
								selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
								selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
							}

						}
						
						Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
						morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
						
						System.out.println("searchcriteria2.length()=="+searchcriteria2.length());
						if(sortedjsArr.length()>=50 && searchcriteria2.length()<=0) {
							siteListContainerDiv.add(morerecordLbl);
							morerecordLbl.setVisible(true);
						}
					} else if((sortedjsArr.length()<50 && searchCriteria.length()<=0)|| searchCriteria.length()>0) {
						//if less than 50 records & no search string provided || if search string is provided
						
						siteListContainerDiv.removeAll();
						sitebeanList.clear();
						
						for(int i=0;i<sortedjsArr.length();i++)
						{
							SiteViewDataBean beanobj=new SiteViewDataBean(
									sortedjsArr.getJSONObject(i).getString("SiteCode"),
									sortedjsArr.getJSONObject(i).getString("Region"),
									sortedjsArr.getJSONObject(i).getString("CreationDate"),
									sortedjsArr.getJSONObject(i).getString("Address"),
									sortedjsArr.getJSONObject(i).getString("Lattitude"),
									sortedjsArr.getJSONObject(i).getString("Longitude"),
									sortedjsArr.getJSONObject(i).getString("SiteName"),
									this);


							siteListContainerDiv.add(beanobj);
							sitebeanList.add(beanobj);
							if(i==0)
							{
								selectedSitecode=sortedjsArr.getJSONObject(i).getString("SiteCode");
								addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
								siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
								beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
								mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");



								String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
								col2HeaderDiv1.removeAll();
								sendSiteName(sitename,siteCode);
								
								selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
								selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
							}


						}
						
					}else {	
						
					}	
					
				}

				if(isMapVisible==true)
				{
					//populateMapview(sitelistresponse);
					refreshGoogleMapview(sitelistresponse);
					siteListContainerDiv.setVisible(false);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
				}
			}
			//}			


		}catch(Exception e)
		{
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			//	parentTabs.setEnabled(false);
			}
		
			
		}


	}

	public void sendSiteName(String siteName, String sitecode2) 
	{
		col2Lbl1Str=siteName;
		col2Lbl2Str=sitecode2;

		col2Lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL1");
		col2Lbl1.setText(col2Lbl1Str+" (");
		col2Lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL2");
		col2Lbl2.setText(" Site Id# "+col2Lbl2Str+")");

		col2HeaderDiv1.removeAll();
		col2HeaderDiv1.add(col2Lbl1,col2Lbl2);

	}
	protected void sortBySiteCode(String orderBy) 
	{
		try
		{
			String res="";

			/*String url = ApplicationConfiguration.getServiceEndpoint("SEARCHSITE");
			url=url+"?searchText="+searchCriteria;
			res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());*/
			res=sortedListResponse;
			sitelistresponse=res;

			sitebeanList.clear();
			siteListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("SiteCode").toUpperCase();
								str2 = jo2.getString("SiteCode").toUpperCase();
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}


					//	System.out.println("Sorted JSON Array with dates: " + sortedjsArr);

				}

			}
			if(sortedjsArr.length()>0)
			{
				if(sortedjsArr.length()>=50) {
					
					sitebeanList.clear();
					siteListContainerDiv.removeAll();

					
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


					//	col1ValueDiv.add(beanobj);
					siteListContainerDiv.add(beanobj);
					sitebeanList.add(beanobj);
					if(i==0 && paramsiteCode==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
						siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
						beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
						mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
						selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						siteListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
					
				}else if(sortedjsArr.length()<50) {
					
					sitebeanList.clear();
					siteListContainerDiv.removeAll();

					
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


						//	col1ValueDiv.add(beanobj);
						siteListContainerDiv.add(beanobj);
						sitebeanList.add(beanobj);
						if(i==0 && paramsiteCode==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
							siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
							beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
							mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
							selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
				}else {
					
				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(sitelistresponse);
				refreshGoogleMapview(sitelistresponse);
				siteListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}



		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}
	protected void sortByRegion(String orderBy) 
	{
		try
		{
			String res="";

			/*String url = ApplicationConfiguration.getServiceEndpoint("SEARCHSITE");
			url=url+"?searchText="+searchCriteria;
			res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());*/
			res=sortedListResponse;
			sitelistresponse=res;

			sitebeanList.clear();
			siteListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("Region").toUpperCase();
								str2 = jo2.getString("Region").toUpperCase();
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				sitebeanList.clear();
				siteListContainerDiv.removeAll();
				
				if(sortedjsArr.length()>=50) {
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


					siteListContainerDiv.add(beanobj);
					sitebeanList.add(beanobj);
					if(i==0 && paramsiteCode==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
						siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
						beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
						mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
						selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						siteListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
					
				}else if(sortedjsArr.length()<50){
					sitebeanList.clear();
					siteListContainerDiv.removeAll();
					
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


						siteListContainerDiv.add(beanobj);
						sitebeanList.add(beanobj);
						if(i==0 && paramsiteCode==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
							siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
							beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
							mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
							selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
				}else {
					
				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(sitelistresponse);
				refreshGoogleMapview(sitelistresponse);
				siteListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}	

	protected void sortByCreationDate(String orderBy) {
		try
		{
			String res="";

			/*	String url = ApplicationConfiguration.getServiceEndpoint("SEARCHSITE");
			url=url+"?searchText="+searchCriteria;
			res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());*/
			res=sortedListResponse;
			sitelistresponse=res;

			sitebeanList.clear();
			siteListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("CreationDate");
								str2 = jo2.getString("CreationDate");
								date1=CommonUtils.convertStringToLocalDate(str1,"dd-MMM-yyyy");
								date2=CommonUtils.convertStringToLocalDate(str2,"dd-MMM-yyyy");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							//return str1.compareTo(str2);
							return date1.compareTo(date2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				
				if(sortedjsArr.length()>=50) {
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


					siteListContainerDiv.add(beanobj);
					sitebeanList.add(beanobj);
					if(i==0 && paramsiteCode==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
						siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
						beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
						mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
						selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
					Label morerecordLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MORE_RECORD_LBL");
					morerecordLbl.setText("Top 50 results being shown. Please refine your search if desired record is not found..");
					
					if(sortedjsArr.length()>=50) {
						siteListContainerDiv.add(morerecordLbl);
						morerecordLbl.setVisible(true);
					}
					
				}else if(sortedjsArr.length()<50) {
					
					sitebeanList.clear();
					siteListContainerDiv.removeAll();

					
					for(int i=0;i<sortedjsArr.length();i++)
					{
						SiteViewDataBean beanobj=new SiteViewDataBean(
								sortedjsArr.getJSONObject(i).getString("SiteCode"),
								sortedjsArr.getJSONObject(i).getString("Region"),
								sortedjsArr.getJSONObject(i).getString("CreationDate"),
								sortedjsArr.getJSONObject(i).getString("Address"),
								sortedjsArr.getJSONObject(i).getString("Lattitude"),
								sortedjsArr.getJSONObject(i).getString("Longitude"),
								sortedjsArr.getJSONObject(i).getString("SiteName"),
								this);


						siteListContainerDiv.add(beanobj);
						sitebeanList.add(beanobj);
						if(i==0 && paramsiteCode==null)
						{
							parentTabs.setSelectedTab(detailsTab);
							addDetailsTab(sortedjsArr.getJSONObject(i).getString("SiteCode"));
							siteCode=sortedjsArr.getJSONObject(i).getString("SiteCode");
							beanobj.getEachRowDiv().addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
							mapsitecode1=sortedjsArr.getJSONObject(i).getString("SiteCode");
							selectedSitecode=siteCode;

							String sitename=sortedjsArr.getJSONObject(i).getString("SiteName");
							sendSiteName(sitename,siteCode);
							
							selectedSiteLatitude=sortedjsArr.getJSONObject(i).getString("Lattitude");
							selectedSiteLongitude=sortedjsArr.getJSONObject(i).getString("Longitude");
						}

					}
					
				}else {
					
				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(sitelistresponse);
				refreshGoogleMapview(sitelistresponse);
				siteListContainerDiv.setVisible(false);
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	private void generateMarkerData(String sitelistresponse2) {
		try {
			String contentString2="";
			
			//String property_attr=generatePropertyAttributes(siteCode);
			
		//	JSONObject property_attr_json=generatePropertyAttributes(siteCode);
		
			generatePropertyAttributes(siteCode);

			//System.out.println("sitelistresponse2:::"+sitelistresponse2);
			markerJSONArray = new JSONArray();

			if(sitelistresponse2 == null || sitelistresponse2.trim().length()==0) {
				sitelistresponse2 = "[]";
			}
			JSONArray js=new JSONArray(sitelistresponse2);
			if(js.length()>0)
			{
				for(int i=0;i<js.length();i++ )
				{
					String lat=js.getJSONObject(i).getString("Lattitude");
					String longi=js.getJSONObject(i).getString("Longitude");
					if(lat.trim().length()>0 && longi.trim().length()>0)
					{
						JSONObject jsobj=new JSONObject();
						jsobj.put("title", js.getJSONObject(i).get("SiteCode"));
						jsobj.put("uniqueId", js.getJSONObject(i).get("SiteCode"));
						jsobj.put("lat", js.getJSONObject(i).get("Lattitude"));
						jsobj.put("lng", js.getJSONObject(i).get("Longitude"));
						jsobj.put("Region", js.getJSONObject(i).get("Region"));
						jsobj.put("Address", js.getJSONObject(i).get("Address"));
						
						
						String propertyAttr=js.getJSONObject(i).getString("PropertyAttributes");
						JSONObject json=new JSONObject(propertyAttr);
						String otherInfo= json.getString("OtherInfo");
			//			generatePropertyAttributes(js.getJSONObject(i).getString("SiteCode"));
						JSONObject property_attr_json2=new JSONObject(otherInfo);
						
//						if(property_attr_json2.getString("SiteCode").equalsIgnoreCase(js.getJSONObject(i).getString("SiteCode"))) {
//							jsobj.put("PropertyType",property_attr_json2.getString("PropertyType"));
//						}else {
//							jsobj.put("PropertyType","");
//						}
						
						if(property_attr_json2.has("Property Type") && property_attr_json2.getString("Property Type").length()>0 ) {
							jsobj.put("PropertyType",property_attr_json2.getString("Property Type"));
						}else {
							jsobj.put("PropertyType","");
						}
						

						markerJSONArray.put(jsobj);

					}
				}

				 //System.out.println("markerJSONArray="+markerJSONArray);
				
				
			//	JSONArray markerJSONArray2=new JSONArray(markerJsonArray3);
				
			//	markerJSONArray=markerJSONArray2;

				for(int i = 0; i < markerJSONArray.length(); i++) {
					JSONObject eachItem = markerJSONArray.getJSONObject(i);
					//	String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + "</em><br><div style=\"width:200px\"><small>" + eachItem.getString("SiteAddress") + "</small></div></body></html>"; 

					//	String contentString = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng") + "</small></div></body></html>";
					//	String contentString1 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng")+ "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+"</span><br><em>" + eachItem.getString("Address")+ "</small></div></body></html>";

					//String contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + 
					//		"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>"; 

					if(eachItem.getString("PropertyType")!=null && eachItem.getString("PropertyType").trim().length()>0) {
						contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + "<br><em>Property Type: " + eachItem.getString("PropertyType")+
								"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>";
								
					}else {
						contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + 
								"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>";
								
					}
					
							 

					eachItem.put("contentString", contentString2);


				}
			}	
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public void populateGMap(boolean mapViewBtnClicked2) {
		
		try {
			//System.out.println("this.mapViewBtnClicked On Dlg Close=" + mapViewBtnClicked);
			if (this.mapViewBtnClicked == true) {

				mapviewDiv.setVisible(true);
				mapviewDiv1.setVisible(true);
				isMapVisible = true;
				searchListDiv.setVisible(true);
				searchListRowDiv2.setVisible(true);

				siteListContainerDiv.setVisible(false);
				headerDiv.setVisible(false);

				headerLbl1.removeAll();
				headerLbl1.setText("Site List-Map View");
//			mapViewChk.setEnabled(false);
				// applyRadiusField.clear();
//			radiusUnitCombo.clear();
				noRecordDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				// googleMapComponent.clearMapMarker();
				// if (googleMapComponent == null) {
				//System.out.println("populateGMap lat= "+lat+" long= "+longi);
				googleMapComponent = new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 1,
						"sitelistmap");
				mapviewDiv.removeAll();
				mapviewDiv.add(googleMapComponent);

				googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onMapMarkerClick(String eventData) {
						// System.out.println("Event Data -->>" + eventData);
						try {
							JSONObject eventDataJSON = new JSONObject(eventData);
							String uniqueId = eventDataJSON.getString("event.detail");
							selectedRowChangeHandler(uniqueId);
							selectSiteViewNode(uniqueId);
							selectedSitecode = uniqueId;
							addDetailsTab(uniqueId);
							
							setLatLongForGmapMarker(uniqueId);
							
							generatePropertyAttributes(uniqueId);
							setPropertyTypeForGmapMarker(uniqueId);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				// }
				googleMapComponent.setVisible(true);
				googleMapComponent.clearMapMarker();
				generateMarkerData(sitelistresponse);
				googleMapComponent.populateMarker(markerJSONArray);
				// googleMapComponent.openInfoWindow(/*selectedSitecode*/);
				// System.out.println("SELECTED_ID="+selectedSitecode);
				googleMapComponent.openInfoWindow2(/* "ep.ID539873BB" */selectedSitecode);

				if (applyRadiusField.getValue().toString().length() > 0 && radiusUnitCombo.getValue() != null) {
					String radius = calcRadius(applyRadiusField.getValue(), radiusUnitCombo.getValue());
					googleMapComponent.applyGeoFence(Double.parseDouble(radius));
					mapViewChk.setValue(true);
					mapViewChk.setEnabled(true);
				}

				// System.out.println("generateMarkerData(sitelistresponse):::"+sitelistresponse);
				// System.out.println("populateMarker(markerJSONArray):::"+markerJSONArray);
			//	System.out.println("populateGMap(selectedSitecode):::" + selectedSitecode);
			}
			if(this.mapViewBtnClicked==false) {
				mapViewBtnClicked=false;
				
				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				searchListDiv.setVisible(true);
				isMapVisible=false;
				//	siteListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Site List");
				mapViewChk.setEnabled(false);
				mapViewChk.setValue(false);
				applyRadiusField.clear();
				radiusUnitCombo.clear();
				
				if(sitelistresponse!=null || !sitelistresponse.equalsIgnoreCase("[]"))
				{
					siteListContainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
				}
				if(sitelistresponse==null || sitelistresponse.equalsIgnoreCase("[]"))
				{
					siteListContainerDiv.setVisible(false);
					noRecordDiv.setVisible(true);
					noRecordDiv2.setVisible(true);
					//	col2HeaderDiv1.removeAll();
				}
				
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void setSelectedLatLong(String latitude, String longitude) {
		this.selectedSiteLatitude=latitude;
		this.selectedSiteLongitude=longitude;
		
	}
	
	protected void setLatLongForGmapMarker(String uniqueId) throws JSONException {
		try {
	//		System.out.println("setLatLongForGmapMarker(markerJSONArray)::::"+markerJSONArray);
			if (markerJSONArray != null || markerJSONArray.length() > 0) {
				JSONArray jsarr=new JSONArray(markerJSONArray.toString());
				for(int i=0;i<jsarr.length();i++) {
					if(uniqueId.equalsIgnoreCase(jsarr.getJSONObject(i).getString("uniqueId"))) {
						this.selectedSiteLatitude=jsarr.getJSONObject(i).getString("lat");
						this.selectedSiteLongitude=jsarr.getJSONObject(i).getString("lng");
					}
					
				}
			}
			
			//System.out.println("setLatLongForGmapMarker(markerJSONArray this.selectedSiteLongitude)::::"+this.selectedSiteLatitude+"  "+this.selectedSiteLongitude );
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void generatePropertyAttributes(String siteCode2) {
		String otherInfo="",propertyType="",sitecode="";
		JSONObject propJson=null;
		try {
			propJson = new JSONObject();
			
			String base_URL=ApplicationConfiguration.getServiceEndpoint("GETSITEPROPERTYATTRIBUTES");
			base_URL = base_URL + "?SiteCode=" + URLEncoder.encode(siteCode2);
			String res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			
	//		System.out.println("Attributes::::: " + res);
			JSONObject json = new JSONObject(res);
			otherInfo= json.getString("OtherInfo");
			sitecode=json.getString("SiteCode");
		//	System.out.println("PropertyAttributes:::"+otherInfo);
			
			JSONObject json_otherinfo = new JSONObject();
			if (otherInfo.startsWith("{")) {
				json_otherinfo = new JSONObject(otherInfo);
				
			}
			
			if (json_otherinfo.length() > 0) {
				
				for (int i = 0; i < json_otherinfo.length(); i++) {
					if(json_otherinfo.has("Property Type")) {
						propertyType=json_otherinfo.getString("Property Type");
						propJson.put("SiteCode", sitecode);
						propJson.put("PropertyType", propertyType);
					}else {
						propJson.put("SiteCode", sitecode);
						propJson.put("PropertyType","");
					}
					
				}
			}
			property_attr_json=propJson;
			
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
		
		
	}
	
	protected void setPropertyTypeForGmapMarker(String uniqueId) throws JSONException {
		try {
			String contentString2="";
			JSONArray markerJSONArray2=new JSONArray();
			
			if (markerJSONArray != null || markerJSONArray.length() > 0) {
				JSONArray js=new JSONArray(markerJSONArray.toString());
				for(int i=0;i<js.length();i++) {
			
					
					JSONObject jsobj=new JSONObject();
					jsobj.put("title", js.getJSONObject(i).get("uniqueId"));
					jsobj.put("uniqueId", js.getJSONObject(i).get("uniqueId"));
					jsobj.put("lat", js.getJSONObject(i).get("lat"));
					jsobj.put("lng", js.getJSONObject(i).get("lng"));
					jsobj.put("Region", js.getJSONObject(i).get("Region"));
					jsobj.put("Address", js.getJSONObject(i).get("Address"));
					
					if(property_attr_json.getString("SiteCode").equalsIgnoreCase(js.getJSONObject(i).getString("uniqueId"))) {
						jsobj.put("PropertyType",property_attr_json.getString("PropertyType"));
					}else {
					//	jsobj.put("PropertyType","");
						jsobj.put("PropertyType",js.getJSONObject(i).get("PropertyType"));
					}

					markerJSONArray2.put(jsobj);

					
				}
//				System.out.println("setPropertyTypeForGmapMarker(markerJSONArray2)::::"+markerJSONArray2);
				
				
				for(int i = 0; i < markerJSONArray2.length(); i++) {
					JSONObject eachItem = markerJSONArray2.getJSONObject(i);
					
					if(eachItem.getString("PropertyType")!=null && eachItem.getString("PropertyType").trim().length()>0) {
						contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + "<br><em>Property Type: " + eachItem.getString("PropertyType")+
								"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>";
								
					}else {
						contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + 
								"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>";
								
					}
							
							 

					eachItem.put("contentString", contentString2);


				}
				
				if(googleMapComponent!=null) {
					googleMapComponent.populateMarker(markerJSONArray2);
					googleMapComponent.openInfoWindow2(uniqueId);
				}
				
			}
			
			
			
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



}
