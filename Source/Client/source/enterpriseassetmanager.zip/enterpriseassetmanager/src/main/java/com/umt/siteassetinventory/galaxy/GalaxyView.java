package com.umt.siteassetinventory.galaxy;




import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.MainView;
import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.galaxy.GalaxyViewBean;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.Route;

@Route(value = "galaxyview", layout = MainView.class)
@CssImport("./styles/galaxy-view.css")
public class GalaxyView extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "GALAXY_VIEW";
//	private ComboBox<String> siteIdCombo;
	private DatePicker startDateField,endDateField;
	private TextField filterRecords;
	private ArrayList<String> siteList=new ArrayList<String>();
	private Button retrievebtn,approvebtn,rejectbtn,resetbtn,clearbtn ;
	private Div  containerDiv,containerBodyDiv,btnRowDiv,footerLayout,prevBtndiv,nextBtndiv;
	private Checkbox selectAllRow;
	private List<GalaxyViewBean> beanList=new ArrayList<GalaxyViewBean>();
	private int remainder,pg,numberofpg;
	private int limit = 10;
	private int clickCnt = 0;
	private int totalCnt;
	private int remainingCnt,quotientCnt;
	private Label pagenumberLbl,totalcountLbl;
	private TextField siteIdField;
	private VerticalLayout filterMenuLayout,filterMenuContainerLayout;
	private boolean toggleClick = true;
	private Div fieldrowDiv2;
	private int pageNo = 0, pageSize = 10;
	private boolean retrieveBtnClicked=false;
	private ComboBox<String> statusField;
	private List<String> statusList=new ArrayList<String>();
	private HashMap<String,String> statustypemap=new HashMap<String,String>();
	
	public GalaxyView() {
		
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Galaxy View");
	//	Div mainlayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD,"MAIN_LAYOUT"); 
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		pageSize = Integer.parseInt(ApplicationConfiguration.getConfigurationValue("GALAXY_VIEW_RECORD_COUNT_LIMIT"));
		
		Div searchDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_DIV"); 
		Label searchLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SEARCH_LBL");
		Div fieldrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROW_DIV");
		
		fieldrowDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "FIELD_ROW_DIV2");
		fieldrowDiv2.getStyle().set("padding-left", "20px");
		filterRecords = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_RECORD_FIELD");
		filterRecords.setSuffixComponent(VaadinIcon.SEARCH.create());
		filterRecords.setValueChangeMode(ValueChangeMode.EAGER);
		Label filterRecordsLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILTER_RECORDS_LBL");
		Div filtericonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_ICON_DIV");
		com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon filterIcon = FontAwesome.Solid.FILTER.create();
		filterIcon.addClassName(SCREENCD+"_FILTERICON");
		filtericonDiv.add(filterIcon);
		filtericonDiv.setTitle("Additional Filter");
		fieldrowDiv2.add(filterRecordsLbl,filterRecords,filtericonDiv);
		
		//siteIdCombo = UIFieldFactory.createComboBox(siteList, false, SCREENCD, "SITEID_COMBO");
		siteIdField=UIFieldFactory.createTextField("", false, SCREENCD,"SITEID_COMBO");
		startDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "START_DATE_FIELD");
		endDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "END_DATE_FIELD");
		statusField=UIFieldFactory.createComboBox(statusList, false,SCREENCD,"STATUS_FIELD");
		retrievebtn = UIFieldFactory.createButton(SCREENCD, "RETRIEVE_BTN");
		clearbtn = UIFieldFactory.createButton(SCREENCD, "CLEAR_BTN");
	//	fieldrowDiv.add(siteIdField,startDateField,endDateField,retrievebtn);
		searchDiv.add(/*searchLbl,fieldrowDiv,*/fieldrowDiv2);
	
		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		footerLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_LAYOUT");
		
		btnRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_ROW_DIV");
		approvebtn = UIFieldFactory.createButton(SCREENCD, "APPROVE_BTN");
		rejectbtn = UIFieldFactory.createButton(SCREENCD, "REJECT_BTN");
		resetbtn = UIFieldFactory.createButton(SCREENCD, "RESET_BTN");
		btnRowDiv.add(approvebtn,rejectbtn,/*resetbtn,*/footerLayout);
		btnRowDiv.setVisible(false);
		
		
		
		
		filterMenuLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "MENU_LAYOUT");
		filterMenuContainerLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "CONTAINER_LAYOUT");
		Div menuDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUHEADER_DIV");
		Div menuFieldDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUFIELD_DIV");
		Div menuBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENUBTN_DIV");
		Label menuLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MENU_LBL");
		menuDiv.add(menuLbl);
		
		filterMenuContainerLayout.add(searchDiv,containerDiv,btnRowDiv);
		
		menuFieldDiv.add(siteIdField,statusField,startDateField,endDateField);
		menuBtnDiv.add(retrievebtn,clearbtn);
		filterMenuLayout.add(menuDiv,menuFieldDiv,menuBtnDiv);
		
		add(filterMenuLayout,filterMenuContainerLayout);
	//	mainlayoutDiv.add(i_objMenuLayout,i_objContainerLayout);
	//	add(mainlayoutDiv);
		
		
//		add(searchDiv,containerDiv,btnRowDiv);
		
		
		
		initalizeToggleMenu();
		populateStatusLists();
		
		filtericonDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				if (toggleClick) {
					filterMenuLayout.addClassName("SIDEBAR_MENU_COLLAPSED");
					filterMenuContainerLayout.removeClassName("CONTAINER_LAYOUT_COLLAPSED");
					filterMenuContainerLayout.addClassName("EXPAND_CONTAINER_LAYOUT");
					
					filterMenuLayout.removeClassName("SIDEBAR_MENU_EXPAND");
		//			mainlayoutDiv.getStyle().set("padding-left","22px");
					fieldrowDiv2.getStyle().set("padding-left", "22px");
					containerDiv.getStyle().set("margin-left", "22px");
					
				
					toggleClick = false;
				} else {
					filterMenuLayout.removeClassName("SIDEBAR_MENU_COLLAPSED");
					filterMenuContainerLayout.removeClassName("EXPAND_CONTAINER_LAYOUT");
					filterMenuContainerLayout.addClassName("CONTAINER_LAYOUT_COLLAPSED");
					
					filterMenuLayout.addClassName("SIDEBAR_MENU_EXPAND");
					fieldrowDiv2.getStyle().set("padding-left", "0px");
					containerDiv.getStyle().set("margin-left", "0px");
					
			
					toggleClick = true;
				}
			}
		});
		
		retrievebtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				pageNo=0;
				pageSize=10;
				retrieveBtnClicked=true;
				retrieveRecords(0,10,true);
			}
		});
		

		approvebtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				approveRecords();
			}
		});

		rejectbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				rejectRecords();
			}
		});


		clearbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				clearRecords();
			}
		});
		
	//	createPagination();
							
				
		filterRecords.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
					private static final long serialVersionUID = 1L;
					
					@Override
					public void valueChanged(ValueChangeEvent<?> event) {
						
						beanList.stream().filter(new Predicate<GalaxyViewBean>() {

							@Override
							public boolean test(GalaxyViewBean t) {
								String searchTxt = filterRecords.getValue();
								if (searchTxt == null || searchTxt.trim().length() == 0) {
									 t.getRowDiv().setVisible(true);
									
									return true;
								}
								if (StringUtils.containsIgnoreCase(t.getActivityId(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSiteId(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSiteName(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSiteType(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getCircle(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSubmittedBy(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSubmitDate(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getReading(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getPreviousReadingDate(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getSubmeterNo(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getCurrentSubmterReading(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getPrevSubmeterReading(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getConsumption(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getErrorFlag(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getErrorDesc(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getCurrentRemark(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getRejectReason(), searchTxt)
										|| StringUtils.containsIgnoreCase(t.getStatus(), searchTxt)) {
								
									t.getRowDiv().setVisible(true);
									return true;
								}
								t.getRowDiv().setVisible(false);
								return false;
							}
						
						}).collect(Collectors.toList());
						

					}
				});
		retrieveRecords(0,10,false);
		

	}
	private void filterRecords() {
		beanList.stream().filter(new Predicate<GalaxyViewBean>() {

			@Override
			public boolean test(GalaxyViewBean t) {
				String searchTxt = filterRecords.getValue();
				if (searchTxt == null || searchTxt.trim().length() == 0) {
					 t.getRowDiv().setVisible(true);
					
					return true;
				}
				if (StringUtils.containsIgnoreCase(t.getActivityId(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSiteId(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSiteName(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSiteType(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getCircle(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSubmittedBy(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSubmitDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getReading(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getPreviousReadingDate(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getSubmeterNo(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getCurrentSubmterReading(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getPrevSubmeterReading(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getConsumption(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getErrorFlag(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getErrorDesc(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getCurrentRemark(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getRejectReason(), searchTxt)
						|| StringUtils.containsIgnoreCase(t.getStatus(), searchTxt)) {
				
					t.getRowDiv().setVisible(true);
					return true;
				}
				t.getRowDiv().setVisible(false);
				return false;
			}
		
		}).collect(Collectors.toList());
	}

	private void initalizeToggleMenu() {
		
		if (toggleClick) {
			filterMenuLayout.addClassName("SIDEBAR_MENU_COLLAPSED");
			filterMenuContainerLayout.removeClassName("CONTAINER_LAYOUT_COLLAPSED");
			filterMenuContainerLayout.addClassName("EXPAND_CONTAINER_LAYOUT");
			
			filterMenuLayout.removeClassName("SIDEBAR_MENU_EXPAND");
		//	mainlayoutDiv.getStyle().set("padding-left","22px");
			fieldrowDiv2.getStyle().set("padding-left", "22px");
			containerDiv.getStyle().set("margin-left", "22px");
			
		
			toggleClick = false;
		} else {
			filterMenuLayout.removeClassName("SIDEBAR_MENU_COLLAPSED");
			filterMenuContainerLayout.removeClassName("EXPAND_CONTAINER_LAYOUT");
			filterMenuContainerLayout.addClassName("CONTAINER_LAYOUT_COLLAPSED");
			
			filterMenuLayout.addClassName("SIDEBAR_MENU_EXPAND");
			fieldrowDiv2.getStyle().set("padding-left", "0px");
			containerDiv.getStyle().set("margin-left", "0px");
		//	menuFieldDiv.getStyle().set("padding-left", "20px !important;");
			
	
			toggleClick = true;
		}
		
	}

	protected void clearRecords() {
		siteIdField.clear();
		startDateField.clear();
		endDateField.clear();
		statusField.clear();
		beanList.clear();
		containerBodyDiv.removeAll();
		pageNo=0;
		pageSize=10;
	//	footerLayout.setVisible(false);
		retrieveBtnClicked=false;
		btnRowDiv.setVisible(false);
		retrieveRecords(0,10,false);
	}



	protected void rejectRecords() {
		//String activityid = "",recordid="";
		JSONArray jsarr=new JSONArray();
		Iterator<GalaxyViewBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			GalaxyViewBean eachRow = listIterator.next();
			if (eachRow.isChecked() && eachRow.getActivityId()!=null && eachRow.status().equals("0")) {
				//activityid+= eachRow.getActivityId()+",";
				//recordid+=eachRow.getRecordId()+",";
				JSONObject jsobj=new JSONObject();
				try {
					jsobj.put("RecordId",eachRow.getRecordId());
					jsobj.put("ActivityId",eachRow.getActivityId());
					jsobj.put("RejectReason",eachRow.rejectReason());
					jsarr.put(jsobj);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				
			}
		}
	
	//	System.out.println("jsarr::::"+jsarr);
	//	System.out.println("jsarr.len::::"+jsarr.length());
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'To be processed' to reject",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("recordJson",jsarr);
	//		System.out.println("recordJson::::"+jsarr);
			
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("REJECTGALAXYRECORDS");
			RestServiceHandler.deleteJSON_DELETE(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"REJECT_DATA",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
	}




	protected void approveRecords() {
	//	String activityid = "",recordid="";
		JSONArray jsarr=new JSONArray();
		Iterator<GalaxyViewBean> listIterator = beanList.iterator();
		while (listIterator.hasNext()) {
			GalaxyViewBean eachRow = listIterator.next();
			if (eachRow.isChecked() && eachRow.getActivityId()!=null && eachRow.status().equals("0")) {
				//activityid+= eachRow.getActivityId()+",";
				//recordid+=eachRow.getRecordId()+",";
				JSONObject jsobj=new JSONObject();
				try {
					jsobj.put("RecordId",eachRow.getRecordId());
					jsobj.put("ActivityId",eachRow.getActivityId());
					jsarr.put(jsobj);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				
			}
		}
	
//		System.out.println("jsarr::::"+jsarr);
//		System.out.println("jsarr.len::::"+jsarr.length());
		if (jsarr==null || jsarr.length()<=0) {
			SiteAssetInventoryUIFramework.getFramework().showMessage("Please select one or more row(s) with status 'To be processed' to approve",ApplicationConstants.DialogTypes.INFO);	
			return;
		}
		
		try {
			Form formData = new Form();
			formData.add("recordJson",jsarr);
			
		//	System.out.println("recordJson::::"+jsarr);
	
			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("APPROVEGALAXYRECORDS");
			RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"APPROVE_DATA",ApplicationConstants.DialogTypes.INFO);	
			retrieveRecords(0,10,false);
			retrieveBtnClicked=false;
			pageNo = 0;
			pageSize = 10;
			filterRecords();
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
	}



/*	protected void clearFields() {
		//siteIdCombo.clear();
		siteIdField.clear();
		startDateField.clear();
		endDateField.clear();
		filterRecords.clear();
		footerLayout.setVisible(false);
		pageNo=0;
		pageSize=10;
	}*/

	protected void retrieveRecords(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		Label activityIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ACTIVITY_ID_LBL");
		Label circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		Label siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		Label siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		Label siteTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITETYPE_LBL");
		Label submittedByLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMITTEDBY_LBL");
		Label submitDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMITDATELBL");
		Label readingDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "READINGDATE_LBL");
		Label previousreadingDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PREV_READING_DATE_LBL");
		Label submeterNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMETERNO_LBL");
		Label currentSubmeterReadingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CURRENT_SUBMETER_READING_LBL");
		Label prevoiusSubmeterReadingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PREV_SUBMETER_READING_LBL");
		Label consumptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMPTION_LBL");
		Label picUrlLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PIC_URL_LBL");
		Label currentRemarkLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CURRENT_REMARK_LBL");
		Label statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		Label rejectReasonLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REJECT_REASON_LBL");
		Label errorFlagLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ERROR_FLAG_LBL");
		Label errorDescLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ERROR_DESC_LBL");
		Label selectLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SELECT_LBL");
	//	selectAllRow = UIFieldFactory.createCheckbox(false, false, SCREENCD, "SELECT_ALL_ROW");
		
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		containerBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_BODY_DIV");
		
		headerDiv.removeAll();
		headerDiv.add(activityIdLbl,siteIdLbl,siteNameLbl,siteTypeLbl,circleLbl,submittedByLbl,submitDateLbl,readingDateLbl,previousreadingDateLbl,
				submeterNoLbl,currentSubmeterReadingLbl,prevoiusSubmeterReadingLbl,consumptionLbl,picUrlLbl,errorFlagLbl,errorDescLbl,
				currentRemarkLbl,rejectReasonLbl,statusLbl,selectLbl);
		
		containerBodyDiv.removeAll();
		containerDiv.removeAll();
		
		containerDiv.add(headerDiv,containerBodyDiv);
		beanList.clear();
		
		try {
			String resp=getGalaxyRecords(pageNo2,pageSize2,retrieveBtnClicked);
			
//			System.out.println("resp="+resp);
			
			if(resp!=null && !resp.equals("null") && !resp.equals("{}") && !resp.equals("[]")) {
				JSONArray jsarr=new JSONArray(resp);
				if(jsarr.length()>0) {
					for(int i=0;i<jsarr.length();i++) {
						GalaxyViewBean beanobj=new GalaxyViewBean(
								jsarr.getJSONObject(i).getString("Recordid"),
								jsarr.getJSONObject(i).getString("Activityid"),
								jsarr.getJSONObject(i).getString("Siteid"),
								jsarr.getJSONObject(i).getString("Sitename"),
								jsarr.getJSONObject(i).getString("Sitetype"),
								jsarr.getJSONObject(i).getString("Circle"),
								jsarr.getJSONObject(i).getString("Submittedby"),
								jsarr.getJSONObject(i).getString("Submitdate"),
								jsarr.getJSONObject(i).getString("Readingdate"),
								jsarr.getJSONObject(i).getString("Previousreadingdate"),
								jsarr.getJSONObject(i).getString("Submeterno"),
								jsarr.getJSONObject(i).getString("Currentsubmeterreading"),
								jsarr.getJSONObject(i).getString("Previoussubmeterreading"),
								jsarr.getJSONObject(i).getString("Currentsubmeterpic"),
								jsarr.getJSONObject(i).getString("Errorflag"),
								jsarr.getJSONObject(i).getString("Errordescription"),
								jsarr.getJSONObject(i).getString("Currentremark"),
								jsarr.getJSONObject(i).getString("Rejectreason"),
								jsarr.getJSONObject(i).getString("Status"),
								this);
						
						containerBodyDiv.add(beanobj);
						beanList.add(beanobj);
						
						
					}
					footerLayout.setVisible(true);
				/*	int pageNumber = pageNo2+1;
					pagenumberLbl.setText(pageNumber+"");
					
					if(jsarr.length()>=pageSize2) {
						nextBtndiv.setEnabled(true);
					}
					else {
						nextBtndiv.setEnabled(false);
					}
					if(pageNo2==0) {
						prevBtndiv.setEnabled(false);
					}*/
			//		displayNextRecords();
					btnRowDiv.setVisible(true);
					
				}
			}else if(resp==null || resp.equals("null") || resp.equals("{}") || resp.equals("[]")) {
				beanList.clear();
				containerBodyDiv.removeAll();
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				containerBodyDiv.add(norecLbl);
			//	pagenumberLbl.setText(1+"");
			//	footerLayout.setVisible(false);
			/*	int pageNumber = pageNo2+1;
				pagenumberLbl.setText(pageNumber+"");
				
				nextBtndiv.setEnabled(false);*/
				btnRowDiv.setVisible(false);
			}else {}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		//	SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
		
		
	}

	private String getGalaxyRecords(int pageNo2, int pageSize2, boolean retrieveBtnClicked) {
		String resp="",status="";
		try {
			String startdate="",sitecode="";
			String enddate="";
		//	System.out.println("date="+startDateField.getValue());
			
			if(startDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(startDateField.getValue());
				startdate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(endDateField.getValue()!=null) {
				String date=CommonUtils.convertLocalDateToString(endDateField.getValue());
				enddate=CommonUtils.convertDateToDifferentFormat(date, "dd/MM/yyyy", "dd-MM-yyyy");
			}
			
			if(siteIdField.getValue().toString().length()>0) {
				sitecode=URLEncoder.encode(siteIdField.getValue().toString().trim());
			}
			
			if(statusField.getValue()!=null) {
				if(statustypemap.containsKey(statusField.getValue())) {
					status=statustypemap.get(statusField.getValue());
				}else {
					status="";
				}
				
			}
			
		//	System.out.println("startdate="+startdate);
		
			String url = ApplicationConfiguration.getServiceEndpoint("GETGALAXYRECORDS");
		//	url=url+"?SiteId="+sitecode+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+""+"&PageSize="+"";
			if(retrieveBtnClicked) {
				//url=url+"?SiteId="+sitecode+"&StartDate="+startdate+"&EndDate="+enddate+"&PageNum="+pageNo2+"&PageSize="+pageSize2;
				url=url+"?SiteId="+sitecode+"&StartDate="+startdate+"&EndDate="+enddate+"&Status="+status+"&PageNum="+""+"&PageSize="+"";
			}else {
				//url=url+"?SiteId="+""+"&StartDate="+""+"&EndDate="+""+"&PageNum="+pageNo2+"&PageSize="+pageSize2;
				url=url+"?SiteId="+""+"&StartDate="+""+"&EndDate="+""+"&Status="+""+"&PageNum="+""+"&PageSize="+"";
			}
			
			System.out.println("url==="+url);
			resp = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
	//		System.out.println("resp==="+resp);
			
		}catch(Exception e) {
			resp=null;
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}
		return resp;
	}

	
	private void createPagination() {
		
		Label pageLabel=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_LBL");
		pageLabel.setText("Page");
		Div pgNumberdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PG_NO_DIV");
		pagenumberLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_NO_LBL");
		pgNumberdiv.add(pagenumberLbl);
		totalcountLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"TOTAL_COUNT_LBL");
		
		Div arrowdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ARROW_DIV");
		nextBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "NEXT_BTN_DIV");
		Icon rightarrowIcon = VaadinIcon.ANGLE_RIGHT.create();
		nextBtndiv.add(rightarrowIcon);
		prevBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PREV_BTN_DIV");
		Icon leftarrowIcon = VaadinIcon.ANGLE_LEFT.create();
		prevBtndiv.add(leftarrowIcon);
		arrowdiv.add(prevBtndiv,nextBtndiv);
		
		leftarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		rightarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		prevBtndiv.setEnabled(false);
		nextBtndiv.setEnabled(false);
		
		footerLayout.add(pageLabel,pgNumberdiv,totalcountLbl,arrowdiv);
		
		
		nextBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
			/*	clickCnt++;
				prevBtndiv.setEnabled(true);
				containerBodyDiv.removeAll();
				
				retrieveRecords();
				
				int clickcount=clickCnt+1;
				int startNo = (clickCnt*limit)+1;
				int endNo = (clickCnt+1)*limit;
				if(endNo>totalCnt)
				{
					pagenumberLbl.setText(clickcount+"");
					totalcountLbl.setText(" of "+ pg);
				}
				else
				{
					pagenumberLbl.setText(clickcount+"");
					totalcountLbl.setText(" of "+ pg);
				}
				if(remainingCnt!=0 && clickCnt==quotientCnt) {
					nextBtndiv.setEnabled(false);
				}*/
				prevBtndiv.setEnabled(true);
				pageNo=pageNo+1;
				retrieveRecords(pageNo,10,retrieveBtnClicked);
			}
		});
		
		prevBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
			/*	clickCnt--;
				nextBtndiv.setEnabled(true);
				if(clickCnt==0) {
					prevBtndiv.setEnabled(false);
				}
				containerBodyDiv.removeAll();
				
				retrieveRecords();
				
				int clickcount=clickCnt+1;
				int startNo = (clickCnt*limit)+1;
				int endNo = (clickCnt+1)*limit;
		
				pagenumberLbl.setText(clickcount+"");
				totalcountLbl.setText(" of "+ pg);
				*/
				nextBtndiv.setEnabled(true);
			//	pageNo--;
				pageNo=pageNo-1;
				retrieveRecords(pageNo,10,retrieveBtnClicked);
				if(pageNo==0) {
					prevBtndiv.setEnabled(false);
				}

			}
		});
	

		
	}
	
	private void displayNextRecords() {
		containerBodyDiv.removeAll();
				
		int totalCnt = beanList.size();
		remainder=totalCnt%limit;
		numberofpg=totalCnt/limit;
		remainingCnt = totalCnt%limit;
		quotientCnt = totalCnt/limit;
	
		
		
		if(beanList.size()!=0) {
			if(clickCnt!=quotientCnt) {
				for(int i=clickCnt*limit;i<(clickCnt+1)*limit;i++) {
					containerBodyDiv.add(beanList.get(i));
					}
			}
			else {
				for(int j = quotientCnt*limit;j<(quotientCnt*limit)+remainingCnt;j++) {
					containerBodyDiv.add(beanList.get(j));
					
				}
			}
		}

		
		if(remainder==0)
		{
			pg=numberofpg;
		}
		if(remainder!=0)
		{
			pg=numberofpg+1;
		}
		
		int startNo = (clickCnt*limit)+1;
		int endNo = (clickCnt+1)*limit;
		if(endNo>totalCnt) {
			pagenumberLbl.setText(startNo+"");
			totalcountLbl.setText(" of "+ pg);
		}
		else {
			pagenumberLbl.setText(startNo+"");
			totalcountLbl.setText(" of "+ pg);
		}
		
		if(totalCnt>limit) {
			nextBtndiv.setEnabled(true);
		}
		else {
			nextBtndiv.setEnabled(false);
		}
		

	}
	
	private void populateStatusLists() {
		
		statustypemap.clear();
		statusList.clear();
		int count=0;
		String str[] = {"To be processed","Approved","Rejected"};
	
				
		for (int i = 0; i < str.length; i++) {
			statustypemap.put(str[i],String.valueOf(count));
			statusList.add(str[i]);
			count++;
		}
		statusField.setItems(statusList);
		
	}


}
