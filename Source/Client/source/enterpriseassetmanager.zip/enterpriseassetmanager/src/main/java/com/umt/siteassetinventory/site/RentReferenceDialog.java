package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap.CustomGoogleMapMarkerClickListener;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/rent-reference-dialog-styles.css")
public class RentReferenceDialog extends Dialog {
	
	private static final long serialVersionUID = 1L;
	private static String SCREENCD = "SITE_RENT_REFERENCE_DIALOG";
	private Div mainLayout;
	private Div titleBar;
	private Div buttonBar;
	private Div bodyLayout;
	private Div tableBodyDiv;
	private CustomGoogleMap googleMapComponent;
	private JSONArray markerJSONArray = new JSONArray();
	private String lat,longi;
	private Div mapviewDiv;
	private String selectedSitecode;
	private ComboBox<String> radiusUnitCombo;
	private NumberField applyRadiusField;
	private String siteCode;
	private String sitelistresponse;
	private String selectedSiteLatitude,selectedSiteLongitude;
	
	private List<RentReferenceDialogBean> rentrefenceDlgbeanList=new ArrayList<RentReferenceDialogBean>();
	
	public RentReferenceDialog(String siteCode, String selectedSiteLatitude, String selectedSiteLongitude) {
		this.siteCode=siteCode;
		this.selectedSiteLatitude=selectedSiteLatitude;
		this.selectedSiteLongitude=selectedSiteLongitude;
		
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label dlgTitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE");
		Image closeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_ICON");
		titleBar.add(dlgTitleLbl,closeIcon);
		
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		Button saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		Button cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(/*saveBtn,*/cancelBtn);
		
		bodyLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_LAYOUT");
		
		
		closeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Image> event) {
				close();

			}
		});
		
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				//saveClicked();
			}
		});

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		
		populateBodyLayout();
		
		mainLayout.add(titleBar, bodyLayout, buttonBar);
		add(mainLayout);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();
	}

	private void populateBodyLayout() {
		
		Div row1Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW1_DIV");
		applyRadiusField= UIFieldFactory.createNumberField(true, SCREENCD,"RADIUS_FIELD");
		Button submitBtn = UIFieldFactory.createButton(SCREENCD, "SUBMIT_BTN");
		
		
		ArrayList<String> unitList=new ArrayList<String>();
		unitList.clear();
		String units[] = {"M","KM","Miles"};
		for (int i = 0; i < units.length; i++) {
			unitList.add(units[i]);
		}
		radiusUnitCombo = UIFieldFactory.createComboBox(unitList, true, SCREENCD, "UNIT_COMBO_FIELD");
	//	radiusUnitCombo.setPlaceholder("units");
		row1Div.add(applyRadiusField,radiusUnitCombo,submitBtn);
		
		Div mapviewWrapperDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_WRAPPER_DIV");
		mapviewDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "RENT_MAP_DIV");
		mapviewWrapperDiv.add(mapviewDiv);
		
		Div tableDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_DIV");
		
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER");
		tableBodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_BODY");
		//retrieveSiteAgreementList();
		populateGoogleMap();
		
		Label sitecode = UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_LBL");
		Label sitename = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		Label siteaddr = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEADDR_LBL");
		Label rentAmt = UIHtmlFieldFactory.createLabel(SCREENCD, "RENTAMT_LBL");
		Label rentFreq = UIHtmlFieldFactory.createLabel(SCREENCD, "RENTFREQ_LBL");
		Label siteType = UIHtmlFieldFactory.createLabel(SCREENCD, "SITETYPE_LBL");
		Label indoor = UIHtmlFieldFactory.createLabel(SCREENCD, "INDOOR_LBL");
		Label plotArea = UIHtmlFieldFactory.createLabel(SCREENCD, "PLOTAREA_LBL");
		
		tableHeaderDiv.add(sitecode,sitename,siteaddr,rentAmt,rentFreq,siteType,indoor,plotArea);
		
		tableDiv.add(tableHeaderDiv,tableBodyDiv);
		
		Div row2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row2Div.add(mapviewWrapperDiv,tableDiv);
		
		
		bodyLayout.add(row1Div,row2Div);
		
		submitBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				submitValues();
			}
		});
		
	}

	

	protected void submitValues() {
		if(applyRadiusField.getValue() == null) {
			applyRadiusField.setInvalid(true);
			applyRadiusField.setErrorMessage("Please enter radius");
			return;
		}else if(radiusUnitCombo.getValue()== null || radiusUnitCombo.getValue().length()==0 ) {
			radiusUnitCombo.setInvalid(true);
			radiusUnitCombo.setErrorMessage("Please select unit");
			return;
		}else {
			radiusUnitCombo.setInvalid(false);
			radiusUnitCombo.setErrorMessage("");
			retrieveNearbySiteAgreementList();
		//	populateGoogleMap();
		}
		
	}

	private void retrieveNearbySiteAgreementList() {
		try {
			// System.out.println("siteCode:::"+siteCode);
			String url = ApplicationConfiguration.getServiceEndpoint("GET_NEARBY_SITEAGREEMENTS");
			url = url + "?SiteCode=" + URLEncoder.encode(siteCode) + "&Distance=" + applyRadiusField.getValue()
					+ "&Unit=" + radiusUnitCombo.getValue();
			String response = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			System.out.println("retrieveNearbySiteAgreementList() ::::::: " + response);

			tableBodyDiv.removeAll();
			rentrefenceDlgbeanList.clear();

			JSONArray jsarr = new JSONArray(response);
			JSONArray maparr = new JSONArray();
			if (jsarr.length() > 0) {

				for (int i = 0; i < jsarr.length(); i++) {

				//	JSONObject agreementDetails = new JSONObject(jsarr.getJSONObject(i).getString("AgreementDetails"));
					
					String details=jsarr.getJSONObject(i).getString("AgreementDetails");
					
					
					if(details.length()>0 && !details.equals("{}")) {
						JSONObject agreementDetails=new JSONObject(details);
						if (agreementDetails.length() > 0) {
							RentReferenceDialogBean beanobj = new RentReferenceDialogBean(
									jsarr.getJSONObject(i).getString("SiteCode"),
									jsarr.getJSONObject(i).getString("SiteDetails"),
									jsarr.getJSONObject(i).getString("AgreementDetails"),this);

						selectedSitecode = jsarr.getJSONObject(0).getString("SiteCode");
						tableBodyDiv.add(beanobj);
						rentrefenceDlgbeanList.add(beanobj);

							JSONObject mapjsonobj = new JSONObject(jsarr.getJSONObject(i).getString("SiteDetails"));
							maparr.put(mapjsonobj);
						}
					}

				}
				sitelistresponse = maparr.toString();
				populateGoogleMap();
			}else {
				tableBodyDiv.removeAll();
				rentrefenceDlgbeanList.clear();
				//mapviewDiv.removeAll();
				if(googleMapComponent!=null) {
			//		googleMapComponent.setVisible(false);
					googleMapComponent.clearMapMarker();
				}
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NO_RECORD", ApplicationConstants.DialogTypes.INFO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private void populateGoogleMap() {
		try
		{
			System.out.println("ratesitelistresponse::::"+sitelistresponse);
			 
		//	lat=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
		//	longi=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			System.out.println("selectedSiteLatitude::::"+selectedSiteLatitude+" selectedSiteLongitude:::"+selectedSiteLongitude);
			
			
			if (selectedSiteLatitude != null && selectedSiteLongitude != null
					&& selectedSiteLatitude.trim().length() > 0 && selectedSiteLongitude.trim().length() > 0) {
				lat = selectedSiteLatitude;
				longi = selectedSiteLongitude;
			} else {
				lat = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
				longi = ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			}
			
			
			System.out.println("googleMapComponent:::"+googleMapComponent);
			
			if (googleMapComponent == null) {
				System.out.println("if null");
				googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi,1,"rentagreementmap");
				googleMapComponent.clearMapMarker();
				mapviewDiv.removeAll();
				mapviewDiv.add(googleMapComponent);

				googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onMapMarkerClick(String eventData) {
						System.out.println("Event Data -->>" + eventData);
						try {
							JSONObject eventDataJSON = new JSONObject(eventData);
							String uniqueId = eventDataJSON.getString("event.detail");
							selectRentRefenceDlgNode(uniqueId);
							
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				
			}
//			mapviewDiv.removeAll();
//			mapviewDiv.add(googleMapComponent);
			selectRentRefenceDlgNode(selectedSitecode);
			googleMapComponent.setVisible(true);
			googleMapComponent.clearMapMarker();
			generateMarkerData2(sitelistresponse);
			googleMapComponent.populateMarker(markerJSONArray);
			googleMapComponent.openInfoWindow2(selectedSitecode);
			
			googleMapComponent.applyGeoFence(calcRadius(applyRadiusField.getValue().toString(), radiusUnitCombo.getValue()));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	protected double calcRadius(String rad, String unit) {

		String val="";
		switch(unit)
		{
		case "M":
			val=rad;
			break;
		case "KM":
			double d=Double.parseDouble(rad)*1000;
			val=String.valueOf(d);
			break;
		case "Miles":
			double v=Double.parseDouble(rad)*1609.34;
			val=String.valueOf(v);
			break;
		}
		return Double.parseDouble(val);
	}
	
	private void generateMarkerData2(String sitelistresponse2) {
		try {

			markerJSONArray = new JSONArray();
			 System.out.println("markerJSONArray2:::::="+markerJSONArray);

			if(sitelistresponse2 == null) {
				sitelistresponse2 = "[]";
			}
			JSONArray js=new JSONArray(sitelistresponse2);
			if(js.length()>0)
			{
				for(int i=0;i<js.length();i++ )
				{
					String lat=js.getJSONObject(i).getString("Lattitude");
					String longi=js.getJSONObject(i).getString("Longitude");
					if(lat.trim().length()>0 && longi.trim().length()>0)
					{
						JSONObject jsobj=new JSONObject();
						jsobj.put("title", js.getJSONObject(i).get("SiteCode"));
						jsobj.put("uniqueId", js.getJSONObject(i).get("SiteCode"));
						jsobj.put("lat", js.getJSONObject(i).get("Lattitude"));
						jsobj.put("lng", js.getJSONObject(i).get("Longitude"));
						jsobj.put("Region", js.getJSONObject(i).get("Region"));
						jsobj.put("Address", js.getJSONObject(i).get("Address"));

						markerJSONArray.put(jsobj);

					}
				}

				 System.out.println("markerJSONArray2="+markerJSONArray);

				for(int i = 0; i < markerJSONArray.length(); i++) {
					JSONObject eachItem = markerJSONArray.getJSONObject(i);
					//	String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + "</em><br><div style=\"width:200px\"><small>" + eachItem.getString("SiteAddress") + "</small></div></body></html>"; 

					//	String contentString = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng") + "</small></div></body></html>";
					//	String contentString1 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng")+ "</span><br><em style=\"font-size:12px\">" + eachItem.getString("Region")+"</span><br><em>" + eachItem.getString("Address")+ "</small></div></body></html>";

					String contentString2 = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>" + eachItem.getString("Region") + 
							"</em><br><div style=\"width:200px; max-height:40px; overflow-wrap:break-word;\"><small>" +  eachItem.getString("Address") + "</small></div></body></html>"; 

					eachItem.put("contentString", contentString2);


				}
			}	
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void selectRentRefenceDlgNode(String siteCode2)
	{
	//	System.out.println("siteCode2::"+siteCode2);
		for(int i = 0; i < rentrefenceDlgbeanList.size(); i++) {
			rentrefenceDlgbeanList.get(i).selectRentRefenceDlgBeanNode(siteCode2);
		}

	}
	public List<RentReferenceDialogBean> getRentReferenceDialogList()
	{
		return rentrefenceDlgbeanList;
	}

	public void selectedRowChangeHandler(String siteCode2) {
		
		try {
			selectedSitecode=siteCode2;
			googleMapComponent.openInfoWindow2(siteCode2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void deselectOtherRows(RentReferenceDialogBean child) 
	{
		for (int i = 0; i < rentrefenceDlgbeanList.size(); i++) 
		{
			rentrefenceDlgbeanList.get(i).deselectEachBeanRow(child);
		}

	}



}
