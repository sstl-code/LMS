package com.umt.siteassetinventory.configuration;

import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/equipment_attribute_master-styles.css")
public class EquipmentAttributeMasterDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENT_ATTRIBUTE_MASTER_DATA_BEAN";
	//private long attributeId, equipmentTypeId;
	private String attributeId, equipmentType, attributeName, dataType, defaultValue, flov, mandatory;
	private EquipmentAttributeMaster parent;
	private Div eachrowDiv;
	//private Button editBtn, deactivateBtn;
	private Div editDiv;
	//private boolean selected = false;


	public EquipmentAttributeMasterDataBean(String attributeId, String attributeName, String equipmentType, String dataType, 
			String mandatory, String defaultValue, String flov, Map<Long, String> activeEquipmentTypeMap, Map<Long, String> passiveEquipmentTypeMap, EquipmentAttributeMaster attributeMaster) {
		this.attributeId = attributeId;
		this.attributeName = attributeName;
		this.equipmentType = equipmentType;
		this.dataType = dataType;
		this.mandatory = mandatory;
		this.defaultValue = defaultValue;
		this.flov = flov;
		this.parent = attributeMaster;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");
		Div eachdataDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV6");


		Label attributeIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL1");
		attributeIdVal.setText(attributeId+"");
		eachdataDiv1.add(attributeIdVal);
		
		Label attributeNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL2");
		attributeNameVal.setText(attributeName);
		eachdataDiv2.add(attributeNameVal);
		
		Label equipmentTypeIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL3");
		equipmentTypeIdVal.setText(equipmentType);
		eachdataDiv3.add(equipmentTypeIdVal);
		
		Label dataTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL4");
		dataTypeVal.setText(dataType);
		eachdataDiv4.add(dataTypeVal);

		Label mandatoryVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL5");
		mandatoryVal.setText(mandatory);
		eachdataDiv5.add(mandatoryVal);
		
		if(CommonUtils.getAttributeDataType(dataType) == 7) {
			JSONObject multiSelectValueJSON;
			try {
				multiSelectValueJSON = new JSONObject(defaultValue);
				JSONArray valArray = new JSONArray(multiSelectValueJSON.getString("MultiSelectDefaultValue"));
				StringBuilder multiSelectListHtmlView = new StringBuilder();
				multiSelectListHtmlView.append("<ul style = \"margin-block-start: 0px; margin-block-end: 0px; padding-inline-start: 16px;\">");
				for(int i = 0; i < valArray.length(); i++) {
					multiSelectListHtmlView.append("<li>" + valArray.getString(i) + "</li>");
				}
				multiSelectListHtmlView.append("</ul>");
				Span attri_value = UIHtmlFieldFactory.createSpan("", SCREENCD, "VAL6");
				attri_value.getElement().setProperty("innerHTML", multiSelectListHtmlView.toString());
				eachdataDiv6.add(attri_value);
			} catch (JSONException e) {
				e.printStackTrace();
				Label defaultValueVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL6");
				defaultValueVal.setText(defaultValue);
				eachdataDiv6.add(defaultValueVal);
			}
		} else {
			Label defaultValueVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL6");
			defaultValueVal.setText(defaultValue);
			eachdataDiv6.add(defaultValueVal);
		}
		

		editDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EDIT_DIV");
		Image editIcon = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
		//Icon editIcon = VaadinIcon.PENCIL.create();
		editDiv.add(editIcon);
		//editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
//		deactivateBtn = UIFieldFactory.createButton(SCREENCD, "DEACTIVATE_BTN");

		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3,eachdataDiv4,eachdataDiv5,eachdataDiv6,editDiv);
		add(eachrowDiv);

		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//selectedRowChangeHandler();
			}
		});
		
		editDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> arg0) {
				editDialog(false, activeEquipmentTypeMap, passiveEquipmentTypeMap);
			}
		});
	}
	
	private void editDialog(boolean addOrEdit, Map<Long, String> activeEquipmentTypeMap, Map<Long, String> passiveEquipmentTypeMap)
	{
		//System.out.println("Working");
		try
		{
		boolean mandatoryBoolean = false;
		if (mandatory.equalsIgnoreCase("Yes")) {
			mandatoryBoolean = true;
		} 
		AddOrEditEquipmentAttribute editEquipmentAttribute = new AddOrEditEquipmentAttribute(parent, this, 
				Long.parseLong(attributeId), attributeName, equipmentType, dataType, mandatoryBoolean, 
				defaultValue, flov, activeEquipmentTypeMap, passiveEquipmentTypeMap);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	private void selectedRowChangeHandler()
//	{
//		selectDeselect(selected);
//		parent.selectedRowChangeHandler(this);
//	}
	
//	protected void selectDeselect(boolean selectedOrDeselected)
//	{
//		if (selectedOrDeselected) {
//			selected = false;
//			eachrowDiv.removeClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//		else
//		{
//			selected = true;
//			eachrowDiv.addClassName("CONFIG_BASE_DATA_BEAN_DATA_ROW_SELECTED");
//		}
//	}

	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	public String getAttributeId() {
		return attributeId;
	}
	
	public String getAttributeName() {
		return attributeName;
	}

	public String getEquipmentType() {
		return equipmentType;
	}

	public String getDataType() {
		return dataType;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public String getMandatory() {
		return mandatory;
	}

	public String getFlov() {
		return flov;
	}
	

//	public boolean isSelected() {
//		return selected;
//	}

}
