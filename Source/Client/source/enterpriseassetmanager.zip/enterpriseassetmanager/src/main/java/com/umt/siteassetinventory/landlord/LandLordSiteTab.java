package com.umt.siteassetinventory.landlord;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;


@CssImport("./styles/landlord_site-styles.css")
public class LandLordSiteTab extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_SITE_TAB";
	private String landlordId;
	private Div infoDiv;
	//private Button addSiteBtn;

	public LandLordSiteTab(String landlordId) {
		this.landlordId = landlordId;
		/*btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		addSiteBtn = UIFieldFactory.createButton(SCREENCD, "ADD_SITE_BTN");*/

		infoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "INFO_DIV");
		if(landlordId != null) {
			populateSiteDetails(landlordId);
		}

		add(infoDiv);
	}
	
	public void populateSiteDetails(String landlordId){
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETLANDLORDSITEDETAILS");
		base_URL = base_URL + "?LandlordId=" + landlordId;

		try {
			String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
					/*"[{\"SiteCode\":\"ep.ID812940DC\",\"SiteName\":\"Test_Site_DC\",\"SiteAddress\":\"Flasrt 2A,Hatara\"},{\"SiteCode\":\"2\",\"SiteName\":"
					+ "\"new site2 \",\"SiteAddress\":\"Psr Atoom Thp III Street 2012 A-B, Jawa Timur\"},{\"SiteCode\":\"ep.ID778860AC\",\"SiteName\":\"North Frontier Site\""
					+ ",\"SiteAddress\":\"Flasrt 2A,Hatara ue cuuieucfefuicuif\"}]";*/
			//System.out.println("landlordSite: " + outputResponse);
			JSONArray jsonArray = new JSONArray(outputResponse);
			if (jsonArray.length()==0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NO_RECORD", ApplicationConstants.DialogTypes.INFO);
			}
			for(int i = 0; i<jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				LandLordSiteBean bean = new LandLordSiteBean(jsonObject.getString("Sitecode"),jsonObject.getString("SiteName"),
						jsonObject.getString("Address"));
				infoDiv.add(bean);
				//System.out.println(jsonObject);
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
