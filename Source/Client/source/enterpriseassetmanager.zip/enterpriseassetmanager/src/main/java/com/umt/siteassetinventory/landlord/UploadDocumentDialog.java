package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIUploadComponent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.FinishedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.vaadin.flow.server.InputStreamFactory;
import com.vaadin.flow.server.StreamResource;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;


public class UploadDocumentDialog extends Dialog 
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "UPLOAD_DOCUMENT_DLG";
	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private Button saveBtn,cancelBtn;
	private String base64EncodedFileContent = "";
	private TextField docnameTextfield;

	private UIUploadComponent uploadDocDiv;
	private String fileFormat="";

	private String fileName="";
	private boolean fileuploadStatus=false;
	private Div previewImgDiv;
	private Image fileImage;

	public UploadDocumentDialog(String fileType, String base64EncodedFileContent3) 
	{
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");


		previewImgDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "PRIVIEW_IMG_DIV");
		populatePreviewImg(base64EncodedFileContent3);
		//	Image defaultImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
		//	previewImgDiv.add(defaultImage);
		previewImgDiv.setVisible(false);

		saveBtn=UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		saveBtn.setEnabled(false);
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);

		//docnameTextfield = UIFieldFactory.createTextField("", false, SCREENCD, "DOC_NAME_FIELD");
		//docnameTextfield.setPlaceholder("Enter Document Name");

		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDocDiv = new UIUploadComponent(fileBuffer, false);
		Upload uploadDoc = uploadDocDiv.getUpload();

		if(fileType.equalsIgnoreCase("Image"))
		{
			uploadDoc.setAcceptedFileTypes(".png", ".jpg", ".jpeg", ".gif");
			TitleLbl.setText("Upload "+fileType);
			previewImgDiv.setVisible(true);
		}
		if(fileType.equalsIgnoreCase("Text"))
		{
			uploadDoc.setAcceptedFileTypes(".txt");
		}
		if(fileType.equalsIgnoreCase("Custom"))
		{
			uploadDoc.setAcceptedFileTypes(".xlsx",".xls", ".csv", ".pdf", ".doc", ".docx", ".txt", ".png", ".jpg", ".jpeg", ".gif");
		}
		int maxfilesize=Integer.parseInt(ApplicationConfiguration.getConfigurationValue("SET_MAX_FILE_UPLOAD_SIZE_IN_KB"));
		uploadDoc.setMaxFileSize(maxfilesize*1000);

		uploadDoc.addFinishedListener(new ComponentEventListener<FinishedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FinishedEvent event) {

				try
				{
					fileName=event.getFileName();
					String fileExtension = event.getFileName().substring(event.getFileName().lastIndexOf(".") + 1);
					if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("txt") || fileExtension.equalsIgnoreCase("doc")
							|| fileExtension.equalsIgnoreCase("docx") || fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx")
							|| fileExtension.equalsIgnoreCase("csv")) 
					{
						byte[] bytes = IOUtils.toByteArray(fileBuffer.getInputStream());
						base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
						if(fileExtension.equalsIgnoreCase("pdf"))
						{
							fileFormat = "application/pdf";
						}
						if(fileExtension.equalsIgnoreCase("txt"))
						{
							fileFormat = "text/plain";
						}
						if(fileExtension.equalsIgnoreCase("doc"))
						{
							fileFormat = "application/msword";
						}
						if(fileExtension.equalsIgnoreCase("docx"))
						{
							fileFormat = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						}
						if (fileExtension.equalsIgnoreCase("xls")) {
							fileFormat = "application/vnd.ms-excel";
						} 
						if (fileExtension.equalsIgnoreCase("xlsx")) {
							fileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
						}
						saveBtn.setEnabled(true);

					}
					if (fileExtension.equalsIgnoreCase("jpg")  || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
					{
						BufferedImage image = ImageIO.read(fileBuffer.getInputStream());
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						ImageIO.write(image, fileExtension, outputStream);
						base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
						populatePreviewImg(base64EncodedFileContent);
						fileFormat = "image/"+fileExtension.toLowerCase();
						saveBtn.setEnabled(true);
					}

				} catch (Exception ex) {
					ex.printStackTrace();
					base64EncodedFileContent = "";
					fileuploadStatus=false;
				}

			}
		});

		uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FailedEvent event) {

				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getReason().getMessage(), DialogTypes.ERROR);
				event.getUpload().interruptUpload();
				saveBtn.setEnabled(false);
				fileuploadStatus=false;
			}
		});

		uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(FileRejectedEvent event) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(event.getErrorMessage(), DialogTypes.ERROR);
				saveBtn.setEnabled(false);
				fileuploadStatus=false;
			}
		});

		VerticalLayout bodyLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "BODY_LAYOUT");
		bodyLayout.add(previewImgDiv,uploadDocDiv);

		mainLayoutDiv.add(titleBar,bodyLayout,buttonBar);

		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveBtnClicked();

			}
		});


	}

	protected void populatePreviewImg(String base64EncodedFileContent2) 
	{
		try {
			if(base64EncodedFileContent2 != null && base64EncodedFileContent2.trim().length() > 0) 
			{
				byte[] imageFileContent = Base64.getDecoder().decode(base64EncodedFileContent2);
				StreamResource fileStreamResource = new StreamResource("FILE_IMAGE", new InputStreamFactory() {
					private static final long serialVersionUID = 1L;

					@Override
					public InputStream createInputStream() {

						return new ByteArrayInputStream(imageFileContent);
					}
				});

				fileImage = new Image(fileStreamResource, "NEW_FILE_IMAGE1");
				fileImage.addClassName(SCREENCD + "_NEW_FILE_IMAGE1");
			}
			else {
				fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
		}
		Image removeIcon= UIHtmlFieldFactory.createImage(SCREENCD,"REMOVE_IMAGE_ICON");
		previewImgDiv.removeAll();
		previewImgDiv.add(fileImage, removeIcon);

		removeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Image> event) {
				previewImgDiv.removeAll();
				fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "DEFAULT_IMAGE");
				previewImgDiv.add(fileImage, removeIcon);
				removeIcon.setEnabled(false);
				base64EncodedFileContent = "";
				saveBtn.setEnabled(true);
			}
		});

	}

	public String getFileName() {
		//		System.out.println("filename2: "+fileName);
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileContent() {
		//		System.out.println("base64EncodedFileContent: "+base64EncodedFileContent);
		return base64EncodedFileContent;
	}

	protected void saveBtnClicked()
	{
		fileuploadStatus=true;
		close();
	}

	public boolean isGetDocUploadStatus() {
		return fileuploadStatus;
	}


}
