package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/landlord-view.css")
public class LandlordViewDataBean extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_VIEW_BEAN";
	private String landlordId,name, region,RegistrationDate;
	private LandlordView parent;
	private Div eachrowDiv;
	private LandlordViewDataBean child;
	
	public LandlordViewDataBean(String landlordId,String name,String region, String RegistrationDate,String panNo, LandlordView landlordView) 
	{
		this.landlordId=landlordId;
		this.name=name;
		this.region=region;
		this.RegistrationDate=RegistrationDate;
		this.parent=landlordView;
		
		child=this;
		eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
		
		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		
		
		Label landlordidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDID_LBL");
		landlordidLbl.setText(landlordId);
		eachdataDiv1.add(landlordidLbl);
		
		Label nameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NAME_LBL");
		nameLbl.setText(name);
		eachdataDiv2.add(nameLbl);
		
		Label regionnoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGION_LBL");
		regionnoLbl.setText(region);
		eachdataDiv3.add(regionnoLbl);
		
	/*	Label regionnoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGION_LBL");
		regionnoLbl.setText(landlordId);
		eachdataDiv3.add(regionnoLbl);*/
		
		/*Label RegistrationDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGISTRATION_LBL");
		RegistrationDateLbl.setText(RegistrationDate);
		eachdataDiv4.add(RegistrationDateLbl);*/
		
		Label RegistrationDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGISTRATION_LBL");
		RegistrationDateLbl.setText(panNo);
		eachdataDiv4.add(RegistrationDateLbl);
		
		
		eachrowDiv.add(/*eachdataDiv1,*/eachdataDiv2,/*eachdataDiv3*/eachdataDiv1,eachdataDiv4);
		add(eachrowDiv);
		
		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				eachRowSelectionChangeHandler(landlordId,event.getSource());
				parent.addDetailsLandlord(landlordId);
			}
		});
	}

	protected void eachRowSelectionChangeHandler(String landlordId2, Div selectedRow) 
	{
		parent.selectedRowChangeHandler(landlordId2);
		parent.deselectOtherRows(child);
		selectedRow.addClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
		parent.sendLandlordName(name,landlordId);
		
	}
	public void deselectEachDiv(LandlordViewDataBean landlordViewDataBean)
	{
		
		for(int i = 0; i < parent.getLandlordBeanList().size(); i++) 
		{
			if(!landlordViewDataBean.equals(parent.getLandlordBeanList().get(i))) 
			{
				eachrowDiv.removeClassName("LANDLORD_VIEW_BEAN_DATA_ROW_SELECTED");
			}
		}
		
	}

	public Div getEachRowDiv() 
	{
		return eachrowDiv;
	}
	public void selectAssetViewBeanNode(String landlordId2) {
		deselectEachDiv(this);
		if(landlordId2.equalsIgnoreCase(landlordId))
		{
			if(eachrowDiv != null)
			{
				eachrowDiv.addClassName(SCREENCD + "_DATA_ROW_SELECTED");
				parent.sendLandlordName(name,landlordId);
			}
		}
		
	}

}
