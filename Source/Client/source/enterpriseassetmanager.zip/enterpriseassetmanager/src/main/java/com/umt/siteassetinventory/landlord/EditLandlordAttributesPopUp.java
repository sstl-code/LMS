package com.umt.siteassetinventory.landlord;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.ApplicationConstants.DialogTypes;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFileAttributeComponent;
import com.umt.siteassetinventory.site.SiteView;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

public class EditLandlordAttributesPopUp extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_ATTRIBUTES_EDIT";
	private Map<String, List<Object>> save_data;
	private String landlordId;
	private LandlordView parent;
	private Map<String, JSONObject> fileAttributeMap;

	public EditLandlordAttributesPopUp(String title, Component component, String landlordID,
			Map<String, List<Object>> save_data, LandlordView landLordView, Map<String, JSONObject> fileAttributeMap) {
		super(title, component);
		
		if(component.getParent().isPresent()) {
//			component.getParent().get().getElement().getStyle().set("overflow-y", "auto");
//			component.getParent().get().getElement().getStyle().set("display", "flex");
//			component.getParent().get().getElement().getStyle().set("height", "500px");
		}
		
		this.parent = landLordView;
		this.landlordId = landlordID;
		this.save_data = save_data;
		this.fileAttributeMap = fileAttributeMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void saveOperartion() {
		try {
    String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATELANDLORDATTRIBUTE");
		
		JSONObject json = new JSONObject();
		Set<String> key_set = save_data.keySet();
		for(String key : key_set) {
			try {
				
				if(save_data.get(key).get(0).equals("FLOV")) {
					if((save_data.get(key).get(2)).equals("1") &&(((ComboBox<Object>) save_data.get(key).get(1)).getValue()==null || 
							(((ComboBox<Object>) save_data.get(key).get(1)).getValue()+"").trim().length()==0)) {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						 return;
					}
					
					if(((ComboBox<Object>) save_data.get(key).get(1)).getValue() != null && (((ComboBox<Object>) save_data.get(key).get(1)).getValue()+"").trim().length()>0) {
						json.put(key, ((ComboBox<Object>)save_data.get(key).get(1)).getValue());
					}
					
				}else if(save_data.get(key).get(0).equals("DATE_PICKER")) {
					if((save_data.get(key).get(2)).equals("1")  && ((DatePicker) save_data.get(key).get(1)).getValue() == null && 
							(((DatePicker) save_data.get(key).get(1)).getValue()+"").trim().length()==0) {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"DATE_VALUE_MANDATORY"));
						 return;
					}
					
					if(((DatePicker) save_data.get(key).get(1)).getValue() != null && (((DatePicker) save_data.get(key).get(1)).getValue()+"").trim().length()>0) {
						json.put(key, CommonUtils.convertLocalDateToString(
								((DatePicker) save_data.get(key).get(1)).getValue()));
					}
					
				}else if(save_data.get(key).get(0).equals("FREEFLOW") ) {
					
					if(key.equalsIgnoreCase("PIN") && (save_data.get(key).get(2)).equals("1") && 
							 ((TextField)save_data.get(key).get(1)).getValue().toString().length()!=6)
					 {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage("PIN must be 6 digits");
						 return;
					 }
					if((save_data.get(key).get(2)).equals("1")  && (((TextField) save_data.get(key).get(1)).getValue() == null || 
							(((TextField) save_data.get(key).get(1)).getValue()+"").trim().length()==0)) {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						 return;
					}
					
					if(((TextField) save_data.get(key).get(1)).getValue() != null && (((TextField) save_data.get(key).get(1)).getValue()+"").trim().length()>0) {
						json.put(key, ((TextField) save_data.get(key).get(1)).getValue());
					}
				}
				else if(save_data.get(key).get(0).equals("NUMERIC")) {
					if((save_data.get(key).get(2)).equals("1")  && (((NumberField) save_data.get(key).get(1)).getValue() == null || 
							(((NumberField) save_data.get(key).get(1)).getValue()+"").trim().length()==0)) {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						 return;
					}
					
					if(((NumberField) save_data.get(key).get(1)).getValue() != null || (((NumberField) save_data.get(key).get(1)).getValue()+"").trim().length()>0) {
						json.put(key, ((NumberField) save_data.get(key).get(1)).getValue());
					}
				}
				else if(save_data.get(key).get(0).equals("ALPHANUMERIC")) {
					
					if(key.equalsIgnoreCase("PAN") && (save_data.get(key).get(2)).equals("1") && 
							 ((TextField)save_data.get(key).get(1)).getValue().toString().length()!=10)
					 {
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage("PAN No must be 10 digit");
						 return;
					 }
					if((save_data.get(key).get(2)).equals("1")  && (((TextField) save_data.get(key).get(1)).getValue() == null || 
							(((TextField) save_data.get(key).get(1)).getValue()+"").trim().length()==0)) {
						
						 ((HasValidation) save_data.get(key).get(1)).setInvalid(true);
						 ((HasValidation) save_data.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						 return;
					}
					
					if(((TextField) save_data.get(key).get(1)).getValue() != null && (((TextField) save_data.get(key).get(1)).getValue()+"").trim().length()>0) {
						json.put(key, ((TextField) save_data.get(key).get(1)).getValue());
					}
				}
				else if(save_data.get(key).get(0).equals("BOOLEAN") ) {
					json.put(key, ((Checkbox) save_data.get(key).get(1)).getValue());
				}else if(save_data.get(key).get(0).equals("MULTIPLE SELECTION") ) {
					CheckboxGroup<String> checkboxGroup = (CheckboxGroup<String>) save_data.get(key).get(1);
					if((save_data.get(key).get(2)).equals("1") && checkboxGroup.isEmpty()) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please select atleast one option for " + key, DialogTypes.INFO);
						return;
					}
					if(!checkboxGroup.isEmpty()) {
						json.put(key, getMultiSelectValue(checkboxGroup.getSelectedItems()));
					}
				}else if(save_data.get(key).get(0).equals("IMAGE FILE") ) {
					UIFileAttributeComponent fileAttribComp = (UIFileAttributeComponent) save_data.get(key).get(1);
					if((save_data.get(key).get(2)).equals("1") && fileAttribComp.getFileJSON() == null) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
						return;
					}
					if(fileAttribComp.getFileJSON() != null) {
						json.put(key, fileAttribComp.getFileJSON());
					}
				}else if(save_data.get(key).get(0).equals("TEXT FILE") ) {
					UIFileAttributeComponent fileAttribComp = (UIFileAttributeComponent) save_data.get(key).get(1);
					if((save_data.get(key).get(2)).equals("1") && fileAttribComp.getFileJSON() == null) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
						return;
					}
					if(fileAttribComp.getFileJSON() != null) {
						json.put(key, fileAttribComp.getFileJSON());
					}
				}else if(save_data.get(key).get(0).equals("CUSTOM FILE") ) {
					UIFileAttributeComponent fileAttribComp = (UIFileAttributeComponent) save_data.get(key).get(1);
					if((save_data.get(key).get(2)).equals("1") && fileAttribComp.getFileJSON() == null) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a file for attribute " + key, DialogTypes.INFO);
						return;
					}
					if(fileAttribComp.getFileJSON() != null) {
						json.put(key, fileAttribComp.getFileJSON());
					}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				save_btn.setEnabled(true);
			}
		}
		
		System.out.println("OtherInfo==="+json);
		
		Form formData = new Form();
		formData.add("LandlordId",landlordId);
		formData.add("OtherInfo",json);
		
		
	//		save_btn.setEnabled(false);
			String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage("Attributes successfully Saved!", ApplicationConstants.DialogTypes.INFO);
			closeDialog();
			parent.addAttributes(landlordId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
	//		save_btn.setEnabled(true);
		}
		finally {
			save_btn.setEnabled(true);
		}
	}
	
	public String getMultiSelectValue(Set<String> selectedItems) throws JSONException {
		JSONObject retVal = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Iterator<String> iterator = selectedItems.iterator();
		while (iterator.hasNext()) {
			String eachVal = iterator.next();
			jsonArray.put(eachVal);
		}

		retVal.put("MultiSelectValue", jsonArray.toString());

		return retVal.toString();
	}

}
