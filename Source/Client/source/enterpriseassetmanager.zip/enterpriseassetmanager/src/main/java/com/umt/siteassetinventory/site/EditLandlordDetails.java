package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.NumberField;

public class EditLandlordDetails extends Div{
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_LANDLORD_TAB_BEAN";
	//private ComboBox payFreq;
	private NumberField payout;
	private String /*payFreqCode,*/ payAmt="", payUnit="";

	public EditLandlordDetails(/*String freq,*/ String amt,String sitecd, String id,  SiteView siteView) {
		addClassName(SCREENCD + "_EDIT_LANDLORD_DIV"); 
		//payFreq = UIFieldFactory.createComboBox(getPayFeq(), false, SCREENCD, "PAY_FREQ");
		payout = UIFieldFactory.createNumberField(/*false*/true, SCREENCD, "PAY_OUT");
		//payFreq.setValue(freq);
		payout.setValue(Double.valueOf(amt) );
		
		agreementInfo(sitecd);
		
		add(payout);
		setPayAmt(String.valueOf(payout.getValue()));
//		getPayFreqCode(freq);
//		payFreq.addValueChangeListener(event ->{
//			event.getValue();
//			
//			getPayFreqCode(String.valueOf(event.getValue()));
//			System.out.println(payFreqCode);
//		});
		
		
		EditLandLordPopUp edit = new EditLandLordPopUp("Edit Landlord", this, sitecd, id, siteView);
		payout.addValueChangeListener(event ->{
			if(payout.getValue() > payout.getMax()) {
				if(payUnit.equals("Fixed")) {
					payout.setErrorMessage("Pay Amount should be less than " + payout.getMax());
					edit.setButtonEnable(false);
				}else if(payUnit.equals("Percentage")) {
					payout.setErrorMessage("Pay Amount should be less than 100");
					edit.setButtonEnable(false);
				}
				
				
			
			}else {
				setPayAmt(String.valueOf(payout.getValue()));
				edit.setButtonEnable(true);
			}
			
		});
		
		
		
	}
	private List<String> getPayFeq() {
		List<String> list= new ArrayList<>();
		
		list.add("Weekly");
		list.add("Fortnightly");
		list.add("Monthly");
		list.add("Quarterly");
		list.add("Bi-Yearly");
		list.add("Yearly");
		
		return list;
		
	}
//	public String getFreqCode() {
//		return payFreqCode;
//	}
    public String getAmt() {
    	return payAmt;
    }
    private void agreementInfo(String siteCode) {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETCURRENTSITEAGREEMENT");
		base_URL = base_URL + "?SiteCode=" + URLEncoder.encode(siteCode);
		try {
			String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("AgreementInfo: " + outputResponse);
			
			JSONObject obj = new JSONObject(outputResponse);
			
			
			Double payAmt = Double.valueOf(obj.getString("PaymentAmount"));
			payUnit = getPaymentUnit(obj.getString("PaymentUnit"));
			
			if(payUnit.equals("Fixed")) {
				payout.setMin(0);
				payout.setMax(payAmt);
			}else if(payUnit.equals("Percentage")) {
				payout.setLabel("Pay Out Amout(In Percentage)");
				payout.setMax(100);
				
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		
		
	}
  
//private void getPayFreqCode(String listItem) {
//		
//		if(listItem.equals("Weekly")) {
//			payFreqCode = "1";
//		}else if(listItem.equals("Fortnightly")) {
//			payFreqCode = "2";
//			
//		}else if(listItem.equals("Monthly")) {
//			payFreqCode = "3";
//		}else if(listItem.equals("Quarterly")) {
//			payFreqCode = "4";
//		}else if(listItem.equals("Bi-Yearly")) {
//			payFreqCode = "5";
//		}else if(listItem.equals("Yearly")) {
//			payFreqCode = "6";
//		}
//		
//		
//		
//		
//	}
private String getPaymentUnit(String code) {
	String value = null;
	if(code.equals("1")) {
		value = "Fixed";
	}else if(code.equals("2")) {
		value = "Percentage";
	}
	
	return value;
	
}
private void setPayAmt(String amt) {
	payAmt = amt;
}

public Double getPayoutShare() {
	return payout.getValue();
}

public NumberField getPayoutField() {
	return payout;
}



}
