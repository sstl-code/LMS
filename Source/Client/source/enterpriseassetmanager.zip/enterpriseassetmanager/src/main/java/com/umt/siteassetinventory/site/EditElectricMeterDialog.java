package com.umt.siteassetinventory.site;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/electric-meter-tab-styles.css")
public class EditElectricMeterDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EDIT_ELECTRIC_METER_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv;
	private Div mainLayout, closeBtnDiv;
	private Button saveBtn, cancelBtn;
	private String metername, metercategory, storeserialno, installationdate, sebmeterauthority, status,
			sebmeterinstallationdate, consumerno;
	private TextField meternameField, metercategoryField, serialnoField, installationdateField, sebmeterauthorityField,
			consumernoField;
	private TextField statusField;
	private DatePicker sebmeterinstallationdateField;
	private List<String> statusList;
	private boolean isSuccess = false;
	private SiteElectricMeterTab siteelectricmetertab;
	private Map<String, String> attri_data;
	private JSONArray json_array;
	private Map<String, List<Object>> save_datamap;
	private Div attributeDiv;
	
	private ComboBox<String> metertypeField;
	private List<String> metertypeList=new ArrayList<String>();
	private DatePicker sebmeterinstalationDateField;
	private Div eachDataDiv1,eachDataDiv2,eachDataDiv3,eachDataDiv4,eachDataDiv5;
	private Div row,row1,row2,row3,row4;
	private TextField SerialNoField,consumerNoField,sebmeterAuthorityField;
	private JSONObject otherinfoJson=new JSONObject();
	

	public EditElectricMeterDialog(String metername, String metercategory, String storeserialno, String installationdate,
			String sebmeterauthority, String status, String sebmeterinstallationdate, String consumerno,String meterserialno,
			SiteElectricMeterTab siteelectricmetertab, JSONArray json_array, Map<String, String> attri_data) {
		//Added by ps 10thApril2023 after uat
		try {
			
		
		System.out.println("json_array=" + json_array);
		System.out.println("attri_data" + attri_data);
		this.siteelectricmetertab = siteelectricmetertab;
		this.metername = metername;
		this.metercategory = metercategory;
		this.storeserialno = storeserialno;
		this.installationdate = installationdate;
		this.sebmeterauthority = sebmeterauthority;
		this.status = status;
		this.sebmeterinstallationdate = sebmeterinstallationdate;
		this.consumerno = consumerno;
		this.attri_data = attri_data;
		this.json_array = json_array;

		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		// Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		// closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);

		//Commented by ps 10thApril2023 after uat
	//	createRows(metername, metercategory, storeserialno, installationdate, sebmeterauthority, status,sebmeterinstallationdate, consumerno);
		
		createRows2(metername, metercategory, storeserialno, installationdate, sebmeterauthority, status,sebmeterinstallationdate, 
				consumerno,meterserialno);
//				
		
//		try {
//			if (json_array != null && json_array.length() > 0 && attri_data != null && !attri_data.isEmpty()) {
//				populateAttributeRows(json_array, attri_data);
//			}
//
//		} catch (Exception e) { // TODO Auto-generated catch block
//			e.printStackTrace();
//		}//Commented by ps 10thApril2023 after uat

		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn, cancelBtn);
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout, buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});

		saveBtn.setDisableOnClick(true);
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				updateData();
			}
		});
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		metertypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					metertypeField.setInvalid(false);
					metertypeField.setErrorMessage("");
				}else {
					metertypeField.setInvalid(true);
					metertypeField.focus();
					metertypeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
				}

			}
		});

	}
	
	

	

/*	public EditElectricMeterDialog(String vendorName, String metercategory2, String storeserialno2,
			String installationDate2, String sebMeterAuthority2, String status2, String sebMeterInstallationDate2,
			String consumerNo2, String serialNo, SiteElectricMeterTab siteElectricMeterTab2, JSONArray arrayList,
			Map<String, String> attri_data2) {
		//Added by ps 10thApril2023 after uat

		System.out.println("json_array=" + json_array);
		System.out.println("attri_data" + attri_data);
		this.siteelectricmetertab = siteelectricmetertab;
		this.metername = metername;
		this.metercategory = metercategory;
		this.storeserialno = storeserialno;
		this.installationdate = installationdate;
		this.sebmeterauthority = sebmeterauthority;
		this.status = status;
		this.sebmeterinstallationdate = sebmeterinstallationdate;
		this.consumerno = consumerno;
		this.attri_data = attri_data;
		this.json_array = json_array;

		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		// Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		// closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);

	//	createRows(metername, metercategory, storeserialno, installationdate, sebmeterauthority, status,sebmeterinstallationdate, consumerno);
		
		createRows2(metername, metercategory, storeserialno, installationdate, sebmeterauthority, status,sebmeterinstallationdate, consumerno,serialNo);
				
		
//		try {
//			if (json_array != null && json_array.length() > 0 && attri_data != null && !attri_data.isEmpty()) {
//				populateAttributeRows(json_array, attri_data);
//			}
//
//		} catch (Exception e) { // TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn, cancelBtn);
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout, buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				updateData();
			}
		});
	}

*/
	private void createRows(String metername2, String metercategory2, String serialno2, String installationdate2,
			String sebmeterauthority2, String status2, String sebmeterinstallationdate2, String consumerno2) {

		try {
			meternameField = UIFieldFactory.createTextField(metername2, false, SCREENCD, "FIELD1");
			metercategoryField = UIFieldFactory.createTextField(metercategory2, false, SCREENCD, "FIELD2");
			serialnoField = UIFieldFactory.createTextField(serialno2, false, SCREENCD, "FIELD3");
			installationdateField = UIFieldFactory.createTextField(installationdate2, false, SCREENCD, "FIELD4");
			sebmeterauthorityField = UIFieldFactory.createTextField(sebmeterauthority2, false, SCREENCD, "FIELD5");
			/*
			 * String status[] = {"Active", "Inactive"}; statusList=new ArrayList<String>();
			 * for (int i = 0; i < status.length; i++) { statusList.add(status[i]); }
			 */

			statusField = UIFieldFactory.createTextField(sebmeterauthority2, false, SCREENCD, "FIELD6");
			statusField.setValue(status2);
			sebmeterinstallationdateField = UIFieldFactory.createDatePicker(false, SCREENCD, "FIELD7");
			if(sebmeterinstallationdate2!=null && sebmeterinstallationdate2.trim().length()>0) {
				sebmeterinstallationdateField.setValue(CommonUtils.convertStringToLocalDate(sebmeterinstallationdate2, "dd/MM/yyyy"));
			}
			
					

			consumernoField = UIFieldFactory.createTextField(consumerno2, false, SCREENCD, "FIELD8");

			meternameField.setEnabled(false);
			installationdateField.setEnabled(false);
			statusField.setEnabled(false);
			serialnoField.setEnabled(false);

			Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			attributeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTE_DIV");
			// Div row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");

//		row_1.add(meternameField, metercategoryField);
//		row_2.add(serialnoField, consumernoField);
//		row_3.add(installationdateField, sebmeterinstallationdateField);
//		row_4.add(sebmeterauthorityField, statusField);

			row_1.add(meternameField, serialnoField);
			row_2.add(installationdateField, statusField);
			// row_3.add(consumernoField,sebmeterinstallationdateField);
			// row_4.add(sebmeterauthorityField,metercategoryField);

		//	bodyDiv.add(row_1, row_2);
			row_1.setVisible(false);
			row_2.setVisible(false);
			 bodyDiv.add(row_1, row_2,attributeDiv);
		} catch (Exception e) {
			e.printStackTrace();
		//	System.out.println(e.getMessage());
		}

	}

	private void populateAttributeRows(JSONArray json_array2, Map<String, String> attri_data2) {
		try {

			Set<String> key_set = attri_data2.keySet();
			save_datamap = new HashMap<>();
			String attri_values = null;
			String data_type = null;
			String mandetory = null;
			attributeDiv.removeAll();
			for (int i = 0; i < json_array.length(); i++) {
				JSONObject json = json_array.getJSONObject(i);
				// System.out.println(json);
				List<Object> dataTypeList = new ArrayList<>();

				for (String key : key_set) {

					if (json.getString("AttributeName").equals(key)) {
						// System.out.println("Test: " +key+ " " + values.get(key));
						attri_values = attri_data2.get(key);

						break;
					}

				}
				String defaultval = "";
				if (json.has("DefaultValue") && json.getString("DefaultValue") != null
						&& json.getString("DefaultValue").trim().length() > 0) {
					defaultval = json.getString("DefaultValue");
				}
				if (json.getString("AttributeDatatype").equals("5")) {
					data_type = "FLOV";
					mandetory = json.getString("Mandatory");
					List<String> choiceList = new ArrayList<String>();
					String str = json.getString("FLOV");
					String flovVal[] = str.split(",");
					choiceList.clear();
					for (String s : flovVal) {
						choiceList.add(s);
					}
					ComboBox<String> flov = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "FLOV");
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						flov.setValue(defaultval);

					} else {
						flov.setValue(attri_values);
					}

					flov.setLabel(json.getString("AttributeName"));
					if (json.getString("Mandatory").equals("1")) {
						flov.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(flov);
					dataTypeList.add(mandetory);
					attributeDiv.add(flov);

				} else if (json.getString("AttributeDatatype").equals("4")) {
					mandetory = json.getString("Mandatory");
					data_type = "DATE_PICKER";
					DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
					ValueDateField.setLabel(json.getString("AttributeName"));

					if (attri_values != null && !attri_values.equals("-") && !attri_values.equals("")) {
						defaultval = attri_values;
					}

					if (defaultval.length() > 0) {
						ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval, "dd/MM/yyyy"));
					}
					if (json.getString("Mandatory").equals("1")) {
						ValueDateField.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(ValueDateField);
					dataTypeList.add(mandetory);
					attributeDiv.add(ValueDateField);
				} else if (json.getString("AttributeDatatype").equals("3")) {
					mandetory = json.getString("Mandatory");
					data_type = "FREEFLOW";
					TextField freeFlow = UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					freeFlow.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						freeFlow.setValue(defaultval);
					} else {
						freeFlow.setValue(attri_values);
					}

					if (json.getString("Mandatory").equals("1")) {
						freeFlow.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(freeFlow);
					dataTypeList.add(mandetory);
					attributeDiv.add(freeFlow);
				} else if (json.getString("AttributeDatatype").equals("2")) {
					mandetory = json.getString("Mandatory");
					data_type = "ALPHANUMERIC";
					TextField textField = UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
					textField.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						textField.setValue(defaultval);
					} else {
						textField.setValue(attri_values);
					}

					if (json.getString("Mandatory").equals("1")) {
						textField.setRequiredIndicatorVisible(true);
					}
					textField.setValueChangeMode(ValueChangeMode.EAGER);
					textField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if (!arg0.getValue().toString().matches("^\\w*$")
									|| arg0.getValue().toString().contains("_")) {
								textField.setValue(arg0.getOldValue().toString());
							}
						}
					});
					dataTypeList.add(data_type);
					dataTypeList.add(textField);
					dataTypeList.add(mandetory);
					attributeDiv.add(textField);
				} else if (json.getString("AttributeDatatype").equals("1")) {
					mandetory = json.getString("Mandatory");
					data_type = "NUMERIC";
					TextField numberTextField = UIFieldFactory.createTextField("", false, SCREENCD, "NUMBERFIELD");
					numberTextField.setLabel(json.getString("AttributeName"));
					if (attri_values == null || attri_values.equals("-") || attri_values.equals("")) {
						if (defaultval.length() > 0) {
							numberTextField.setValue(defaultval);
						}
					} else {
						numberTextField.setValue(attri_values);
					}
					numberTextField.setValueChangeMode(ValueChangeMode.EAGER);
					numberTextField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

						private static final long serialVersionUID = 1L;

						@Override
						public void valueChanged(ValueChangeEvent<?> arg0) {

							if (!arg0.getValue().toString().matches("[0-9]+")
									&& !arg0.getValue().toString().matches("")) {
								numberTextField.setValue(arg0.getOldValue().toString());
							}
							if (!arg0.getValue().toString().matches("^\\w*$")) {
								numberTextField.setValue(arg0.getOldValue().toString());
							}
						}
					});

					if (json.getString("Mandatory").equals("1")) {
						numberTextField.setInvalid(false);
						numberTextField.setRequiredIndicatorVisible(true);
					}
					dataTypeList.add(data_type);
					dataTypeList.add(numberTextField);
					dataTypeList.add(mandetory);
					attributeDiv.add(numberTextField);
				}

				save_datamap.put(json.getString("AttributeName"), dataTypeList);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void updateData() {
		try {
//			saveBtn.setEnabled(false);
			Form form = new Form();
			form.add("StoreSerialNo", Integer.parseInt(storeserialno));
			form.add("vendorId", Integer.parseInt("1"));
			form.add("description", "");

			// System.out.println("form="+form);

			//String url = ApplicationConfiguration.getServiceEndpoint("UPDATE_EQUIPMENT");
			//RestServiceHandler.updateJSON_PUT(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
		
			//	callupdateAttributeAssetsApi();
			
			callupdateEquipmentSerialNo();
		//	callupdateAttributeAssetsApi2();

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			isSuccess = false;
		//	saveBtn.setEnabled(true);
		}
		finally {
			saveBtn.setEnabled(true);
		}

	}
	
	private void callupdateEquipmentSerialNo() {
		try {
			
			if((SerialNoField.getValue().length()<=0)){
				if(SerialNoField.getValue().length()<=0)
				{
					SerialNoField.setInvalid(true);
					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
					
		    }
				
			if(metertypeField.isRequired()==true) {
					if(metertypeField.getValue()==null || metertypeField.getValue().length()<=0) {
						metertypeField.setInvalid(true);
						metertypeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Meter Category",metertypeField.getValue());
					}
				}else {
					consumerNoField.setInvalid(false);
					consumerNoField.setErrorMessage("");
				}
				
				if(consumerNoField.isRequired()==true) {
					if(consumerNoField.getValue()==null || consumerNoField.getValue().length()<=0) {
						consumerNoField.setInvalid(true);
						consumerNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Consumer No",consumerNoField.getValue());
					}
				}else {
					consumerNoField.setInvalid(false);
					consumerNoField.setErrorMessage("");
				}
				
				if(sebmeterinstalationDateField.isRequired()==true) {
					if(sebmeterinstalationDateField.getValue()==null) {
						sebmeterinstalationDateField.setInvalid(true);
						sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"DATE_VALUE_MANDATORY"));
						return;
					}else if(sebmeterinstalationDateField.getValue()!=null) {
						LocalDate now = LocalDate.now();
						String currentDate=CommonUtils.convertLocalDateToString(now);
						
						Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
						Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse(currentDate);
						
						if(date1.after(date2)){
				            sebmeterinstalationDateField.setInvalid(true);
							sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"WRONG_VALUE"));
							return;
				        }else {
				        	otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
				        }
					}
					else {
						otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
					}
				}else {
					sebmeterinstalationDateField.setInvalid(false);
					sebmeterinstalationDateField.setErrorMessage("");
				}

				
				if(sebmeterAuthorityField.isRequired()==true) {
					if(sebmeterAuthorityField.getValue()==null || sebmeterAuthorityField.getValue().length()<=0) {
						sebmeterAuthorityField.setInvalid(true);
						sebmeterAuthorityField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("SEB Meter Authority",sebmeterAuthorityField.getValue());
					}
				}else {
					sebmeterAuthorityField.setInvalid(false);
					sebmeterAuthorityField.setErrorMessage("");
				}
					
			
//			if((SerialNoField.getValue().length()<=0)){
//				if(SerialNoField.getValue().length()<=0)
//				{
//					SerialNoField.setInvalid(true);
//					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
//					return;
//				}
//					
//		    }else {
				saveBtn.setEnabled(false);
		    	Form formData = new Form();
				formData.add("StoreSerialNo",storeserialno);
				formData.add("EquipmentSerialNo",SerialNoField.getValue());
				
				System.out.println("formData=="+formData);
				
				String base_URL = ApplicationConfiguration.getServiceEndpoint("UPDATE_EQUIPMENT_SERIALNO");
				RestServiceHandler.updateJSON_PUT(base_URL, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				callupdateAttributeAssetsApi2();		
				
			//	SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
	//	    }
			
			
					
			
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),ApplicationConstants.DialogTypes.ERROR);
		//	saveBtn.setEnabled(true);		
		}
		finally {
			saveBtn.setEnabled(true);
		}
	}

	private void callupdateAttributeAssetsApi() {
		JSONObject json = new JSONObject();
		Set<String> key_set = save_datamap.keySet();
		System.out.println("save_datamap==="+save_datamap);
		for (String key : key_set) {
			try {

				if (save_datamap.get(key).size()>0 && save_datamap.get(key).get(0).equals("FLOV")) {
					if ((save_datamap.get(key).get(2)).equals("1")
							&& ((ComboBox<Object>) save_datamap.get(key).get(1)).getValue() == null
							&& (((ComboBox<Object>) save_datamap.get(key).get(1)).getValue() + "").trim()
									.length() == 0) {
						((HasValidation) save_datamap.get(key).get(1)).setInvalid(true);
						((HasValidation) save_datamap.get(key).get(1)).setErrorMessage(
								SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "VALUE_MANDATORY"));
						return;
					}

					if (((ComboBox<Object>) save_datamap.get(key).get(1)).getValue() != null
							&& (((ComboBox<Object>) save_datamap.get(key).get(1)).getValue() + "").trim()
									.length() > 0) {
						json.put(key, ((ComboBox<Object>) save_datamap.get(key).get(1)).getValue());
					}

				} else if (save_datamap.get(key).size()>0 && save_datamap.get(key).get(0).equals("DATE_PICKER")) {
					if ((save_datamap.get(key).get(2)).equals("1")
							&& ((DatePicker) save_datamap.get(key).get(1)).getValue() == null
							&& (((DatePicker) save_datamap.get(key).get(1)).getValue() + "").trim().length() == 0) {
						((HasValidation) save_datamap.get(key).get(1)).setInvalid(true);
						((HasValidation) save_datamap.get(key).get(1)).setErrorMessage(
								SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "VALUE_MANDATORY"));
						return;
					}

					if (((DatePicker) save_datamap.get(key).get(1)).getValue() != null
							&& (((DatePicker) save_datamap.get(key).get(1)).getValue() + "").trim().length() > 0) {
						json.put(key, CommonUtils
								.convertLocalDateToString(((DatePicker) save_datamap.get(key).get(1)).getValue()));
					}

				} else if (save_datamap.get(key).size()>0 && save_datamap.get(key).get(0).equals("FREEFLOW")) {

					if ((save_datamap.get(key).get(2)).equals("1")
							&& ((TextField) save_datamap.get(key).get(1)).getValue() == null
							&& (((TextField) save_datamap.get(key).get(1)).getValue() + "").trim().length() == 0) {
						((HasValidation) save_datamap.get(key).get(1)).setInvalid(true);
						((HasValidation) save_datamap.get(key).get(1)).setErrorMessage(
								SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "VALUE_MANDATORY"));
						return;
					}

					if (((TextField) save_datamap.get(key).get(1)).getValue() != null
							&& (((TextField) save_datamap.get(key).get(1)).getValue() + "").trim().length() > 0) {
						json.put(key, ((TextField) save_datamap.get(key).get(1)).getValue());
					}

				}

				else if (save_datamap.get(key).size()>0 && (save_datamap.get(key).get(0).equals("ALPHANUMERIC")
						|| save_datamap.get(key).get(0).equals("NUMERIC"))) {
					if ((save_datamap.get(key).get(2)).equals("1")
							&& ((TextField) save_datamap.get(key).get(1)).getValue() == null
							&& (((TextField) save_datamap.get(key).get(1)).getValue() + "").trim().length() == 0) {
						((HasValidation) save_datamap.get(key).get(1)).setInvalid(true);
						((HasValidation) save_datamap.get(key).get(1)).setErrorMessage(
								SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "VALUE_MANDATORY"));
						return;
					}

					if (((TextField) save_datamap.get(key).get(1)).getValue() != null
							&& (((TextField) save_datamap.get(key).get(1)).getValue() + "").trim().length() > 0) {
						json.put(key, ((TextField) save_datamap.get(key).get(1)).getValue());
					}

				}

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Form formData = new Form();
		formData.add("StoreSerialNo",storeserialno);
		formData.add("OtherInfo", json);

	//	System.out.println("formData: " + json);

		try {
			String base_URL = ApplicationConfiguration.getServiceEndpoint("UPDATEATTRIBUTEASSETS");
			String response = RestServiceHandler.updateJSON_PUT(base_URL, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			// SiteAssetInventoryUIFramework.getFramework().showMessage("Attributes
			// successfully Saved!", ApplicationConstants.DialogTypes.INFO);
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "SAVE_DATA",
					ApplicationConstants.DialogTypes.INFO);
			siteelectricmetertab.refreshData();
			isSuccess = true;
			close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			isSuccess = false;
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
		}

	}
	
	
	private void callupdateAttributeAssetsApi2() {//Added by ps 10thApril2023 after uat
		//JSONObject otherinfoJson=new JSONObject();
		/*try {
			
			if((SerialNoField.getValue().length()<=0)){
				if(SerialNoField.getValue().length()<=0)
				{
					SerialNoField.setInvalid(true);
					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
					
		    }
				
				if(metertypeField.isRequired()==true) {
					if(metertypeField.getValue()==null || metertypeField.getValue().length()<=0) {
						metertypeField.setInvalid(true);
						metertypeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Meter Category",metertypeField.getValue());
					}
				}else {
					consumerNoField.setInvalid(false);
					consumerNoField.setErrorMessage("");
				}
				
				if(consumerNoField.isRequired()==true) {
					if(consumerNoField.getValue()==null || consumerNoField.getValue().length()<=0) {
						consumerNoField.setInvalid(true);
						consumerNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Consumer No",consumerNoField.getValue());
					}
				}else {
					consumerNoField.setInvalid(false);
					consumerNoField.setErrorMessage("");
				}
				
				if(sebmeterinstalationDateField.isRequired()==true) {
					if(sebmeterinstalationDateField.getValue()==null) {
						sebmeterinstalationDateField.setInvalid(true);
						sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else if(sebmeterinstalationDateField.getValue()!=null) {
						LocalDate now = LocalDate.now();
						String currentDate=CommonUtils.convertLocalDateToString(now);
						
						Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
						Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse(currentDate);
						
						if(date1.after(date2)){
				            sebmeterinstalationDateField.setInvalid(true);
							sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"WRONG_VALUE"));
							return;
				        }else {
				        	otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
				        }
					}
					else {
						otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
					}
				}else {
					sebmeterinstalationDateField.setInvalid(false);
					sebmeterinstalationDateField.setErrorMessage("");
				}

				
				if(sebmeterAuthorityField.isRequired()==true) {
					if(sebmeterAuthorityField.getValue()==null || sebmeterAuthorityField.getValue().length()<=0) {
						sebmeterAuthorityField.setInvalid(true);
						sebmeterAuthorityField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("SEB Meter Authority",sebmeterAuthorityField.getValue());
					}
				}else {
					sebmeterAuthorityField.setInvalid(false);
					sebmeterAuthorityField.setErrorMessage("");
				}
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		

		Form formData = new Form();
		formData.add("StoreSerialNo",storeserialno);
		formData.add("OtherInfo",otherinfoJson);

		System.out.println("formData: " + formData);
		System.out.println("otherinfoJson: " + otherinfoJson);

		try {
			saveBtn.setEnabled(false);
			String base_URL = ApplicationConfiguration.getServiceEndpoint("UPDATEATTRIBUTEASSETS");
			String response = RestServiceHandler.updateJSON_PUT(base_URL, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "SAVE_DATA",
					ApplicationConstants.DialogTypes.INFO);
			siteelectricmetertab.refreshData();
			isSuccess = true;
			close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			isSuccess = false;
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
	//		saveBtn.setEnabled(true);
		}
		finally {
			saveBtn.setEnabled(true);
		}
		

	}
	
	
	private void createRows2(String metername2, String metercategory2, String serialno2, String installationdate2,
			String sebmeterauthority2, String status2, String sebmeterinstallationdate2, String consumerno2,String meterserialno2) {
		//Added by ps 10thApril2023 after uat 
		row1=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row2=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row3=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		eachDataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		
		SerialNoField= UIFieldFactory.createTextField("", true, SCREENCD,"SERIAL_NO_FIELD");
		consumerNoField= UIFieldFactory.createTextField("", false, SCREENCD,"CONSUMER_NO_FIELD");
		sebmeterAuthorityField= UIFieldFactory.createTextField("", false, SCREENCD,"SEBAUTHORITY_FIELD");
		metertypeField=UIFieldFactory.createComboBox(metertypeList, true, SCREENCD,"METERTYPE_FIELD");
		sebmeterinstalationDateField=UIFieldFactory.createDatePicker(false, SCREENCD,"PERIOD_END_DATE_FIELD");
		eachDataDiv1.add(metertypeField);
		eachDataDiv2.add(consumerNoField);
		eachDataDiv3.add(sebmeterinstalationDateField);
		eachDataDiv4.add(sebmeterAuthorityField);
		eachDataDiv5.add(SerialNoField);
	
		populatemetertypeCombo();
		
		
		row1.add(eachDataDiv1,eachDataDiv2);
		row2.add(eachDataDiv3,eachDataDiv4);
		row3.add(eachDataDiv5);
	//	row.add(row1,row2);
		bodyDiv.add(row1,row2,row3);
		
		SerialNoField.setValue(meterserialno2);
	//	SerialNoField.setEnabled(false);
		consumerNoField.setValue(consumerno2);
		sebmeterAuthorityField.setValue(sebmeterauthority2);
//		sebmeterinstalationDateField.setValue(value);
		System.out.println("sebmeterinstallationdate2=="+sebmeterinstallationdate2);
		if(sebmeterinstallationdate2!=null) {
			sebmeterinstalationDateField.setValue(CommonUtils.convertStringToLocalDate(sebmeterinstallationdate2,"dd/MM/yyyy"));
		}
		
		metertypeField.setValue(metercategory);
		if(metertypeField.getValue()!=null) {
			attributeUiOrchestration(metertypeField.getValue());
		}
		
//		sebmeterinstalationDateField.setValue(CommonUtils.convertStringToLocalDate(CommonUtils.convertDateToDifferentFormat(sebmeterinstallationdate2,"dd-MMM-yyyy","dd/MM/yyyy"),
//				"dd/MM/yyyy"));
		
		metertypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if(value!=null)
				{
					attributeUiOrchestration(value);
				
				}


			}
		});

	}
	
	private void populatemetertypeCombo() {
		metertypeList=new ArrayList<String>();
		String str[] = {"SEB Meter","Sub Meter","Prepaid Meter","SEB Prepaid Meter"};
		for (int i = 0; i < str.length; i++) {
			metertypeList.add(str[i]);
		}
		
		metertypeField.setItems(metertypeList);
	//	if(metertypeList.size()>0) {
		//	metertypeField.setValue(metertypeList.get(0));
//			metertypeField.setValue(metercategory);
//			if(metertypeField.getValue()!=null) {
//				attributeUiOrchestration(metertypeField.getValue());
//			}
			
	//	}
		
	}
	
	protected void attributeUiOrchestration(String value) {

		if(value.equalsIgnoreCase("SEB Meter")) {
			eachDataDiv2.setVisible(true);
			eachDataDiv3.setVisible(true);
			eachDataDiv4.setVisible(true);
			
			mandatoryFields();
		}else if(value.equalsIgnoreCase("SEB Prepaid Meter")) {
			eachDataDiv2.setVisible(true);
			eachDataDiv3.setVisible(true);
			eachDataDiv4.setVisible(true);
			
			mandatoryFields();
		}
		else if(value.equalsIgnoreCase("Sub Meter")) {
			eachDataDiv2.setVisible(false);
			eachDataDiv3.setVisible(false);
			eachDataDiv4.setVisible(false);
		//	System.out.println(value);
			nonmandatoryFields();
		}else if(value.equalsIgnoreCase("Prepaid Meter")) {
			eachDataDiv2.setVisible(false);
			eachDataDiv3.setVisible(false);
			eachDataDiv4.setVisible(false);
			nonmandatoryFields();
		}else {
			
		}
		
	}


	
	private void mandatoryFields() {
		consumerNoField.setVisible(true);
		consumerNoField.setRequired(true);
		consumerNoField.setRequiredIndicatorVisible(true);
		
		sebmeterinstalationDateField.setVisible(true);
		sebmeterinstalationDateField.setRequired(true);
		sebmeterinstalationDateField.setRequiredIndicatorVisible(true);
		
		sebmeterAuthorityField.setVisible(true);
		sebmeterAuthorityField.setRequired(true);
		sebmeterAuthorityField.setRequiredIndicatorVisible(true);
		
	//	row3.remove(eachDataDiv5);
	//	row1.remove(eachDataDiv5);
		
		row1.removeAll();
		row3.removeAll();
		
		row1.add(eachDataDiv1,eachDataDiv2);
		row3.add(eachDataDiv5);
	}
	
	private void nonmandatoryFields() {
		consumerNoField.setVisible(false);
		consumerNoField.setRequired(false);
		consumerNoField.setRequiredIndicatorVisible(false);
		
		sebmeterinstalationDateField.setVisible(false);
		sebmeterinstalationDateField.setRequired(false);
		sebmeterinstalationDateField.setRequiredIndicatorVisible(false);
		
		sebmeterAuthorityField.setVisible(false);
		sebmeterAuthorityField.setRequired(false);
		sebmeterAuthorityField.setRequiredIndicatorVisible(false);
		
		row3.removeAll();
		row1.removeAll();
		
		row1.add(eachDataDiv1,eachDataDiv5);
		//System.out.println("inside");
	}


}
