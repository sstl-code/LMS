package com.umt.siteassetinventory.site;

import org.codehaus.jettison.json.JSONException;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddSiteAssetPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddSiteAsset addSiteAsset;
	private String screencd;
	private boolean dataSaved;
	private SiteAssetsTab viewSiteAssetsTab;


	public AddSiteAssetPopup(String title, Component component, SiteAssetsTab siteAssetsTab, String screencd) {
		super(title, component);
		this.addSiteAsset = (AddSiteAsset) component;
		this.viewSiteAssetsTab = siteAssetsTab;
		this.screencd = screencd;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDASSETTOSITE");
		try {
			boolean selectedRecord = false;
			if (addSiteAsset.addSiteAssetDataBeanList==null || addSiteAsset.addSiteAssetDataBeanList.size()==0) {
				SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "NO_RECORD_TO_SAVE", ApplicationConstants.DialogTypes.ERROR);
				return;
			}
			for (AddSiteAssetDataBean bean : addSiteAsset.addSiteAssetDataBeanList) {
				if (bean.isSelected()) {
					selectedRecord = true;
					Form formData = new Form();
					formData.add("SiteCode", addSiteAsset.getSiteCode());
					formData.add("StoreSerialNo", bean.getAssetId());
					formData.add("Remarks", addSiteAsset.getRemarks());
//					formData.add("StatusId", 4);
					
					//System.out.println("input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					String msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "ASSET_SAVE_SUCCESSFUL");
					//msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
					Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
					dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
						private static final long serialVersionUID = 1L;
						

						@Override
						public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
							if(!event.isOpened()) {
								dataSaved = true;
								viewSiteAssetsTab.refreshData();
								close();	
							}
						}
					});		
				}
			}

			if(!selectedRecord)
			{
				SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "NO_RECORD_SELECTED", ApplicationConstants.DialogTypes.ERROR);
			}	
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
