package com.umt.siteassetinventory.landlord;


import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.site.ThumbnailImage;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.server.VaadinServletRequest;


@CssImport("./styles/workflow_details-style.css")
public class WorkflowDetails extends Dialog 
{
	private static final long serialVersionUID = 1L;
	//private static final Logger logger = LogManager.getLogger(WorkflowDetails.class);
	public static final String SCREENCD = "WORKFLOW_DETAILS";

	private String instanceId;
	private Label etaLbl;
	private Label etaVLbl;
	private Label TitleLbl;
	private Label workflowNameLbl;
	private Label workflowNameVLbl;
	private Label startDateLbl;
	private Label startDateVLbl;
	private Label statusLbl;
	private Label statusVLbl;
	private Label progressLbl;
	private Label progressVLbl;
	private Label dataFieldHLbl;
	private Label valueHLbl;
	private Label dataFieldLbl;
	private Label valueLbl;
	private Label taskNameLbl;
	private Label tasktypeLbl;
	private Label taskStateLbl;
	private Label assignetoLbl;
	private Label taskNameHLbl;
	private Label tasktypeHLbl;
	private Label taskStateHLbl;
	private Label assignetoHLbl;
	private Div mainLayoutDiv;
	private Button closeBtn;
	private HorizontalLayout InstanceInfo1_HL;
	private HorizontalLayout InstanceInfo2_HL;
	private HorizontalLayout InstanceInfo3_HL;
	private Div titleBar,footerDiv;
	private Div datadescSectionHeader;
	private Div datadescSection;
	private Div taskSectionHeader;
	private Div taskSection;
	private Div dataDescRowDiv;
	private Div taskRowDiv; 
	private Div instanceSection;
	private VerticalLayout dataDetails;
	private VerticalLayout taskDetails;
	private String str_JsonWorkFlow;
	private int status;
	private String landlordId;
	private Tabs summaryTabs;
	private Tab dataTab, TasksTab;
	private ProgressBar progressInfo;
	
	
	//private UIRoundProgressBar roundProgressBar;


	public WorkflowDetails(String strJson, String landlordId, int status)
	{
		this.str_JsonWorkFlow = strJson;
		this.landlordId = landlordId;
		this.status = status;
		createComponent();
	}

	public void createComponent()
	{

		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		InstanceInfo1_HL = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "ROW1");
		InstanceInfo2_HL = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "ROW2");
		InstanceInfo3_HL = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "ROW3");
		instanceSection = UIHtmlFieldFactory.createDiv(SCREENCD, "INSTANCE_SECTION_DIV");
		dataDetails = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DATADESC_DETAILS");
		taskDetails = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "TASK_DETAILS");
		datadescSection = UIHtmlFieldFactory.createDiv(SCREENCD, "DATADESC_SECTION_DIV");
		datadescSectionHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "DATADESC_SECTION_HEADER_DIV");
		taskSectionHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "TASK_SECTION_HEADER_DIV");
		taskSection = UIHtmlFieldFactory.createDiv(SCREENCD, "TASK_SECTION_DIV");

		Div displayDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DISPLAY_DIV_1");

		Div hrow = UIHtmlFieldFactory.createDiv(SCREENCD, "H_ROW");

		Div div1 = UIHtmlFieldFactory.createDiv(SCREENCD, "DIV_1");
		Div div2 = UIHtmlFieldFactory.createDiv(SCREENCD, "DIV_2");
		Div div3 = UIHtmlFieldFactory.createDiv(SCREENCD, "DIV_3");
		Div div4 = UIHtmlFieldFactory.createDiv(SCREENCD, "DIV_4");
		Div div5 = UIHtmlFieldFactory.createDiv(SCREENCD, "DIV_5");

		/*Div dataFieldHDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DATAFIELDH_DIV");
		 Div valueHDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUEH_DIV");
	     Div taskNameDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TASKNAME_DIV");
		 Div tasktypeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TASKTYPE_DIV");
		 Div taskStateDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TASKSTATE_DIV");
		 Div assignetoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ASSIGNTO_DIV");*/
		dataFieldHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATAFIELDH_LBL");
		valueHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUEH_LBL");
		taskNameHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKNAMEH_LBL");
		tasktypeHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKTYPEH_LBL");
		taskStateHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKSTATEH_LBL");
		assignetoHLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSIGNTOH_LBL");

		etaLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ETA_LBL");
		etaVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ETA_VLBL");
		workflowNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "WORKFLOWNAME_LBL");
		workflowNameVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "WORKFLOWNAME_VLBL");
		startDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STARTDATE_LBL");
		startDateVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STARTDATE_VLBL");
		statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		statusVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VLBL");
		progressLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PROGRESS_LBL");
		progressVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PROGRESS_VLBL");
		progressInfo = new ProgressBar();
		progressInfo.setMin(0);
		progressInfo.addClassName(SCREENCD+"_PROGRESS_BAR");
		//roundProgressBar = new UIRoundProgressBar();
		closeBtn = UIFieldFactory.createButton(SCREENCD, "CLOSE_BTN");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);
		footerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_DIV");
		footerDiv.add(closeBtn);
		/*dataFieldHDiv.add(dataFieldHLbl);
		 valueHDiv.add(valueHLbl);*/
		datadescSectionHeader.add(dataFieldHLbl,valueHLbl);
		datadescSection.add(datadescSectionHeader);
		/*taskNameDiv.add(taskNameHLbl);
		 tasktypeDiv.add(tasktypeHLbl);
		 taskStateDiv.add(taskStateHLbl);
		 assignetoDiv.add(assignetoHLbl);*/
		taskSectionHeader.add(taskNameHLbl,tasktypeHLbl,taskStateHLbl,assignetoHLbl);
		taskSection.add(taskSectionHeader);
		retrieveWorkflowDetails();

		Div etaDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ETA_DIV");
		etaDiv.add(etaLbl);
		Div etaVDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ETA_V_DIV");
		etaVDiv.add(etaVLbl);

		Div startDateDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "START_DATE_DIV");
		startDateDiv.add(startDateLbl);
		Div startDateVDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "START_DATE_V_DIV");
		startDateVDiv.add(startDateVLbl);

		Div workFlowNamDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "WORK_FLOW_DIV");
		workFlowNamDiv.add(workflowNameLbl);
		Div workFlowNamVDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "WORK_FLOW_DIV");
		workFlowNamVDiv.add(workflowNameVLbl);

		Div statusDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "STATUS_DIV");
		statusDiv.add(statusLbl);
		Div statusVDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "STATUS_V_DIV");
		statusVDiv.add(statusVLbl);

		Div progressDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PROGRESS_DIV");
		progressDiv.add(progressInfo/*roundProgressBar*/);
		Div progressVDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PROGRESS_V_DIV");
		progressVDiv.add(progressVLbl);

		div1.add(workFlowNamDiv, workFlowNamVDiv);
		div2.add(startDateDiv, startDateVDiv);
		div3.add(statusDiv, statusVDiv);
		div4.add(etaDiv, etaVDiv);
		div5.add(progressDiv, progressVDiv);

		hrow.add(div1, div2, div3, div4, div5);

		summaryTabs = new Tabs();
		summaryTabs.addClassName("TAB_STYLE");
		dataTab = UIOrderedLayoutFactory.createTab(SCREENCD,"DATA_TAB");
		TasksTab = UIOrderedLayoutFactory.createTab(SCREENCD,"TASKS_TAB");

		summaryTabs.add(dataTab, TasksTab);
		dataDetails.setVisible(true);
		taskDetails.setVisible(false);

		//		 InstanceInfo1_HL.add(instanceIdLbl,instanceIdVLbl,startDateLbl,startDateVLbl);
		//		 InstanceInfo2_HL.add(workflowNameLbl,workflowNameVLbl,statusLbl,statusVLbl);
		dataDetails.add(datadescSection);
		taskDetails.add(taskSection);
		instanceSection.add(hrow);
		InstanceInfo3_HL.add(dataDetails,taskDetails);
		displayDiv.add(instanceSection, summaryTabs, InstanceInfo3_HL);
		mainLayoutDiv.add(titleBar,displayDiv, footerDiv);
		add(mainLayoutDiv);

		closeBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() 
		{

			private static final long serialVersionUID = 1L;
			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();

			}
		});

		summaryTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {

			private static final long serialVersionUID = 1L;
			private Tab selectedTab;
			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				selectedTab = event.getSelectedTab();
				if(selectedTab.equals(dataTab)) {
					dataDetails.setVisible(true);
					taskDetails.setVisible(false);
				}else if(selectedTab.equals(TasksTab)) {
					dataDetails.setVisible(false);
					taskDetails.setVisible(true);
				}

			}
		});

		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

	}

	public void retrieveWorkflowDetails()
	{
		String strJsonWorkflow = "";
		try
		{
			strJsonWorkflow = this.str_JsonWorkFlow;
			//System.out.println("JsonWorkflow>>>>"+strJsonWorkflow);
			//strJsonWorkflow = "{\"instanceId\":\"7788425362\",\"partition\":\"rocketin0068\",\"engine\":\"Workflow\",\"workflow\":\"customer_verification\",\"state\":\"Started\",\"dataDesc\":[{\"fieldName\":\"Address\",\"fieldType\":\"STRING\",\"fieldData\":\"Lake Town, Kolkata, 700156\"},{\"fieldName\":\"DOB\",\"fieldType\":\"DATE\",\"fieldData\":\"01-Jan-2002\"},{\"fieldName\":\"CreditLimit\",\"fieldType\":\"DOUBLE\",\"fieldData\":\"0\"},{\"fieldName\":\"CIN\",\"fieldType\":\"LONG\",\"fieldData\":\"6666\"},{\"fieldName\":\"VIP\",\"fieldType\":\"BOOLEAN\",\"fieldData\":\"false\"},{\"fieldName\":\"Age\",\"fieldType\":\"INTEGER\",\"fieldData\":\"20\"}],\"maxDurationSecs\":0,\"startTimeStamp\":1641042945000,\"priority\":100,\"tasks\":[{\"taskName\":\"Verify Address\",\"taskType\":\"Manual\",\"taskState\":\"Finished\",\"manualTaskState\":\"Accepted\",\"assignedTo\":[],\"editableFieldNames\":[\"Address\"],\"attributes\":{\"Address\":\"Lake Town, Kolkata, 700156\",\"Customer Number\":\"6666\",\"VIP\":\"false\",\"URL\":\"http://172.16.210.210:7701/partnerportal/customerdetail?CIN=6666\"},\"parentTasks\":[],\"parentInstanceId\":\"\",\"critical\":true,\"taskDurationSecs\":0},{\"taskName\":\"Verify Documents\",\"taskType\":\"Manual\",\"taskState\":\"Finished\",\"manualTaskState\":\"Accepted\",\"assignedTo\":[],\"editableFieldNames\":[\"DOB\",\"Age\",\"VIP\"],\"attributes\":{\"Address\":\"Lake Town, Kolkata, 700156\",\"Customer Number\":\"6666\",\"VIP\":\"false\",\"URL\":\"http://172.16.210.210:7701/partnerportal/customerdetail?CIN=6666\"},\"parentTasks\":[\"Verify Address\"],\"parentInstanceId\":\"\",\"critical\":true,\"taskDurationSecs\":0},{\"taskName\":\"Verify CreditScore\",\"taskType\":\"Manual\",\"taskState\":\"Started\",\"manualTaskState\":\"Accepted\",\"assignedTo\":[\"rocketin0068\"],\"editableFieldNames\":[\"CreditLimit\"],\"attributes\":{\"Customer Number\":\"6666\",\"Customer Adress\":\"Lake Town, Kolkata, 700156\",\"VIP\":\"false\",\"URL\":\"http://172.16.210.210:7701/partnerportal/customerdetail?CIN=6666\"},\"parentTasks\":[\"Verify Documents\"],\"parentInstanceId\":\"\",\"critical\":true,\"taskDurationSecs\":0}]}";
			JSONObject j_ObjworkflowJSON = new JSONObject(strJsonWorkflow);
			if (j_ObjworkflowJSON.has("instanceId") && j_ObjworkflowJSON.getString("instanceId")!=null && j_ObjworkflowJSON.getString("instanceId").length()>0) {
				instanceId = j_ObjworkflowJSON.getString("instanceId");
				TitleLbl.setText(TitleLbl.getText().replaceAll("@@INSTANCEID@@", instanceId));
			} 

			//JSONObject j_ObjInstanceJSON = j_ObjworkflowJSON.getJSONObject("instanceId");
			/*String strInstanceId = instanceIdVLbl.getText();
				strInstanceId = strInstanceId.replaceAll("@@INSTANCEID@@", j_ObjworkflowJSON.getString("instanceId"));
				instanceIdVLbl.setText(strInstanceId);*/
			int etaVal = 0;
			if (j_ObjworkflowJSON.has("etaSecs") && j_ObjworkflowJSON.getString("etaSecs")!=null && j_ObjworkflowJSON.getString("etaSecs").length()>0) 
				etaVal = Integer.parseInt(j_ObjworkflowJSON.getString("etaSecs"));
			//etaTimeStamp = etaTimeStamp.replaceAll("@@ETA@@", etaVal);
			Date sysDate = new Date();
			//System.out.println("sysDate="+sysDate);
			Format etaFormat = new SimpleDateFormat("dd-MMM-YYYY HH:mm:ss");
			//etaTimeStamp = format.format(eta);
			Calendar gcal = new GregorianCalendar();
			gcal.setTime(sysDate);
			gcal.add(Calendar.SECOND, etaVal);


			String strStartTimeStamp = startDateVLbl.getText();
			if (j_ObjworkflowJSON.has("startTimeStamp") && j_ObjworkflowJSON.getString("startTimeStamp")!=null && j_ObjworkflowJSON.getString("startTimeStamp").length()>0) {
				strStartTimeStamp = strStartTimeStamp.replaceAll("@@STARTDATE@@", j_ObjworkflowJSON.getString("startTimeStamp"));
				Date date = new Date(Long.parseLong(strStartTimeStamp));
				Format format = new SimpleDateFormat("dd-MMM-YYYY HH:mm:ss");
				strStartTimeStamp = format.format(date);
				etaVLbl.setText(format.format(gcal.getTime()));
			} 	
			else
			{
				strStartTimeStamp = "-";
			}
			startDateVLbl.setText(strStartTimeStamp);

			String strWorkflow = workflowNameVLbl.getText();
			if (j_ObjworkflowJSON.has("workflow") && j_ObjworkflowJSON.getString("workflow")!=null && j_ObjworkflowJSON.getString("workflow").length()>0) 
				strWorkflow = strWorkflow.replaceAll("@@WORKFLOWNAME@@", j_ObjworkflowJSON.getString("workflow"));
			else
				strWorkflow = "-";
			workflowNameVLbl.setText(strWorkflow);

			String strStatus = statusVLbl.getText();
			if (j_ObjworkflowJSON.has("state") && j_ObjworkflowJSON.getString("state")!=null && j_ObjworkflowJSON.getString("state").length()>0) 
				strStatus = strStatus.replaceAll("@@STATUS@@", j_ObjworkflowJSON.getString("state"));
			else
				strStatus = "-";			
			statusVLbl.setText(strStatus);
			//String etaTimeStamp = etaVLbl.getText();


			JSONObject jaDataTemplate = j_ObjworkflowJSON.getJSONObject("dataTemplate");
			Iterator<String> paramKeysIterator = jaDataTemplate.keys();
			//System.out.println("jaDataTemplate="+jaDataTemplate.toString());
			while (paramKeysIterator.hasNext()) {
				dataDescRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DATADESC_ROW_DIV");
				dataFieldLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATAFIELD_LBL");
				valueLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				String paramKey = paramKeysIterator.next();
				//System.out.println("paramKey="+paramKey);
				JSONObject paramValJson = new JSONObject();
				//String landlordId = "";
				String strFieldName = "";
				String valueString = "";
				strFieldName = dataFieldLbl.getText();
				strFieldName = strFieldName.replaceAll("@@DATAFIELD@@", paramKey);
				dataFieldLbl.setText(strFieldName);

				/*String strFieldData = valueLbl.getText();
				strFieldData = strFieldData.replaceAll("@@VALUE@@", json.getString("fieldData"));*/
				dataDescRowDiv.add(dataFieldLbl);
				if(jaDataTemplate.has(paramKey) && jaDataTemplate.getJSONObject(paramKey)!=null && jaDataTemplate.getJSONObject(paramKey).length()>0);
				{
					paramValJson = jaDataTemplate.getJSONObject(paramKey);
					JSONObject valueStringJson = new JSONObject();


					if (paramValJson.has("valueString") && paramValJson.getString("valueString")!=null && paramValJson.getString("valueString").length()>0) 
					{	
						valueString = paramValJson.getString("valueString");
					}
					//System.out.println("valueString="+valueString);
					if (paramKey.equalsIgnoreCase("SiteCode")) {
						landlordId = valueString;
					}
					if (paramValJson.has("contentType") && paramValJson.getString("contentType")!=null && paramValJson.getString("contentType").length()>0 && 
							paramValJson.getString("contentType").trim().equalsIgnoreCase("File") && valueString.startsWith("{")) {

						//System.out.println("valueStringJson="+valueStringJson);
						String fileName = "";
						valueStringJson = new JSONObject(valueString);
						if (valueStringJson==null || valueStringJson.length()==0 || !valueStringJson.has("filename")|| valueStringJson.getString("filename")==null || valueStringJson.getString("filename").trim().length()==0) {
							fileName = "";
						} else {
							//System.out.println("valueStringJson[filename]="+valueStringJson.getString("filename"));
							fileName = valueStringJson.getString("filename");
							String fileContent = valueStringJson.getString("content");
							//System.out.println("landlordId="+landlordId);
							dataDescRowDiv.add(setFileIcon(paramValJson.getString("fileType"), fileName, fileContent));
						}					
					} 
					else {
						valueLbl.setText(valueString);
						dataDescRowDiv.add(valueLbl);
					}
				}		
				datadescSection.add(dataDescRowDiv);
			}

			JSONArray jaTask = new JSONArray();
			if (j_ObjworkflowJSON.has("tasks") && j_ObjworkflowJSON.get("tasks")!=null ) 
				jaTask = (JSONArray) j_ObjworkflowJSON.get("tasks");
			int maxVal = 0;
			int progress = 0;
			for (int i = 0; i < jaTask.length(); i++) 
			{

				JSONObject json = jaTask.getJSONObject(i);
				taskRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TASK_ROW_DIV");
				taskNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKNAME_LBL");
				String strTaskName = taskNameLbl.getText();
				if (json.has("taskName") && json.getString("taskName")!=null && json.getString("taskName").length()>0) 
					strTaskName = strTaskName.replaceAll("@@TASKNAME@@", json.getString("taskName"));
				else
					strTaskName = "-";
				taskNameLbl.setText(strTaskName);
				tasktypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKTYPE_LBL");
				String strTaskType = tasktypeLbl.getText();
				if (json.has("taskType") && json.getString("taskType")!=null && json.getString("taskType").length()>0) 
					strTaskType = strTaskType.replaceAll("@@TASKTYPE@@", json.getString("taskType"));
				else
					strTaskType = "-";	
				tasktypeLbl.setText(strTaskType);
				taskStateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TASKSTATE_LBL");
				String strTaskState = taskStateLbl.getText();
				if (json.has("taskState") && json.getString("taskState")!=null && json.getString("taskState").length()>0) 
					strTaskState = strTaskState.replaceAll("@@TASKSTATE@@", json.getString("taskState"));
				else
					strTaskState = "-";			
				taskStateLbl.setText(strTaskState);
				assignetoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSIGNTO_LBL");
				String strAssignedTo = assignetoLbl.getText();
				if (json.has("assignedTo") && json.getString("assignedTo")!=null && json.getString("assignedTo").length()>0) 
					strAssignedTo = strAssignedTo.replaceAll("@@ASSIGNTO@@", json.getString("assignedTo"));
				else
					strAssignedTo = "-";			
				if(strAssignedTo.contains("\""))
				{
					strAssignedTo = strAssignedTo.substring(0,strAssignedTo.lastIndexOf("\""));
					strAssignedTo = strAssignedTo.substring(strAssignedTo.indexOf("\"")+1,strAssignedTo.length());
				}
				else
				{
					strAssignedTo = strAssignedTo.substring(0,strAssignedTo.lastIndexOf("]"));
					strAssignedTo = strAssignedTo.substring(strAssignedTo.indexOf("]")+2,strAssignedTo.length());
				}
				assignetoLbl.setText(strAssignedTo);
				taskRowDiv.add(taskNameLbl,tasktypeLbl,taskStateLbl,assignetoLbl);
				taskSection.add(taskRowDiv);
				maxVal++;
				if (json.has("taskState") && json.getString("taskState")!=null && json.getString("taskState").length()>0 && json.getString("taskState").trim().equalsIgnoreCase("Finished")) {
					progress++;
				}
			}
			progressInfo.setMax(maxVal);
			progressInfo.setValue(progress);
			/*int progressPercentage = (progress/maxVal)*100;
			roundProgressBar.setProgress(progressPercentage);*/
			progressVLbl.setText(progress + " of " + maxVal + " tasks completed");

		}
		catch(Exception e) 
		{
			e.printStackTrace();
			this.close();
			e.getMessage().toString();
		}

	}

	private Div setFileIcon(String fileType, String filename, String filecontent)
	{
		Div fileDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILE_ICON_DIV");
		Image fileIcon = null;
		if (filename!=null && filename.trim().length()>0)
		{
			String fileExtension = filename.substring(filename.lastIndexOf(".") + 1);
			if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
			{
				//Div imageThumbnailDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "IMAGE_THUMBNAIL_DIV");
				ThumbnailImage img = new ThumbnailImage(filecontent);
				fileDiv.add(img.displayFileImage());
			}
			else
			{
				switch (fileType.toUpperCase()) {
				case "IMAGE":
					fileIcon = UIHtmlFieldFactory.createImage(SCREENCD, "FILE_IMAGE_ICON");
					break;
				case "TEXT":
					fileIcon = UIHtmlFieldFactory.createImage(SCREENCD, "FILE_DOC_ICON");
					break;
				case "DOCUMENT":
					fileIcon = UIHtmlFieldFactory.createImage(SCREENCD, "FILE_DOC_ICON");
					break;
				default:
					fileIcon = UIHtmlFieldFactory.createImage(SCREENCD, "FILE_DEFAULT_ICON");
					break;
				}
				fileIcon.addClassName(SCREENCD+"_FILE_ICON");
				fileDiv.add(fileIcon);
			}
		}
		fileDiv.setTitle("Click here to view");
		fileDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {	
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				if (filename!=null && filename.trim().length()>0) {
					String url = VaadinServletRequest.getCurrent().getScheme() + "://"
							+ VaadinServletRequest.getCurrent().getServerName() + ":"
							+ VaadinServletRequest.getCurrent().getServerPort() + "/"
							+ VaadinServletRequest.getCurrent().getContextPath() + "/landlordviewworkflowparamfile";
					//System.out.println("url landlordId="+landlordId);
					url = url + "?LandlordId=" + landlordId + "&InstanceId=" + instanceId + "&Status=" + status + "&Filename=" + filename;
					UI.getCurrent().getPage().open(url);
				}
			}
		});


		return fileDiv;
	}


}   
