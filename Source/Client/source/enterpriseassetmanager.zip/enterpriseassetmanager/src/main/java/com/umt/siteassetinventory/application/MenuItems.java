package com.umt.siteassetinventory.application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.umt.siteassetinventory.application.ApplicationConstants.Menu;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.server.VaadinServletRequest;

@CssImport("./styles/menu_item-styles.css")
public class MenuItems extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "MENU_ITEM";
	private boolean menuItemOrderingVertical;
	private Component menuIcon, menuIconActive;
	private String menuName;
	private String navTarget;
	private QueryParameters queryParams;
	private boolean externalTarget; 
	private boolean selected;
	private Label menuNameLbl;
	private Div menuDiv;
	private Div menuIconDiv;
	private Menu menu;

	public MenuItems() {
		menu = Menu.NullValue;
		renderMenu();
	}

	public MenuItems(Component menuIcon, String menuName, Menu menu, boolean menuItemOrderingVertical) {
		this.menuIcon = menuIcon;
		this.menuName = menuName;
		this.menu = menu;
		this.menuItemOrderingVertical = menuItemOrderingVertical;
		renderMenu();
	}

	public MenuItems(Component menuIcon, Component menuIconActive, String menuName, Menu menu, String navTarget, QueryParameters queryParams, boolean externalTarget,  boolean menuItemOrderingVertical) {
		this.menuIcon = menuIcon;
		this.menuIconActive = menuIconActive;
		this.menuName = menuName;
		this.menu = menu;
		this.navTarget = navTarget;
		this.queryParams = queryParams;
		this.externalTarget = externalTarget;
		this.menuItemOrderingVertical = menuItemOrderingVertical;
		renderMenu();
	}

	public Component getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(Component menuIcon) {
		this.menuIcon = menuIcon;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public String getNavTarget() {
		return navTarget;
	}

	public void setNavTarget(String navTarget) {
		this.navTarget = navTarget;
	}

	public QueryParameters getQueryParams() {
		return queryParams;
	}

	public void setQueryParams(QueryParameters queryParams) {
		this.queryParams = queryParams;
	}

	public boolean isExternalTarget() {
		return externalTarget;
	}

	public void setExternalTarget(boolean externalTarget) {
		this.externalTarget = externalTarget;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;

		if(isSelected()) {
			addClassName(SCREENCD + "_SELECTED");
			menuIconDiv.removeAll();
			menuIconDiv.add(menuIconActive);
		}
		else {

			removeClassName(SCREENCD + "_SELECTED");
			menuIconDiv.removeAll();
			menuIconDiv.add(menuIcon);

		}
	}
	public void setIcon(Image img) {
		menuIconDiv.removeAll();
		menuIconDiv.add(img);
	}

	private void renderMenu() {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		menuDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		menuIconDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MENU_ICON_DIV");
		menuNameLbl = UIHtmlFieldFactory.createLabel(menuName, SCREENCD, "MENU_NAME_LBL");

		if(menuIcon == null) {
			menuIcon = FontAwesome.Regular.ARROW_ALT_CIRCLE_RIGHT.create();
		}
		if(isSelected()) {
			menuIconDiv.add(menuIconActive);
		}else if(!isSelected()){
			menuIconDiv.add(menuIcon);
		}


		menuDiv.add(menuIconDiv, menuNameLbl);
		add(menuDiv);

		if(menuItemOrderingVertical) {
			addClassName(SCREENCD + "_MAIN_LAYOUT_ORDER_VERTICAL");
			menuDiv.addClassName(SCREENCD + "_CONTAINER_DIV_ORDER_VERTICAL");
			menuIconDiv.addClassName(SCREENCD + "_MENU_ICON_DIV_ORDER_VERTICAL");
			menuNameLbl.addClassName(SCREENCD + "_MENU_NAME_LBL_ORDER_VERTICAL");
		}

		addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//In case of Horizontal Menu bar,
				//the menu selection will take place
				//through tab change
				if(menuItemOrderingVertical) {
					return;
				}
				menuClickHandler();
			}
		});
	}

	public void menuClickHandler() {
		if(navTarget == null || navTarget.trim().length() == 0) {
			return;
		}

		if(!externalTarget) {
			if(queryParams == null) {
				if (navTarget.trim().equalsIgnoreCase("usermanagement")) {
					String url = VaadinServletRequest.getCurrent().getScheme() + "://" +
							VaadinServletRequest.getCurrent().getServerName() + ":" +
							VaadinServletRequest.getCurrent().getServerPort() + "/" + "usermanagement";

					UI.getCurrent().getPage().open(url);
				}
				else if (navTarget.trim().equalsIgnoreCase("dynamicpage")) {
					HashMap<String, List<String>> queryParamMap = new HashMap<String, List<String>>();
					List<String> target = new ArrayList<String>();
					target.add(menuName.replace(" ", "_"));
					queryParamMap.put("target", target);
					System.out.println("queryParamMap="+queryParamMap.toString());
					
					QueryParameters queryParameter = new QueryParameters(queryParamMap);
					UI.getCurrent().navigate(navTarget, queryParameter);
				}
				else
					UI.getCurrent().navigate(navTarget);
			}
			else {
				UI.getCurrent().navigate(navTarget, queryParams);
			}
		}
		else {
			UI.getCurrent().getPage().setLocation(navTarget);
		}
		SiteAssetInventoryUIFramework.getFramework().showVerticalMenuBar(false);
	}
}
