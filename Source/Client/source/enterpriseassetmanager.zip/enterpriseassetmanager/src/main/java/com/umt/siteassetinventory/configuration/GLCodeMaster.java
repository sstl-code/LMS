package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.invoice.AddInvoiceDialog;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/glcode_master-styles.css")
public class GLCodeMaster extends Div{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "GLCODE_MASTER";

	private TextField filterFld;
	private Button addBtn;
	private Div tableContainerDiv;
	protected List<GLCodeMasterBean> beanList= new ArrayList<>();
	private ConfigView parent;

	public GLCodeMaster(ConfigView parent) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.parent = parent;
		Div filterDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILTER_DIV");
		filterFld = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_FLD");
		filterFld.setPlaceholder("Filter GL Codes..");
		addBtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");
		
		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		
		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);

		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, /*eachrowDiv3,*/ eachrowDiv4, eachrowDiv5);

		filterDiv.add(filterFld , addBtn);
		
		add(filterDiv, tableHeaderDiv, tableContainerDiv);

		addBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				AddOrEditGLCodeDlg dlg = new AddOrEditGLCodeDlg(parent,"Add");
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AddOrEditGLCodeDlg srcDlg = (AddOrEditGLCodeDlg)event.getSource();
						if(!srcDlg.isOpened() && srcDlg.success) {
							populateData();
						}
					}

				});
			}
		});
		
		filterFld.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				try {
				beanList.stream().filter(new Predicate<GLCodeMasterBean>() {

					@Override
					public boolean test(GLCodeMasterBean t) {
						String filterTxt = filterFld.getValue().trim();
						if (filterTxt == null || filterTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if (StringUtils.containsIgnoreCase(t.getIds(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getGLCode(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getDesc(), filterTxt)
								|| StringUtils.containsIgnoreCase(t.getStatus(), filterTxt)) {
							t.setVisible(true);
							return true;
						}
						t.setVisible(false);
						return false;
					}
				}).collect(Collectors.toList());
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		filterFld.setValueChangeMode(ValueChangeMode.EAGER);
		
		populateData();
	}
	
	protected void populateData() {
		tableContainerDiv.removeAll();
		beanList.clear();
		String response = getGLCodes();
	//	System.out.println("response ::::::: "+response+response.length());

		try {
			if(response!=null && response.length()>0) {
				JSONArray ja = new JSONArray(response);
				if(ja.length()>0) {
					for (int i = 0; i < ja.length(); i++) {
						JSONObject jo = ja.getJSONObject(i);
						GLCodeMasterBean bean = new GLCodeMasterBean(jo.getString("Id"),jo.getString("GLCode"), 
								jo.getString("Description"), jo.getString("Status"),this);
						
						beanList.add(bean);
						tableContainerDiv.add(bean);
					}
				}
				
				
				
			}

			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private String getGLCodes()
	{
		String response="";
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETGLCODE");
			//System.out.println(url);
			response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			System.out.println(url + " response ::::::: "+response);
		//	return response;
		} catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		//	return null;
		}		
		return response;
	}

}
