package com.umt.siteassetinventory.assets;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap;
import com.umt.siteassetinventory.framework.googlemap.CustomGoogleMap.CustomGoogleMapMarkerClickListener;
import com.umt.siteassetinventory.site.SiteListMapViewDialog;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.router.Route;

@Route(value = "assetsview", layout = MainView.class)
@CssImport("./styles/assets-view.css")
public class AssetsView extends BaseStructure implements AfterNavigationObserver,HasUrlParameter<String>{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSETS_VIEW";
	private AssetsView parent;
	private Tab detailsTab,attributesTab,LandlordTab,activeAssetTab,passiveAssetTab,historyTab,documentTab,ticketsTab;
	private Button addAssetsBtn;
	private Button viewMapBtn,applyBtn,clearMapBtn;
	private TextField applyRadiusField;
	private Checkbox mapViewChk;
	private Div assetListContainerDiv;
	private List<AssetsViewDataBean> assetbeanList=new ArrayList<AssetsViewDataBean>();
	private String selectedAssetId,searchCriteria,searchcriteria2="";
	public String assetlistresponse;
	public String route="";
	private AssetDetailsTab assetdetailsTabVL;
	private AssetAttributesTab assetattributesTabVL;
	private AssetHistoryTab historyTabVL;
	private AssetDocumentsTab documentsTabVL;
	private TicketsTab ticketsTabVL;
	private int  StoreSerialNo=-1,VendorId=-1,StoreId=-1,StatusId=-1, EquipmentTypeId=-1,StoreLocId=-1,EquipmentSerialNo=-1;
	private Map<String, List<String>> parameterMap;
	private String paramAssetId;
	private Div detailsTabHolder, assestTabHolder;
	private String equ_id;

	private AssetListMapView mapView;
	private Div mapviewDiv1,mapviewDiv;
	public boolean isMapVisible=false;
	private String mapassetId1;
	private String str1,str2;
	private JSONArray sortedjsArr;

	private Label col2Lbl1,col2Lbl2;
	private String col2Lbl1Str,col2Lbl2Str;

	private Div idiv1,idiv2;
	private Div idiv3,idiv4;
	private Div idiv5,idiv6;
	private Icon caret_down1,caret_down2,caret_down3;
	private Icon caret_up1,caret_up2,caret_up3;
	private String sortedListResponse;

	private Div historyTabHolder, documentTabHolder,ticketsTabHolder;
	
	private CustomGoogleMap googleMapComponent;
	private JSONArray markerJSONArray = new JSONArray();
	private String lat,longi;
	private ComboBox<String> radiusUnitCombo;
	private Div noRecordDiv,noRecordDiv2;
	private Div recordcontainerDiv;
	private LocalDate date1,date2;
	private String allVendors;
	
	private String paramequipmentId;

	public AssetsView() 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		parent=this;
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Assets View");
		//	getAssetsViewobj(parent);

		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAIL_TAB_LBL"));
		attributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ATTR_TAB_LBL"));
		LandlordTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "LANDLORD_TAB_LBL"));
		historyTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "HISTORY_TAB_LBL"));
		activeAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ACTIVE_ASSET_TAB_LBL"));
		passiveAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PASSIVE_ASSET_TAB_LBL"));
		documentTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DOCUMENTS_TAB_LBL"));
		ticketsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TICKETS_TAB_LBL"));

		parentTabs.add(detailsTab,attributesTab,/*activeAssetTab,passiveAssetTab,LandlordTab*/historyTab,documentTab,ticketsTab);
		add(rowDiv);

		detailsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_TAB_DIV");
		assestTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTES_TAB_DIV");

		historyTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "HISTORY_TAB_DIV");
		documentTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "DOC_TAB_DIV");
		ticketsTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "TICKETS_TAB_DIV");
		
		noRecordDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
		noRecordDiv2.setVisible(false);
		recordcontainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RECORD_DIV");
		recordcontainerDiv.setVisible(true);



		//	detailsTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_TAB_DIV");
		//	assestTabHolder = UIHtmlFieldFactory.createDiv(SCREENCD, "ATTRIBUTES_TAB_DIV");
		allVendors = getVendors();

		assetdetailsTabVL=new AssetDetailsTab(parent);
//		assetattributesTabVL=new AssetAttributesTab();
		
		historyTabVL=new AssetHistoryTab();
		documentsTabVL=new AssetDocumentsTab();
		ticketsTabVL=new TicketsTab();

		createHeader();
		//	populateAssetsDetailRow(searchcriteria2);
		populateAssetsDetailRow2(searchcriteria2);
		generateMarkerData(assetlistresponse);



		parentTabs.setSelectedTab(detailsTab);
		assetdetailsTabVL.setVisible(true);
		//	addDetailsTab();

		//	col2ValueDiv.removeAll();
		//	col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
		//	assetattributesTabVL.setVisible(false);
		assetdetailsTabVL.setVisible(true);
		/*	historyTabVL.setVisible(false);
		documentsTabVL.setVisible(false);
		ticketsTabVL.setVisible(false);*/
		assetdetailsTabVL.setAssetId(getSelectedAssetId());

		//	historyTabHolder.setVisible(false);
		//	documentTabHolder.setVisible(false);
		//	ticketsTabHolder.setVisible(false);
		
		recordcontainerDiv.add(detailsTabHolder, assestTabHolder,historyTabHolder, documentTabHolder,ticketsTabHolder);
		col2ValueDiv.add(/*detailsTabHolder, assestTabHolder,historyTabHolder, documentTabHolder,ticketsTabHolder*/recordcontainerDiv,noRecordDiv2);

		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) {
				/*	col2ValueDiv.removeAll();
					detailsTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "DETAILS_TAB_DIVV");
					col2ValueDiv.add(detailsTabHolder);
					addDetailsTab();*/
					
					
					detailsTabHolder.setVisible(true);
					assestTabHolder.setVisible(false);
					assetdetailsTabVL.setVisible(true);
					assetdetailsTabVL.setAssetId(getSelectedAssetId());
					assetdetailsTabVL.setAssetObj(parent);
					col2ValueDiv.removeAll();
					col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(getSelectedAssetId()));
					historyTabVL.setVisible(false);
					documentsTabVL.setVisible(false);
					ticketsTabVL.setVisible(false);
					historyTabHolder.setVisible(false);
					documentTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					//					addDetailsTab();
				} else if(event.getSelectedTab().equals(attributesTab)) {
					assetdetailsTabVL.setVisible(false);
					detailsTabHolder.setVisible(false);
					col2ValueDiv.removeAll();
					col2ValueDiv.add(assestTabHolder);
					assestTabHolder.setVisible(true);
				//	System.out.println("equ_id="+equ_id);
					addAttributesTab(equ_id, selectedAssetId);
					historyTabVL.setVisible(false);
					documentsTabVL.setVisible(false);
					ticketsTabVL.setVisible(false);
					historyTabHolder.setVisible(false);
					documentTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
				} else if(event.getSelectedTab().equals(historyTab)) {
					col2ValueDiv.removeAll();
					historyTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "HISTORY_TAB_DIV");
					col2ValueDiv.add(/*historyTabVL*/historyTabHolder);
					addHistory();

					assetdetailsTabVL.setVisible(false);
					assetattributesTabVL.setVisible(false);
					assetdetailsTabVL.setVisible(false);
					historyTabVL.setVisible(true);
					historyTabHolder.setVisible(true);

					//historyTabVL.setAssetId(getSelectedAssetId()/*"7"*/);
					//	historyTabVL.loadAssets();
					documentsTabVL.setVisible(false);
					ticketsTabVL.setVisible(false);
					
					documentTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					assestTabHolder.setVisible(false);
					
					
				} else if(event.getSelectedTab().equals(documentTab)) {
					
					col2ValueDiv.removeAll();
					documentTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENTS_TAB_DIV");
					col2ValueDiv.add(documentTabHolder);	
					addDocuments();
					
					assetdetailsTabVL.setVisible(false);
					assetattributesTabVL.setVisible(false);
					assetdetailsTabVL.setVisible(false);
					historyTabVL.setVisible(false);
					documentsTabVL.setVisible(true);
					documentTabHolder.setVisible(true);
					
					//	documentsTabVL.loadAssetDocumentScreen(getSelectedAssetId());
					ticketsTabVL.setVisible(false);
					historyTabHolder.setVisible(false);
					ticketsTabHolder.setVisible(false);
					assestTabHolder.setVisible(false);
					
				} else if(event.getSelectedTab().equals(ticketsTab)) {
					
					col2ValueDiv.removeAll();
					ticketsTabHolder= UIHtmlFieldFactory.createDiv(SCREENCD, "TICKETS_TAB_DIV");
					col2ValueDiv.add(/*ticketsTabVL*/ticketsTabHolder);	
					addTickets();
					
					assetdetailsTabVL.setVisible(false);
					assetattributesTabVL.setVisible(false);
					assetdetailsTabVL.setVisible(false);
					historyTabVL.setVisible(false);
					documentsTabVL.setVisible(false);
					ticketsTabVL.setVisible(true);
					ticketsTabHolder.setVisible(true);
					//ticketsTabVL.setAssetId(getSelectedAssetId());
					
					
					
				//	ticketsTabVL.displayWorkflows();
					historyTabHolder.setVisible(false);
					documentTabHolder.setVisible(false);
					assestTabHolder.setVisible(false);
					
					
				}
			}
		});
	}

	protected void addHistory() {
		try
		{
			historyTabHolder.removeAll();
			historyTabVL=new AssetHistoryTab();
			historyTabVL.setAssetId(getSelectedAssetId());
			historyTabVL.loadAssets();
			historyTabHolder.add(historyTabVL);
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
	}

	protected void addDocuments() {
		try
		{
			documentTabHolder.removeAll();
			documentsTabVL=new AssetDocumentsTab();
			documentsTabVL.loadAssetDocumentScreen(getSelectedAssetId());
			documentTabHolder.add(documentsTabVL);
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}

	protected void addTickets()
	{
		try
		{
			ticketsTabHolder.removeAll();
			ticketsTabVL=new TicketsTab();
			ticketsTabVL.setAssetId(getSelectedAssetId());
			//ticketsTabVL.displayWorkflows();
			ticketsTabHolder.add(ticketsTabVL);
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}

	public void addDetailsTab() {
		detailsTabHolder.removeAll();
		assetdetailsTabVL=new AssetDetailsTab(parent);
		detailsTabHolder.add(assetdetailsTabVL.populateAssetDetails(getSelectedAssetId()));
		getEquipmentId();
		//	System.out.println("Equid: " + getEquipmentId());


	}
	public void addAttributesTab(String eq_id, String assetID) {
		this.equ_id = eq_id;
		assestTabHolder.removeAll();
		assetattributesTabVL=new AssetAttributesTab(eq_id, assetID, this);
		assestTabHolder.add(assetattributesTabVL);
	}

	private void createHeader()
	{

		// mapView=new SiteListMapView(null,this);
	/*	mapView=new AssetListMapView(this);
		mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");

		mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
		mapviewDiv.add(mapView);
		mapviewDiv1.add(mapviewDiv);
		mapView.setVisible(false);
		mapviewDiv1.setVisible(false);*/
		
		assetListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
		noRecordDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
		noRecordDiv.setVisible(false);
		
		lat=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
		longi=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
		
		
		mapviewDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV1");
		mapviewDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "MAP_VIEW_DIV");
		mapviewDiv1.add(mapviewDiv);
		mapviewDiv1.setVisible(false);

		Div eachDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");

		Label headerLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
		eachDiv1.add(headerLbl1);

		Image viewmapImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_MAP_IMAGE");
		eachDiv3.add(viewmapImg);

		addAssetsBtn = UIFieldFactory.createButton(SCREENCD, "ADD_ASSETS_BTN");
		eachDiv4.add(addAssetsBtn);

		col1HeaderDiv.add(eachDiv1,/*eachDiv3,*/eachDiv4);

		Div headerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_HEADER_DIV");

		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");

		idiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up1=VaadinIcon.CARET_UP.create();
		caret_up1.addClassName("CARET_UP");
		idiv1.add(caret_up1);
		idiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down1=VaadinIcon.CARET_DOWN.create();
		caret_down1.addClassName("CARET_DOWN");
		idiv2.add(caret_down1);
		Div IconDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv1.add(idiv1,idiv2);


		idiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up2=VaadinIcon.CARET_UP.create();
		caret_up2.addClassName("CARET_UP");
		idiv3.add(caret_up2);
		idiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down2=VaadinIcon.CARET_DOWN.create();
		caret_down2.addClassName("CARET_DOWN");
		idiv4.add(caret_down2);
		Div IconDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv2.add(idiv3,idiv4);

		idiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_up3=VaadinIcon.CARET_UP.create();
		caret_up3.addClassName("CARET_UP");
		idiv5.add(caret_up3);
		idiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "I_DIV");
		caret_down3=VaadinIcon.CARET_DOWN.create();
		caret_down3.addClassName("CARET_DOWN");
		idiv6.add(caret_down3);
		Div IconDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "ICON_DIV");
		IconDiv3.add(idiv5,idiv6);

		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachdataDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachdataDiv2.add(lbl2,IconDiv1);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachdataDiv3.add(lbl3,IconDiv2);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachdataDiv4.add(lbl4,IconDiv3);

		headerDiv.add(/*eachdataDiv1,*/eachdataDiv2,eachdataDiv3,eachdataDiv4);

		Div searchListDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_DIV");
		Div searchListRowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV1");
		Div searchListRowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_LIST_ROW_DIV2");

		viewMapBtn= UIFieldFactory.createButton(SCREENCD, "VIEW_MAP_BTN");
		applyBtn= UIFieldFactory.createButton(SCREENCD, "APPLY_BTN");
		clearMapBtn= UIFieldFactory.createButton(SCREENCD, "CLOSE_BTN");
		applyRadiusField= UIFieldFactory.createTextField("", false, SCREENCD,"APPLY_RADIUS_FIELD");
		applyRadiusField.setPlaceholder("Type radius");
		mapViewChk = UIFieldFactory.createCheckbox(false, false, SCREENCD, "MAP_VIEW");
		mapViewChk.setEnabled(false);
		
		ArrayList<String> unitList=new ArrayList<String>();
		unitList.clear();
		String units[] = { "m","km","miles"};
		for (int i = 0; i < units.length; i++) {
			unitList.add(units[i]);
		}
		radiusUnitCombo = UIFieldFactory.createComboBox(unitList, false, SCREENCD, "UNIT_COMBO_FIELD");
		radiusUnitCombo.setPlaceholder("units");
		radiusUnitCombo.setEnabled(false);
		
		Div radiusDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "RADIUS_DIV");
		radiusDiv.add(applyRadiusField,radiusUnitCombo);

		searchListRowDiv1.add(mapViewChk,viewMapBtn);
		searchListRowDiv2.add(/*locationimgDiv,applyRadiusField*/radiusDiv,applyBtn,clearMapBtn);
		searchListRowDiv2.setVisible(false);

		searchListDiv.add(searchListRowDiv1,searchListRowDiv2);

	//	assetListContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITE_LIST_CONTAINER_DIV");
		col1ValueDiv.add(searchListDiv,mapviewDiv1,headerDiv,assetListContainerDiv,noRecordDiv);
		
		applyRadiusField.setValueChangeMode(ValueChangeMode.EAGER);
		
		applyRadiusField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) 
			{
				if (applyRadiusField.getValue() == null || applyRadiusField.getValue().trim().length() <= 0) 
				{
					radiusUnitCombo.setEnabled(false);
				}
				if (applyRadiusField.getValue().trim().length() > 0) 
				{
					radiusUnitCombo.setEnabled(true);
				}
			}
		});


		viewMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
			/*	mapView.setVisible(true);
				mapView.populateAssetDetails(assetlistresponse);
				mapView.setSelectedSite(selectedAssetId);
				mapviewDiv.setVisible(true);
				mapviewDiv1.setVisible(true);
				isMapVisible=true;
				searchListDiv.setVisible(true);
				assetListContainerDiv.setVisible(false);
				headerDiv.setVisible(false);
				searchListRowDiv2.setVisible(true);
				headerLbl1.removeAll();
				headerLbl1.setText("Asset List-Map View");*/
				
				try {
					
					mapviewDiv.setVisible(true);
					mapviewDiv1.setVisible(true);
					isMapVisible=true;
					searchListDiv.setVisible(true);
					assetListContainerDiv.setVisible(false);
					headerDiv.setVisible(false);
					searchListRowDiv2.setVisible(true);
					headerLbl1.removeAll();
					headerLbl1.setText("Asset List-Map View");
					mapViewChk.setEnabled(false);
					applyRadiusField.clear();
					radiusUnitCombo.clear();
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					if (googleMapComponent == null) {
						googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 2,"assetlistmap");
						mapviewDiv.removeAll();
						mapviewDiv.add(googleMapComponent);

						googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onMapMarkerClick(String eventData) {
								//System.out.println("Event Data -->>" + eventData);
								try {
									JSONObject eventDataJSON = new JSONObject(eventData);
									String uniqueId = eventDataJSON.getString("event.detail");
									selectedRowChangeHandler(uniqueId);
									selectAssetViewNode(uniqueId);
									assetlistresponse = uniqueId;
									col2ValueDiv.removeAll();
									col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(uniqueId));
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});
					}
					googleMapComponent.setVisible(true);
					googleMapComponent.clearMapMarker();
					generateMarkerData(assetlistresponse);
					googleMapComponent.populateMarker(markerJSONArray);
				//	googleMapComponent.openInfoWindow(selectedAssetId);
					googleMapComponent.openInfoWindow2(selectedAssetId);
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		clearMapBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
			/*	mapView.setVisible(false);
				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				isMapVisible=false;
				searchListDiv.setVisible(true);
				assetListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Asset List");*/
				
				mapviewDiv.setVisible(false);
				mapviewDiv1.setVisible(false);
				searchListDiv.setVisible(true);
				isMapVisible=false;
			//	assetListContainerDiv.setVisible(true);
				headerDiv.setVisible(true);
				searchListRowDiv2.setVisible(false);
				headerLbl1.removeAll();
				headerLbl1.setText("Asset List");
				mapViewChk.setEnabled(false);
				mapViewChk.setValue(false);
				applyRadiusField.clear();
				radiusUnitCombo.clear();
				if(assetlistresponse!=null || !assetlistresponse.equalsIgnoreCase("[]"))
				{
					assetListContainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
				}
				if(assetlistresponse==null || assetlistresponse.equalsIgnoreCase("[]"))
				{
					assetListContainerDiv.setVisible(false);
					noRecordDiv.setVisible(true);
					noRecordDiv2.setVisible(true);
				//	col2HeaderDiv1.removeAll();
				}
			}
		});
		addAssetsBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) 
			{

				AddAssetsDialog dlg= new AddAssetsDialog(parent);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AddAssetsDialog srcDlg = (AddAssetsDialog)event.getSource();
						if(!srcDlg.isOpened()&& (srcDlg.isSuccess()==true)) 
						{
							populateAssetsDetailRow2(searchcriteria2);
						}
					}

				});
			}
		});
		
		applyBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				try 
				{
					if(applyRadiusField.getValue().toString().length()<=0)
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide radius", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if (radiusUnitCombo.getValue() == null) 
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide units", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if(applyRadiusField.getValue().toString().length()<=0 && radiusUnitCombo.getValue() == null)
					{
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please provide both radius and units", ApplicationConstants.DialogTypes.ERROR);
						return;
					}
					if(applyRadiusField.getValue().toString().length()>0)
					{
						String radius=calcRadius(applyRadiusField.getValue(),radiusUnitCombo.getValue());
						googleMapComponent.applyGeoFence(Double.parseDouble(radius));
						mapViewChk.setValue(true);
						mapViewChk.setEnabled(true);
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		mapViewChk.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) 
			{
				if(event.getValue().equals(false))
				{
					googleMapComponent.clearGeoFence();
					mapViewChk.setEnabled(false);
				}
				
			}
		});
		

		eachDiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) 
			{

				SiteListMapViewDialog dlg= new SiteListMapViewDialog(null,selectedAssetId,parent,null,"Asset_view");
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						SiteListMapViewDialog srcDlg = (SiteListMapViewDialog)event.getSource();
						if(!srcDlg.isOpened()) 
						{

						}
					}

				});
			}
		});

		idiv1.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByAssetType("descending");

				caret_up1.getStyle().set("color", "#0000ff87");
				caret_down1.getStyle().set("color", "#8080809e");

				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");
			}
		});
		idiv2.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByAssetType("ascending");

				caret_down1.getStyle().set("color", "#0000ff87");
				caret_up1.getStyle().set("color", "#8080809e");

				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");
			}
		});

		idiv3.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByEqSerialNo("descending");

				caret_up2.getStyle().set("color", "#0000ff87");
				caret_down2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});
		idiv4.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByEqSerialNo("ascending");

				caret_down2.getStyle().set("color", "#0000ff87");
				caret_up2.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down3.getStyle().set("color", "#8080809e");
				caret_up3.getStyle().set("color", "#8080809e");

			}
		});

		idiv5.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByCreationDate("descending");

				caret_up3.getStyle().set("color", "#0000ff87");
				caret_down3.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");

			}
		});
		idiv6.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				sortByCreationDate("ascending");

				caret_down3.getStyle().set("color", "#0000ff87");
				caret_up3.getStyle().set("color", "#8080809e");

				caret_down1.getStyle().set("color", "#8080809e");
				caret_up1.getStyle().set("color", "#8080809e");
				caret_down2.getStyle().set("color", "#8080809e");
				caret_up2.getStyle().set("color", "#8080809e");

			}
		});


	}
	protected String calcRadius(String rad, String unit) {
		
		String val="";
		switch(unit)
		{
		case "m":
			val=rad;
			break;
		case "km":
			double d=Double.parseDouble(rad)*1000;
			val=String.valueOf(d);
			break;
		case "miles":
			double v=Double.parseDouble(rad)*1609.34;
			val=String.valueOf(v);
			break;
		}
		return val;
	}

	public void populateAssetsDetailRow(String searchCriteria) 
	{

		try
		{
			String res="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCH_EQUIPMENTS");
			url=url+"?searchText="+searchCriteria;
			//		System.out.println("url1="+url);
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("asset_search_res:::"+res);


			//System.out.println("asset_res="+res);
			assetlistresponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						AssetsViewDataBean beanobj=new AssetsViewDataBean(
								jsarr.getJSONObject(i).getString("StoreSerialNo"),
								jsarr.getJSONObject(i).getString("EquipmentType"),
								jsarr.getJSONObject(i).getString("EquipmentSerialNo"),
								jsarr.getJSONObject(i).getString("CreationDate"),
								this);



						assetListContainerDiv.add(beanobj);
						assetbeanList.add(beanobj);
						if(i==0 && paramAssetId==null)
						{
							equ_id = beanobj.getTheFirstEquipmentID(jsarr.getJSONObject(i).getString("EquipmentType"));
							selectedAssetId=jsarr.getJSONObject(i).getString("StoreSerialNo");
							beanobj.getEachRowDiv().addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
							addDetailsTab();

							mapassetId1=jsarr.getJSONObject(i).getString("StoreSerialNo");
						}

					}
				}
				/*	if(jsarr.length()<0)
			{
				col2ValueDiv.removeAll();
				col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
			}*/
			}	
			if(isMapVisible==true)
			{
				//populateMapview(assetlistresponse);
				refreshGoogleMapview(assetlistresponse);
				assetListContainerDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				noRecordDiv.setVisible(false);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	public void selectedRowChangeHandler(String assetid) 
	{
		parentTabs.setSelectedTab(detailsTab);
		selectedAssetId=assetid;
		//	addDetailsTab();
		col2ValueDiv.removeAll();
		assetdetailsTabVL.setAssetId(selectedAssetId);
		assetdetailsTabVL.setAssetObj(parent);
		col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(getSelectedAssetId()));
		
	//	System.out.println("Param SiteCode:::"+paramAssetId);


		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) 
				{
					col2ValueDiv.removeAll();
					assetdetailsTabVL.setAssetId(selectedAssetId);
					col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(getSelectedAssetId()));


					//addDetailsTab();
				} else if(event.getSelectedTab().equals(attributesTab)) {
					assetattributesTabVL.setAssetId(selectedAssetId);
				}
			}
		});
	}


	public void deselectOtherRows(AssetsViewDataBean child2) 
	{
		for (int i = 0; i < assetbeanList.size(); i++) 
		{
			assetbeanList.get(i).deselectEachDiv(child2);
		}


	}

	public void setEquipmentId(String id) {
		equ_id = id;
	}
	private String getEquipmentId() {
		return equ_id;
	}


	public List<AssetsViewDataBean> getAssetBeanList() {
		return assetbeanList;
	}
	public String getSelectedAssetId()
	{
		return selectedAssetId;

	}

	@Override
	public void afterNavigation(AfterNavigationEvent event) {
		//	System.out.println("route="+event.getLocation().getPathWithQueryParameters());
		route=event.getLocation().getPathWithQueryParameters();
		if(route.equalsIgnoreCase("assetsview")|| route.contains("assetsview?StoreSerialNo="))
		{
			this.searchCriteria=searchcriteria2;
			getAssetsViewobj(parent);
		}

	}
	@Override
	public void setParameter(BeforeEvent event, @OptionalParameter String parameter) 
	{
		try
		{
			//equ_id
			List<String> paramValue = null;
			List<String> paramValue2 = null;
			Location location = event.getLocation();
			QueryParameters queryParameters = location.getQueryParameters();
			parameterMap = queryParameters.getParameters();
		//	System.out.println("parameterMap::"+parameterMap);
			if(parameterMap.size()>0)
			{
				paramValue = parameterMap.get("StoreSerialNo");
				paramValue2 = parameterMap.get("EquipmentId");
			//    System.out.println("paramValue="+paramValue);
				if(paramValue != null && paramValue.size() > 0 )
				{
					paramAssetId = paramValue.get(0);
				}
				if(paramValue2 != null && paramValue2.size() > 0 )
				{
					paramequipmentId=paramValue2.get(0);
				}
			//		System.out.println("paramsiteCode::"+paramAssetId);
				if(paramAssetId!=null)
				{
					//	populateAssetsDetailRow(paramAssetId);
					populateAssetsDetailRow1(paramAssetId);
					selectAssetViewNode(paramAssetId);
					selectedAssetId=paramAssetId;
					//	col2ValueDiv.removeAll();
					//	col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(paramAssetId));
					this.selectedAssetId=paramAssetId;
					selectedRowChangeHandler(paramAssetId);
				}
				if(paramequipmentId!=null) {
					this.equ_id=paramequipmentId;
					
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			UI.getCurrent().navigate("assetsview");
		}
	}
	private void populateAssetsDetailRow1(String paramAssetId2)
	{
		try
		{
			String res="";

			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url=url+"?StoreSerialNo="+paramAssetId2+"&VendorId="+VendorId+"&StoreId="+StoreId+"&StatusId="+StatusId+
					"&EquipmentTypeId="+EquipmentTypeId+"&StoreLocId="+StoreLocId+"&EquipmentSerialNo="+EquipmentSerialNo;
			//System.out.println("url1="+url);
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+"asset_res2_paramview:::"+res);


			assetlistresponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				for(int i=0;i<jsarr.length();i++)
				{
					AssetsViewDataBean beanobj=new AssetsViewDataBean(
							jsarr.getJSONObject(i).getString("StoreSerialNo"),
							jsarr.getJSONObject(i).getString("EquipmentType"),
							jsarr.getJSONObject(i).getString("EquipmentSerialNo"),
							jsarr.getJSONObject(i).getString("CreationDate"),
							this);

					assetListContainerDiv.add(beanobj);
					assetbeanList.add(beanobj);
					
				//	generateMarkerData(assetlistresponse);

				}
				col2ValueDiv.removeAll();
				col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(paramAssetId2));
			}	
		}catch(Exception e)
		{
			e.printStackTrace();
			UI.getCurrent().navigate("assetsview");
			col2ValueDiv.removeAll();
		}



	}


	private void selectAssetViewNode(String paramAssetId2)
	{
		for(int i = 0; i < assetbeanList.size(); i++) {
			assetbeanList.get(i).selectAssetViewBeanNode(paramAssetId2);
		}

	}
	private void populateMapview(String assetlistresponse2) 
	{
		mapView.populateAssetDetails(assetlistresponse2);
		mapView.setSelectedSite(mapassetId1/*selectedSitecode*/);
		mapviewDiv.setVisible(true);
		mapviewDiv1.setVisible(true);

	}
	private void refreshGoogleMapview(String sitelistresponse2) 
	{
		try
		{
		
			mapviewDiv.setVisible(true);
			mapviewDiv1.setVisible(true);
			lat=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LATITUDE");
			longi=ApplicationConfiguration.getConfigurationValue("DEFAULT_MAP_CENTRE_LONGITUDE");
			googleMapComponent.clearMapMarker();
			if (googleMapComponent == null) {
				googleMapComponent=new CustomGoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", lat, longi, 2,"assetlistmap");
				mapviewDiv.removeAll();
				mapviewDiv.add(googleMapComponent);

				googleMapComponent.addMapMarkerClickListener(new CustomGoogleMapMarkerClickListener() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onMapMarkerClick(String eventData) {
						//System.out.println("Event Data -->>" + eventData);
						try {
							JSONObject eventDataJSON = new JSONObject(eventData);
							String uniqueId = eventDataJSON.getString("event.detail");
							selectedRowChangeHandler(uniqueId);
							selectAssetViewNode(uniqueId);
							selectedAssetId = uniqueId;
							col2ValueDiv.removeAll();
							col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(uniqueId));
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
			}
			googleMapComponent.setVisible(true);
			generateMarkerData(sitelistresponse2);
			googleMapComponent.populateMarker(markerJSONArray);
			//googleMapComponent.openInfoWindow(/*mapsitecode1*/selectedAssetId);
			googleMapComponent.openInfoWindow2(selectedAssetId);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}


	public void addMapMarkerClickHandler(String caption)
	{
		//System.out.println("AssetmapmarkerClicked::"+caption);
		selectedRowChangeHandler(caption);
		selectAssetViewNode(caption);
		selectedAssetId=caption;
		col2ValueDiv.removeAll();
		col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(caption));

	}
	public void populateAssetsDetailRow2(String searchCriteria) 
	{

		try
		{
			String res="";

			String url = ApplicationConfiguration.getServiceEndpoint("SEARCH_EQUIPMENTS");
			//url=url+"?searchText="+searchCriteria;
			url=url+"?searchText="+CommonUtils.getEncodedText(searchCriteria).replaceAll("\\+","%20");
			//		System.out.println("url1="+url);
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("asset_search_res:::"+res);

			assetlistresponse=res;

			sortedListResponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();
			
			if(assetlistresponse==null || assetlistresponse.equals("[]"))
			{
				noRecordDiv.setVisible(true);
				noRecordDiv2.setVisible(true);
				assetListContainerDiv.setVisible(false);
				//col2ValueDiv.removeAll();
				recordcontainerDiv.setVisible(false);
				col2ValueDiv.setVisible(false);
				assetbeanList.clear();
				noRecordDiv.removeAll();
				noRecordDiv2.removeAll();
				Label lbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_REC_LBL");
				noRecordDiv.add(lbl);
			}

			caret_down1.getStyle().set("color", "#8080809e");
			caret_down2.getStyle().set("color", "#8080809e");
			caret_down3.getStyle().set("color", "#8080809e");
			caret_up1.getStyle().set("color", "#8080809e");
			caret_up2.getStyle().set("color", "#8080809e");
			caret_up3.getStyle().set("color", "#8080809e");

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0 && !assetlistresponse.equals("[]"))
				{
					col2ValueDiv.setVisible(true);
					assetListContainerDiv.setVisible(true);
					recordcontainerDiv.setVisible(true);
					noRecordDiv.setVisible(false);
					noRecordDiv2.setVisible(false);
					parentTabs.setSelectedTab(detailsTab);
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("CreationDate");
								str2 = jo2.getString("CreationDate");
								
							//	DateFormat d1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
								date1=CommonUtils.convertStringToLocalDate(str1,"dd-MMM-yyyy");
								date2=CommonUtils.convertStringToLocalDate(str2,"dd-MMM-yyyy");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							//return str1.compareTo(str2);
							return date1.compareTo(date2);
						}
					});

					Collections.reverse(jsonsList);//descending order
					sortedjsArr=new JSONArray(jsonsList);
					//	System.out.println("Sorted JSON Array with dates: " + sortedjsArr);

				}

			

			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					AssetsViewDataBean beanobj=new AssetsViewDataBean(
							sortedjsArr.getJSONObject(i).getString("StoreSerialNo"),
							sortedjsArr.getJSONObject(i).getString("EquipmentType"),
							sortedjsArr.getJSONObject(i).getString("EquipmentSerialNo"),
							sortedjsArr.getJSONObject(i).getString("CreationDate"),
							this);



					assetListContainerDiv.add(beanobj);
					assetbeanList.add(beanobj);
					if(i==0 /*&& paramAssetId==null*/)
					{
						selectedAssetId=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						equ_id = beanobj.getTheFirstEquipmentID(sortedjsArr.getJSONObject(i).getString("EquipmentType"));
						beanobj.getEachRowDiv().addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
					/*	col2ValueDiv.removeAll();
						col2ValueDiv.add(detailsTabHolder);
						addDetailsTab();*/
						col2ValueDiv.removeAll();
						col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
						mapassetId1=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						String eqType=sortedjsArr.getJSONObject(i).getString("EquipmentType");

						sendEquipmentName(eqType,selectedAssetId);
					}

				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(assetlistresponse);
				refreshGoogleMapview(assetlistresponse);
				assetListContainerDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				noRecordDiv.setVisible(false);
			}
		}		
		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	public void sendEquipmentName(String equipmentType, String equipmentSerialNo2)
	{
		col2Lbl1Str=equipmentType;
		col2Lbl2Str=equipmentSerialNo2;

		col2Lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL1");
		col2Lbl1.setText(col2Lbl1Str+" ( ");
		col2Lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "COL2_LBL2");
		col2Lbl2.setText(" Equipment Serial No.# "+col2Lbl2Str+")");

		col2HeaderDiv1.removeAll();
		col2HeaderDiv1.add(col2Lbl1,col2Lbl2);

	}


	protected void sortByAssetType(String orderBy) 
	{
		try
		{
			String res="";

			res=sortedListResponse;
			assetlistresponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("EquipmentType");
								str2 = jo2.getString("EquipmentType");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					AssetsViewDataBean beanobj=new AssetsViewDataBean(
							sortedjsArr.getJSONObject(i).getString("StoreSerialNo"),
							sortedjsArr.getJSONObject(i).getString("EquipmentType"),
							sortedjsArr.getJSONObject(i).getString("EquipmentSerialNo"),
							sortedjsArr.getJSONObject(i).getString("CreationDate"),
							this);



					assetListContainerDiv.add(beanobj);
					assetbeanList.add(beanobj);
					if(i==0 && paramAssetId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedAssetId=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						beanobj.getEachRowDiv().addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
						col2ValueDiv.removeAll();
						col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
						mapassetId1=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						String eqType=sortedjsArr.getJSONObject(i).getString("EquipmentType");

						sendEquipmentName(eqType,selectedAssetId);
					}

				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(assetlistresponse);
				refreshGoogleMapview(assetlistresponse);
				assetListContainerDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				noRecordDiv.setVisible(false);
			}



		}catch(Exception e)
		{
			e.printStackTrace();
		}


	}
	protected void sortByEqSerialNo(String orderBy) 
	{
		try
		{
			String res="";

			res=sortedListResponse;
			assetlistresponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("EquipmentSerialNo");
								str2 = jo2.getString("EquipmentSerialNo");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return str1.compareTo(str2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					AssetsViewDataBean beanobj=new AssetsViewDataBean(
							sortedjsArr.getJSONObject(i).getString("StoreSerialNo"),
							sortedjsArr.getJSONObject(i).getString("EquipmentType"),
							sortedjsArr.getJSONObject(i).getString("EquipmentSerialNo"),
							sortedjsArr.getJSONObject(i).getString("CreationDate"),
							this);



					assetListContainerDiv.add(beanobj);
					assetbeanList.add(beanobj);
					if(i==0 && paramAssetId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedAssetId=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						beanobj.getEachRowDiv().addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
						col2ValueDiv.removeAll();
						col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
						mapassetId1=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						String eqType=sortedjsArr.getJSONObject(i).getString("EquipmentType");

						sendEquipmentName(eqType,selectedAssetId);
					}

				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(assetlistresponse);
				refreshGoogleMapview(assetlistresponse);
				assetListContainerDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				noRecordDiv.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}	

	protected void sortByCreationDate(String orderBy) {
		try
		{
			String res="";

			res=sortedListResponse;
			assetlistresponse=res;

			assetbeanList.clear();
			assetListContainerDiv.removeAll();

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsonArray=new JSONArray(res);
				if(jsonArray.length()>0)
				{
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								str1 = jo1.getString("CreationDate");
								str2 = jo2.getString("CreationDate");
								
								date1=CommonUtils.convertStringToLocalDate(str1,"dd-MMM-yyyy");
								date2=CommonUtils.convertStringToLocalDate(str2,"dd-MMM-yyyy");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							//return str1.compareTo(str2);
							return date1.compareTo(date2);
						}
					});

					if(orderBy.equalsIgnoreCase("descending"))
					{
						Collections.reverse(jsonsList);
						sortedjsArr=new JSONArray(jsonsList);
					}
					if(orderBy.equalsIgnoreCase("ascending"))
					{
						sortedjsArr=new JSONArray(jsonsList);
					}

				}

			}
			if(sortedjsArr.length()>0)
			{
				for(int i=0;i<sortedjsArr.length();i++)
				{
					AssetsViewDataBean beanobj=new AssetsViewDataBean(
							sortedjsArr.getJSONObject(i).getString("StoreSerialNo"),
							sortedjsArr.getJSONObject(i).getString("EquipmentType"),
							sortedjsArr.getJSONObject(i).getString("EquipmentSerialNo"),
							sortedjsArr.getJSONObject(i).getString("CreationDate"),
							this);



					assetListContainerDiv.add(beanobj);
					assetbeanList.add(beanobj);
					if(i==0 && paramAssetId==null)
					{
						parentTabs.setSelectedTab(detailsTab);
						selectedAssetId=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						beanobj.getEachRowDiv().addClassName("ASSETS_VIEW_BEAN_DATA_ROW_SELECTED");
						col2ValueDiv.removeAll();
						col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(selectedAssetId));
						mapassetId1=sortedjsArr.getJSONObject(i).getString("StoreSerialNo");
						String eqType=sortedjsArr.getJSONObject(i).getString("EquipmentType");

						sendEquipmentName(eqType,selectedAssetId);
					}

				}
			}
			if(isMapVisible==true)
			{
				//populateMapview(assetlistresponse);
				refreshGoogleMapview(assetlistresponse);
				assetListContainerDiv.setVisible(false);
				noRecordDiv2.setVisible(false);
				noRecordDiv.setVisible(false);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void refreshAssetDetails(String assetserialno)
	{
		col2ValueDiv.removeAll();
		col2ValueDiv.add(assetdetailsTabVL.populateAssetDetails(assetserialno));

	}
	
	private void generateMarkerData(String sitelistresponse2) {
		try {
			
			markerJSONArray = new JSONArray();
			if(sitelistresponse2 == null) {
				sitelistresponse2 = "[]";
			}
			JSONArray js=new JSONArray(sitelistresponse2);
			for(int i=0;i<js.length();i++ )
			{
				String lat=js.getJSONObject(i).getString("Latitude");
				String longi=js.getJSONObject(i).getString("Longitude");
				if(lat.trim().length()>0 && longi.trim().length()>0)
				{
					JSONObject jsobj=new JSONObject();
					jsobj.put("title", js.getJSONObject(i).get("StoreSerialNo"));
					jsobj.put("uniqueId", js.getJSONObject(i).get("StoreSerialNo"));
					jsobj.put("lat", js.getJSONObject(i).get("Latitude"));
					jsobj.put("lng", js.getJSONObject(i).get("Longitude"));
					jsobj.put("EquipmentSerialNo", js.getJSONObject(i).get("EquipmentSerialNo"));
					jsobj.put("EquipmentType", js.getJSONObject(i).get("EquipmentType"));
					
					markerJSONArray.put(jsobj);
					
				}
			}
			
			//System.out.println("markerJSONArray2="+markerJSONArray);
			
			for(int i = 0; i < markerJSONArray.length(); i++) {
				JSONObject eachItem = markerJSONArray.getJSONObject(i);
				
			//	String contentString = "<html><body><span style=\"font-size:18px\">" + eachItem.getString("uniqueId") + "</span><br><em>Latitude :" + eachItem.getString("lat") + "</em><br><div style=\"width:200px\"><small>Longitude: " + eachItem.getString("lng") + "</small></div></body></html>";
				String contentString1 = "<html><body><span style=\"font-size:18px; width: 200px; max-height: 65px; overflow-wrap:break-word;\">" + eachItem.getString("EquipmentSerialNo")  + 
						"</span><br><em>" + eachItem.getString("EquipmentType")+ "</small></div></body></html>";
				
				
				eachItem.put("contentString", contentString1);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getVendors()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETALLVENDORS");
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	public String getAllVendors() {
		return allVendors;
	}

	public void setAllVendors(String allVendors) {
		this.allVendors = allVendors;
	}
}
