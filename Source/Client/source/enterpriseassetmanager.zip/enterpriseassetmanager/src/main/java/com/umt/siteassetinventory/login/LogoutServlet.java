package com.umt.siteassetinventory.login;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.umt.siteassetinventory.application.ApplicationConfiguration;


@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public LogoutServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String contextPath = getServletContext().getRealPath("/");
		String htmlfile = "/app/logout.html";
		
		String authReqURL = req.getScheme() + "://" + req.getServerName() + ":"
				+ req.getServerPort() + req.getContextPath() + "/authreq";
		
		BufferedReader objReader = null;
		try {
			objReader = new BufferedReader(new FileReader(contextPath + htmlfile));
			String currentLine = null;
			StringBuffer outputBuffer = new StringBuffer();
			PrintWriter out = resp.getWriter();
			while ((currentLine = objReader.readLine()) != null) {
				outputBuffer.append(currentLine + "\n");
			}
			String htmlOutput = outputBuffer.toString();
			htmlOutput = htmlOutput.replace("@@LOGOUT_API_URL@@", ApplicationConfiguration.getServiceEndpoint("LOGOUT"));
			htmlOutput = htmlOutput.replace("@@AUTH_REQ_URL@@", authReqURL);
			htmlOutput = htmlOutput.replace("@@DOMAIN@@", req.getServerName());
			resp.setContentType("text/html");
			out.print(htmlOutput);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (objReader != null) {
				objReader.close();
			}
		}
	}
}
