package com.umt.siteassetinventory.framework.componentfactory;

import java.io.InputStream;

import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

@CssImport("./styles/upload_dialog-styles.css")
public class UploadDialog extends Dialog {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "UPLOAD_DLG";
	private boolean doneBtnClicked = false;
	private boolean cancelBtnClicked = false;
	private Button doneBtn;
	private UIUploadComponent uploadDiv;

	public UploadDialog(String titleTxt) {
		
		MemoryBuffer fileBuffer = new MemoryBuffer();
		uploadDiv = new UIUploadComponent(fileBuffer, true);
		
		HorizontalLayout buttonbarHL = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "BUTTONBAR_HL");
		doneBtn = UIFieldFactory.createButton(SCREENCD, "DONE_BTN");
		Button cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				cancelBtnClicked = true;
				doneBtnClicked = false;
				close();
			}
		});

		doneBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				cancelBtnClicked = false;
				doneBtnClicked = true;
				close();
			}
		});
		
		Label titleLbl = UIHtmlFieldFactory.createLabel("Upload "+titleTxt, SCREENCD, "TITLE_LBL");
		buttonbarHL.add(doneBtn, cancelBtn);
		add(titleLbl, uploadDiv, buttonbarHL);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setWidth("600px");
		setHeight("430px");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);

	}
	
	/*public void dialogOpen()
	{
		open();
	}*/
	public Upload getUpload()
	{
		return uploadDiv.getUpload();
	}

	public void setAcceptedFileTypes(String[] acceptedFileTypes)
	{
		uploadDiv.setAcceptedFiles(acceptedFileTypes);
	}
	
	public void setMaxFileSize(int maxfilesize)
	{
		uploadDiv.setMaxFileSize(maxfilesize);
	}
	
	public void setDropAllowed(boolean dropAllowed)
	{
		uploadDiv.setDropAllowed(dropAllowed);	
	}
	
	public void setUploadButton(Component button)
	{
		uploadDiv.setUploadButton(button);
	}
	
	public InputStream getInputStream() {
		return uploadDiv.getInputStream();
	}

	public String getFileExtension() {
		return uploadDiv.getFileExtension();
	}
	
	public String getBase64EncodedFileContent() {
		return uploadDiv.getBase64EncodedFileContent();
	}

	public boolean isDoneClicked() {
		return doneBtnClicked;
	}

	public boolean isCancelClicked() {
		return cancelBtnClicked;
	}
	
	public boolean isUploadFailed() {
		return uploadDiv.isUploadFailed() ;
	}
	
	public boolean isUploadRejected() {
		return uploadDiv.isUploadRejected() ;
	}
	
	public FailedEvent getFailedEvent() {
		return uploadDiv.getFailedEvent();
	}
	
	public FileRejectedEvent getRejectedEvent() {
		return uploadDiv.getRejectedEvent();
	}
	
	public String getFileName() {
		return uploadDiv.getFileName();
	} 
	
	public void setFileName(String fileName) {
		uploadDiv.setFileName(fileName);
	}
}
