package com.umt.siteassetinventory.site;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/rent-reference-dialog-styles.css")
public class RentReferenceDialogBean extends Div {
	
	private static final long serialVersionUID = 1L;
	private static String SCREENCD = "SITE_RENT_REFERENCE_DIALOG_BEAN";
	private String SiteCode,SiteDetails,AgreementDetails;
	private Div beanRowDiv;
	private RentReferenceDialog parent;
	private RentReferenceDialogBean child;

	public RentReferenceDialogBean(String SiteCode,String SiteDetails,String AgreementDetails, RentReferenceDialog parent) {
		
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.SiteCode=SiteCode;
		this.SiteDetails=SiteDetails;
		this.AgreementDetails=AgreementDetails;
		this.parent=parent;
		child=this;
		
		try {
			Label sitecode = UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_LBL");
			Label sitename = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
			
			Div siteaddrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "SITEADDR_DIV");
			Label siteaddr = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEADDR_LBL");
			siteaddrDiv.add(siteaddr);
			
			Label rentAmt = UIHtmlFieldFactory.createLabel(SCREENCD, "RENTAMT_LBL");
			Label rentFreq = UIHtmlFieldFactory.createLabel(SCREENCD, "RENTFREQ_LBL");
			
			Label siteType = UIHtmlFieldFactory.createLabel(SCREENCD, "SITETYPE_LBL");
			
			
			Label indoorLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INDOOR_LBL");
			
			Label plotArea = UIHtmlFieldFactory.createLabel(SCREENCD, "PLOTAREA_LBL");
			

			JSONObject siteDetailsObj = new JSONObject(SiteDetails);
			if(siteDetailsObj.length()>0) {
				for (int i = 0; i < siteDetailsObj.length(); i++) {
					sitecode.setText(siteDetailsObj.getString("SiteCode"));
					sitename.setText(siteDetailsObj.getString("SiteName"));
					siteaddr.setText(siteDetailsObj.getString("Address"));
					
					siteaddrDiv.setTitle(siteDetailsObj.getString("Address"));
					
					JSONObject otherinfoObj = new JSONObject(siteDetailsObj.getString("OtherInfo"));
					System.out.println(siteDetailsObj.getString("SiteCode")+"::::"+otherinfoObj);
					if(otherinfoObj.length()>0) {
//						if (otherinfoObj.has("Site Type")) {
//							siteType.setText(otherinfoObj.getString("Site Type"));
//						}else if(otherinfoObj.has("Indoor and Outdoor")) {
//							System.out.println("Indoor and Outdoor:::"+otherinfoObj.getString("Indoor and Outdoor"));
//							indoorLbl.setText(otherinfoObj.getString("Indoor and Outdoor"));
//						}else if(otherinfoObj.has("Plot Area")) {
//							plotArea.setText(otherinfoObj.getString("Plot Area"));
//						}else {
//							siteType.setText("");
//							indoorLbl.setText("");
//							plotArea.setText("");
//						}
						if (otherinfoObj.has("Site Type")) {
							siteType.setText(otherinfoObj.getString("Site Type"));
						}else {
							siteType.setText("");
						}
						
						if(otherinfoObj.has("Indoor and Outdoor")) {
							indoorLbl.setText(otherinfoObj.getString("Indoor and Outdoor"));
						}else {
							indoorLbl.setText("");
						}
						
						if(otherinfoObj.has("Plot Area")) {
							plotArea.setText(otherinfoObj.getString("Plot Area"));
						}else {
							plotArea.setText("");
						}
						
						
						
					}
				
				}
			}
			
			
			JSONObject agreementdetailsObj = new JSONObject(AgreementDetails);
			System.out.println("agreementdetailsObj::::"+agreementdetailsObj);
		//	System.out.println("agreementdetailsObj.length()::::"+agreementdetailsObj.length());
			if(agreementdetailsObj.length()>0) {
				for (int i = 0; i < agreementdetailsObj.length(); i++) {
//						rentAmt.setText(agreementdetailsObj.getString("Rent Amount "));
//						rentFreq.setText(agreementdetailsObj.getString("Rent Frequency "));
					rentAmt.setText(agreementdetailsObj.getString("Rent Amount"));
					rentFreq.setText(agreementdetailsObj.getString("Rent Frequency"));
				}
			}
			
			beanRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			beanRowDiv.add(sitecode,sitename,/*siteaddr*/siteaddrDiv,rentAmt,rentFreq,siteType,indoorLbl,plotArea);
			
			
			add(beanRowDiv);
			
			beanRowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(ClickEvent<Div> event) {
			
					parent.selectedRowChangeHandler(SiteCode);
					parent.deselectOtherRows(child);
					beanRowDiv.addClassName(SCREENCD + "_DATA_ROW_SELECTED");
					
				}
			});
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectRentRefenceDlgBeanNode(String siteCode2) {
		deselectEachBeanRow(this);
		if (siteCode2.equalsIgnoreCase(SiteCode)) {
			if (beanRowDiv != null) {
				beanRowDiv.addClassName(SCREENCD + "_DATA_ROW_SELECTED");
			}
		}
		
	}

	public void deselectEachBeanRow(RentReferenceDialogBean beanChild) {
		for(int i = 0; i < parent.getRentReferenceDialogList().size(); i++) 
		{
			if(!beanChild.equals(parent.getRentReferenceDialogList().get(i))) 
			{
				beanRowDiv.removeClassName("SITE_RENT_REFERENCE_DIALOG_BEAN_DATA_ROW_SELECTED");
			}
		}
		
	}

}
