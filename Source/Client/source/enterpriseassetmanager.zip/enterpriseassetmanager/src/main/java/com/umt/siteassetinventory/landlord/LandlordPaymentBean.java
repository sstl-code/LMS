package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

public class LandlordPaymentBean extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "PAYMENTS_TAB_BEAN";
	private Div eachPaymentDiv;
	private String siteCode,landlordId,paymentId,transactionId="",amount,mode,reqdate,status,
	remarks,reqDate,paymentInstrumentNo,paymentDate;
	
	public LandlordPaymentBean(String siteCode, String landlordId, String paymentId, String transactionId, String amount, String mode,
			String reqdate, String status, String remarks, String paymentDate,String paymentInstrumentNo, String paymentDetails, LandlordPaymentsTab landlordPaymentsTab) 
	{
		this.siteCode=siteCode;
		this.landlordId=landlordId;
		this.paymentId=paymentId;
		this.amount=amount;
		this.mode=mode;
		this.reqdate=reqdate;
	//	this.status=status;
		this.remarks=remarks;
		this.reqDate=reqdate;
		this.paymentInstrumentNo=paymentInstrumentNo;
		this.paymentDate=paymentDate;
		
		eachPaymentDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_PAYMENT_DIV");
		
		Div headerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div bodyDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		
		if (transactionId!=null && transactionId.trim().length()>0) {
		//	this.transactionId = " (Transaction Id #"+transactionId+")";
			this.transactionId = "UTR No. #"+transactionId;
//			this.transactionId = "UTR No. #"+transactionId+"";
		}
		
		Label siteCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
	//	siteCodeLbl.setText("Site Code "+siteCode+this.transactionId);
		
		Label landlordIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL2");
		landlordIdLbl.setText("Landlord Id "+landlordId);
		
		Icon disputeIcon = VaadinIcon.EXCLAMATION_CIRCLE.create();
		disputeIcon.addClassName(SCREENCD+"_DISPUTE_ICON");
		
		Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		Button viewDetailsBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_DETAILS_BTN");
		buttonDiv.add(viewDetailsBtn);
		
	//	headerDiv.add(siteCodeLbl/*landlordIdLbl*//*,disputeIcon*/);
		headerDiv.add(this.transactionId);
		if (paymentDetails!=null && paymentDetails.trim().length()>0) {
			headerDiv.add(buttonDiv);
		}
		
		Div each_V_Div1=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV1");
		Label paymentLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_LBL");
		Label paymentVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_V_LBL");
		paymentVLbl.setText(paymentId);
		each_V_Div1.add(paymentLbl,paymentVLbl);
		
		Div each_V_Div2=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV2");
		Label amtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "AMOUNT_LBL");
		Label amtVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "AMOUNT_V_LBL");
		amtVLbl.setText(CommonUtils.roundValue(amount,2));
		each_V_Div2.add(amtLbl,amtVLbl);
		
	/*	Div each_V_Div3=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV3");
		Label modeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MODE_LBL");
		Label modeVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MODE_V_LBL");
		modeVLbl.setText(mode);
		each_V_Div3.add(modeLbl,modeVLbl);*/
		Div each_V_Div3=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV3");
		Label sitecodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MODE_LBL");
		Label sitecodeVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "MODE_V_LBL");
		sitecodeVLbl.setText(siteCode);
		each_V_Div3.add(sitecodeLbl,sitecodeVLbl);
		
		Div each_V_Div4=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV4");
		Label dateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_LBL");
		Label dateVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATE_V_LBL");
		dateVLbl.setText(reqdate);
		each_V_Div4.add(dateLbl,dateVLbl);
		
		Div each_V_Div7=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV7");
		Label paymentdateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_DATE_LBL");
		Label paymentdateVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PAYMENT_DATE_V_LBL");
		paymentdateVLbl.setText(paymentDate);
		each_V_Div7.add(paymentdateLbl,paymentdateVLbl);
		
		Div each_V_Div5=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV5");
		Label statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		Label statusVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_V_LBL");
	//	statusVLbl.setText(status);
		each_V_Div5.add(statusLbl,statusVLbl);
		
		Div each_V_Div6=UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV6");
		Label detailsLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAILS_LBL");
		Label detailsVLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DETAILS_V_LBL");
		detailsVLbl.setText(remarks);
		each_V_Div6.add(detailsLbl,detailsVLbl);
		
		bodyDiv.add(each_V_Div1,each_V_Div2,each_V_Div3,each_V_Div4,each_V_Div7,each_V_Div5,each_V_Div6);
		
	/*	disputeIcon.setVisible(false);
		if(paymentDate.equals("1"))
		{
			disputeIcon.setVisible(true);
		}*/
		if(status.equalsIgnoreCase("1"))
		{
		//	dateVLbl.removeAll();
			statusVLbl.removeAll();
	//		dateLbl.removeAll();
			//statusVLbl.setText("Initiated");
			statusVLbl.setText("Success");
		//	this.reqDate=reqdate;
	//		dateVLbl.setText(reqdate);
	//		dateLbl.setText("Request Date");
			this.status="Success";
		}
		if(status.equalsIgnoreCase("2"))
		{
	//		dateVLbl.removeAll();
			statusVLbl.removeAll();
	//		dateLbl.removeAll();
		//	statusVLbl.setText("Paid");
			statusVLbl.setText("Failure");
	//		this.reqDate=paymentDate;
	//		dateVLbl.setText(paymentDate);
	//		dateLbl.setText("Payment Date");
			this.status="Failure";
		}
		
		eachPaymentDiv.add(headerDiv,bodyDiv);
		add(eachPaymentDiv);
		
		viewDetailsBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {		
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				ViewPaymentDetails view = new ViewPaymentDetails(paymentDetails);
			}
		});
	}

	public Div geteachPaymentDiv() {
		return eachPaymentDiv;
	}

	public String paymentId() {
		return paymentId;
	}

	public String getAmt() {
		//return amount;
		return CommonUtils.roundValue(amount,2);
	}

	public String getSiteCode() {
		return siteCode;
	}

	public String getRequestPaymentDate() {
		return reqDate;
	}
	public String getPaymentDate() {
		return paymentDate;
	}

	public String getStatus() {
		return status;
	}

	public String getRemarks() {
		return remarks;
	}

}
