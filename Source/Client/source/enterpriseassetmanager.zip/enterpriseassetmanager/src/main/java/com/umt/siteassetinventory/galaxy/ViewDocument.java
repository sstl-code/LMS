package com.umt.siteassetinventory.galaxy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ViewDocument")
public class ViewDocument extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String imgUrl;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		imgUrl = request.getParameter("imgUrl");

		try {
			OutputStream outputStream = null;
			InputStream inStream = null;
			if (imgUrl != null) {
				String filePath = imgUrl;

				URL url = new URL(filePath);
				URLConnection connection = url.openConnection();

				HttpURLConnection httpConnection = (HttpURLConnection) connection;
				int responseCode = httpConnection.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) {
					inStream = httpConnection.getInputStream();
				}
				byte[] filecontent = inputStreamToByte(inStream);
				String mimeType = connection.getContentType();
				response.setContentType(mimeType);

				try {
					outputStream = response.getOutputStream();
					outputStream.write(filecontent);
				} catch (Exception ex) {
					throw ex;
				} finally {
					if (outputStream != null) {
						try {
							outputStream.flush();
							outputStream.close();
						} catch (IOException ex) {
							ex.printStackTrace();
						}
					}
				}

			} else {
				PrintWriter out = response.getWriter();
				out.println("Document not available");
			}

		} catch (Exception e) {
			e.printStackTrace();
			PrintWriter out = response.getWriter();
			out.println("Failed to display document");
		}

	}

	public static byte[] inputStreamToByte(InputStream is) {
		try {
			ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
			int ch;
			while ((ch = is.read()) != -1) {
				bytestream.write(ch);
			}
			byte data[] = bytestream.toByteArray();
			bytestream.close();
			return data;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
