package com.umt.siteassetinventory.assets;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/asset_history-style.css")
public class AssetHistoryTab extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_HISTORY";

	private Div containerDiv;
	protected List<AssetHistoryDataBean> assetHistoryDataBeanList;
	private String assetId;

	public AssetHistoryTab() {

		addClassName(SCREENCD + "_MAIN_LAYOUT");

		containerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		/*Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		Div eachrowDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV6");

		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		eachrowDiv5.add(lbl5);
		Label lbl6 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL6");
		eachrowDiv6.add(lbl6);
		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5, eachrowDiv6);
		add(tableHeaderDiv, tableContainerDiv);
*/
		add(containerDiv);
	}

	protected void loadAssets()
	{
		containerDiv.removeAll();
		assetHistoryDataBeanList = new ArrayList<>();
		try {
			JSONArray equipmentsHistoryJA = new JSONArray();
			String equipmentsHistory = getEquipmentHistory();
			equipmentsHistoryJA = new JSONArray(equipmentsHistory);
			for (int i = 0; i < equipmentsHistoryJA.length(); i++) {
				JSONObject assetHistoryJson = equipmentsHistoryJA.getJSONObject(i);
				AssetHistoryDataBean bean = new AssetHistoryDataBean(assetHistoryJson.getString("Startdate"), assetHistoryJson.getString("Enddate"), 
						assetHistoryJson.getString("Storename"), assetHistoryJson.getString("StoreLocationId"), 
						assetHistoryJson.getString("StatusCode"), assetHistoryJson.getString("Remarks"));
				containerDiv.add(bean);
				assetHistoryDataBeanList.add(bean);
			}

		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getEquipmentHistory()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTHISTORY");
			String response = RestServiceHandler.retriveJSON_GET(url + "?StoreSerialNo=" + getAssetId(), SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + "?StoreSerialNo=" + getAssetId()+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

}
