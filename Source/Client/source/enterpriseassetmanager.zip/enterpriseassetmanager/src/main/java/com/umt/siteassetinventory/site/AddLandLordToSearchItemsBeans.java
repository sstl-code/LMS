package com.umt.siteassetinventory.site;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;

public class AddLandLordToSearchItemsBeans extends Div {
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_LANDLORD";
	private Checkbox checkBox;
	private Label contact_no, name, email, address; 
	private AddLandLord parent;
	private Div eachrowDiv;
	private AddLandLordToSearchItemsBeans child;
	
	
	
	
	public AddLandLordToSearchItemsBeans(String landlord_id, String landlord_name, String landlord_email,String contactNo, String landlord_address, AddLandLord obj) {
		this.parent = obj;
		child=this;
		
		
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_BEAN_DIV");
		Div row1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		checkBox = UIFieldFactory.createCheckbox(false, false, SCREENCD, "CHECKBOX");
		contact_no = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_CONTACT_LBL");
		name = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_NAME_LBL"); 
		email = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_EMAIL_LBL");  
		email.setTitle(landlord_email);
		address = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_ADDRESS_LBL");
		address.setTitle(landlord_address);
		
		contact_no.setText(contactNo);
		name.setText(landlord_name);
		email.setText(landlord_email);
		address.setText(landlord_address);
		
		
		
		row1.add(name);
		row2.add(email);
		row3.add(contact_no);
		row4.add(address);
		
		eachrowDiv.add(row1, row2, row3, row4);
		add(eachrowDiv);
		
		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				eachRowSelectionChangeHandler();
				obj.setLandlordID(landlord_id);
				
			}
		});
		
		checkBox.addClickListener(new ComponentEventListener<ClickEvent<Checkbox>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Checkbox> event) {
				
//				System.out.println(name.getText());
			}
		});
		checkBox.addValueChangeListener(event ->  {
			
			if(event.getValue() == true) {
				//System.out.println(name.getText() + event.getValue());
				obj.setLandlordID(landlord_id);
			}
			
			
				
			}
		);
		
	}
	
	protected void eachRowSelectionChangeHandler() {
		parent.deselectOtherRows(child);
		eachrowDiv.addClassName("SELECTED");
		
		
	}

	public void deselectEachDiv(AddLandLordToSearchItemsBeans child2)
	{
		
		for(int i = 0; i < parent.getSiteBeanList().size(); i++) 
		{
			if(!child2.equals(parent.getSiteBeanList().get(i))) 
			{
				eachrowDiv.removeClassName("SELECTED");
			}
		}
		
	}

}
