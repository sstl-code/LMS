package com.umt.siteassetinventory.landlord;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.invoice.InvoiceManagementBean;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/landlord-payment.css")
public class LandlordPaymentsTab extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "PAYMENTS_TAB";
	private Div paymentContainerDiv,paymentContainerDiv2;
	private Long id1, id2;
	private TextField filterRecords;
	private List<LandlordPaymentBean> beanList=new ArrayList<LandlordPaymentBean>();

	public LandlordPaymentsTab() {
		filterRecords = UIFieldFactory.createTextField("", false, SCREENCD, "FILTER_RECORD_FIELD");
		filterRecords.setSuffixComponent(VaadinIcon.SEARCH.create());
		filterRecords.setValueChangeMode(ValueChangeMode.EAGER);
		
		 filterRecords.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
				private static final long serialVersionUID = 1L;
				
				@Override
				public void valueChanged(ValueChangeEvent<?> event) {
					
					beanList.stream().filter(new Predicate<LandlordPaymentBean>() {

						@Override
						public boolean test(LandlordPaymentBean t) {
							String searchTxt = filterRecords.getValue().trim();
							if (searchTxt == null || searchTxt.trim().length() == 0) {
								 t.geteachPaymentDiv().setVisible(true);
								
								return true;
							}
							if (StringUtils.containsIgnoreCase(t.paymentId(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getAmt(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getSiteCode(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getRequestPaymentDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getPaymentDate(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getStatus(), searchTxt)
									|| StringUtils.containsIgnoreCase(t.getRemarks(), searchTxt)) {
									
							
								t.geteachPaymentDiv().setVisible(true);
								return true;
							}
							t.geteachPaymentDiv().setVisible(false);
							return false;
						}
					
					}).collect(Collectors.toList());
					

				}
			});
		
		
	}
	public void setLandlordId(String landlordId) {
		// TODO Auto-generated method stub

	}
	public Div populatePayments(String landlordId) 
	{
		try
		{
			
			JSONArray js = new JSONArray();
			paymentContainerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");

			String url = ApplicationConfiguration.getServiceEndpoint("GET_LANDLORD_PAYMENTS");
			url=url+"?LandlordId="+landlordId;
			String res = RestServiceHandler.retrieveTEXT_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
		//	System.out.println(url+" landlord_payment:::"+res);
			
			String res1="[\r\n" + 
					"  {\r\n" + 
					"    \"PaymentId\": 12,\r\n" + 
					"    \"LandlordId\": 1,\r\n" + 
					"    \"SiteCode\": \"ml.Johor.S000001\",\r\n" + 
					"    \"Amount\": 8680,\r\n" + 
					"    \"PaymentMode\": \"NEFT\",\r\n" + 
					"    \"Status\": 2,\r\n" + 
					"    \"RequestDate\": \"10-Jun-2022\",\r\n" + 
					"    \"PaymentDate\": \"18-Jun-2022\",\r\n" + 
					"    \"PaymentInstrumentNo\": \"Bank Account -11002989998912, SBI\",\r\n" + 
					"    \"Remarks\": \"NEFT Trans Id - SBI32390\",\r\n" + 
					"    \"Details\": \"{\\\"Electricity\\\":2000.00,\\\"Rent\\\":5000.0,\\\"CGST\\\":840.00,\\\"SGST\\\":840.00}\",\r\n" + 
					"    \"Transactionid\": \"TR005\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"PaymentId\": 11,\r\n" + 
					"    \"LandlordId\": 1,\r\n" + 
					"    \"SiteCode\": \"ml.Johor.S000001\",\r\n" + 
					"    \"Amount\": 8680,\r\n" + 
					"    \"PaymentMode\": \"NEFT\",\r\n" + 
					"    \"Status\": 2,\r\n" + 
					"    \"RequestDate\": \"10-May-2022\",\r\n" + 
					"    \"PaymentDate\": \"12-May-2022\",\r\n" + 
					"    \"PaymentInstrumentNo\": \"Bank Account -11002989998912, SBI\",\r\n" + 
					"    \"Remarks\": \"NEFT Trans Id - SBI88990\",\r\n" + 
					"    \"Details\": \"{\\\"Electricity\\\":2000.00,\\\"Rent\\\":5000.0,\\\"CGST\\\":840.00,\\\"SGST\\\":840.00}\",\r\n" + 
					"    \"Transactionid\": \"TR004\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"PaymentId\": 9,\r\n" + 
					"    \"LandlordId\": 1,\r\n" + 
					"    \"SiteCode\": \"ml.Johor.S000001\",\r\n" + 
					"    \"Amount\": 8680,\r\n" + 
					"    \"PaymentMode\": \"NEFT\",\r\n" + 
					"    \"Status\": 2,\r\n" + 
					"    \"RequestDate\": \"10-Mar-2022\",\r\n" + 
					"    \"PaymentDate\": \"12-Mar-2022\",\r\n" + 
					"    \"PaymentInstrumentNo\": \"Bank Account -11002989998912, SBI\",\r\n" + 
					"    \"Remarks\": \"NEFT Trans Id - SBI83230\",\r\n" + 
					"    \"Details\": \"{\\\"Electricity\\\":2000.00,\\\"Rent\\\":5000.0,\\\"CGST\\\":840.00,\\\"SGST\\\":840.00}\",\r\n" + 
					"    \"Transactionid\": \"TR001\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"PaymentId\": 1,\r\n" + 
					"    \"LandlordId\": 1,\r\n" + 
					"    \"SiteCode\": \"ml.Johor.S000001\",\r\n" + 
					"    \"Amount\": 8680,\r\n" + 
					"    \"PaymentMode\": \"NEFT\",\r\n" + 
					"    \"Status\": 2,\r\n" + 
					"    \"RequestDate\": \"10-Feb-2022\",\r\n" + 
					"    \"PaymentDate\": \"12-Feb-2022\",\r\n" + 
					"    \"PaymentInstrumentNo\": \"Bank Account -11002989998912, SBI\",\r\n" + 
					"    \"Remarks\": \"NEFT Trans Id - SBI74990\",\r\n" + 
					"    \"Details\": \"{\\\"Electricity\\\":2000.00,\\\"Rent\\\":5000.0,\\\"CGST\\\":840.00,\\\"SGST\\\":840.00}\",\r\n" + 
					"    \"Transactionid\": \"TR000\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"PaymentId\": 10,\r\n" + 
					"    \"LandlordId\": 1,\r\n" + 
					"    \"SiteCode\": \"ml.Johor.S000001\",\r\n" + 
					"    \"Amount\": 8680,\r\n" + 
					"    \"PaymentMode\": \"NEFT\",\r\n" + 
					"    \"Status\": 2,\r\n" + 
					"    \"RequestDate\": \"10-Apr-2022\",\r\n" + 
					"    \"PaymentDate\": \"12-Apr-2022\",\r\n" + 
					"    \"PaymentInstrumentNo\": \"Bank Account -11002989998912, SBI\",\r\n" + 
					"    \"Remarks\": \"NEFT Trans Id - SBI13345\",\r\n" + 
					"    \"Details\": \"{\\\"Electricity\\\":2000.00,\\\"Rent\\\":5000.0,\\\"CGST\\\":840.00,\\\"SGST\\\":840.00}\",\r\n" + 
					"    \"Transactionid\": \"TR003\"\r\n" + 
					"  }\r\n" + 
					"]";

			if(res!=null && res.trim().length()>0)
			{
				js = new JSONArray(res);
				if (js.length()>0) {
					List<JSONObject> jsonList = new ArrayList<JSONObject>();
					for (int i = 0; i < js.length(); i++) {
						jsonList.add(js.getJSONObject(i));
					}
					Collections.sort(jsonList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
								id1 = jo1.getLong("PaymentId");
								id2 = jo2.getLong("PaymentId");
							} catch(JSONException e) {
								e.printStackTrace();
							}

							return id1.compareTo(id2);
							//return date1.compareTo(date2);
						}
					});

					Collections.reverse(jsonList);//descending order
					JSONArray sortedjsArr=new JSONArray(jsonList);
					//System.out.println(" sortedjsArr:::"+sortedjsArr.toString());

					if(sortedjsArr.length()>0)
					{
						paymentContainerDiv.removeAll();
						beanList.clear();
						paymentContainerDiv.add(filterRecords);
						for(int i=0;i<sortedjsArr.length();i++)
						{

							LandlordPaymentBean beanobj=new LandlordPaymentBean(sortedjsArr.getJSONObject(i).getString("SiteCode"),
									sortedjsArr.getJSONObject(i).getString("LandlordId"),
									sortedjsArr.getJSONObject(i).getString("PaymentId"),
									sortedjsArr.getJSONObject(i).getString("Transactionid"),
									sortedjsArr.getJSONObject(i).getString("Amount"),
									sortedjsArr.getJSONObject(i).getString("PaymentMode"),
									sortedjsArr.getJSONObject(i).getString("RequestDate"),
									sortedjsArr.getJSONObject(i).getString("Status"),
									sortedjsArr.getJSONObject(i).getString("Remarks"),
									sortedjsArr.getJSONObject(i).getString("PaymentDate"),
									sortedjsArr.getJSONObject(i).getString("PaymentInstrumentNo"),
									sortedjsArr.getJSONObject(i).getString("Details"),
									this);

							paymentContainerDiv.add(beanobj);
							beanList.add(beanobj);
						}
					}
				}
			}
			if(res==null || res.trim().length()==0 || js.length()<=0)
			{
				paymentContainerDiv.removeAll();
				Label lbl=UIHtmlFieldFactory.createLabel(SCREENCD, "NO_REC_LBL");
				lbl.setText("No payment record found");
				paymentContainerDiv.add(lbl);
			}
		} catch(Exception e)
		{
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}

		return paymentContainerDiv;
	}

}
