package com.umt.siteassetinventory.assets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/assets-view.css")
public class EditAssetDetailsDialog extends Dialog
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EDIT_ASSET_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv;
	private Div mainLayout,closeBtnDiv;
	private Button saveBtn,cancelBtn;
	private TextField storeserialNo,equipmentType,servicetype,vendorName,description,equipmentserialno,storeId,storename,storeLocId,
	startdate,stopdate,statusCode;
	
	private  ComboBox<String> vendorNameCombo;
	private List<String> vendorList;
	private HashMap<String,JSONObject> assetMap,vendorMap;
	private boolean isSuccess=false;
	private String vendorId;
	private String vendorName2;

	public EditAssetDetailsDialog(String serialno, String equipmentType2, String vendorName2, String equipmentserialNo2, String description2, String vendorname3, String storeid2,
			String storename2, String storeLocationId, String startDate2, String stopDate2, String statuscode, String serviceType2) 
	{
		this.vendorName2=vendorName2;
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl,closeBtnDiv);
		
		createRows(serialno,equipmentType2,vendorName2,equipmentserialNo2,description2,vendorname3,storeid2,
				storename2,storeLocationId,startDate2,stopDate2,statuscode,serviceType2);
		
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();
		
		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				//close();
				updateData();
			}
		});
		
		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});
	}


	private void createRows(String serialno, String equipmentType2, String vendorName2, String equipmentserialNo2, String description2, String vendorname3, String storeid2, String storename2, String storeLocationId,
			String startDate2, String stopDate2, String statuscode, String serviceType2) 
	{
		storeserialNo = UIFieldFactory.createTextField(serialno, false, SCREENCD, "FIELD1");
		equipmentType = UIFieldFactory.createTextField(equipmentType2, false, SCREENCD, "FIELD2");
	//	vendorName = UIFieldFactory.createTextField(vendorName2, false, SCREENCD, "FIELD3");
		vendorList=new ArrayList<String>();
		vendorNameCombo=UIFieldFactory.createComboBox(vendorList,true, SCREENCD, "VENDOR_COMBO");
		vendorNameCombo.setValue(vendorName2);
		vendorNameCombo.setRequiredIndicatorVisible(true);
		vendorNameCombo.setRequired(true);
		vendorNameCombo.setInvalid(false);
		equipmentserialno = UIFieldFactory.createTextField(equipmentserialNo2, false, SCREENCD, "FIELD4");
		storeId = UIFieldFactory.createTextField(storeid2, false, SCREENCD, "FIELD5");
		storename = UIFieldFactory.createTextField(storename2, false, SCREENCD, "FIELD6");
		storeLocId = UIFieldFactory.createTextField(storeLocationId, false, SCREENCD, "FIELD7");
		statusCode = UIFieldFactory.createTextField(statuscode, false, SCREENCD, "FIELD8");
		description=UIFieldFactory.createTextField(description2, false, SCREENCD, "FIELD9");
		servicetype = UIFieldFactory.createTextField("", false, SCREENCD, "FIELD10");
		startdate = UIFieldFactory.createTextField(startDate2, false, SCREENCD, "FIELD11");
		stopdate = UIFieldFactory.createTextField(stopDate2, false, SCREENCD, "FIELD12");
		
		
		
		Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV4");
		Div row_5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
	/*	Div vendorNameComboDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "VENDOR_NAME_COMBO_DIV");
		vendorNameComboDiv.add(vendorNameCombo);
		Div equipmentTypeDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "VENDOR_NAME_COMBO_DIV");
		equipmentTypeDiv.add(equipmentType);*/
		
		
		row_1.add(storeserialNo,storename);
		row_2.add(storeLocId,statusCode);
		row_3.add(equipmentserialno,description);
		row_4.add(equipmentType,vendorNameCombo);
		row_5.add(startdate,stopdate);
		row_6.add(servicetype);
		
		storeserialNo.setEnabled(false);
		startdate.setEnabled(false);
		stopdate.setEnabled(false);
		storeId.setEnabled(false);
		servicetype.setEnabled(false);
		storeLocId.setEnabled(false);
		storename.setEnabled(false);
		statusCode.setEnabled(false);
		equipmentType.setEnabled(false);
		equipmentserialno.setEnabled(false);
		
		if(Integer.parseInt(serviceType2)==1)
		{
			vendorNameCombo.setLabel("Operator Name");
			servicetype.setValue("Active Asset");
		}
		if(Integer.parseInt(serviceType2)==0)
		{
			vendorNameCombo.setLabel("Vendor Name");
			servicetype.setValue("Passive Asset");
		}
		if(storename2.toUpperCase().equalsIgnoreCase("SITE"))
		{
			storeLocId.setLabel("Site Code");
		}
		if(storename2.toUpperCase().equalsIgnoreCase("WAREHOUSE"))
		{
			storeLocId.setLabel("Store Location Id");
		}
		
	
		
		
		bodyDiv.add(row_1,row_2,row_3,row_4,row_5,row_6);
		
		populateEquipmentTypeCombo();
		populateVendorList(equipmentType.getValue());
		
		
	}
	
	private void populateEquipmentTypeCombo() 
	{
		try {
			
			assetMap = new HashMap<>();
			String res="";
			String url=ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPE");
			res=RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			
		//	System.out.println("eqip_type::"+res);
			
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						String equipmentType=jsarr.getJSONObject(i).getString("EquipmentType");
						assetMap.put(equipmentType,jsarr.getJSONObject(i));
					}
				}
				
				
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
	}

	private void populateVendorList(String equipmentTypevalue) 
	{
		try {
			
			String equipmentTypeId1=assetMap.get(equipmentTypevalue).getString("EquipmentTypeId");
			
			vendorList=new ArrayList<String>();
			
			vendorList.clear();
			vendorMap = new HashMap<>();
			String res="";
			String url=ApplicationConfiguration.getServiceEndpoint("GET_EQUIPMENT_TYPE_VENDOR");
			url=url+"?EquipmentTypeId="+Integer.parseInt(equipmentTypeId1);
		
			res=RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			
			
			
			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						String vendorname=jsarr.getJSONObject(i).getString("VendorName");
						String vendorid=jsarr.getJSONObject(i).getString("VendorId");
						vendorList.add(vendorname);
						vendorMap.put(vendorname,jsarr.getJSONObject(i));
					}
					vendorNameCombo.setItems(vendorList);
				}
			//	vendorId=vendorMap.get(vendorNameCombo.getValue()).getString("VendorId");
			}
			vendorNameCombo.setValue(vendorName2);
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
		
	}
	protected void updateData() 
	{
		try
		{
			
		/*	if(vendorNameCombo.getValue()==null)
			{
				vendorNameCombo.setInvalid(true);
				vendorNameCombo.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
				return;
			}*/
		//	if(vendorNameCombo.getValue()!=null)
		//	{
				vendorId=vendorMap.get(vendorNameCombo.getValue()).getString("VendorId");
				Form form=new Form();
				form.add("StoreSerialNo",Integer.parseInt(storeserialNo.getValue()));
				form.add("vendorId",Integer.parseInt(vendorId));
				form.add("description",description.getValue());
			//	form.add("equipmentserialno",equipmentserialno.getValue());
				//System.out.println("form="+form);
				
				String url=ApplicationConfiguration.getServiceEndpoint("UPDATE_EQUIPMENT");
			//	System.out.println("url="+url);
				RestServiceHandler.updateJSON_PUT(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
				isSuccess=true;
				close();
		//	}	
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			isSuccess=false;
		}
		
	}


	public boolean isSuccess() {
		return isSuccess;
	}

}
