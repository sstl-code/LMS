package com.umt.siteassetinventory;

import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.IFrame;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.router.Route;

@Route(value = "dynamicpage", layout = MainView.class)
@CssImport("./styles/dynamic_page-styles.css")
public class DynamicPage extends VerticalLayout implements HasUrlParameter<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String SCREENCD = "DYNAMIC_PAGE";

	private String targetMenu= "", targetIframe= "";


	public DynamicPage() {
		System.out.println("DynamicPage()");
	}


	@Override
	public void setParameter(BeforeEvent event, @OptionalParameter String parameter) {
		System.out.println("setParameter()");
		Location location = event.getLocation();
		QueryParameters queryParameters = location.getQueryParameters();
		//	    System.out.println("queryParameters="+queryParameters);

		Map<String, List<String>> parametersMap = queryParameters.getParameters();
		//	    System.out.println("parametersMap="+parametersMap.toString());

		if(parametersMap.isEmpty())
		{
			return;
		}

		List<String> targetList = parametersMap.get("target");
		if(targetList == null || targetList.size() == 0)
		{
			return;
		}    
		targetMenu = targetList.get(0).replace("_", " ");
		System.out.println("targetMenu= "+targetMenu);
		init();
	}
	
	private void init()
	{
		System.out.println("init()");
		try {
			SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar(targetMenu);
			//		String report_iframeSrc = VaadinServletRequest.getCurrent().getScheme() 
			//				+ "://" + VaadinServletRequest.getCurrent().getServerName() 
			//				+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
			//				+"/reports/" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

			//String report_iframeSrc2="https://172.18.0.11:7004"+"/reports/" + ApplicationConfiguration.getConfigurationValue("AUDIT_TRAIL_SRC");

			System.out.println("targetMenu= "+targetMenu);
			JSONArray dynamicMenuJA = new JSONArray(ApplicationConfiguration.getConfigurationValue("DYNAMIC_MENU_LIST"));
			for (int i = 0; i < dynamicMenuJA.length(); i++) {
				JSONObject dynamicMenuJson = dynamicMenuJA.getJSONObject(i);
				String menuCaption = "";
				if (dynamicMenuJson.has("menu-caption")) {
					menuCaption = dynamicMenuJson.getString("menu-caption");
					if (menuCaption.equals(targetMenu)) {
						targetIframe = dynamicMenuJson.getString("menu-target");
						break;
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("targetIframe= "+targetIframe);	
		IFrame iframe = new IFrame(targetIframe);
		iframe.addClassName(SCREENCD + "_IFRAME");
		removeAll();
		add(iframe);
	}
}
