package com.umt.siteassetinventory.configuration;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/equipment_type_master-styles.css")
public class GLCodeMasterBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "GLCODE_MASTER_BEAN";
	private String glCode, glName, desc, status2,id;
	private GLCodeMaster parent;
	private Div eachrowDiv;
	//private Button editBtn, deactivateBtn;
	private Div editDiv;

	public GLCodeMasterBean(String id, String glcode,String description, 
			String status, GLCodeMaster parent) {
		this.id = id;
		this.glCode = glcode;
		this.desc = description;
		this.status2 = status;
		this.parent = parent;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");


		Label equipmentTypeIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL1");
		equipmentTypeIdVal.setText(id+"");
		eachdataDiv1.add(equipmentTypeIdVal);

		Label equipmentTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL2");
		equipmentTypeVal.setText(glcode);
		eachdataDiv2.add(equipmentTypeVal);
		
		Label equipmentTypeNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL3");
		equipmentTypeNameVal.setText(glName);
		eachdataDiv3.add(equipmentTypeNameVal);

		Label descVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL4");
		descVal.setText(desc);
		eachdataDiv4.add(descVal);

		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VAL5");
		if(status.equals("1")) {
			this.status2="Active";
			statusVal.setText(this.status2);
		}else {
			this.status2="Inactive";
			statusVal.setText(this.status2);
		}
		eachdataDiv5.add(statusVal);

		editDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EDIT_DIV");
		Image editIcon = UIHtmlFieldFactory.createImage("CONFIGURATION", "EDIT_ICON");
		editDiv.add(editIcon);

		eachrowDiv.add(eachdataDiv1,eachdataDiv2,/*eachdataDiv3,*/eachdataDiv4,eachdataDiv5,editDiv);
		add(eachrowDiv);

	
		editDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> arg0) {
				AddOrEditGLCodeDlg dlg = new AddOrEditGLCodeDlg(null,"Edit");
				dlg.setFieldValue(glcode, desc, status2,id);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AddOrEditGLCodeDlg srcDlg = (AddOrEditGLCodeDlg)event.getSource();
						if(!srcDlg.isOpened() && srcDlg.success) {
							parent.populateData();
						}
					}

				});
			}
		});
	}
	
	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	
	
	public String getGLCode() {
		return glCode;
	}

	public String getEquipmentTypeName() {
		return glName;
	}

	public String getDesc() {
		return desc;
	}

	public String getStatus() {
		return status2;
	}

	public String getIds() {
		// TODO Auto-generated method stub
		return id;
	}

}
