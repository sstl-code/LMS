package com.umt.siteassetinventory.assetinventory;

import java.io.File;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.flowingcode.vaadin.addons.googlemaps.GoogleMap;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMap.GoogleMapClickEvent;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMap.MapType;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker.GoogleMapMarkerClickEvent;
import com.flowingcode.vaadin.addons.googlemaps.LatLon;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.html.Div;

public class SitesMapView extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_MAP_VIEW";
	private List<MapMarkerData> mapMarkerList = new ArrayList<SitesMapView.MapMarkerData>(); 
	private GoogleMap siteMap;
	private String selectedSiteCode;
	private SiteMaster parent;
	
	public SitesMapView(SiteMaster parent) {
		this.parent = parent;
		siteMap = new GoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", null, null);
		siteMap.setSizeFull();
		siteMap.setMapType(MapType.ROADMAP);
		siteMap.setDraggable(true);
		siteMap.setZoom(12);
		/*
		 * siteMap.addClickListener(new
		 * ComponentEventListener<GoogleMap.GoogleMapClickEvent>() { private static
		 * final long serialVersionUID = 1L;
		 * 
		 * @Override public void onComponentEvent(GoogleMapClickEvent event) {
		 * System.out.println("Lat: " + event.getLatitude());
		 * System.out.println("Long: " + event.getLongitude()); } });
		 */
		
		//map.setCenter(new LatLon(Double.parseDouble(latitude), Double.parseDouble(longitude)));
		//map.addMarker(siteCode + "," + address, new LatLon(Double.parseDouble(latitude), Double.parseDouble(longitude)), false, "");
		
		addClassName(SCREENCD + "_MAIN_LAYOUT");
	}
	
	public void loadData(String fileName, String siteCode) {
		String homeDirectory = System.getProperty("user.home");
		String assetDataFile = homeDirectory + File.separator + "AssetInventory" + File.separator + fileName;
		Map<String, String> columnIndexMap = new HashMap<String, String>();
		mapMarkerList.clear();
		try {
			CSVParser csvParser = new CSVParser(new FileReader(assetDataFile), CSVFormat.DEFAULT);
			boolean lookUpHeader = true;
			Iterator<CSVRecord> iterator = csvParser.iterator();
			while (iterator.hasNext()) {
				CSVRecord eachRecord = iterator.next();

				if (eachRecord == null || eachRecord.size() <= 0) {
					continue;
				}

				if (lookUpHeader) {
					for (int i = 0; i < eachRecord.size(); i++) {
						//csvHeader.add(eachRecord.get(i));
						columnIndexMap.put(i + "", eachRecord.get(i));
					}
					lookUpHeader = false;
				} else {
					MapMarkerData marker = new MapMarkerData();
					for (int i = 0; i < eachRecord.size(); i++) {
						if (i == 0) {
							marker.setSiteCode(eachRecord.get(i));
						} else {
							String columnName = columnIndexMap.get(i + "");
							if(columnName.trim().equalsIgnoreCase("Site Address")) {
								marker.setSiteAddress(eachRecord.get(i));
							} else if(columnName.trim().equalsIgnoreCase("Site Region")) {
								marker.setSiteRegion(eachRecord.get(i));
							} else if(columnName.trim().equalsIgnoreCase("Latitude")) {
								marker.setLatitude(eachRecord.get(i));
							} else if(columnName.trim().equalsIgnoreCase("Longitude")) {
								marker.setLongitude(eachRecord.get(i));
							}
						}
					}
					
					mapMarkerList.add(marker);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		populateMap();
	}
	
	private void populateMap() {
		for(int i = 0; i < mapMarkerList.size(); i++) {
			//map.setCenter(new LatLon(Double.parseDouble(latitude), Double.parseDouble(longitude)));
			MapMarkerData eachItem = mapMarkerList.get(i);
			GoogleMapMarker marker = siteMap.addMarker(eachItem.getSiteCode(), new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())), false, "");
			 mapMarkerList.get(i).setMarker(marker);
			String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getSiteCode() + "</span><br><em>" + eachItem.getSiteRegion() + "</em><br><div style=\"width:200px\"><small>" + eachItem.getSiteAddress() + "</small></div></body></html>"; 
			//String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getSiteCode() + "</span></body></html>";
			marker.addInfoWindow(htmlContent);
			//marker.setInfoWindowVisible(true);
			marker.setAnimationEnabled(true);
			
			marker.addClickListener(new ComponentEventListener<GoogleMapMarker.GoogleMapMarkerClickEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(GoogleMapMarkerClickEvent event) {
					GoogleMapMarker marker = event.getSource();
					//System.out.println(marker.getCaption());
					if(parent != null) {
						parent.setSelectedSite(marker.getCaption());
						closeOtherMarkerInfoWindow(marker.getCaption());
					}
				}
			});
		}
		add(siteMap);
	}
	
	public void closeOtherMarkerInfoWindow(String code) {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if (!eachItem.getSiteCode().trim().equalsIgnoreCase(code)) {
					eachItem.getMarker().setInfoWindowVisible(false);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void closeMarkerInfoWindow() {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				//if (eachItem.getSiteCode().trim().equalsIgnoreCase(selectedSiteCode)) {
					eachItem.getMarker().setInfoWindowVisible(false);
					//break;
				//}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void setSelectedSite(String siteCode) {
		try {
			selectedSiteCode = siteCode;
			for(int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if(eachItem.getSiteCode().trim().equalsIgnoreCase(selectedSiteCode)) {
					siteMap.setCenter(new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())));
					eachItem.getMarker().setInfoWindowVisible(true);
					break;
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private class MapMarkerData implements Serializable {
		private static final long serialVersionUID = 1L;
		private String siteCode;
		private String siteAddress;
		private String siteRegion;
		private String latitude;
		private String longitude;
		private GoogleMapMarker marker;
		
		public MapMarkerData() {
			
		}

		public GoogleMapMarker getMarker() {
			return marker;
		}

		public void setMarker(GoogleMapMarker marker) {
			this.marker = marker;
		}

		public String getSiteCode() {
			return siteCode;
		}

		public void setSiteCode(String siteCode) {
			this.siteCode = siteCode;
		}

		public String getSiteAddress() {
			return siteAddress;
		}

		public void setSiteAddress(String siteAddress) {
			this.siteAddress = siteAddress;
		}

		public String getSiteRegion() {
			return siteRegion;
		}

		public void setSiteRegion(String siteRegion) {
			this.siteRegion = siteRegion;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}
	}
}
