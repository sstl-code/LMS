package com.umt.siteassetinventory.assetinventory;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/site-view.css")
public class SiteViewDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_VIEW_BEAN";
	private String sitecode;
	private SiteView parent;

	public SiteViewDataBean(String sitecode, String region, String rating, SiteView siteView) 
	{
		this.sitecode=sitecode;
		this.parent=siteView;
		Div eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
		
		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		
		
		Label sitecodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_LBL");
		sitecodeLbl.setText(sitecode);
		eachdataDiv1.add(sitecodeLbl);
		
		Label regionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGION_LBL");
		regionLbl.setText(region);
		eachdataDiv2.add(regionLbl);
		
		Label ratingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RATING_LBL");
		ratingLbl.setText(rating);
		eachdataDiv3.add(ratingLbl);
		
		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3);
		add(eachrowDiv);
		
		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				eachRowSelectionChangeHandler(sitecode);
			}
		});
	}
	protected void eachRowSelectionChangeHandler(String sitecode2) 
	{
		parent.selectedRowChangeHandler(sitecode2);
		
	}
	public String getselectedSiteCode()
	{
		return sitecode;
		
	}
	

}
