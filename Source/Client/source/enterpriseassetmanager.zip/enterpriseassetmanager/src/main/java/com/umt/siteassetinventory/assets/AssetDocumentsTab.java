package com.umt.siteassetinventory.assets;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.site.SiteDocumentUploadBean;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

@CssImport("./styles/asset_doc-styles.css")
public class AssetDocumentsTab extends VerticalLayout
{
	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "ASSET_DOCUMENT";

	private String assetId = "";
	private VerticalLayout documentsVL;
	private List<AssetDocumentUploadBean> assetDocumentUploadDatalist = new ArrayList<AssetDocumentUploadBean>();
	private AssetDocumentUploadBean eachDocument;
	//private boolean firstTimeLoad = true;
	private Div documentsHeader;


	public AssetDocumentsTab()
	{
		addClassName(SCREENCD + "_" + "MAIN_LAYOUT");

		Label headerLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL");

		/*	Icon addbtn = VaadinIcon.PLUS_CIRCLE_O.create();
		addbtn.addClassName(SCREENCD+"_ADD_BTN_ICON");*/
		//Label addbtnLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ADD_BTN_LBL");
		Button addbtn = UIFieldFactory.createButton(SCREENCD, "ADD_BTN");
		//addbtnDiv.add(/*addbtn*/addbtnLbl);

		HorizontalLayout headerLayout = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "HEADER_HL");
		headerLayout.add(headerLbl, addbtn);

		Div documentsContainer = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENT_CONTAINER_DIV");
		documentsHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENT_HEADER_DIV");
		Label type = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE");
		Label name = UIHtmlFieldFactory.createLabel(SCREENCD, "NAME");
		Label desc = UIHtmlFieldFactory.createLabel(SCREENCD, "DESC");
		documentsHeader.add(type, name, desc);


		documentsVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DOCUMENT_VL");

		documentsContainer.add(documentsHeader,documentsVL);
		add(headerLayout,documentsContainer);


		addbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

				AssetDocumentUploadDialog dlg= new AssetDocumentUploadDialog(assetId);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AssetDocumentUploadDialog srcDlg = (AssetDocumentUploadDialog)event.getSource();
						if(!srcDlg.isOpened()&&(srcDlg.isGetDocUploadStatus()==true))
						{
							populateAssetDocuments(assetId);
						} 
					}
				});
			}
		});
	}

	public void loadAssetDocumentScreen(String assetId) {
		/*if(firstTimeLoad) {*/

		this.assetId = assetId;
		populateAssetDocuments(assetId);
		//			firstTimeLoad = false;
		//
		//		}
	}

	//	private List<AssetDocumentUploadBean> generateOtherDocumentRow(AssetDocumentUploadDialog obj,String assetId) 
	//	{
	//
	//		List<String> Fieldlist= new ArrayList<>();
	//		Fieldlist.add(obj.getDocumentNameTextfield().getValue());
	//		assetDocumentUploadDatalist.clear();
	//		for(int i=0;i<Fieldlist.size();i++)
	//		{
	//			String getTextfield=Fieldlist.get(i);
	//			eachDocument =new AssetDocumentUploadBean(getTextfield,this,assetId);
	//			documentsVL.add(eachDocument.getAssetDocumentUploadBean());
	//			assetDocumentUploadDatalist.add(eachDocument);
	//		}
	//		return assetDocumentUploadDatalist;
	//
	//	}

	public List<AssetDocumentUploadBean> populateAssetDocuments(String assetId) 
	{
		documentsVL.removeAll();
		assetDocumentUploadDatalist.clear();
		String outputResponse="";
		try 
		{
			String base_URL=ApplicationConfiguration.getServiceEndpoint("GETASSETDOCUMENTS");
			base_URL = base_URL.trim()+ "?StoreSerialNo=" + assetId;
			//System.out.println(base_URL);
			outputResponse = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());	
			//System.out.println(base_URL+" :::::: "+outputResponse);
			if(outputResponse.equals(null) || outputResponse.trim().length()==0)
			{
				return null;
			}
			else { 

				JSONArray jsonArr=new JSONArray(outputResponse);
				//assetDocumentUploadDatalist.clear();
				for(int i=0;i<jsonArr.length();i++)
				{ 
					JSONObject jsonObj = jsonArr.getJSONObject(i); 
					String attributes = jsonObj.getString("attributes");
					JSONObject attributesJson = new JSONObject(attributes);
					String desc = ""; 
					if (attributesJson.has("description") && attributesJson.getString("description")!=null && attributesJson.getString("description").trim().length()>0) {
						desc = attributesJson.getString("description");
					}
					eachDocument =new AssetDocumentUploadBean(jsonObj.getString("fileuid"), attributesJson.getString("type"), jsonObj.getString("filename"), 
							desc, jsonObj.getString("url"), this, assetId);
					
					documentsVL.add(eachDocument.getAssetDocumentUploadBean());
					if (i==0) {
						System.out.println(jsonObj.getString("url").substring(0, jsonObj.getString("url").indexOf("/RuleServer"))+" replaced by "+
				      	eachDocument.getViewUrlToOpen().substring(0, eachDocument.getViewUrlToOpen().indexOf("/RuleServer")));
					}
					assetDocumentUploadDatalist.add(eachDocument);
				}
			}

		}catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

		return assetDocumentUploadDatalist;


	}

	public void removeDocumentrow(AssetDocumentUploadBean beanobj) 
	{

		documentsVL.remove(beanobj.recordHL);
		assetDocumentUploadDatalist.remove(beanobj);
		//assetDocumentUploadDatalist.remove(beanobj.RecordHL);
		/*int position = beanobj.getPosition();
        ////System.out.println("pos"+position);
        String docTypename = assetDocumentUploadDatalist.get(position).getDocName1();
        assetDocumentUploadDatalist.remove(docTypename);*/
	}

}
