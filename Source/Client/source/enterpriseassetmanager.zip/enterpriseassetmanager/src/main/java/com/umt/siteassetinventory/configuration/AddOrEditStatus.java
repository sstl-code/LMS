package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;

@CssImport("./styles/add_edit_status-styles.css")
public class AddOrEditStatus extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_STATUS";

	private TextField statusCodeFld, statusDescFld;
	private ComboBox<String> storeCombo, recStatusCombo;
	//private String siteCode;
	private long statusId;
	private Map<Long, String> storeMap;

	public AddOrEditStatus(StatusMaster statusMaster, Map<Long, String> storeMap) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		
		this.storeMap = storeMap;

		storeCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "STORE_COMBO");
		List<String> listOfValues = new ArrayList<String>();
		//System.out.println("equipmentTypeMap size="+equipmentTypeMap.size()+" equipmentTypeMap="+equipmentTypeMap.toString());
		storeMap.forEach((k,v) -> {
			//System.out.println("key="+k);
			listOfValues.add(storeMap.get(k));
		});
		storeCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
		statusCodeFld = UIFieldFactory.createTextField("", true, SCREENCD, "STATUS_CODE_FIELD");
		statusDescFld = UIFieldFactory.createTextField("", true, SCREENCD, "STATUS_DESC_FIELD");

		recStatusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, SCREENCD, "STATUS_COMBO");
		recStatusCombo.setValue("Active");
		recStatusCombo.setEnabled(false);
		
		AddOrEditStatusPopup popup = new AddOrEditStatusPopup("Add Status", true, this, statusMaster, SCREENCD);

		add(storeCombo, statusCodeFld, statusDescFld, recStatusCombo);

	}

	public AddOrEditStatus(StatusMaster statusMaster, StatusMasterDataBean statusMasterDataBean, Map<Long, String> storeMap, long statusId, String store, 
			String statusCode, String statusDesc, String recStatus) {
		this.statusId = statusId;
		this.storeMap = storeMap;
		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		try {
			storeCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "STORE_COMBO");
			List<String> listOfValues = new ArrayList<String>();
			//System.out.println("equipmentTypeMap size="+equipmentTypeMap.size()+" equipmentTypeMap="+equipmentTypeMap.toString());
			storeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				listOfValues.add(storeMap.get(k));
			});
			storeCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
			storeCombo.setValue(store);
			storeCombo.setEnabled(false);
			statusCodeFld = UIFieldFactory.createTextField(statusCode, true, SCREENCD, "STATUS_CODE_FIELD");
			statusCodeFld.setEnabled(false);
			statusDescFld = UIFieldFactory.createTextField(statusDesc, true, SCREENCD, "STATUS_DESC_FIELD");

			recStatusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "STATUS_LIST", ','), true, SCREENCD, "STATUS_COMBO");
			recStatusCombo.setValue(recStatus);
			AddOrEditStatusPopup popup = new AddOrEditStatusPopup("Edit Status", false, this, statusMaster, SCREENCD);

			add(storeCombo, statusCodeFld, statusDescFld, recStatusCombo);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean validation() {
		storeCombo.setInvalid(false);
		statusCodeFld.setInvalid(false);
		statusDescFld.setInvalid(false);
		recStatusCombo.setInvalid(false);

		if (storeCombo.getValue()==null || storeCombo.getValue().toString().trim().length()==0) {
			storeCombo.setInvalid(true);
			storeCombo.setErrorMessage("Please enter "+storeCombo.getLabel().toLowerCase());
			return false;
		}
		
		if (statusCodeFld.getValue()==null || statusCodeFld.getValue().trim().length()==0) {
			statusCodeFld.setInvalid(true);
			statusCodeFld.setErrorMessage("Please enter "+statusCodeFld.getLabel().toLowerCase());
			return false;
		}

		if (statusDescFld.getValue()==null || statusDescFld.getValue().toString().trim().length()==0) {
			statusDescFld.setInvalid(true);
			statusDescFld.setErrorMessage("Please enter "+statusDescFld.getLabel().toLowerCase());
			return false;
		}

		if (recStatusCombo.getValue()==null || recStatusCombo.getValue().trim().length()==0) {
			recStatusCombo.setInvalid(true);
			recStatusCombo.setErrorMessage("Please enter "+recStatusCombo.getLabel().toLowerCase());
			return false;
		}
		return true;
	}
	
	
	public long getStatusId() {
		return statusId;
	}

	public String getStatusCode() {
		if (statusCodeFld.getValue()==null)
			return "";
		else
			return statusCodeFld.getValue();
	}

	public String getStatusDesc() {
		if (statusDescFld.getValue()==null)
			return "";
		else
			return statusDescFld.getValue()+"";
	}

	public String getRecStatus() {
		if (recStatusCombo.getValue()==null)
			return "";
		else
			return recStatusCombo.getValue();
	}
	
	public String getStoreId() {
		if (storeCombo.getValue()==null)
			return "";
		else
		{
			Iterator<Long> equipmentKeys = storeMap.keySet().iterator();
			while (equipmentKeys.hasNext()) {
				long key = equipmentKeys.next();
				if (storeMap.get(key).trim().equals(storeCombo.getValue().trim())) {
					//System.out.println("key from get="+key);
					return key+"";
				}
		
			}
		}
		return "";
	}


}
