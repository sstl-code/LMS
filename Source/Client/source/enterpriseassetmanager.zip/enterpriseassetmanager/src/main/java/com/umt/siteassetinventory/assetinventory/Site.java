package com.umt.siteassetinventory.assetinventory;

import java.util.List;
import java.util.Map;

import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.baselayout.BaseStructure;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.router.Route;

@Route(value = "site", layout = MainView.class)

public class Site extends BaseStructure implements AfterNavigationObserver{

	
	private static final long serialVersionUID = 1L;
	public Site() {
		
	}
	@Override
	public void afterNavigation(AfterNavigationEvent event) {
//		System.out.println(event.getLocation().getPathWithQueryParameters());
//		SiteAssetInventoryUIFramework.getFramework().setCurrentPath(event.getLocation().getPathWithQueryParameters());
	}
	
	
}
