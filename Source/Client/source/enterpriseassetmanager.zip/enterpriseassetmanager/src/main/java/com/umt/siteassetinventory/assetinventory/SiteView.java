package com.umt.siteassetinventory.assetinventory;

import org.codehaus.jettison.json.JSONArray;

import com.umt.siteassetinventory.MainView;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.router.Route;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;

@Route(value = "siteview_not_required", layout = MainView.class)
@CssImport("./styles/site-view.css")
public class SiteView extends BaseStructucture
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_VIEW";
	private Tab detailsTab,attributesTab,LandlordTab,activeAssetTab,passiveAssetTab,documentTab,TicketsTab;
	private SiteDetailsTab siteDetailsTabVL;
	private SiteAttributesTab siteAttributeTabVL;

	
	private String selectedSitecode;

	public SiteView() 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Site View");
		
		detailsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DETAIL_TAB_LBL"));
		attributesTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ATTR_TAB_LBL"));
		LandlordTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "LANDLORD_TAB_LBL"));
		activeAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "ACTIVE_ASSET_TAB_LBL"));
		passiveAssetTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "PASSIVE_ASSET_TAB_LBL"));
		documentTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "DOCUMENTS_TAB_LBL"));
		TicketsTab=new Tab(SiteAssetInventoryUIFramework.getFramework().getLabel(SCREENCD, "TICKETS_TAB_LBL"));
		
		siteDetailsTabVL=new SiteDetailsTab();
		siteAttributeTabVL=new SiteAttributesTab();
		
		
		parentTabs.add(detailsTab,attributesTab,LandlordTab,activeAssetTab,passiveAssetTab,documentTab,TicketsTab);
		add(rowDiv);
		
		createHeader();
		populateSiteDetailRow();
		
		parentTabs.setSelectedTab(detailsTab);
		siteDetailsTabVL.setVisible(true);
		siteDetailsTabVL.setSiteCode(getSelectedsitecode());
		siteAttributeTabVL.setVisible(false);
		
		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) {
					siteDetailsTabVL.setVisible(true);
					siteAttributeTabVL.setVisible(false);
					siteDetailsTabVL.setSiteCode(getSelectedsitecode());
					
					
				} else if(event.getSelectedTab().equals(attributesTab)) {
					siteDetailsTabVL.setVisible(false);
					siteAttributeTabVL.setVisible(true);
					siteAttributeTabVL.setSiteCode(getSelectedsitecode());
				}
			}
		});
		
		
			
		
	}
	
	public void selectedRowChangeHandler(String siteCode) 
	{
		parentTabs.setSelectedTab(detailsTab);
		selectedSitecode=siteCode;
		siteDetailsTabVL.setSiteCode(selectedSitecode);
		
		parentTabs.addSelectedChangeListener(new ComponentEventListener<Tabs.SelectedChangeEvent>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(SelectedChangeEvent event) {
				if(event.getSelectedTab().equals(detailsTab)) 
				{
					siteDetailsTabVL.setSiteCode(selectedSitecode);
				} else if(event.getSelectedTab().equals(attributesTab)) {
					siteAttributeTabVL.setSiteCode(selectedSitecode);
				}
			}
		});
	}
	private void populateSiteDetailRow() 
	{
		
		try
		{
			String res="[\r\n" + 
					"  {\r\n" + 
					"    \"SiteCode\": \"ep.ID812940MY\",\r\n" + 
					"    \"Region\": \"Baidung\",\r\n" + 
					"    \"Rating\": \"675\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"SiteCode\": \"ep.ID539873BB\",\r\n" + 
					"    \"Region\": \"Baidung\",\r\n" + 
					"    \"Rating\": \"600\"\r\n" + 
					"  },\r\n" + 
					"  {\r\n" + 
					"    \"SiteCode\": \"ep.ID540578BR\",\r\n" + 
					"    \"Region\": \"Baidung\",\r\n" + 
					"    \"Rating\": \"500\"\r\n" + 
					"  }\r\n" + 
					"]";
			
			
			Div headerDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_HEADER_DIV");
			
			Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			
			Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
			eachdataDiv1.add(lbl1);
			Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
			eachdataDiv2.add(lbl2);
			Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
			eachdataDiv3.add(lbl3);
			headerDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3);
			col1ValueDiv.add(headerDiv);
			
			JSONArray jsarr=new JSONArray(res);
			for(int i=0;i<jsarr.length();i++)
			{
				SiteViewDataBean beanobj=new SiteViewDataBean(
						jsarr.getJSONObject(i).getString("SiteCode"),
						jsarr.getJSONObject(i).getString("Region"),
						jsarr.getJSONObject(i).getString("Rating"),this);
						
						
				col1ValueDiv.add(beanobj);
				if(i==0)
				{
					selectedSitecode=jsarr.getJSONObject(i).getString("SiteCode");
				}
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
			
		
	}
	private void createHeader() 
	{
		Div eachDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		Div eachDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_DIV");
		
		Label headerLbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_LBL1");
		eachDiv1.add(headerLbl1);
		
		col1HeaderDiv.add(eachDiv1,eachDiv2,eachDiv3);
		
		
	}
	public String getSelectedsitecode()
	{
		return selectedSitecode;
		
	}
	

}
