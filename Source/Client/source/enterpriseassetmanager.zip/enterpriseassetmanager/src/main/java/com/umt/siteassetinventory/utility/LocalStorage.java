package com.umt.siteassetinventory.utility;

import com.vaadin.flow.component.UI;

public class LocalStorage {

	//private static String KEY_NAME = "FormValue";
	private static String formvalue=null;
    public enum Storage {
        localStorage
    }

    public interface Callback {
        void onValueDetected(String value);
    }

    
    public static void setItem(String key, String value) {
        setItem(Storage.localStorage, key, value);
    }

 
    public static void setItem(Storage storage, String key, String value) {
        setItem(UI.getCurrent(), storage, key, value);
    }

    public static void setItem(UI ui, Storage storage, String key, String value) {
        ui.getPage().executeJs("window[$0].setItem($1,$2)", storage.toString(), key, value);
    }

    public static void removeItem(String key) {
        removeItem(Storage.localStorage, key);
    }

    
    public static void removeItem(Storage storage, String key) {
        removeItem(UI.getCurrent(), storage, key);
    }

   
    public static void removeItem(UI ui, Storage storage, String key) {
        ui.getPage().executeJs("window[$0].removeItem($1)", storage.toString(), key);
    }

    public static void clear() {
        clear(Storage.localStorage);
    }

    public static void clear(Storage storage) {
        clear(UI.getCurrent(), storage);
    }

    public static void clear(UI ui, Storage storage) {
        ui.getPage().executeJs("window[$0].clear()", storage.toString());
    }

  
    public static void getItem(String key, Callback callback) {
        getItem(Storage.localStorage, key, callback);
    }

   
    public static void getItem(Storage storage, String key, Callback callback) {
        getItem(UI.getCurrent(), storage, key, callback);
    }

    public static void getItem(UI ui, Storage storage, String key, Callback callback) {
        ui.getPage()
                .executeJs("return window[$0].getItem($1);", storage.toString(), key)
                .then(String.class, callback::onValueDetected, s -> {
                    // for error (most likely non-existing mapping), return null
                    callback.onValueDetected(null);
                })
        ;
    }
    
    public static String showStoredValue(String KEY_NAME) {
    	
		LocalStorage.getItem(
			KEY_NAME,
            value -> {
            	System.out.println("Stored value:=="+value);
            	formvalue=value;
            	
            }
        );
		return formvalue;
		
    }

}
