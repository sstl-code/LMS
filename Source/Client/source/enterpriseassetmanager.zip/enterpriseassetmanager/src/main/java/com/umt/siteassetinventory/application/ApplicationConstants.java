package com.umt.siteassetinventory.application;

public interface ApplicationConstants 
{
	public static final String LOGIN_MEDIA_GOOGLE = "GOOGLE";
	public static final String LOGIN_MEDIA_FACEBOOK = "FACEBOOK";
	public static final String LOGIN_MEDIA_LINKEDIN = "LINKEDIN";
	public static final String API_RESPONSE_STATUS_CODE = "Status";	
	public static final String API_RESPONSE_MESSAGE = "Message";
	public static final String LOGIN_MEDIA_SELF = "SELF";
	public static final String API_RESPONSE_ACCOUNT_NO = "Account Number";	
	
	public enum DialogTypes {INFO, ERROR};
	
	public static final String USER_PROFILE_READ = "UserProfile_Read";
	public static final String PARTNER_PROFILE_READ = "PartnerProfile_Read";
	public static final String PARTNER_PROFILE_UPDATE = "PartnerProfile_Update";
	public static final String SETTINGS_READ = "Settings_Read";	
	public static final String SETTINGS_UPDATE = "Settings_Update";
	public static final String MASTER_CREATE = "Master_Create";
	public static final String MASTER_READ = "Master_Read";	
	public static final String MASTER_DELETE = "Master_Delete";
	public static final String MASTER_UPDATE = "Master_Update";
	public static final String USER_CREATE = "User_Create";
	public static final String USER_READ = "User_Read";	
	public static final String USER_UPDATE = "User_Update";
	public static final String USER_DELETE = "User_Delete";
	public static final String CUSTOMER_CREATE = "Customer_Create";
	public static final String CUSTOMER_READ = "Customer_Read";
	public static final String CUSTOMER_UPDATE = "Customer_Update";
	public static final String CUSTOMER_DELETE = "Customer_Delete";
	public static final String PAYMENT_CREATE = "Payment_Create";
	public static final String PAYMENT_READ = "Payment_Read";
	public static final String SEARCH_READ = "Search_Read";
	public static final String BILLING_ADMIN_CONSOLE_READ = "BillingAdminConsole_Read";
	public static final String BILLING_ADMIN_CONSOLE_CREATE = "BillingAdminConsole_Create";
	public static final String BILLGEN_MANAGE = "BillGen_Manage";
	public static final String BILLPOST_MANAGE = "BillPost_Manage";	
	public static final String LEDGER_CREATE = "Ledger_Create";
	public static final String LEDGER_READ = "Ledger_Read";
	public static final String LEDGER_MANAGE = "Ledger_Manage";	
	public static final String EMAIL_MANAGE = "Email_Manage";
	public static final String DUNNING_MANAGE = "Dunning_Manage";
	public static final String CHARGING_READ = "Charging_Read";
	public static final String COMMON_READ = "Common_Read";	
	public static final String BILLING_CORE_API_READ = "BillingCoreAPI_Read";
	public static final String BILLING_CORE_API_CREATE = "BillingCoreAPI_Create";
	public static final String BILLING_CORE_API_UPDATE = "BillingCoreAPI_Update";
	public static final String ODBILLGEN_CREATE = "ODBillGen_Create";
	public static final String ODBILLPOST_CREATE = "ODBillPost_Create";
	public static final String PDFGEN_READ = "PDFGen_Read";
	public static final String OFFERING_CONTROLLER_READ = "OfferingController_Read";
	public static final String OFFERING_CONTROLLER_CREATE = "OfferingController_Create";
	
	public enum Menu {NullValue, SiteView, AssetView, LandlordView, Configuration, UserManagement, AuditTrail, Report, Default, Logout,
		GalaxyView,InvoiceManagement,MyTasks,ChangePw};
	
}
