package com.umt.siteassetinventory.site;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.assets.AssetsView;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/electric-meter-tab-styles.css")
public class AddElectricMetersDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_ELECTRIC_METERS_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv,additionalAttrDiv,col1Div,col2Div;
	private Div mainLayout,closeBtnDiv;
	private Button saveBtn,cancelBtn;
	private TextField descriptionField,SerialNoField,consumerNoField,sebmeterAuthorityField;
	private HashMap<String, List<Object>> dynamicAttributesMap;
	private String attrname,mandatoryFlag;
	private ComboBox<String> AssetTypeCombo,AssetCombo,VendorCombo;
	private List<String> assetList,vendorList;
	private HashMap<String,JSONObject> assetMap,vendorMap;
	private Map<Long, String> activeEquipmentTypeMap, passiveEquipmentTypeMap;
	private Map<String, JSONArray> attributeListMap;
	private String equipmentTypeId,vendorId;
	private String attributeDatatype;
	private SiteElectricMeterTab siteElectricMeterTab;
	private String allVendors;
	private ComboBox<String> metertypeField;
	private List<String> metertypeList=new ArrayList<String>();
	private DatePicker sebmeterinstalationDateField;
	private Div eachDataDiv1,eachDataDiv2,eachDataDiv3,eachDataDiv4,eachDataDiv5;
	private Div row1,row2,row3;
	

	public AddElectricMetersDialog(SiteElectricMeterTab siteElectricMeterTab) {
		
		this.siteElectricMeterTab=siteElectricMeterTab;
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		closeBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
	//	Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
	//	closeBtnDiv.add(closeImg);
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);

		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);

	//	generateFieldNameValuePair();
		
		generateFieldNameValuePair2();

		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});

		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});
		saveBtn.setDisableOnClick(true);
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
			//	saveData2();
				saveData3();
			}
		});
		
		metertypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					metertypeField.setInvalid(false);
					metertypeField.setErrorMessage("");
				}else {
					metertypeField.setInvalid(true);
					metertypeField.focus();
					metertypeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
				}

			}
		});
	}

	protected void saveData3() {
		try {
			if((SerialNoField.getValue().length()<=0)){
				if(SerialNoField.getValue().length()<=0)
				{
					SerialNoField.setInvalid(true);
					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
					
		    }
		
			if((SerialNoField.getValue().length()>0))
			{	
				JSONObject saveobjJson=new JSONObject();
				
				saveobjJson.put("EquipmentTypeId","1");
				saveobjJson.put("VendorId","1");
				saveobjJson.put("Description","");
				saveobjJson.put("SerialNo",SerialNoField.getValue());


				JSONObject otherinfoJson=new JSONObject();
				
				if(metertypeField.isRequired()==true) {
					if(metertypeField.getValue()==null || metertypeField.getValue().length()<=0) {
						metertypeField.setInvalid(true);
						metertypeField.focus();
						metertypeField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Meter Category",metertypeField.getValue());
					}
				}else {
					metertypeField.setInvalid(false);
					metertypeField.setErrorMessage("");
				}
				
				if(consumerNoField.isRequired()==true) {
					if(consumerNoField.getValue()==null || consumerNoField.getValue().length()<=0) {
						consumerNoField.setInvalid(true);
						consumerNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("Consumer No",consumerNoField.getValue());
					}
				}else {
					consumerNoField.setInvalid(false);
					consumerNoField.setErrorMessage("");
				}
				
				if(sebmeterinstalationDateField.isRequired()==true) {
					if(sebmeterinstalationDateField.getValue()==null) {
						sebmeterinstalationDateField.setInvalid(true);
						sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"DATE_VALUE_MANDATORY"));
						return;
					}
					else if(sebmeterinstalationDateField.getValue()!=null) {
						LocalDate now = LocalDate.now();
						String currentDate=CommonUtils.convertLocalDateToString(now);
						
						Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
						Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse(currentDate);
						
						if(date1.after(date2)){
				            sebmeterinstalationDateField.setInvalid(true);
							sebmeterinstalationDateField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"WRONG_VALUE"));
							return;
				        }else {
				        	otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
				        }
					}
					else {
						otherinfoJson.put("SEB Meter Installation Date",CommonUtils.convertLocalDateToString(sebmeterinstalationDateField.getValue()));
					}
				}else {
					sebmeterinstalationDateField.setInvalid(false);
					sebmeterinstalationDateField.setErrorMessage("");
				}

				
				if(sebmeterAuthorityField.isRequired()==true) {
					if(sebmeterAuthorityField.getValue()==null || sebmeterAuthorityField.getValue().length()<=0) {
						sebmeterAuthorityField.setInvalid(true);
						sebmeterAuthorityField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
						return;
					}else {
						otherinfoJson.put("SEB Meter Authority",sebmeterAuthorityField.getValue());
					}
				}else {
					sebmeterAuthorityField.setInvalid(false);
					sebmeterAuthorityField.setErrorMessage("");
				}

				saveobjJson.put("OtherInfo",otherinfoJson);
//				System.out.println("saveobjJson="+saveobjJson);
				
//				saveBtn.setEnabled(false);

				Form form =new Form();
				form.add("EquipmentInfo",saveobjJson);
				System.out.println("form="+form);

				String url=ApplicationConfiguration.getServiceEndpoint("CREATEEQUIPMENT");
				//System.out.println("url="+url);
				String resp=RestServiceHandler.createJSON_POST(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				System.out.println("CREATE_EQUIPMENTresp="+resp);
				callAddAssetToSiteApi(resp);
			
			}	
				
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		finally {
			saveBtn.setEnabled(true);
		}
		
		
	}


	private void generateFieldNameValuePair2() {
		row1=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row2=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row3=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		//UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		eachDataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		eachDataDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
		
		SerialNoField= UIFieldFactory.createTextField("", true, SCREENCD,"SERIAL_NO_FIELD");
		consumerNoField= UIFieldFactory.createTextField("", false, SCREENCD,"CONSUMER_NO_FIELD");
		sebmeterAuthorityField= UIFieldFactory.createTextField("", false, SCREENCD,"SEBAUTHORITY_FIELD");
		metertypeField=UIFieldFactory.createComboBox(metertypeList, true, SCREENCD,"METERTYPE_FIELD");
		sebmeterinstalationDateField=UIFieldFactory.createDatePicker(false, SCREENCD,"PERIOD_END_DATE_FIELD");
		eachDataDiv1.add(metertypeField);
		eachDataDiv2.add(consumerNoField);
		eachDataDiv3.add(sebmeterinstalationDateField);
		eachDataDiv4.add(sebmeterAuthorityField);
		eachDataDiv5.add(SerialNoField);
		populatemetertypeCombo();
		
		row1.add(eachDataDiv1,eachDataDiv2);
		row2.add(eachDataDiv3,eachDataDiv4);
		row3.add(eachDataDiv5);
	//	row.add(row1,row2);
		bodyDiv.add(row1,row2,row3);
		
		metertypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if(value!=null)
				{
					attributeUiOrchestration(value);
				
				}


			}
		});

		
	}


	protected void attributeUiOrchestration(String value) {
		if(value.equalsIgnoreCase("SEB Meter")) {
			eachDataDiv2.setVisible(true);
			eachDataDiv3.setVisible(true);
			eachDataDiv4.setVisible(true);
			
			mandatoryFields();
		}else if(value.equalsIgnoreCase("SEB Prepaid Meter")) {
			eachDataDiv2.setVisible(true);
			eachDataDiv3.setVisible(true);
			eachDataDiv4.setVisible(true);
			
			mandatoryFields();
		}
		else if(value.equalsIgnoreCase("Sub Meter")) {
			eachDataDiv2.setVisible(false);
			eachDataDiv3.setVisible(false);
			eachDataDiv4.setVisible(false);
			
			nonmandatoryFields();
		}else if(value.equalsIgnoreCase("Prepaid Meter")) {
			eachDataDiv2.setVisible(false);
			eachDataDiv3.setVisible(false);
			eachDataDiv4.setVisible(false);
			nonmandatoryFields();
		}else {
			
		}
		
	}


	
	private void mandatoryFields() {
		consumerNoField.setVisible(true);
		consumerNoField.setRequired(true);
		consumerNoField.setRequiredIndicatorVisible(true);
		
		sebmeterinstalationDateField.setVisible(true);
		sebmeterinstalationDateField.setRequired(true);
		sebmeterinstalationDateField.setRequiredIndicatorVisible(true);
		
		sebmeterAuthorityField.setVisible(true);
		sebmeterAuthorityField.setRequired(true);
		sebmeterAuthorityField.setRequiredIndicatorVisible(true);
		
	//	row3.remove(eachDataDiv5);
	//	row1.remove(eachDataDiv5);
		
		row1.removeAll();
		row3.removeAll();
		
		row1.add(eachDataDiv1,eachDataDiv2);
		row3.add(eachDataDiv5);
	}
	
	private void nonmandatoryFields() {
		consumerNoField.setVisible(false);
		consumerNoField.setRequired(false);
		consumerNoField.setRequiredIndicatorVisible(false);
		
		sebmeterinstalationDateField.setVisible(false);
		sebmeterinstalationDateField.setRequired(false);
		sebmeterinstalationDateField.setRequiredIndicatorVisible(false);
		
		sebmeterAuthorityField.setVisible(false);
		sebmeterAuthorityField.setRequired(false);
		sebmeterAuthorityField.setRequiredIndicatorVisible(false);
		
		row1.removeAll();
		row3.removeAll();
		row1.add(eachDataDiv1,eachDataDiv5);
	}




	private void populatemetertypeCombo() {
		metertypeList=new ArrayList<String>();
		String str[] = {"SEB Meter","Sub Meter","Prepaid Meter","SEB Prepaid Meter"};
		for (int i = 0; i < str.length; i++) {
			metertypeList.add(str[i]);
		}
		
		metertypeField.setItems(metertypeList);
		if(metertypeList.size()>0) {
			metertypeField.setValue(metertypeList.get(0));
			if(metertypeField.getValue()!=null) {
				attributeUiOrchestration(metertypeField.getValue());
			}
			
		}
		
	}


	protected void saveData2() {
		try {
			if((SerialNoField.getValue().length()<=0)){
				if(SerialNoField.getValue().length()<=0)
				{
					SerialNoField.setInvalid(true);
					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
					
		    }
		
			if((SerialNoField.getValue().length()>0))
			{	
				JSONObject saveobjJson=new JSONObject();
				/*saveobjJson.put("EquipmentTypeId",equipmentTypeId);
				saveobjJson.put("VendorId",vendorId);
				saveobjJson.put("Description",descriptionField.getValue());
				saveobjJson.put("SerialNo",SerialNoField.getValue());*/
				saveobjJson.put("EquipmentTypeId","1");
				saveobjJson.put("VendorId","1");
				saveobjJson.put("Description","");
				saveobjJson.put("SerialNo",SerialNoField.getValue());


				JSONObject otherinfoJson=new JSONObject();


				if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
				{
					Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();
					//	System.out.println("dynamicAttributesMap="+dynamicAttributesMap);

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=dynamicAttributesMap.get(key);

						if(value.size()>0)
						{	
							String datatype=dynamicAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=dynamicAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":

								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									otherinfoJson.put(key, ((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField)dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;

								}
								if (((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()!=null)
								{
									otherinfoJson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							}
						}	
					}
				}

				saveobjJson.put("OtherInfo",otherinfoJson);
				System.out.println("saveobjJson="+saveobjJson);

				Form form =new Form();
				form.add("EquipmentInfo",saveobjJson);
				System.out.println("form="+form);

				String url=ApplicationConfiguration.getServiceEndpoint("CREATEEQUIPMENT");
				//System.out.println("url="+url);
				String resp=RestServiceHandler.createJSON_POST(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				System.out.println("CREATE_EQUIPMENTresp="+resp);
				callAddAssetToSiteApi(resp);
				//SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
				//isSuccess=true;
				//close();

			}	
				
		}catch(Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
		
	}


	protected void saveData() 
	{

		try 
		{
//			if((AssetCombo.getValue()==null)|| (VendorCombo.getValue()==null)||
//					(descriptionField.getValue().length()<=0)||(SerialNoField.getValue().length()<=0))
			if((SerialNoField.getValue().length()<=0)){

			{
			/*	if(AssetCombo.getValue()==null)
				{
					AssetCombo.setInvalid(true);
					AssetCombo.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
				if(VendorCombo.getValue()==null)
				{
					VendorCombo.setInvalid(true);
					VendorCombo.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}*/
				if(SerialNoField.getValue().length()<=0)
				{
					SerialNoField.setInvalid(true);
					SerialNoField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}
			/*	if(descriptionField.getValue().length()<=0)
				{
					descriptionField.setInvalid(true);
					descriptionField.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
					return;
				}*/




			}

			System.out.println("SerialNoField.getValue()="+SerialNoField.getValue());
//			if((AssetCombo.getValue()!=null)&& (VendorCombo.getValue()!=null) && (descriptionField.getValue().length()>0)
//					&& (SerialNoField.getValue().length()>0))
			if((SerialNoField.getValue().length()>0))
			{	
				System.out.println("inside");

				JSONObject saveobjJson=new JSONObject();
				/*saveobjJson.put("EquipmentTypeId",equipmentTypeId);
				saveobjJson.put("VendorId",vendorId);
				saveobjJson.put("Description",descriptionField.getValue());
				saveobjJson.put("SerialNo",SerialNoField.getValue());*/
				saveobjJson.put("EquipmentTypeId","1");
				saveobjJson.put("VendorId","1");
				saveobjJson.put("Description","");
				saveobjJson.put("SerialNo",SerialNoField.getValue());


				JSONObject otherinfoJson=new JSONObject();


				if(dynamicAttributesMap!=null && dynamicAttributesMap.size()>0)
				{
					Iterator<String> itrKeys = dynamicAttributesMap.keySet().iterator();
					//	System.out.println("dynamicAttributesMap="+dynamicAttributesMap);

					while (itrKeys.hasNext()) 
					{
						String key = itrKeys.next();
						List<Object> value=dynamicAttributesMap.get(key);

						if(value.size()>0)
						{	
							String datatype=dynamicAttributesMap.get(key).get(0).toString().toUpperCase();
							String mandatory=dynamicAttributesMap.get(key).get(2).toString();
							switch(datatype)
							{
							case "FLOV":

								if(mandatory.equalsIgnoreCase("1")&&((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()==null)			
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue()!=null)			
								{
									otherinfoJson.put(key, ((ComboBox<Object>)dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "NUMERIC":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "ALPHANUMERIC":
								if(mandatory.equalsIgnoreCase("1")&&((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if(((TextField)dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField)dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							case "DATE":
								if (mandatory.equalsIgnoreCase("1")&&((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()==null)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;

								}
								if (((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()!=null)
								{
									otherinfoJson.put(key, CommonUtils.convertLocalDateToString(
											((DatePicker) dynamicAttributesMap.get(key).get(1)).getValue()));
								}
								break;
							case "FREEFLOW":
								if (mandatory.equalsIgnoreCase("1")&&((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()<=0)
								{
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setInvalid(true);
									((HasValidation) dynamicAttributesMap.get(key).get(1)).setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"VALUE_MANDATORY"));
									return;
								}
								if (((TextField) dynamicAttributesMap.get(key).get(1)).getValue().toString().length()>0)
								{
									otherinfoJson.put(key, ((TextField) dynamicAttributesMap.get(key).get(1)).getValue());
								}
								break;
							}
						}	
					}
				}

				saveobjJson.put("OtherInfo",otherinfoJson);
				System.out.println("saveobjJson="+saveobjJson);

				Form form =new Form();
				form.add("EquipmentInfo",saveobjJson);
				System.out.println("form="+form);

				String url=ApplicationConfiguration.getServiceEndpoint("CREATEEQUIPMENT");
				//System.out.println("url="+url);
				String resp=RestServiceHandler.createJSON_POST(url, form, SiteAssetInventoryUIFramework.getFramework().getToken());
				System.out.println("CREATE_EQUIPMENTresp="+resp);
				callAddAssetToSiteApi(resp);
				//SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
				//isSuccess=true;
				//close();

			}	
		
		}}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

	}

	private void callAddAssetToSiteApi(String storeserialno) {
		try {
	//		saveBtn.setEnabled(false);
			Form formData = new Form();
			formData.add("SiteCode",siteElectricMeterTab.getSiteCode());
			formData.add("StoreSerialNo",storeserialno);
			formData.add("Remarks","");
			String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDASSETTOSITE");
			RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			close();
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
			siteElectricMeterTab.refreshData();
	
		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		
		}
		
	}


	private void generateFieldNameValuePair() 
	{
		try {	
			Div row1=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row2=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
			Div row3=UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");

			Div eachDataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");
			Div eachDataDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV");

			assetList=new ArrayList<String>();
			vendorList=new ArrayList<String>();

			populateEquipmentTypeCombo();
			//	populateVendorTypeCombo();

			AssetTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "ASSET_TYPE_LIST", ','), true, SCREENCD, "ASSET_TYPE_COMBO");
			AssetTypeCombo.setValue("Passive");
			
			activeEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				assetList.add(activeEquipmentTypeMap.get(k));
			});
			AssetCombo = UIFieldFactory.createComboBox(assetList, true, SCREENCD, "ASSET_COMBO");
			VendorCombo=UIFieldFactory.createComboBox(vendorList, true, SCREENCD, "VENDOR_COMBO");

			descriptionField= UIFieldFactory.createTextField("", true, SCREENCD,"DESCRIPTION_FIELD");
			SerialNoField= UIFieldFactory.createTextField("", true, SCREENCD,"SERIAL_NO_FIELD");

			eachDataDiv1.add(AssetTypeCombo);
			eachDataDiv2.add(AssetCombo);
			eachDataDiv3.add(VendorCombo);
			eachDataDiv5.add(descriptionField);
			eachDataDiv4.add(SerialNoField);
			

		/*	row1.add(eachDataDiv1,eachDataDiv2);
			row2.add(eachDataDiv3,eachDataDiv4);
			row3.add(eachDataDiv5);*/
			row1.add(SerialNoField);


			additionalAttrDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_DIV");
			/*	col1Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL1_DIV");
		col2Div=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL2_DIV");
		Div colRowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ADDITIONAL_ATTR_COL_ROW_DIV");
		colRowDiv.add(col1Div,col2Div);
		additionalAttrDiv.add(colRowDiv);*/

	//		bodyDiv.add(row1,row2,row3,additionalAttrDiv);
			bodyDiv.add(row1,additionalAttrDiv);

			assetTypeChangeHandler();
			//System.out.println("assetList="+assetList);
			
			AssetTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					assetTypeChangeHandler();

				}
			});

			AssetCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					String value = event.getValue();
					//VendorCombo.clear();
					VendorCombo.setItems(new ArrayList<String>());
					if (value!=null && value.trim().length()>0) {
						getAssetAttributes(value);
						populateVendorTypeCombo(value);
					}
					

				}
			});
			VendorCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void valueChanged(ValueChangeEvent<String> event) {
					String value = event.getValue();
					if(value!=null)
					{
						getVendorId(value);
					}


				}
			});


		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	


	private void assetTypeChangeHandler() {
		List<String> listOfValues = new ArrayList<String>();
		VendorCombo.setItems(new ArrayList<String>());
		if (AssetTypeCombo.getValue()!=null && AssetTypeCombo.getValue().trim().length()>0) {
			if (AssetTypeCombo.getValue().trim().equalsIgnoreCase("ACTIVE")) {
			//	VendorCombo.setLabel("Operator");
				activeEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(activeEquipmentTypeMap.get(k));
				});	
			} else if (AssetTypeCombo.getValue().trim().equalsIgnoreCase("PASSIVE")) {
				//VendorCombo.setLabel("Vendor");
				//VendorCombo.setLabel("Electric Meter Operator");
				passiveEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(passiveEquipmentTypeMap.get(k));
				});	
			}				
		}
//		System.out.println("listOfValues=="+listOfValues);
		AssetCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
		if(listOfValues.size()>0) {
				AssetCombo.setValue(listOfValues.get(0));
				String assetcombovalue = AssetCombo.getValue();
				if (assetcombovalue!=null && assetcombovalue.trim().length()>0) {
					getAssetAttributes(assetcombovalue);
					populateVendorTypeCombo(assetcombovalue);
				}
			}
	}

	private void populateEquipmentTypeCombo() 
	{
		try {
			//assetList.clear();
			assetMap = new HashMap<>();
			activeEquipmentTypeMap = new HashMap<>();
			passiveEquipmentTypeMap = new HashMap<>();
			String res="";
			String url=ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPE");
			res=RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());

			//System.out.println(url+" eqip_type::"+res);

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						String serviceType = "";
						JSONObject jo = jsarr.getJSONObject(i);
						String equipmentType=jo.getString("EquipmentType");
						//assetList.add(equipmentType);
						assetMap.put(equipmentType,jsarr.getJSONObject(i));

						if (jo.getString("ServiceType")!=null) {
							serviceType = jo.getString("ServiceType");
						} 
						if (Integer.parseInt(serviceType)==1) {
							activeEquipmentTypeMap.put(jo.getLong("EquipmentTypeId"), equipmentType);
						} else if (Integer.parseInt(serviceType)==0) {
							passiveEquipmentTypeMap.put(jo.getLong("EquipmentTypeId"), equipmentType);
						}
					}
				}

			}

		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

	}
	private void populateVendorTypeCombo(String attributetype) 
	{
		try {

			String equipmentTypeId1=assetMap.get(attributetype).getString("EquipmentTypeId");
			//	System.out.println("equipmentTypeId1="+equipmentTypeId1);

			vendorList=new ArrayList<String>();
			//	VendorCombo=UIFieldFactory.createComboBox(vendorList, true, SCREENCD, "VENDOR_COMBO");

			vendorList.clear();
			vendorMap = new HashMap<>();
			LinkedHashSet<String> uniqueVendorNameList = new LinkedHashSet<String>();
			String res="";
			String url=ApplicationConfiguration.getServiceEndpoint("GET_EQUIPMENT_TYPE_VENDOR");
			url=url+"?EquipmentTypeId="+Integer.parseInt(equipmentTypeId1);
			//System.out.println("GET_EQUIPMENT_TYPE_VENDOR_url::"+url);
			res=RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());

			//System.out.println("GET_EQUIPMENT_TYPE_VENDOR::"+res);

			//		System.out.println("vendor_type::"+res);

			if(res!=null && res.trim().length()>0)
			{
				JSONArray jsarr=new JSONArray(res);
				if(jsarr.length()>0)
				{
					for(int i=0;i<jsarr.length();i++)
					{
						String vendorname=jsarr.getJSONObject(i).getString("VendorName");
						String vendorid=jsarr.getJSONObject(i).getString("VendorId");
						String response = getAllVendors();
						try {
							JSONArray ja = new JSONArray(response);
							for (int v = 0; v < ja.length(); v++) {
								JSONObject jo = ja.getJSONObject(v);
								if (jo.getString("VendorName").equals(vendorname) && jo.getInt("Status")==1) {
									uniqueVendorNameList.add(vendorname);
									vendorMap.put(vendorname,jsarr.getJSONObject(i));
									break;
								}
							}
						}
						catch (Exception e) {
							e.printStackTrace();
						}	
						
						
					}
				}

			}
			VendorCombo.setItems(uniqueVendorNameList);

		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}

	}
	
	private String getAllVendors()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETALLVENDORS");
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + " response ::::::: "+response);
			if(response!=null && response.length()>0) {
				allVendors=response;
			}else {
				allVendors="[]";
			}
			return allVendors;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	protected void getVendorId(String vendorname) 
	{
		try
		{
			String vendorId1=vendorMap.get(vendorname).getString("VendorId");
			vendorId=vendorId1;

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	private void getAssetAttributes(String attributetype) 
	{
		String res="";
		try 
		{
			String equipmentTypeId1=assetMap.get(attributetype).getString("EquipmentTypeId");
			equipmentTypeId=equipmentTypeId1;

			String url=ApplicationConfiguration.getServiceEndpoint("GETASSETATTRIBUTE");
			url=url+"?AttributeType="+""+"&EquipmentTypeId="+Integer.parseInt(equipmentTypeId1);
			System.out.println("attr_url::"+url);
			res=RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());

			System.out.println("attr_res::"+res);

			populateAssetLevelAttributes2(res);

		}catch(Exception e)
		{
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

	private Map<String, JSONArray>   populateAssetLevelAttributes2(String response)
	{
		additionalAttrDiv.removeAll();
		attributeListMap= new LinkedHashMap<String, JSONArray>();

		String res = response;

		try {
			if (res != null) 
			{
				JSONArray ja = new JSONArray(res);
				if(ja.length()>0)
				{
					attributeListMap.put("ASSET_ATTRIBUTES", ja);
				}

				//	System.out.println("Map="+attributeListMap);

				/***additional attr****/
				if(attributeListMap!=null && attributeListMap.size()>0)	
				{
					Map<String, JSONArray> attributeMap=attributeListMap;
					JSONArray mapvalueArr=attributeMap.get("ASSET_ATTRIBUTES");
					Div attrrow=null;
					dynamicAttributesMap = new HashMap<>();
					for(int i=0;i<mapvalueArr.length();i++)
					{

						JSONObject js=mapvalueArr.getJSONObject(i);
						List<Object> dataTypeList = new ArrayList<>();
						Iterator<String> keys = js.keys();
						Div eachDataDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
						if((i%2)==0)
						{
							attrrow=UIHtmlFieldFactory.createDiv(SCREENCD, "ATTR_ROW_DIV");
						}



						//	while(keys.hasNext()) 
						//	{
						//   String key = keys.next();
						attrname=js.getString("AttributeName");
						String defaultval= "";
						if (js.has("DefaultValue") && js.getString("DefaultValue")!=null && js.getString("DefaultValue").trim().length()>0) {
							defaultval=js.getString("DefaultValue");
						}
						mandatoryFlag=js.getString("Mandatory").toString();
						attributeDatatype=js.getString("AttributeDatatype");

						switch(attributeDatatype.toString())
						{
						case "5":
							String datatype="FLOV";
							List<String> choiceList=new ArrayList<String>();
							String str=js.getString("FLOV");
							String flovVal[]=str.split(",");
							choiceList.clear();
							for(String s:flovVal)
							{
								choiceList.add(s);
							}
							ComboBox<String> valueCombo = UIFieldFactory.createComboBox(choiceList, false, SCREENCD, "VALUE");
							valueCombo.setLabel(attrname);

							dataTypeList.add(datatype);
							dataTypeList.add(valueCombo);
							dataTypeList.add(mandatoryFlag);
							if(defaultval.length()>0)
							{
								valueCombo.setValue(defaultval);
							}
							if(mandatoryFlag.equals("1"))
							{
								valueCombo.setInvalid(false);
								valueCombo.setRequiredIndicatorVisible(true);
							}

							eachDataDiv.add(valueCombo);
							attrrow.add(eachDataDiv);

							break;
						case "1":
							datatype="NUMERIC";
							TextField numberTextField=UIFieldFactory.createTextField("", false, SCREENCD, "VALUE");
							numberTextField.setLabel(attrname);
							//	numberTextField.setValue(Double.parseDouble(defaultval));
							dataTypeList.add(datatype);
							dataTypeList.add(numberTextField);
							dataTypeList.add(mandatoryFlag);
							if(defaultval.length()>0)
							{
								numberTextField.setValue(defaultval);
							}
							if(mandatoryFlag.equals("1"))
							{
								numberTextField.setInvalid(false);
								numberTextField.setRequiredIndicatorVisible(true);
							}
							numberTextField.setValueChangeMode(ValueChangeMode.EAGER);
							numberTextField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

								private static final long serialVersionUID = 1L;

								@Override
								public void valueChanged(ValueChangeEvent<?> arg0) {

									if(!arg0.getValue().toString().matches("[0-9]+") && !arg0.getValue().toString().matches(""))
									{
										numberTextField.setValue(arg0.getOldValue().toString());
									}
									if(!arg0.getValue().toString().matches("^\\w*$"))
									{
										numberTextField.setValue(arg0.getOldValue().toString());
									}
								}
							});

							eachDataDiv.add(numberTextField);
							attrrow.add(eachDataDiv);

							break;
						case "4":
							datatype="DATE";
							DatePicker ValueDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "VALUE");
							ValueDateField.setLabel(attrname);
							dataTypeList.add(datatype);
							dataTypeList.add(ValueDateField);
							dataTypeList.add(mandatoryFlag);
							if(defaultval.length()>0)
							{
								ValueDateField.setValue(CommonUtils.convertStringToLocalDate(defaultval,"dd/MM/yyyy"));
							}
							if(mandatoryFlag=="1")
							{
								ValueDateField.setRequired(false);
								ValueDateField.setRequiredIndicatorVisible(true);
							}

							eachDataDiv.add(ValueDateField);
							attrrow.add(eachDataDiv);


							break; 
						case "3":
							datatype="FREEFLOW";
							TextField textField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
							textField.setLabel(attrname);
							//	textField.setValue(defaultval);
							dataTypeList.add(datatype);
							dataTypeList.add(textField);
							dataTypeList.add(mandatoryFlag);
							if(defaultval.length()>0)
							{
								textField.setValue(defaultval);
							}
							if(mandatoryFlag.equals("1"))
							{
								textField.setRequired(false);
								textField.setRequiredIndicatorVisible(true);
							}

							eachDataDiv.add(textField);
							attrrow.add(eachDataDiv);


							break;
						case "2":
							datatype="ALPHANUMERIC";
							TextField alphanumericField=UIFieldFactory.createTextField("",false, SCREENCD, "VALUE");
							alphanumericField.setLabel(attrname);
							//	alphanumericField.setValue(defaultval);
							dataTypeList.add(datatype);
							dataTypeList.add(alphanumericField);
							dataTypeList.add(mandatoryFlag);
							if(defaultval.length()>0)
							{
								alphanumericField.setValue(defaultval);
							}
							if(mandatoryFlag.equals("1"))
							{
								alphanumericField.setRequired(false);
								alphanumericField.setRequiredIndicatorVisible(true);
							}
							alphanumericField.setValueChangeMode(ValueChangeMode.EAGER);
							alphanumericField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {

								private static final long serialVersionUID = 1L;

								@Override
								public void valueChanged(ValueChangeEvent<?> arg0) {

									if(!arg0.getValue().toString().matches("^\\w*$") || arg0.getValue().toString().contains("_"))
									{
										alphanumericField.setValue(arg0.getOldValue().toString());
									}
								}
							});

							eachDataDiv.add(alphanumericField);
							attrrow.add(eachDataDiv);



							break;
						default:
							break;   
						}
						dynamicAttributesMap.put(attrname,dataTypeList);
						//	}
						additionalAttrDiv.add(attrrow);
					}
				}	
			}	

		}catch(JSONException ex)
		{
			ex.printStackTrace();	
		}
		return attributeListMap;

	}
}
