package com.umt.siteassetinventory.assets;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/assets-view.css")
public class AssetDetailsTab extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ASSET_DETAILS_TAB";
	private int  VendorId=-1,StoreId=-1,StatusId=-1, EquipmentTypeId=-1,StoreLocId=-1,EquipmentSerialNo=-1;
	private String serialno="-",equipmentType="-",vendorName="-",equipmentserialNo="-",description="-",vendorname="-",storeid="-",storename="-",storeLocationId="-",
	startDate="-", stopDate="-",statuscode="-",serviceType="-";
	
	private Label serialnoLbl, equipmentTypelbl, serviceTypeLbl, vendorNameLbl, descriptionLbl, equipmentserialNoLbl, storeidLbl, 
	storenameLbl, storeLocationIdLbl, startdateLbl, stopdateLbl,statuscodeLbl;
	
	private Label serialnoLbl_v, equipmentTypelbl_v, serviceTypeLbl_v, vendorNameLbl_v, descriptionLbl_v, 
	equipmentserialNoLbl_v, storeidLbl_v, storenameLbl_v, storeLocationIdLbl_v, startDate_v, stopDate_v,statuscodeLbl_v;
	private Div asset_detailsDiv,asset_detailsValueDiv;
	private Button editBtn, decommissionBtn, assignBtn, returnBtn, changeStatusBtn; 
	private Div btnDiv;
	
	private String assetId2;
	private AssetsView assetviewobj;
	
	public AssetDetailsTab(AssetsView parent) 
	{
		assetviewobj=parent;
	}
	public Div populateAssetDetails(String selectedAssetId) 
	{
		//System.out.println("selectedAssetId="+selectedAssetId);
		try
		{
			asset_detailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ASSET_DETAILS_DIV");
			String res="";
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url=url+"?StoreSerialNo="+selectedAssetId+"&VendorId="+VendorId+"&StoreId="+StoreId+"&StatusId="+StatusId+"&EquipmentTypeId="+EquipmentTypeId+
				"&StoreLocId="+StoreLocId+"&EquipmentSerialNo="+EquipmentSerialNo;
			
			res = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" assetDetails_res1="+res);
			
			createRows(res);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return asset_detailsDiv;
		
	}
	
	
	private void createRows(String res) 
	{
		try 
		{
			btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
			editBtn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
			decommissionBtn = UIFieldFactory.createButton(SCREENCD, "DECOMMISSION_BTN"); 
			assignBtn = UIFieldFactory.createButton(SCREENCD, "ASSIGN_BTN"); 
			returnBtn = UIFieldFactory.createButton(SCREENCD, "RETURN_BTN");
			changeStatusBtn = UIFieldFactory.createButton(SCREENCD, "CHANGE_STATUS_BTN");
			btnDiv.add(assignBtn, returnBtn, changeStatusBtn, editBtn);

			if(res!=null && res.trim().length()>0)
			{
				JSONArray js=new JSONArray(res);
				if(js.length()>0)
				{
					for(int i=0;i<js.length();i++)
					{
						if (js.getJSONObject(i).getString("StoreSerialNo")!=null && js.getJSONObject(i).getString("StoreSerialNo").trim().length()>0) {
							serialno=js.getJSONObject(i).getString("StoreSerialNo");
						}
						if (js.getJSONObject(i).getString("EquipmentType")!=null && js.getJSONObject(i).getString("EquipmentType").trim().length()>0) {
							equipmentType=js.getJSONObject(i).getString("EquipmentType");
						}
						if (js.getJSONObject(i).getString("ServiceType")!=null && js.getJSONObject(i).getString("ServiceType").trim().length()>0) {
							serviceType=js.getJSONObject(i).getString("ServiceType");
						}
						if (js.getJSONObject(i).getString("VendorName")!=null && js.getJSONObject(i).getString("VendorName").trim().length()>0) {
							vendorName=js.getJSONObject(i).getString("VendorName");
						}
						if (js.getJSONObject(i).getString("Description")!=null && js.getJSONObject(i).getString("Description").trim().length()>0) {
							description=js.getJSONObject(i).getString("Description");
						}
						if (js.getJSONObject(i).getString("EquipmentSerialNo")!=null && js.getJSONObject(i).getString("EquipmentSerialNo").trim().length()>0) {
							equipmentserialNo=js.getJSONObject(i).getString("EquipmentSerialNo");
						}
						if (js.getJSONObject(i).getString("StoreId")!=null && js.getJSONObject(i).getString("StoreId").trim().length()>0) {
							storeid=js.getJSONObject(i).getString("StoreId");
						}
						if (js.getJSONObject(i).getString("StoreName")!=null && js.getJSONObject(i).getString("StoreName").trim().length()>0) {
							storename=js.getJSONObject(i).getString("StoreName");
						}
						if (js.getJSONObject(i).getString("StoreLocationId")!=null && js.getJSONObject(i).getString("StoreLocationId").trim().length()>0) {
							storeLocationId=js.getJSONObject(i).getString("StoreLocationId");
						}
						if (js.getJSONObject(i).getString("StatusCode")!=null && js.getJSONObject(i).getString("StatusCode").trim().length()>0) {
							statuscode=js.getJSONObject(i).getString("StatusCode");
						}
						if (js.getJSONObject(i).getString("CreationDate")!=null && js.getJSONObject(i).getString("CreationDate").trim().length()>0) {
							startDate=js.getJSONObject(i).getString("CreationDate");
						}
						if (js.getJSONObject(i).getString("ChangedOn")!=null && js.getJSONObject(i).getString("ChangedOn").trim().length()>0) {
							stopDate=js.getJSONObject(i).getString("ChangedOn");
						}		
					}	
				}
				
				Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				Div row_3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				Div row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				Div row_5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				Div row_6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
				
				
				Div v1 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v2 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v3 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v4 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v5 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v6 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v7 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v8 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v9 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v10 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v11 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				Div v12 = UIHtmlFieldFactory.createDiv(SCREENCD, "VALUE_DIV");
				
				
				serialnoLbl =  UIHtmlFieldFactory.createLabel(SCREENCD, "SERIALNO_LBL");
				equipmentTypelbl =  UIHtmlFieldFactory.createLabel(SCREENCD, "EQUIPMENT_TYPE_LBL");
				serviceTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SERVICE_TYPE_LBL");
				vendorNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDORNAME_LBL");
				descriptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DESCRIPTION_LBL");
				equipmentserialNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "EQUIPMENT_SERIALNO_LBL");
				storeidLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STOREID_LBL");
				storenameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STORENAME_LBL"); 
				storeLocationIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STORE_LOC_ID_LBL"); 
				startdateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STARTDATE_LBL");
				stopdateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STOPDATE_LBL");
				statuscodeLbl=UIHtmlFieldFactory.createLabel(SCREENCD, "STATUSCODE_LBL");
				
				
				serialnoLbl_v=  UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				equipmentTypelbl_v =  UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				serviceTypeLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				vendorNameLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				descriptionLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				equipmentserialNoLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				storeidLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				storenameLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL"); 
				storeLocationIdLbl_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL"); 
				startDate_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				stopDate_v = UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				statuscodeLbl_v=UIHtmlFieldFactory.createLabel(SCREENCD, "VALUE_LBL");
				
				serialnoLbl_v.setText(serialno);
				equipmentTypelbl_v.setText(equipmentType);
			//	serviceTypeLbl_v.setText(serviceType);
				vendorNameLbl_v.setText(vendorName);
				descriptionLbl_v.setText(description);
				equipmentserialNoLbl_v.setText(equipmentserialNo);
			//	storeidLbl_v.setText(storeid);
				storenameLbl_v.setText(storename);
				if(storename.toUpperCase().equalsIgnoreCase("VENDOR"))
				{
					String response = assetviewobj.getAllVendors();
					try {
						JSONArray ja = new JSONArray(response);
						for (int i = 0; i < ja.length(); i++) {
							JSONObject jo = ja.getJSONObject(i);
							if(jo.getLong("VendorId")==Long.parseLong(storeLocationId) && jo.getString("VendorName")!=null)
							{
								storeLocationIdLbl_v.setText(jo.getString("VendorName"));
								break;
							}
						}
					}
					catch (Exception e) {
						e.printStackTrace();
					}		
				}
				else
					storeLocationIdLbl_v.setText(storeLocationId);
				statuscodeLbl_v.setText(statuscode);
				startDate_v.setText(startDate);
			//	stopDate_v.setText(stopDate);
				
				if(Integer.parseInt(serviceType)==1)
				{
					vendorNameLbl.setText("Operator Name");
					serviceTypeLbl_v.setText("Active Asset");
				}
				if(Integer.parseInt(serviceType)==0)
				{
					vendorNameLbl.setText("Vendor Name");
					serviceTypeLbl_v.setText("Passive Asset");
				}
				if(storename.toUpperCase().equalsIgnoreCase("SITE"))
				{
					storeLocationIdLbl.setText("Site Code");
				}
				if(storename.toUpperCase().equalsIgnoreCase("WAREHOUSE"))
				{
					storeLocationIdLbl.setText("Store Location Id");
				}
				if(storename.toUpperCase().equalsIgnoreCase("VENDOR"))
				{
					storeLocationIdLbl.setText("Vendor Name");
				}
				
				
				v1.add(serialnoLbl,serialnoLbl_v);
				v2.add(equipmentTypelbl,equipmentTypelbl_v);
				v3.add(serviceTypeLbl,serviceTypeLbl_v);
				v4.add(vendorNameLbl,vendorNameLbl_v);
				v5.add(descriptionLbl,descriptionLbl_v);
				v6.add(equipmentserialNoLbl,equipmentserialNoLbl_v);
			//	v7.add(storeidLbl,storeidLbl_v);
				v8.add(storenameLbl,storenameLbl_v);
				v9.add(storeLocationIdLbl,storeLocationIdLbl_v);
				v10.add(statuscodeLbl,statuscodeLbl_v);
				v11.add(startdateLbl,startDate_v);
			//	v12.add(stopdateLbl,stopDate_v);
				
				row_1.add(v1,v2);
				row_2.add(v3,v4);
				row_3.add(v5,v6);
				row_4.add(/*v7*/v9,v8);
				row_5.add(v11,v10/*v12*/);
				//row_6.add(/*v9,*/v10);
				
				asset_detailsValueDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ASSET_DETAILS_VALUE_DIV");
				
				asset_detailsValueDiv.add(row_1,row_2,row_3,row_4,row_5,row_6);

				assignBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) 
					{
						openChangeAssetDetailsParams(1);
					}
				});

				returnBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) 
					{
						openChangeAssetDetailsParams(2);
					}
				});

				changeStatusBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) 
					{
						openChangeAssetDetailsParams(3);
					}
				});


				editBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) 
					{
								
						EditAssetDetailsDialog dlg= new EditAssetDetailsDialog(serialno,equipmentType,vendorName,equipmentserialNo,description,vendorname,storeid,storename,storeLocationId,
								startDate, stopDate,statuscode,serviceType);
						dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
							private static final long serialVersionUID = 1L;

							@Override
							public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
								EditAssetDetailsDialog srcDlg = (EditAssetDetailsDialog)event.getSource();
								if(!srcDlg.isOpened() && srcDlg.isSuccess()==true) 
								{
									populateAssetDetails(serialno);
								//	SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"SAVE_DATA",ApplicationConstants.DialogTypes.INFO);
									if(assetviewobj!=null)
									{
										assetviewobj.refreshAssetDetails(serialno);
									}
									
								}
							}


						});
					}
				});
				
				decommissionBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) {
						
					}
				});
				
				asset_detailsDiv.removeAll();
				asset_detailsDiv.add(btnDiv,asset_detailsValueDiv);


			}

		}catch(Exception e)
		{
			e.printStackTrace();
			UI.getCurrent().navigate("assetsview");
		}
		
	}
	
	private void openChangeAssetDetailsParams(int changeParam)
	{
		ChangeAssetDetailsParams changeAssetDetailsParams = new ChangeAssetDetailsParams(this, changeParam);
		assetviewobj.refreshAssetDetails(serialno);
	}

	public void setAssetId(String selectedassetId) 
	{
		//System.out.println(selectedassetId);
		assetId2=selectedassetId;
		serialno=selectedassetId;
	}
	
	public String getSerialno() {
		return serialno;
	}
	
	public int getStatusId() {
		return StatusId;
	}
	
	public String getStoreid() {
		return storeid;
	}
	
	public String getStorename() {
		return storename;
	}
	
	public String getStatuscode() {
		return statuscode;
	}
	
	public String getEquipmentType() {
		return equipmentType;
	}
	
	public String getVendorName() {
		return vendorName;
	}
	
	public void setAssetObj(AssetsView parent) 
	{
		assetviewobj=parent;
		
	}
	public void refreshDetails(boolean dataSaved) 
	{
		try
		{
		//	System.out.println("dataSaved="+dataSaved);
			if(dataSaved==true && assetviewobj!=null)
			{
				assetviewobj.refreshAssetDetails(serialno);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}


}
