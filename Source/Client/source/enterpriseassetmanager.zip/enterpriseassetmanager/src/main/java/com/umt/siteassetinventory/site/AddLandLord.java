package com.umt.siteassetinventory.site;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.landlord.AddLandlordDialog;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/add_landlord-style.css")
public class AddLandLord extends Div{
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_LANDLORD";
	private Div searchItemDiv, searchItemHeaderDiv, searchItemsBean;
	private Checkbox checkBox;
	private Label id, name, email, address; 
	private Div aggrementDiv, payOutDiv;
	private ComboBox<String> payoutFreq;
	private NumberField payout;
	private String landlordId, payFreqCode, payAmt;
	private Label agreementId, agreementPaymentFreq, agreementPayAmt, agreementPayUnit, agreementStratDate;
	private Label agreementId_v, agreementPaymentFreq_v, agreementPayAmt_v, agreementPayUnit_v, agreementStratDate_v;
	private String payUnit;
	private String error;
	private List<AddLandLordToSearchItemsBeans> searchList =new ArrayList<AddLandLordToSearchItemsBeans>();
	private Button createLandlordBtn;

	public AddLandLord(String siteCode, SiteView siteView) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		Div createBtnDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "CREATE_BTN_DIV"); 
		createLandlordBtn = UIFieldFactory.createButton(SCREENCD, "CREATE_LANDLORD_BTN");
		createBtnDiv.add(createLandlordBtn);
		Div search_div = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_DIV");
		TextField searchInput = UIFieldFactory.createTextField("", false, SCREENCD, "SEARCH_FIELD");
		searchInput.setSuffixComponent(VaadinIcon.SEARCH.create());
		searchInput.setPlaceholder("Search Landlord");
		search_div.add(searchInput);
		aggrementDiv= UIHtmlFieldFactory.createDiv(SCREENCD, "AGREEMENT_DIV"); 
		payOutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "PAYOUT_DIV"); 
		payoutFreq = UIFieldFactory.createComboBox(getPayFeq(), false, SCREENCD, "PAY_FREQ");
		payoutFreq.setRequiredIndicatorVisible(true);
		payout = UIFieldFactory.createNumberField(false, SCREENCD, "PAY_OUT");
		payout.setRequiredIndicatorVisible(true);
		
		
		
		
		
		
		
		searchItemHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_ITEM_HEADER_DIV"); 
		
		Div row = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_SPACE_DIV");
		Div row1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row2.addClassName("SAPCE_1");
		Div row3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row3.addClassName("SAPCE_2");
		Div row4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		row4.addClassName("ADDRESS_ROW");
		
		Label landLordContact = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_CONTACT_HEADER_LBL");
		Label landLordNme = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_NAME_HEADER_LBL");
		Label landLordEmail = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_EAMIL_HEADER_LBL");
		Label landLordAddress = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_ADDRESSLBL");
		
		row1.add(landLordNme);
		row2.add(landLordEmail);
		row3.add(landLordContact);
		row4.add(landLordAddress);
		
		searchItemHeaderDiv.add(row1, row2, row3, row4);
		
		Div aggriment_row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "AGGRI_ROW_DIV");
		Div aggriment_row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "AGGRI_ROW_DIV");
		Div aggriment_row_3 = UIHtmlFieldFactory.createDiv(SCREENCD, "AGGRI_ROW_DIV");
		Div aggriment_row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "AGGRI_ROW_DIV");
		Div aggriment_row_5 = UIHtmlFieldFactory.createDiv(SCREENCD, "AGGRI_ROW_DIV");
		
		agreementId = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_ID");
		agreementPaymentFreq = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_FREQ");
		agreementPayAmt = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_AMT");
		agreementPayUnit = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_UNIT");
		agreementStratDate = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_START_DATE");
		
		agreementId_v = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_ID_V");
		agreementPaymentFreq_v = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_FREQ_V");
		agreementPayAmt_v = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_AMT_V");
		agreementPayUnit_v = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_PAY_UNIT_V");
		agreementStratDate_v = UIHtmlFieldFactory.createLabel(SCREENCD, "AGREEMENT_START_DATE_V");
		
		aggriment_row_1.add(agreementId, agreementId_v);
		aggriment_row_2.add(agreementPaymentFreq, agreementPaymentFreq_v);
		aggriment_row_3.add(agreementPayAmt, agreementPayAmt_v);
		aggriment_row_4.add(agreementPayUnit, agreementPayUnit_v);
		aggriment_row_5.add(agreementStratDate, agreementStratDate_v);
		
		agreementInfo(siteCode);
		payOutDiv.add(payout);
		
//		agreementId_v.setText("-");
//		agreementPaymentFreq_v.setText("-");
//		agreementPayAmt_v.setText("-");
//		agreementPayUnit_v.setText("-");
//		agreementStratDate_v.setText("-");
		
		
		
		
		aggrementDiv.add(aggriment_row_1, aggriment_row_2, aggriment_row_3,aggriment_row_4, aggriment_row_5);
		
		
		
		searchItemDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_ITEM_DIV");
		
		
		
		
		add(createBtnDiv,search_div,searchItemHeaderDiv, searchItemDiv, payOutDiv);
		
		searchInput.addKeyPressListener(Key.ENTER, event ->{
			searchItemDiv.removeAll();
			String base_URL=ApplicationConfiguration.getServiceEndpoint("SEARCHLANDLORD");
			base_URL = base_URL + "?searchText=" + URLEncoder.encode(searchInput.getValue());
			
			try {
				String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
				//System.out.println(base_URL+" search: " + outputResponse);
				JSONArray jsonArray = new JSONArray(outputResponse);
				for(int i = 0; i<jsonArray.length(); i++) {
					JSONObject jsonObject = jsonArray.getJSONObject(i);
					AddLandLordToSearchItemsBeans itemBean = new AddLandLordToSearchItemsBeans(
							
							jsonObject.getString("LandlordId"),
							jsonObject.getString("Name"),
							jsonObject.getString("Email"),
							jsonObject.getString("ContactNo"),
							jsonObject.getString("Address"),
							this
							);
					
					searchItemDiv.add(itemBean);
					searchList.add(itemBean);
					
					}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		});
		
		payoutFreq.addValueChangeListener(event ->{
			event.getValue();
			
			getPayFreqCode(event.getValue());
			//System.out.println(payFreqCode);
		});
		payout.addValueChangeListener(event ->{
			if(payout.getValue() > payout.getMax()) {
				if(payUnit.equals("Fixed")) {
					payout.setErrorMessage("Pay Amount should be less than " + payout.getMax());
				}else if(payUnit.equals("Percentage")) {
					payout.setErrorMessage("Pay Amount should be less than 100");
				}
				
				
			
			}else {
				setPayAmt(String.valueOf(payout.getValue()));
			}
			
		});
		
		//System.out.println("error : " + error);
		
		
		
		
			
			
				AddLandLordPopUp addlandlordPopup = new AddLandLordPopUp("Add Landlord", this, siteCode, siteView);
//				if(error.equals("Error- Error getting current site agreement")) {
//					
//					SiteAssetInventoryUIFramework.getFramework().showMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD,"ADD_AGREEMENT_INFO"), ApplicationConstants.DialogTypes.INFO);
//					addlandlordPopup.setButtonEnable(false);
//				}
				
			
			
				createLandlordBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(ClickEvent<Button> event) {
						createLandlord();
					}
				});
		
		
		
	}
	protected void createLandlord() {
		AddLandlordDialog dlg =new AddLandlordDialog();
		
	}
	public void setLandlordID(String id) {
		landlordId = id;
	}
	public String getLandLordId() {
		return landlordId;
	}
	
	private void agreementInfo(String siteCode) {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETCURRENTSITEAGREEMENT");
		base_URL = base_URL + "?SiteCode=" + URLEncoder.encode(siteCode);
		//System.out.println(base_URL);
		try {
			String outputResponse=RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(" AgreementInfo: " + outputResponse);
			
			JSONObject obj = new JSONObject(outputResponse);
			agreementId_v.setText(obj.getString("AgreementId"));
			agreementPaymentFreq_v.setText(getPayOutFreqValue(obj.getString("PaymentFrequency")));
			agreementPayAmt_v.setText(obj.getString("PaymentAmount"));
			agreementPayUnit_v.setText(getPaymentUnit(obj.getString("PaymentUnit")));
			agreementStratDate_v.setText(obj.getString("AgreementDate"));
			
			Double payAmt = Double.valueOf(obj.getString("PaymentAmount"));
			payUnit = getPaymentUnit(obj.getString("PaymentUnit"));
			
			if(payUnit.equals("Fixed")) {
				payout.setMin(0);
				payout.setMax(payAmt);
			}else if(payUnit.equals("Percentage")) {
				payout.setLabel("Pay Out Amout(In Percentage)");
				payout.setMax(100);
				
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			error = CommonUtils.getErrorMessage(e.getMessage());
			e.printStackTrace();
		}
		
		
	}
	
//	private Div addLandLordBean(String landlord_id, String landlord_name, String landlord_email, String landlord_address) {
//		
//		searchItemsBean = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_BEAN_DIV");
//		
//		Div row1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
//		Div row2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
//		Div row3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
//		Div row4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
//		
//		checkBox = UIFieldFactory.createCheckbox(false, false, SCREENCD, "CHECKBOX");
//		id = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_ID_LBL");
//		name = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_NAME_LBL"); 
//		email = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_EMAIL_LBL");  
//		address = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_ADDRESS_LBL");
//		address.setTitle(landlord_address);
//		
//		id.setText(landlord_id);
//		name.setText(landlord_name);
//		email.setText(landlord_email);
//		address.setText(landlord_address);
//		
//		
//		row1.add(id);
//		row2.add(name);
//		row3.add(email);
//		row4.add(address);
//		
//		searchItemsBean.add(checkBox, row1, row2, row3, row4);
//		
//		checkBox.addClickListener(new ComponentEventListener<ClickEvent<Checkbox>>() {
//			
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public void onComponentEvent(ClickEvent<Checkbox> event) {
//				
//				//System.out.println(name.getText());
//			}
//		});
//		
//		
//		
//		return searchItemsBean;
//	}
	private List<String> getPayFeq() {
		List<String> list= new ArrayList<>();
		
		list.add("Weekly");
		list.add("Fortnightly");
		list.add("Monthly");
		list.add("Quarterly");
		list.add("Bi-Yearly");
		list.add("Yearly");
		
		return list;
		
	}
	private void getPayFreqCode(String listItem) {
		
		if(listItem.equals("Weekly")) {
			payFreqCode = "1";
		}else if(listItem.equals("Fortnightly")) {
			payFreqCode = "2";
			
		}else if(listItem.equals("Monthly")) {
			payFreqCode = "3";
		}else if(listItem.equals("Quarterly")) {
			payFreqCode = "4";
		}else if(listItem.equals("Bi-Yearly")) {
			payFreqCode = "5";
		}else if(listItem.equals("Yearly")) {
			payFreqCode = "6";
		}
		
		
		
		
	}
	private String getPayOutFreqValue(String code) {
		String value = null;
		if(code.equals("1")) {
			value = "Weekly";
		}else if(code.equals("2")) {
			value = "Fortnightly";
		}else if(code.equals("3")) {
			value = "Monthly";
		}
		else if(code.equals("4")) {
			value = "Quarterly";
		}
		else if(code.equals("5")) {
			value = "Bi-Yearly";
		}
		else if(code.equals("6")) {
			value = "Yearly";
		}
		
		return value;
		
	}
	private String getPaymentUnit(String code) {
		String value = null;
		if(code.equals("1")) {
			value = "Fixed";
		}else if(code.equals("2")) {
			value = "Percentage";
		}
		
		return value;
		
	}
	public String getFreqCode() {
		return payFreqCode;
	}
	private void setPayAmt(String amt) {
		payAmt = amt;
	}
	public String getPayAmt() {
		return payAmt;
	}
	public List<AddLandLordToSearchItemsBeans> getSiteBeanList()
	{
		return searchList;
	}

	public void deselectOtherRows(AddLandLordToSearchItemsBeans child) 
	{
		for (int i = 0; i < searchList.size(); i++) 
		{
			searchList.get(i).deselectEachDiv(child);
		}
		
	}
}
