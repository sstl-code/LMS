package com.umt.siteassetinventory.application;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/app_header-style.css")
public class ApplicationHeader extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "HEADER";
	private Div truebyllogodiv, toggleMenuIcondiv;
	private Label userEmailLbl, userLoginTimestampLbl;
	private Image truebyllogo, menuImgIcon;
	private Div mobHeaderDiv, desktopHeaderDiv;
	private Div searchBtnDiv;
	private TextField searchInput;

	public ApplicationHeader() {
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		mobHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MOB_HEADER_DIV");
		desktopHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DESKTOP_HEADER_DIV");

		truebyllogodiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TRUEBYL_LOGO_DIV");
		toggleMenuIcondiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TOGGLE_MENU_ICON_DIV");

		Div searchDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_INPUT_DIV");
		searchBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_BTN_DIV");
		Label searchLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SEARCH_LBL");
		searchBtnDiv.add(searchLbl);

		searchInput = UIFieldFactory.createTextField("", false, SCREENCD, "SEARCH_FIELD");
		searchInput.setPlaceholder("Search");
		searchInput.setSuffixComponent(VaadinIcon.SEARCH.create());

		searchDiv.add(searchInput);

		menuImgIcon = UIHtmlFieldFactory.createImage(SCREENCD, "MENU_ICON_IMG");
		toggleMenuIcondiv.add(menuImgIcon);
		truebyllogo = UIHtmlFieldFactory.createImage(SCREENCD, "TRUEBYL_LOGO");
		try {
			truebyllogo.setSrc(ApplicationConfiguration.getConfigurationValue("LOGO_URL"));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		truebyllogodiv.add(truebyllogo);
		Div userLoginDetailDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "USER_LOGIN_DETAIL_DIV");
		userEmailLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LOGGED_IN_USER_EMAIL_LBL");
		userLoginTimestampLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "USER_LOGIN_TIMESTAMP_LBL");
		userLoginDetailDiv.add(userEmailLbl, userLoginTimestampLbl);

		if (CommonUtils.getClientView() == false) {
			desktopHeaderDiv.add(toggleMenuIcondiv, truebyllogodiv,searchDiv, userLoginDetailDiv);
			add(desktopHeaderDiv);
		} else if (CommonUtils.getClientView() == true) {
			mobHeaderDiv.add(toggleMenuIcondiv, truebyllogodiv);
			add(mobHeaderDiv);
		}

		searchInput.addKeyPressListener(Key.ENTER, event ->{
			//System.out.println("heelooo");
			if(SiteAssetInventoryUIFramework.getFramework().getApplicationMainView() != null) {
				if(SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().getCurrentModule() != null) {
					SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().getCurrentModule().searchRecords(searchInput.getValue());
				}
			}
		});
		//		searchBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
		//			
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(ClickEvent<Div> event) {
		//				System.out.println("search Value:: " + searchInput.getValue());
		//				System.out.println("Location:: " + SiteAssetInventoryUIFramework.getFramework().getCurrentPath());
		//				if(SiteAssetInventoryUIFramework.getFramework().getApplicationMainView() != null) {
		//					if(SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().getCurrentModule() != null) {
		//						SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().getCurrentModule().searchRecords(searchInput.getValue());
		//					}
		//				}
		//			}
		//		});

		toggleMenuIcondiv.addClickListener(new
				ComponentEventListener<ClickEvent<Div>>() {

			private static final long serialVersionUID = 1L;

			@Override public void onComponentEvent(ClickEvent<Div> event) {

				//System.out.println("click");

				SiteAssetInventoryUIFramework.getFramework().showVerticalMenuBar(true);

			} });


		try {
			if (SiteAssetInventoryUIFramework.getFramework().isUserLoggedIn()) {
				userEmailLbl.setText(SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());
				String loggedInDateTimeTxt = userLoginTimestampLbl.getText();
				loggedInDateTimeTxt = loggedInDateTimeTxt.replaceAll("@@LOGIN_DATE_TIME@@", 
						CommonUtils.getDisplayDateTime(SiteAssetInventoryUIFramework.getFramework().getUserInfo().getLoginDateTime()));
				userLoginTimestampLbl.setText(loggedInDateTimeTxt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public TextField getSearchInput() {
		return searchInput;
	}

}
