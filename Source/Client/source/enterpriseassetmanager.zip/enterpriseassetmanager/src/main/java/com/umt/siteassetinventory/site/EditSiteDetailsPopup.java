package com.umt.siteassetinventory.site;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;

public class EditSiteDetailsPopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private EditSiteDetails editDetails;
	private String sitecd;
	private SiteView siteView;
	private String screencd;
	

	public EditSiteDetailsPopup(String title, Component component, String sitecd, SiteView siteView, String screencd) {
		super(title, component);
		this.sitecd=sitecd;
		this.editDetails=(EditSiteDetails) component;
		this.siteView = siteView;
		this.screencd = screencd;
		
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String base_URL=ApplicationConfiguration.getServiceEndpoint("EDITSITEDETAILS");
		
		
		
		try {
	//		save_btn.setEnabled(false);
			JSONObject json = new JSONObject();
			json.put("SiteName", editDetails.getSiteName());
			json.put("Address", editDetails.getSiteAddress());
			json.put("Description", editDetails.getSiteDescription());
			json.put("Region", editDetails.getSiteRegion());
			json.put("Latitude", editDetails.getSiteLatitude());
			json.put("Longitude", editDetails.getSiteLongitute());
			
			
			//System.out.println("json:: " + json);
			
			Form formData = new Form();
			formData.add("SiteCode", sitecd);
			formData.add("siteDetails", json);
			
			String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("Save:" + response);
			SiteAssetInventoryUIFramework.getFramework().showMessage(screencd, "EDIT_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
			closeDialog();		
			siteView.addDetailsTab(sitecd);
			
			
//			detailsTab.siteNameV.setText(editDetails.getSiteName());
//			siteAddressV.setText(editDetails.getSiteAddress());
//			siteDesV.setText(editDetails.getSiteDescription());
//			siteRegV.setText(editDetails.getSiteRegion());
//			sitelatV.setText(editDetails.getSiteLatitude());
//			siteLongV.setText( editDetails.getSiteLongitute());
			
			
			
		} catch (JSONException e) {
			
			e.printStackTrace();
		//	save_btn.setEnabled(true);
		} catch (Exception e) {
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
		//	save_btn.setEnabled(true);
		}
		finally {
			save_btn.setEnabled(true);
		}
		
		
	}

}
