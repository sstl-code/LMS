package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/landlord-invoice.css")
public class LandlordInvoicesTabBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_INVOICES_TAB_BEAN";
	private LandlordInvoicesTab parent;
	//	private String invoiceId2,sitecode2,sitename2,landlordName2,landlordErpCode2,agreementIdName,invoiceGenDate2,
	//	invoicePeriod2,invoiceAmt2,status2;
	private Div rowDiv;
	private Checkbox selectRowChkbox;
	//private TextField remarkField,rejectReasonField;;

	private String invoiceid,Status,siteCode,Sitename,/*Landlordname,*/Circle,/*SapVendorCode,*/invoiceno,invoiceType,Billingtype,
	rentStatus,invoicedate,dueDate,Period_StartDate,Period_EndDate,RentShare,invoiceAmount,solutiontype,Billingcycle,remarks;
	
	private int roundPrecision=2;


	public LandlordInvoicesTabBean(String invoiceid, String Circle, String siteCode, String Sitename, /*String Landlordname,
			String SapVendorCode,*/ String invoicedate, String dueDate, String Period_StartDate, String Period_EndDate, String RentShare,
			String solutiontype, String Billingtype, String Billingcycle, String rentStatus, String invoiceType, String Status,
			String invoiceno,String grossInvoiceAmount,String DueOn,String Gst_Rate,String invoiceAmount,String BillForOperator,
			String InvoiceArrears,String SubmissionDate,String ReceivedDate,String Tds_Rate,String RejectReason,String Remarks1,
			String Remarks2,LandlordInvoicesTab landlordInvoicesTab) {


		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.parent=landlordInvoicesTab;
		this.invoiceid=invoiceid;
		this.Status=Status;
		this.siteCode=siteCode;
		this.Sitename=Sitename;
//		this.Landlordname=Landlordname;
		this.Circle=Circle;
//		this.SapVendorCode=SapVendorCode;
		this.invoiceno=invoiceno;
		this.invoiceType=invoiceType;
		this.Billingtype=Billingtype;
		this.rentStatus=rentStatus;	
		this.invoicedate=invoicedate;
		this.dueDate=dueDate;
		this.Period_StartDate=Period_StartDate;
		this.Period_EndDate=Period_EndDate;
		this.RentShare=RentShare;
		this.solutiontype=solutiontype;
		this.invoiceAmount=invoiceAmount;
		this.Billingcycle=Billingcycle;
		this.remarks=Remarks1;


		//		if(status.equalsIgnoreCase("2")) {
		//			status="Exported";
		//			selectRowChkbox.setValue(false);
		//			selectRowChkbox.setEnabled(false);
		//		}else if(status.equalsIgnoreCase("1")){
		//			status="New";
		//			selectRowChkbox.setEnabled(true);
		//		}else {
		//			status="";
		//			selectRowChkbox.setEnabled(true);
		//		}

		rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Label circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		Label siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		Label siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
//		Label landlordNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDNAME_LBL");
//		Label sapvendorCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAPVENDORCODE_LBL");
		Label landlordrentsharePercentageLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_RENT_SHARE_PERCENT_LBL");
		Label solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		Label billingTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_TYPE_LBL");
		Label rentStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RENT_STATUS_LBL");
		Label typeofinvoiceLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_OF_INVOICE_LBL");
		Label invoiceIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_ID_LBL");
		Label invoiceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICENO_LBL");
		Label invoiceDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_DATE_LBL");
		Label dueDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DUE_DATE_LBL");
		Label billingCycleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_CYCLE_LBL");
		Label invoiceStartDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_START_DATE_LBL");
		Label invoiceEndDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_END_DATE_LBL");
		//Label grossAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "GROSS_AMT_LBL");
		Label invoiceAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_AMT_LBL");
		Label statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		//rejectReasonField= UIFieldFactory.createTextField("", true, SCREENCD,"REJECT_REASON_FIELD");
		Label remarkLbl= UIHtmlFieldFactory.createLabel(SCREENCD,"REMARKS_LBL");
		selectRowChkbox = UIFieldFactory.createCheckbox(false, false, SCREENCD, "SELECT_ROW_CHECKBOX");

		siteIdLbl.setText(siteCode);
		circleLbl.setText(Circle);
		siteNameLbl.setText(Sitename);
//		landlordNameLbl.setText(Landlordname);
//		sapvendorCodeLbl.setText(SapVendorCode);
		landlordrentsharePercentageLbl.setText(CommonUtils.roundValue(RentShare, roundPrecision));
		solutionTypeLbl.setText(solutiontype);
		billingTypeLbl.setText(CommonUtils.getLandlordInvoiceBillingTypeCd(Integer.parseInt(Billingtype)));
		rentStatusLbl.setText(rentStatus);
		typeofinvoiceLbl.setText(CommonUtils.getLandlordInvoiceTypeValueCd(Integer.parseInt(invoiceType)));
		invoiceIdLbl.setText(invoiceid);
		invoiceNoLbl.setText(invoiceno);
		
		//CommonUtils.convertTimeStamp(Long.parseLong(invoicedate));
		invoiceDateLbl.setText(invoicedate);
		invoiceStartDateLbl.setText(Period_StartDate);
		invoiceEndDateLbl.setText(Period_EndDate);
		dueDateLbl.setText(dueDate);
		invoiceAmtLbl.setText(CommonUtils.roundValue(invoiceAmount, roundPrecision));
		billingCycleLbl.setText(Billingcycle);
		statusLbl.setText(CommonUtils.getLandlordInvoiceStatusCd(Integer.parseInt(Status)));
		remarkLbl.setText(Remarks1);

		rowDiv.add(siteIdLbl,circleLbl,siteNameLbl,/*landlordNameLbl,sapvendorCodeLbl,*/landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
				rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,dueDateLbl,invoiceAmtLbl,
				billingCycleLbl,statusLbl,/*rejectReasonField,*/remarkLbl/*,selectRowChkbox*/);

		add(rowDiv);

	}

	/*	public String getSiteName() {
		return sitename2;
	}*/


	public boolean isChecked() {
		return selectRowChkbox.getValue();
	}

	public int getInvoiceId() {
		return Integer.parseInt(invoiceid);
	}

	public String getStatus() {
		return CommonUtils.getLandlordInvoiceStatusCd(Integer.parseInt(Status));

	}

	public String getRemarks() {
		return remarks;
	}

	public Div getRowDiv() {
		return rowDiv;
	}

//	public String landlordName() {
//		return Landlordname ;
//	}

	public String getSiteName() {
		return Sitename;
	}

	public String getSiteId() {
		return siteCode;
	}

	public String getCircle() {
		return Circle;
	}

//	public String sapvendorcode() {
//		return SapVendorCode;
//	}

	public String getInvoiceNo() {
		return invoiceno;
	}

	public String Invoicetype() {
		return CommonUtils.getLandlordInvoiceTypeValueCd(Integer.parseInt(invoiceType));
	}

	public String billType() {
		return CommonUtils.getLandlordInvoiceBillingTypeCd(Integer.parseInt(Billingtype));
	}

	public String rentStatus() {
		return rentStatus;
	}

	public String getInvoicedate() {
		return invoicedate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public String getPeriod_StartDate() {
		return Period_StartDate;
	}

	public String getPeriod_EndDate() {
		return Period_EndDate;
	}

	public String getRentShare() {
		return CommonUtils.roundValue(RentShare, roundPrecision);
	}

	public String getInvoiceAmount() {
		return CommonUtils.roundValue(invoiceAmount, roundPrecision);
	}

	public String getSolutiontype() {
		return solutiontype;
	}

	public String getBillingcycle() {
		return Billingcycle;
	}
	
	
}
