package com.umt.siteassetinventory.site;

import java.util.ArrayList;
import java.util.List;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.server.VaadinServletRequest;

public class SiteLandLordBean extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_LANDLORD_TAB_BEAN";
	private Label landLordId_value;
	private Button viewBtn, remove_btn, edit_btn;
	private Label landlordNme, address, email, status, contactNo, payOut/*, payOutFreqLbl*/;
	private Label landlordNme_v, address_v, email_v, status_v, contactNo_v, payOut_v/*, payOutFreq_v*/;
	private Div statusDiv;
	private Dialog removeDialog;
	private SiteView siteView;
	private Div editLandlordDiv;
	//private ComboBox payFreq;
	private NumberField payout;
	private String payFreqCode;
	
	
	
	public SiteLandLordBean(String siteCode,String id,String name, String addressV, String emailV, String statusV, String contactV, String payoutV, /*String payOutFreq,*/ SiteView siteView ) {
		addClassName(SCREENCD +"MAIN_LAYOUT");
		this.siteView = siteView;
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIV");
		Div idDiv =  UIHtmlFieldFactory.createDiv(SCREENCD, "ID_DIV");
		Label landLordId = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_ID_LBL");
		landLordId_value = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_ID_VALUE_LBL");
		landLordId_value.setText(id);
		idDiv.add(landLordId, landLordId_value);
		
		Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");
		viewBtn = UIFieldFactory.createButton(SCREENCD, "VIEW_BTN");
		remove_btn = UIFieldFactory.createButton(SCREENCD, "REMOVE_BTN");
		edit_btn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN"); 
		buttonDiv.add(edit_btn, viewBtn, remove_btn);
		headerDiv.add(idDiv, buttonDiv);
		
		Div bodyInfoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_INFO_DIV");
		Div row_1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row_7 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		landlordNme = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_NAME_LBL");
		address = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_ADDRESS_LBL");
		email = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_EMAIL_LBL");
		status = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_STATUS_LBL");
		contactNo = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_CONTACT_NO_LBL");
		payOut = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_PAYOUT_LBL");
		//payOutFreqLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_PAYOUT_FREQ_LBL"); 
		
		landlordNme_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_NAME_V_LBL");
		address_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_ADDRESS_V_LBL");
		email_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_EMAIL_V_LBL");
		statusDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "STATUS_DIV");
		status_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_STATUS_V_LBL");
		contactNo_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_CONTACT_NO_V_LBL");
		payOut_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_PAYOUT_V_LBL");
		//payOutFreq_v = UIHtmlFieldFactory.createLabel(SCREENCD, "LAND_LORD_PAYOUTFREQ_V_LBL");
		getColorStatusCode(statusV);
		statusDiv.add(status_v);
		
		landlordNme_v.setText(name);
		address_v.setText(addressV);
		email_v.setText(emailV);
		status_v.setText(getStatus(statusV));
		contactNo_v.setText(contactV);
		payOut_v.setText(CommonUtils.roundValue(payoutV, 2));
		//payOutFreq_v.setText(getPayOutFreqValue(payOutFreq));
		
		if(statusV.equals("0")) {
			remove_btn.setEnabled(false);
			edit_btn.setEnabled(false);
		}else if(statusV.equals("1")) {
			remove_btn.setEnabled(true);
			edit_btn.setEnabled(true);
		}
		
		
		
		row_1.add(landlordNme, landlordNme_v);
		row_2.add(address, address_v);
		row_3.add(email, email_v);
		row_4.add(status, statusDiv);
		row_5.add(contactNo, contactNo_v);
		row_6.add(payOut, payOut_v);
		//row_7.add(payOutFreqLbl, payOutFreq_v);
		
		
		
		
		
		bodyInfoDiv.add(row_1,row_3,row_5, row_2, row_4,  row_6);
		
		add(headerDiv, bodyInfoDiv);
		
		viewBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
			/*	String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() + "/"
						+ "siteassetinventory/landlordview?LandlordId="+id;*/
				String url = VaadinServletRequest.getCurrent().getScheme() + "://"
						+ VaadinServletRequest.getCurrent().getServerName() + ":"
						+ VaadinServletRequest.getCurrent().getServerPort() 
						+VaadinServletRequest.getCurrent().getContextPath()
						+ "/landlordview?LandlordId="+id;
				UI.getCurrent().getPage().open(url);
				
			}
		});
		
		remove_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				
				
				
				removeDialog(siteCode, id);
				
				
			}
		});
		edit_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				EditLandlordDetails details = new EditLandlordDetails(/*payOutFreq_v.getText(), */payOut_v.getText(), siteCode,id, siteView);
				
			}
		});
		
		
		
	}
	
	
	
	private String getStatus(String code) {
		
		String status = null;
		
		if(code.equals("0")) {
			status = "Inactive";
		} else if(code.equals("1")){
			status = "Active";
		}
		return status;
		
	}
	private Dialog removeDialog(String sidecode, String id) {
		removeDialog = new Dialog();
		Div headerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "HEADER_DIALOG_DIV");
		Label headerTitle = UIHtmlFieldFactory.createLabel(SCREENCD, "HEADER_TITLE_LBL");
		headerDiv.add(headerTitle);
		Div bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		 FontAwesome.Solid.Icon icon = FontAwesome.Solid.INFO_CIRCLE.create();
		 icon.addClassName("INFO_ICON");
		 Label infoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMOVE_CONFIRMATION_INFO");
		 bodyDiv.add(icon, infoLbl);
		
		 Div buttonDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_DIV");
		 Button yes_btn = UIFieldFactory.createButton(SCREENCD, "YES_BTN");
		 Button no_btn = UIFieldFactory.createButton(SCREENCD, "NO_BTN");
		 buttonDiv.add(yes_btn, no_btn);
		 
		 
		 removeDialog.add(headerDiv, bodyDiv, buttonDiv);
		 
		 yes_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
                String base_URL=ApplicationConfiguration.getServiceEndpoint("REMOVELANDLORDSFROMSITE");
				
				Form formData = new Form();
				formData.add("SiteCode",sidecode);
				formData.add("LandlordId",id);
				
				try {
					String response = RestServiceHandler.deleteJSON_DELETE(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					siteView.addlandlordTab(sidecode);
					SiteAssetInventoryUIFramework.getFramework().showMessage("Landlord is Removed!", ApplicationConstants.DialogTypes.INFO);
					removeDialog.close();
					remove_btn.setEnabled(false);
				} catch (Exception e) {
					SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
					e.printStackTrace();
				} 
				
			}
		});
		 
		 no_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				removeDialog.close();
				
			}
		});
		
		removeDialog.open();
		return removeDialog;
	}
	private List<String> getPayFeq() {
		List<String> list= new ArrayList<>();
		
		list.add("Weekly");
		list.add("Fortnightly");
		list.add("Monthly");
		list.add("Quarterly");
		list.add("Bi-Yearly");
		list.add("Yearly");
		
		return list;
		
	}
	private String getPayOutFreqValue(String code) {
		String value = null;
		if(code.equals("1")) {
			value = "Weekly";
		}else if(code.equals("2")) {
			value = "Fortnightly";
		}else if(code.equals("3")) {
			value = "Monthly";
		}
		else if(code.equals("4")) {
			value = "Quarterly";
		}
		else if(code.equals("5")) {
			value = "Bi-Yearly";
		}
		else if(code.equals("6")) {
			value = "Yearly";
		}
		
		return value;
		
	}
     private void getPayFreqCode(String listItem) {
		
		if(listItem.equals("Weekly")) {
			payFreqCode = "1";
		}else if(listItem.equals("Fortnightly")) {
			payFreqCode = "2";
			
		}else if(listItem.equals("Monthly")) {
			payFreqCode = "3";
		}else if(listItem.equals("Quarterly")) {
			payFreqCode = "4";
		}else if(listItem.equals("Bi-Yearly")) {
			payFreqCode = "5";
		}else if(listItem.equals("Yearly")) {
			payFreqCode = "6";
		}
		
		
		
		
	}
	private void getColorStatusCode(String code) {
		if(code.equals("0")) {
			statusDiv.getStyle().set("background", "#d80000");
		} else if(code.equals("1")){
			statusDiv.getStyle().set("background", "#4caf50");
		}
		
	}
	
	/*public String getPayFreq() {
		return getPayOutFreqValue(payOutFreq_v.getText());
	}*/

	public String getPayOutAmt() {
	    return payOut_v.getText();	
	}
}
