package com.umt.siteassetinventory.invoice;

import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
//import org.vaadin.gatanaso.MultiselectComboBox;
import org.vaadin.gatanaso.MultiselectComboBox;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
//import com.vaadin.flow.component.combobox.MultiSelectComboBox;

@CssImport("./styles/invoice-mangement.css")
public class AddInvoiceDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_INVOICE_DLG";
	private Div titleBar;
	private Div buttonBar;
	private Div mainLayout, bodyDiv, closeBtnDiv;
	private Button saveBtn, cancelBtn, uploadBtn;
	private ComboBox<String> solutiontypeField;
	private ComboBox<String> billingtypeField;
	private ComboBox<String> invoicetypeField;
	private TextField rentstatusField;
	private DatePicker invoicedateField;
	private TextField billingcycleField;
	private NumberField grossinvoiceamountField;
	private NumberField invoicearrearsField;
	private TextField remarksField, invoiceNoField, due_dateAsPerAgreementField;

	private DatePicker submissiondateField;
	private NumberField invoiceamountField, totalField;
	// private NumberField gst_rateField;
	private TextField gst_rateField;
	private DatePicker duedateField;
	private DatePicker receiveddateField;
	private DatePicker period_startdateField;
	private DatePicker period_enddateField;
	private ComboBox<String> landlordidField;
	private ComboBox<String> sitecodeField, agreementNameField;
	private TextField sitenameField, sapvendorcodeField, rentshareField, circleField;
	private ComboBox<String> landlordnameField;
	// private ComboBox<String>
	// sitenameField,landlordidField,landlordnameField,agreementNameField,
	// sapvendorcodeField,rentshareField;
	private boolean isManualGiven=false;
	private List<String> siteList = new ArrayList<String>(), circleList = new ArrayList<String>(),
			sitenameList = new ArrayList<String>(), agreementnameList = new ArrayList<String>(),
			landlordnameList = new ArrayList<String>(), landlordidList = new ArrayList<String>(),
			rentShareList = new ArrayList<String>(), billingTypeList = new ArrayList<String>(),
			sapvendorcodeList = new ArrayList<String>(), rentstatusList = new ArrayList<String>(),
			invoiceTypeList = new ArrayList<String>(), billcycleList = new ArrayList<String>(),
			siteOPList = new ArrayList<String>(), solutiontypeList = new ArrayList<String>();

	private String paymentDayOfMonth;
	private JSONArray landlordJsrr;
	private MultiselectComboBox<String> billforoperatorField;

	public boolean success = false;
	private String base64EncodedFileContent = "", fileName = "", fileType = "", docDesc = "";
	private Label filenameLbl;
	private Image removeIcon;
	private HashMap<String, Integer> invoicetypemap = new HashMap<String, Integer>();
	private HashMap<Integer, String> invoicetypemap2 = new HashMap<Integer, String>();
	private HashMap<String, Integer> billtypemap = new HashMap<String, Integer>();
	private HashMap<Integer, String> billtypemap2 = new HashMap<Integer, String>();
	private Div usagedetailsDiv;
	private TextField sanctionloadField, consumerNoField;
	private ComboBox<String> meterserialNoField, metertypeField, lpsc_payableField;
	private NumberField /* meterserialNoField,consumerNoField, */ noofdaysField, opening_readingField,
			otherchargesField, tdsField, closing_readingField, calculated_consumptionField, manual_consumptionField,
			per_day_consumptionField, eb_amountField, unit_rateField, fix_load_chargeField, dg_chargeField,
			fcu_chargeField, late_payment_service_chargeField, final_payable_amountField;

	private Map<String, JSONObject> agreementMap = new HashMap<String, JSONObject>();
	private List<String> meterNoList = new ArrayList<String>(), metertypeList = new ArrayList<String>(),
			lpscList = new ArrayList<String>();
	private Map<String, String> meterNoMap = new HashMap<String, String>();
	private Map<String, String> agreementNameIdMap2 = new HashMap<String, String>();
	private Map<String, String> landlordMap = new HashMap<String, String>();
	private Map<String, Integer> meterTypeMap = new HashMap<String, Integer>();
	private HashMap<Integer, String> meterTypeMap2 = new HashMap<Integer, String>();
	private String siteCode2;
	private boolean isrentalTab, isUsageTab, isEmgTab;
	private String mode, invoiceid;

	public Button saveAsDraft_btn, clearDraft_btn;

	private String KEY_NAME = "ADD_RENTAL_INVOICE_FORMVALUE";
	private JSONObject temp_RentalInvoiceJson;
	private JSONObject temp_UsageInvoiceJson;

	private LocalDate date1, date2;
	private JSONArray sortedjsArr;
	private Map<String, String> agreementIdNameMap = new HashMap<String, String>();
	private String rentalDraftForm,usageDraftForm;
	private int str1,str2;
	private double d1,d2;

	public AddInvoiceDialog(boolean isrentalTab, boolean isUsageTab, boolean isEmgTab, String mode) {
//		System.out.println("isrentalTab=="+isrentalTab);
//		System.out.println("isUsageTab=="+isUsageTab);
//		System.out.println("isEmgTab=="+isEmgTab);
		this.isrentalTab = isrentalTab;
		this.isUsageTab = isUsageTab;
		this.isEmgTab = isEmgTab;
		this.mode = mode;

		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");

		closeBtnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CLOSE_BTN_DIV");
		Image closeImg = UIHtmlFieldFactory.createImage(SCREENCD, "CLOSE_IMAGE");
		closeBtnDiv.add(closeImg);

		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl, closeBtnDiv);

		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		saveAsDraft_btn = UIFieldFactory.createButton(SCREENCD, "SAVE_DRAFT_BTN");
		clearDraft_btn = UIFieldFactory.createButton(SCREENCD, "CLEAR_DRAFT_BTN");
		buttonBar.add(saveAsDraft_btn, clearDraft_btn, saveBtn, cancelBtn);

		Div row1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row7 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row8 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row9 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row10 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row11 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row12 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row13 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row14 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div row15 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");

		usagedetailsDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "USAGE_DIV");
		Div usagerow1 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow2 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow3 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow4 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow5 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow6 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow7 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow8 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow9 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		Div usagerow10 = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");

		// meterserialNoField=UIFieldFactory.createNumberField(false,
		// SCREENCD,"METERSERIALNO_FIELD");
		// consumerNoField= UIFieldFactory.createNumberField(false,
		// SCREENCD,"CONSUMERNO_FIELD");
		/*
		 * meterserialNoField=UIFieldFactory.createTextField("",false,
		 * SCREENCD,"METERSERIALNO_FIELD");
		 * consumerNoField=UIFieldFactory.createTextField("",false,
		 * SCREENCD,"CONSUMERNO_FIELD"); metertypeField=
		 * UIFieldFactory.createNumberField(false, SCREENCD,"METERTYPE_FIELD");
		 * sanctionloadField= UIFieldFactory.createTextField("", false,
		 * SCREENCD,"SANCTIONLOAD_FIELD"); noofdaysField=
		 * UIFieldFactory.createNumberField(false, SCREENCD,"NOOFDAYS_FIELD");
		 * opening_readingField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"OPENING_FIELD");
		 * closing_readingField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"CLOSING_FIELD");
		 * calculated_consumptionField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"CALCULATEDCONSUMPTION_FIELD");
		 * manual_consumptionField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"MANUALCONSUMPTION_FIELD");
		 * per_day_consumptionField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"PERDAYCONSUMPTION_FIELD"); eb_amountField=
		 * UIFieldFactory.createNumberField( false, SCREENCD,"EBAMT_FIELD");
		 * unit_rateField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"UNITRATE_FIELD");
		 * fix_load_chargeField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"FIXLOADCHARGE_FIELD");
		 * dg_chargeField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"DGCHARGE_FIELD");
		 * fcu_chargeField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"FCUCHARGE_FIELD"); late_payment_service_chargeField=
		 * UIFieldFactory.createNumberField(false, SCREENCD,"LATESERVICECHARGE_FIELD");
		 * lpsc_payableField= UIFieldFactory.createNumberField(false,
		 * SCREENCD,"LPSC_PAY_FIELD");
		 * final_payable_amountField=UIFieldFactory.createNumberField(false,
		 * SCREENCD,"FINALPAYABLEAMT_FIELD"); otherchargesField=
		 * UIFieldFactory.createNumberField(false, SCREENCD,"OTHER_CHARGES_FIELD");
		 */

		meterserialNoField = UIFieldFactory.createComboBox(meterNoList, false, SCREENCD, "METERSERIALNO_FIELD");
		consumerNoField = UIFieldFactory.createTextField("", false, SCREENCD, "CONSUMERNO_FIELD");
		metertypeField = UIFieldFactory.createComboBox(metertypeList, false, SCREENCD, "METERTYPE_FIELD");
		sanctionloadField = UIFieldFactory.createTextField("", false, SCREENCD, "SANCTIONLOAD_FIELD");
		noofdaysField = UIFieldFactory.createNumberField(false, SCREENCD, "NOOFDAYS_FIELD");
		opening_readingField = UIFieldFactory.createNumberField(false, SCREENCD, "OPENING_FIELD");
		closing_readingField = UIFieldFactory.createNumberField(false, SCREENCD, "CLOSING_FIELD");
		calculated_consumptionField = UIFieldFactory.createNumberField(false, SCREENCD, "CALCULATEDCONSUMPTION_FIELD");
		manual_consumptionField = UIFieldFactory.createNumberField(false, SCREENCD, "MANUALCONSUMPTION_FIELD");
		per_day_consumptionField = UIFieldFactory.createNumberField(false, SCREENCD, "PERDAYCONSUMPTION_FIELD");
		eb_amountField = UIFieldFactory.createNumberField(false, SCREENCD, "EBAMT_FIELD");
		unit_rateField = UIFieldFactory.createNumberField(false, SCREENCD, "UNITRATE_FIELD");
		fix_load_chargeField = UIFieldFactory.createNumberField(false, SCREENCD, "FIXLOADCHARGE_FIELD");
		dg_chargeField = UIFieldFactory.createNumberField(false, SCREENCD, "DGCHARGE_FIELD");
		fcu_chargeField = UIFieldFactory.createNumberField(false, SCREENCD, "FCUCHARGE_FIELD");
		late_payment_service_chargeField = UIFieldFactory.createNumberField(false, SCREENCD, "LATESERVICECHARGE_FIELD");
		lpsc_payableField = UIFieldFactory.createComboBox(lpscList, false, SCREENCD, "LPSC_PAY_FIELD");
		final_payable_amountField = UIFieldFactory.createNumberField(false, SCREENCD, "FINALPAYABLEAMT_FIELD");
		otherchargesField = UIFieldFactory.createNumberField(false, SCREENCD, "OTHER_CHARGES_FIELD");
		totalField = UIFieldFactory.createNumberField(false, SCREENCD, "TOTAL_FIELD");

		closing_readingField.setValueChangeMode(ValueChangeMode.EAGER);
		opening_readingField.setValueChangeMode(ValueChangeMode.EAGER);
		manual_consumptionField.setValueChangeMode(ValueChangeMode.EAGER);
		calculated_consumptionField.setValueChangeMode(ValueChangeMode.EAGER);
		eb_amountField.setValueChangeMode(ValueChangeMode.EAGER);
		totalField.setValueChangeMode(ValueChangeMode.EAGER);
		noofdaysField.setValueChangeMode(ValueChangeMode.EAGER);
		fcu_chargeField.setValueChangeMode(ValueChangeMode.EAGER);
		dg_chargeField.setValueChangeMode(ValueChangeMode.EAGER);
		late_payment_service_chargeField.setValueChangeMode(ValueChangeMode.EAGER);
		fix_load_chargeField.setValueChangeMode(ValueChangeMode.EAGER);
		unit_rateField.setValueChangeMode(ValueChangeMode.EAGER);

		eb_amountField.setValue(0.0);
		fix_load_chargeField.setValue(0.0);
		dg_chargeField.setValue(0.0);
		fcu_chargeField.setValue(0.0);
		late_payment_service_chargeField.setValue(0.0);
		noofdaysField.setValue(1.0);
		totalField.setValue(0.0);

		usagerow1.add(consumerNoField, metertypeField);
		usagerow2.add(sanctionloadField, noofdaysField);
		// usagerow3.add(closing_readingField,opening_readingField);
		usagerow3.add(opening_readingField, closing_readingField);
		usagerow4.add(calculated_consumptionField, manual_consumptionField);
		usagerow5.add(per_day_consumptionField, eb_amountField);
		usagerow6.add(unit_rateField, fix_load_chargeField);
		usagerow7.add(dg_chargeField, fcu_chargeField);
		usagerow8.add(late_payment_service_chargeField, otherchargesField);
		usagerow9.add(lpsc_payableField, final_payable_amountField);
		// usagerow10.add(totalField);
		usagedetailsDiv.add(usagerow1, usagerow2, usagerow3, usagerow4, usagerow5, usagerow6, usagerow7, usagerow8,
				usagerow9, usagerow10);

		Div uploadDocDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOAD_DIV");
		Div filenameDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "FILENAME_DIV");
		removeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "REMOVE_IMAGE_ICON");
		filenameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "FILENAME_LBL");
		filenameDiv.add(filenameLbl, removeIcon);
		uploadBtn = UIFieldFactory.createButton(SCREENCD, "UPLOAD_BTN");
		uploadDocDiv.add(uploadBtn, filenameDiv);
		com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon uploadIcon = FontAwesome.Solid.UPLOAD.create();
		uploadBtn.setIcon(uploadIcon);
		filenameDiv.setVisible(false);
		uploadDocDiv.setTitle("Upload");

		populateSiteComboLists();
		populateBillingTypeLists();

		invoiceNoField = UIFieldFactory.createTextField("", true, SCREENCD, "INVOICENO_FIELD");
		sitecodeField = UIFieldFactory.createComboBox(siteList, true, SCREENCD, "SITECODE_FIELD");

		// circleField= UIFieldFactory.createComboBox(circleList, true,
		// SCREENCD,"CIRCLE_FIELD");
		// sitenameField=UIFieldFactory.createComboBox(sitenameList, true,
		// SCREENCD,"SITENAME_FIELD");
		circleField = UIFieldFactory.createTextField("", true, SCREENCD, "CIRCLE_FIELD");
		sitenameField = UIFieldFactory.createTextField("", true, SCREENCD, "SITENAME_FIELD");

		landlordidField = UIFieldFactory.createComboBox(landlordidList, true, SCREENCD, "LANDLORDID_FIELD");
		// sapvendorcodeField=UIFieldFactory.createComboBox(sapvendorcodeList, false,
		// SCREENCD,"SAPVENDORCODE_FIELD");
		sapvendorcodeField = UIFieldFactory.createTextField("", true, SCREENCD, "SAPVENDORCODE_FIELD");

//		landlordnameField=UIFieldFactory.createComboBox(landlordnameList, true, SCREENCD,"LANDLORDNAME_FIELD");
//		rentshareField=UIFieldFactory.createComboBox(rentShareList, false, SCREENCD,"RENTSHARE_FIELD");
//		landlordnameField=UIFieldFactory.createTextField("", true, SCREENCD,"LANDLORDNAME_FIELD");
		landlordnameField = UIFieldFactory.createComboBox(landlordnameList, true, SCREENCD, "LANDLORDNAME_FIELD");
		rentshareField = UIFieldFactory.createTextField("", false, SCREENCD, "RENTSHARE_FIELD");

		agreementNameField = UIFieldFactory.createComboBox(agreementnameList, false, SCREENCD, "AGREEMENTNAME_FIELD");

		// solutiontypeField= UIFieldFactory.createTextField("", true,
		// SCREENCD,"SOLUTION_TYPE_FIELD");
		// billingtypeField= UIFieldFactory.createTextField("", true,
		// SCREENCD,"BILLING_TYPE_FIELD");

		solutiontypeField = UIFieldFactory.createComboBox(solutiontypeList, false, SCREENCD, "SOLUTION_TYPE_FIELD");
		billingtypeField = UIFieldFactory.createComboBox(billingTypeList, true, SCREENCD, "BILLING_TYPE_FIELD");

		invoicetypeField = UIFieldFactory.createComboBox(invoiceTypeList, true, SCREENCD, "INVOICE_TYPE_FIELD");
		// rentstatusField=UIFieldFactory.createComboBox(rentstatusList, false,
		// SCREENCD,"RENT_STATUS_FIELD");
		rentstatusField = UIFieldFactory.createTextField("", false, SCREENCD, "RENT_STATUS_FIELD");

		invoicedateField = UIFieldFactory.createDatePicker(true, SCREENCD, "INVOICE_DATE_FIELD");
		// Locale finnishLocale = new Locale("uk", "UK");

		// DatePicker datePicker = new DatePicker("Select a date:");
		// invoicedateField.setLocale(finnishLocale);

		// billingcycleField=UIFieldFactory.createComboBox(billcycleList, false,
		// SCREENCD,"BILLING_CYCLE_FIELD");
		billingcycleField = UIFieldFactory.createTextField("", false, SCREENCD, "BILLING_CYCLE_FIELD");

		period_startdateField = UIFieldFactory.createDatePicker(true, SCREENCD, "PERIOD_START_DATE_FIELD");
		period_enddateField = UIFieldFactory.createDatePicker(true, SCREENCD, "PERIOD_END_DATE_FIELD");

		grossinvoiceamountField = UIFieldFactory.createNumberField(true, SCREENCD, "GROSS_INVOICEAMT_FIELD");
		grossinvoiceamountField.setValue(0.0);
		// gst_rateField=UIFieldFactory.createNumberField(true,
		// SCREENCD,"GST_RATE_FIELD");
		// gst_rateField.setValue(0.0);

		gst_rateField = UIFieldFactory.createTextField("", true, SCREENCD, "GST_RATE_FIELD");
		gst_rateField.setValue("0");

		grossinvoiceamountField.setValueChangeMode(ValueChangeMode.EAGER);
		gst_rateField.setValueChangeMode(ValueChangeMode.EAGER);

		invoiceamountField = UIFieldFactory.createNumberField(true, SCREENCD, "INVOICEAMT_FIELD");
		remarksField = UIFieldFactory.createTextField("", false, SCREENCD, "REMARKS_FIELD");

		tdsField = UIFieldFactory.createNumberField(false, SCREENCD, "TDS_FIELD");

		billforoperatorField = UIFieldFactory.createMultiselectComboBox(siteOPList, false, SCREENCD,
				"BILL_OPERATOR_FIELD");
		billforoperatorField.addValueChangeListener(event -> {
			Set<String> value = billforoperatorField.getValue();
			// System.out.println("value=="+value);
		});

		invoicearrearsField = UIFieldFactory.createNumberField(false, SCREENCD, "INVOICE_ARREARS_FIELD");
		invoicearrearsField.setValueChangeMode(ValueChangeMode.EAGER);
		invoicearrearsField.setValue(0.0);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate now = LocalDate.now();
		submissiondateField = UIFieldFactory.createDatePicker(true, SCREENCD, "SUBMISSION_DATE_FIELD");
		submissiondateField.setValue(now);
		submissiondateField.setEnabled(false);

		receiveddateField = UIFieldFactory.createDatePicker(true, SCREENCD, "RECEIVED_DATE_FIELD");
		duedateField = UIFieldFactory.createDatePicker(true, SCREENCD, "DUE_DATE_FIELD");

		due_dateAsPerAgreementField = UIFieldFactory.createTextField("", false, SCREENCD, "DUE_DATE_AGREEMENT_FIELD");
		// due_dateAsPerAgreementField.setValue(paymentDayOfMonth);

		/*
		 * row1.add(sitecodeField,invoiceNoField); row2.add(circleField,sitenameField);
		 * row3.add(landlordidField,sapvendorcodeField);
		 * row4.add(landlordnameField,rentshareField);
		 * row5.add(invoicetypeField,rentstatusField);
		 * row6.add(invoicedateField,billingcycleField);
		 * row7.add(solutiontypeField,billingtypeField);
		 * row8.add(period_startdateField,period_enddateField);
		 * row9.add(grossinvoiceamountField,gst_rateField);
		 * row10.add(invoiceamountField,billforoperatorField);
		 * row11.add(invoicearrearsField,submissiondateField);
		 * row12.add(receiveddateField,duedateField);
		 * row13.add(agreementNameField,due_dateAsPerAgreementField);
		 */

		/*
		 * row1.add(sitecodeField,sitenameField);
		 * row2.add(circleField,agreementNameField);
		 * row3.add(billingcycleField,rentstatusField);
		 * //row4.add(landlordidField,landlordnameField);
		 * row4.add(landlordnameField,tdsField);
		 * row5.add(rentshareField,billforoperatorField);
		 * row6.add(sapvendorcodeField,solutiontypeField);
		 * row7.add(invoicetypeField,billingtypeField);
		 * row8.add(period_startdateField,period_enddateField);
		 * row9.add(grossinvoiceamountField,gst_rateField);
		 * row10.add(invoiceamountField,invoicedateField);
		 * row11.add(invoicearrearsField,submissiondateField);
		 * row12.add(receiveddateField,duedateField);
		 * row13.add(invoiceNoField,due_dateAsPerAgreementField); //
		 * row14.add(remarksField,uploadDocDiv,meterserialNoField); //
		 * row15.add(tdsField);
		 */

		row1.add(sitecodeField, sitenameField);
		row2.add(circleField, agreementNameField);
		row3.add(landlordnameField, billingcycleField);
		row4.add(rentstatusField, due_dateAsPerAgreementField);
		row5.add(rentshareField, billforoperatorField);
		row6.add(sapvendorcodeField, solutiontypeField);
		row7.add(invoicetypeField, billingtypeField);
		row8.add(period_startdateField, period_enddateField);
		row9.add(grossinvoiceamountField, gst_rateField);
		row10.add(invoiceamountField, invoicedateField);
		row11.add(invoicearrearsField, submissiondateField);
		row12.add(receiveddateField, duedateField);
		row13.add(invoiceNoField, remarksField);

		bodyDiv.add(row1, row2, row3, row4, row5, row6, row7, row8, row9, row10, row11, row12, row13, row14,
				usagedetailsDiv);

		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout, buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		if (isrentalTab == false && isUsageTab == true) {// usage tab
			usagerow10.removeAll();
			row14.removeAll();

			row4.removeAll();
			row5.removeAll();
			row4.add(billforoperatorField, due_dateAsPerAgreementField);

			// usagerow10.add(totalField,uploadDocDiv);
			// row14.add(remarksField,meterserialNoField);
			usagerow10.add(/* totalField,remarksField */);
			row14.add(meterserialNoField, uploadDocDiv);
			usagedetailsDiv.setVisible(true);
			uploadDocDiv.setVisible(true);
			meterserialNoField.setVisible(true);
			populateInvoiceTypeUsageLists();
			// populateMeterSerialNo();
			populateMeterTypeField();
			populateLpscPayableField();
			// calculateNoOfDays();

			grossinvoiceamountField.setLabel("Total");

			KEY_NAME = "ADD_USAGE_INVOICE_FORMVALUE";
			setUsageFormValue(isrentalTab, isUsageTab, isEmgTab, mode);// save as draft

		} else if (isrentalTab == true && isUsageTab == false) {// rental tab
			row14.removeAll();
			// row14.add(remarksField,uploadDocDiv);
			row14.add(uploadDocDiv);
			usagedetailsDiv.setVisible(false);
			uploadDocDiv.setVisible(true);
			meterserialNoField.setVisible(false);
			populateInvoiceTypeRentalLists();

			row4.removeAll();
			row5.removeAll();
			row4.add(rentstatusField, due_dateAsPerAgreementField);
			row5.add(rentshareField, billforoperatorField);

			grossinvoiceamountField.setLabel("Gross Invoice Amount");

			KEY_NAME = "ADD_RENTAL_INVOICE_FORMVALUE";
			setRentalFormValue(isrentalTab, isUsageTab, isEmgTab, mode);// save as draft

		} else {
			usagedetailsDiv.setVisible(false);
			uploadDocDiv.setVisible(true);
			meterserialNoField.setVisible(false);

			grossinvoiceamountField.setLabel("Gross Invoice Amount");

			setRentalFormValue(isrentalTab, isUsageTab, isEmgTab, mode);// save as draft
		}

		saveAsDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				saveAsDraft(isrentalTab, isUsageTab, isEmgTab, mode);
			}
		});

		clearDraft_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				clearDraft(isrentalTab, isUsageTab, isEmgTab, mode);
			}
		});

		closeBtnDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				close();
			}
		});

		/*
		 * landlordidField.addValueChangeListener(new
		 * ValueChangeListener<ValueChangeEvent<String>>() { private static final long
		 * serialVersionUID = 1L;
		 * 
		 * @Override public void valueChanged(ValueChangeEvent<String> event) { String
		 * value = event.getValue(); if(value!=null) { populateSapVendorCodeList(value);
		 * populateLandlordNameComboList(value);
		 * 
		 * populateTdsField(value);
		 * 
		 * }
		 * 
		 * 
		 * } });
		 */
		
		billingtypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					billingtypeField.setInvalid(false);
					billingtypeField.setErrorMessage("");
				}else {
					billingtypeField.setInvalid(true);
					billingtypeField.focus();
					billingtypeField.setErrorMessage("Please Fill up this field");
				}

			}
		});
		
		
	
		landlordnameField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					String landlordid = landlordMap.get(value);
					populateSapVendorCodeList(landlordid);
					populateRentShareField(landlordid);
					populateTdsField(landlordid);

					landlordidField.setValue(landlordid);
					
					landlordnameField.setInvalid(false);
					landlordnameField.setErrorMessage("");

				}else {
					landlordnameField.setInvalid(true);
					landlordnameField.focus();
					landlordnameField.setErrorMessage("Please Fill up this field");
				}

			}
		});

//		if(sitecodeField.getValue()!=null) {
//			siteCode2 = sitecodeField.getValue();
//			populateCircleComboLists(sitecodeField.getValue());
//			populateAgreementComboList(sitecodeField.getValue());
//			populateLandlordIdComboList(sitecodeField.getValue());
//			populateBillOperatorsComboList(sitecodeField.getValue());
//			
//			populateMeterSerialNo(sitecodeField.getValue());
//
//			if (isEmgTab == true && isUsageTab == true) {
//				getUsageInvoiceRecordsForEmg(sitecodeField.getValue());
//			}
//		}
		
		
		if(agreementNameField.getValue()!=null) {
			try {
			//populateFieldBasedOnAgreement(agreementNameField.getValue());
		//	populateAgreementComboList(sitecodeField.getValue());
			agreementNameIdMap2 = new HashMap<String, String>();
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEAGREEMENTS");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecodeField.getValue());
			String response = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			JSONArray jsonobj = new JSONArray(response);
			for (int i = 0; i < jsonobj.length(); i++) {
				JSONObject agreementJson = jsonobj.getJSONObject(i);
				// agreementJson.getLong("AgreementId"),
				if (agreementJson.getString("Status").equalsIgnoreCase("1")) {// Active Agreements only

					String agreementName = agreementJson.getString("Name") + "("+ agreementJson.getString("AgreementId") + ")";
					agreementnameList.add(agreementName);
							
					agreementNameIdMap2.put(agreementName, agreementJson.getString("AgreementId"));

				//	agreementIdNameMap.put(agreementJson.getString("AgreementId"), agreementJson.getString("Name"));
				}
			}
			
		//	agreementNameField.setItems(agreementnameList);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if(sitecodeField.getValue()!=null) {
			try {
				landlordJsrr = new JSONArray();
//				landlordnameList = new ArrayList<String>();
//				landlordidList = new ArrayList<String>();
//				rentShareList = new ArrayList<String>();
//				landlordMap = new HashMap<String, String>();
				
				String url = ApplicationConfiguration.getServiceEndpoint("GETSITELANDLORDDETAILS");
				url = url + "?SiteCode=" + URLEncoder.encode(sitecodeField.getValue());
				String response = RestServiceHandler.retriveJSON_GET(url,
						SiteAssetInventoryUIFramework.getFramework().getToken());
				JSONArray agreementsJA = new JSONArray(response);
				
				for (int i = 0; i < agreementsJA.length(); i++) {
					JSONObject agreementJson = agreementsJA.getJSONObject(i);
					if(agreementJson.getString("Status").equalsIgnoreCase("1")&& Double.parseDouble(agreementJson.getString("PayoutAmount"))>0.0) {//Active LandlordOnly
						landlordnameList.add(agreementJson.getString("LandlordName"));
						landlordidList.add(agreementJson.getString("LandlordId"));
						rentShareList.add(agreementJson.getString("PayoutAmount"));

						landlordMap.put(agreementJson.getString("LandlordName"), agreementJson.getString("LandlordId"));
						JSONObject js1 = new JSONObject();
						js1.put("LandlordName", agreementJson.getString("LandlordName"));
						js1.put("LandlordId", agreementJson.getString("LandlordId"));
						js1.put("PayoutAmount", agreementJson.getString("PayoutAmount"));
						landlordJsrr.put(js1);
					}
					
				}
				
				String url2 = ApplicationConfiguration.getServiceEndpoint("GETSITEOPERATORS");
				url2 = url2 + "?SiteCode=" + URLEncoder.encode(sitecodeField.getValue());
				String res = RestServiceHandler.retriveJSON_GET(url2,SiteAssetInventoryUIFramework.getFramework().getToken());
				if (res != null && res.trim().length() > 0) {
					JSONArray jsarr = new JSONArray(res);
					if (jsarr.length() > 0) {
						for (int i = 0; i < jsarr.length(); i++) {
							siteOPList.add(jsarr.getJSONObject(i).getString("OpCoName"));
						}
					}
				}
				
				
				
				String url3 = ApplicationConfiguration.getServiceEndpoint("GETSITEATTRIBUTE");
				url3 = url3 + "?SiteCode=" + URLEncoder.encode(sitecodeField.getValue());
				String res3 = RestServiceHandler.retriveJSON_GET(url3,SiteAssetInventoryUIFramework.getFramework().getToken());
						
				if (res3 != null && res3.trim().length() > 0) {
					JSONObject jsobj = new JSONObject(res3);
					if (jsobj.length() > 0) {
						String str = jsobj.getString("OtherInfo");
						if (str != null) {
							JSONObject otherinfo = new JSONObject(str);
							if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("Solution Type")) {
								solutiontypeList.add(otherinfo.getString("Solution Type"));
							}

						}
					}
				}
				
				
				String url4 = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
				url4 = url4 + "?StoreSerialNo=-1&StoreId=9996&StatusId=-1&VendorId=" + "-1" + "&EquipmentTypeId=" + "-1"
						+ "&StoreLocId=" + URLEncoder.encode(sitecodeField.getValue()) + "&EquipmentSerialNo=-1";

				String res4 = RestServiceHandler.retriveJSON_GET(url4,SiteAssetInventoryUIFramework.getFramework().getToken());	
				if (res4 != null && res4.trim().length() > 0) {
					JSONArray jsarr = new JSONArray(res4);
					if (jsarr.length() > 0) {
						for (int i = 0; i < jsarr.length(); i++) {
							meterNoList.add(jsarr.getJSONObject(i).getString("EquipmentSerialNo"));
							meterNoMap.put(jsarr.getJSONObject(i).getString("EquipmentSerialNo"),
									jsarr.getJSONObject(i).getString("StoreSerialNo"));
						}
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
		sitecodeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					resetFormValue2();
					siteCode2 = value;
					populateCircleComboLists(value);
					// populateSiteNameComboLists(value);
					populateAgreementComboList(value);
					populateLandlordIdComboList(value);
					populateBillOperatorsComboList(value);
					// populateSolutionTypeLists(value);

					populateMeterSerialNo(value);
					// populateMeterTypeField();

					if (isEmgTab == true && isUsageTab == true) {
						getUsageInvoiceRecordsForEmg(value);
					} 
					sitecodeField.setInvalid(false);
					sitecodeField.setErrorMessage("");

				}else {
					sitecodeField.setInvalid(true);
					sitecodeField.focus();
					resetFormValue();
					sitecodeField.setErrorMessage("Please Fill up this field");
				}

			}
		});
		meterserialNoField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					getEquipmentAttributes(value);
					meterserialNoField.setInvalid(false);
					meterserialNoField.setErrorMessage("");

				}else {
					meterserialNoField.setInvalid(true);
					meterserialNoField.focus();
					meterserialNoField.setErrorMessage("Please Fill up this field");
				}

			}
		});
		agreementNameField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					populateFieldBasedOnAgreement(value);
				}

			}
		});
		
		

		invoicetypeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				try {
					String value = event.getValue();
					if (value == null) {
						fcu_chargeField.setEnabled(false);
						dg_chargeField.setEnabled(false);
						
						invoicetypeField.setInvalid(true);
						invoicetypeField.focus();
						invoicetypeField.setErrorMessage("Please Fill up this field");
					} else if (value != null) {
						if (value.equalsIgnoreCase("EB+DG") || value.equalsIgnoreCase("DG")) {
							dg_chargeField.setEnabled(true);
						} else if (value != null
								&& (!value.equalsIgnoreCase("EB+DG") || !value.equalsIgnoreCase("DG"))) {
							dg_chargeField.setValue(0.0);
							dg_chargeField.setEnabled(false);
						} else {
							dg_chargeField.setValue(0.0);
							dg_chargeField.setEnabled(false);
						}
						if (value.equalsIgnoreCase("EB+FCU") || value.equalsIgnoreCase("FCU")) {
							fcu_chargeField.setEnabled(true);
						} else if (!value.equalsIgnoreCase("EB+FCU") || !value.equalsIgnoreCase("FCU")) {
							fcu_chargeField.setValue(0.0);
							fcu_chargeField.setEnabled(false);
						} else {
							fcu_chargeField.setValue(0.0);
							fcu_chargeField.setEnabled(false);
						}
						
						invoicetypeField.setInvalid(false);
						invoicetypeField.setErrorMessage("");
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});

		if (mode.equalsIgnoreCase("create")) {
			saveAsDraft_btn.setVisible(true);
			clearDraft_btn.setVisible(true);
		} else {
			saveAsDraft_btn.setVisible(false);
			clearDraft_btn.setVisible(false);
			saveBtn.getStyle().set("margin-left", "auto");

		}

		saveBtn.setDisableOnClick(true);
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				if (mode.equalsIgnoreCase("create")) {
					saveData(isrentalTab, isUsageTab);
				} else if (mode.equalsIgnoreCase("edit")) {
					updateData(isrentalTab, isUsageTab);
				}

			}
		});

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		removeIcon.addClickListener(new ComponentEventListener<ClickEvent<Image>>() {
			private static final long serialVersionUID = 1L;

			public void onComponentEvent(ClickEvent<Image> event) {
				base64EncodedFileContent = "";
				fileName = "";
				fileType = "";
				docDesc = "";
				filenameDiv.setVisible(false);
			}
		});

		uploadBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				try {
					UploadInvoiceDocument dlg = new UploadInvoiceDocument();
					dlg.addOpenedChangeListener(
							new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
								private static final long serialVersionUID = 1L;

								@Override
								public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
									UploadInvoiceDocument srcDlg = (UploadInvoiceDocument) event.getSource();
									if (!srcDlg.isOpened() && srcDlg.fileuploadStatus) {
										base64EncodedFileContent = srcDlg.getFileContent();
										fileName = srcDlg.getFileName();
										fileType = srcDlg.getFileType();
										docDesc = srcDlg.getFileDescription();

										filenameDiv.setVisible(true);
										filenameLbl.setText(fileName);

									}
								}

							});

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});

		/*
		 * gst_rateField.addValueChangeListener(new
		 * ValueChangeListener<ValueChangeEvent<Double>>() { private static final long
		 * serialVersionUID = 1L;
		 * 
		 * @Override public void valueChanged(ValueChangeEvent<Double> event) { Double
		 * value = event.getValue(); System.out.println(String.valueOf(value).length());
		 * if(value!=null && grossinvoiceamountField.getValue()!=null) { double k =
		 * (double)(grossinvoiceamountField.getValue()*(value/100.0f));
		 * 
		 * // invoiceamountField.setValue(k+grossinvoiceamountField.getValue()); double
		 * val=k+grossinvoiceamountField.getValue();
		 * invoiceamountField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2))
		 * ); }
		 * 
		 * } });
		 */
		gst_rateField.setPattern("([0-9]{0,2})");// allows only 2digit
		gst_rateField.setPreventInvalidInput(true);
		gst_rateField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				Double gst = 0.0;
				if (event.getValue().length() > 0) {

					gst = Double.parseDouble(event.getValue());
				}

				if (gst != null && grossinvoiceamountField.getValue() != null) {
					double k = (double) (grossinvoiceamountField.getValue() * (gst / 100.0f));

					// invoiceamountField.setValue(k+grossinvoiceamountField.getValue());
					double val = k + grossinvoiceamountField.getValue();
					invoiceamountField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
				}

//					System.out.println("gst=="+gst);
//					System.out.println("gst_rateField.getValue()=="+gst_rateField.getValue());
//					System.out.println("gst_rateField.getValue().length()=="+gst_rateField.getValue().length());

				if (invoiceamountField.getValue() != null) {
					final_payable_amountField
							.setValue(Double.parseDouble(CommonUtils.roundValue(invoiceamountField.getValue(), 2)));
				}

			}
		});

		grossinvoiceamountField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {// gross
																											// invoice
																											// field for
																											// Rental
			private static final long serialVersionUID = 1L; // total field for electricity

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				Double value2 = event.getValue();
				Double grossinvoiceamountFieldVal = 0.0;
				Double ebamountFieldVal = 0.0;
				Double fix_load_chargeFieldVal = 0.0;
				Double dg_chargeFieldVal = 0.0;
				Double fcu_chargeFieldVal = 0.0;

				if (value2 == null) {
					grossinvoiceamountFieldVal = 0.0;
					invoiceamountField.clear();
				} else {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}

				// System.out.println("grossinvoiceamountField.getValue()=="+grossinvoiceamountField.getValue());

				try {

					if (gst_rateField.getValue().length() > 0) {

						// System.out.println("grossinvoiceamountField.getValue()2222=="+grossinvoiceamountField.getValue());
						double k = (double) (grossinvoiceamountFieldVal
								* (Double.parseDouble(gst_rateField.getValue()) / 100.0f));
						double val2 = k + grossinvoiceamountFieldVal;
						invoiceamountField.setValue(Double.parseDouble(CommonUtils.roundValue(val2, 2)));
					} else {
						// System.out.println("grossinvoiceamountField.getValue()=="+grossinvoiceamountField.getValue());
						invoiceamountField
								.setValue(Double.parseDouble(CommonUtils.roundValue(grossinvoiceamountFieldVal, 2)));
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

				// System.out.println("grossinvoiceamountField.getValue()=="+grossinvoiceamountField.getValue());
				// System.out.println("grossinvoiceamountField.getValue().length()=="+grossinvoiceamountField.getValue().length());
//				if(grossinvoiceamountField.getValue()==null && gst_rateField.getValue().length()>0) {
//					invoiceamountField.clear();
//				}

				if (invoiceamountField.getValue() != null) {
					final_payable_amountField
							.setValue(Double.parseDouble(CommonUtils.roundValue(invoiceamountField.getValue(), 2)));
				}

				if (lpsc_payableField.getValue() != null && lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
					if (late_payment_service_chargeField.getValue() != null) {
//						double value=grossinvoiceamountFieldVal+late_payment_service_chargeField.getValue();
//						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value,2)));
						double value = invoiceamountField.getValue() + late_payment_service_chargeField.getValue();
						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
					} else {
//						double value=grossinvoiceamountFieldVal+0.0;
//						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value,2)));
//						double value=invoiceamountField.getValue()+0.0;
//						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value,2)));

						// final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(invoiceamountField.getValue(),2)));
					}

				} else if (lpsc_payableField.getValue() != null
						&& lpsc_payableField.getValue().equalsIgnoreCase("No")) {
//					double value=grossinvoiceamountFieldVal;
//					final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value,2)));
					double value = invoiceamountField.getValue();
					final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
				} else {

				}

				if (eb_amountField.getValue() != null) {
					ebamountFieldVal = eb_amountField.getValue();
				}
				if (fix_load_chargeField.getValue() != null) {
					fix_load_chargeFieldVal = fix_load_chargeField.getValue();
				}
				if (dg_chargeField.getValue() != null) {
					dg_chargeFieldVal = dg_chargeField.getValue();
				}
				if (fcu_chargeField.getValue() != null) {
					fcu_chargeFieldVal = fcu_chargeField.getValue();
				}

//				double val=(grossinvoiceamountFieldVal-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);

				double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
						- dg_chargeFieldVal
						- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

			}
		});

		period_startdateField.addValueChangeListener(event -> {
//			if(event.getValue()!=null) {
//				period_enddateField.addValueChangeListener(event2->{
//					calculateNoOfDays();
//				});
//			}
			period_enddateField.addValueChangeListener(event2 -> {
				calculateNoOfDays();
			});
		});

		/*
		 * period_startdateField.addBlurListener(event->{ // if(event.getValue()!=null)
		 * { // period_enddateField.addValueChangeListener(event2->{ //
		 * calculateNoOfDays(); // }); // } // period_startdateField.clear(); //
		 * period_enddateField.addValueChangeListener(event2->{ // calculateNoOfDays();
		 * // }); if(period_startdateField.isInvalid()==true) {
		 * System.out.println("period_startdateField23333");
		 * period_startdateField.setInvalid(true);
		 * period_startdateField.setErrorMessage("Please select a valid date"); } });
		 */

		period_enddateField.addValueChangeListener(event -> {
//			if(event.getValue()!=null) {
//				period_enddateField.addValueChangeListener(event2->{
//					calculateNoOfDays();
//				});
//			}

//			period_enddateField.addValueChangeListener(event2->{
//				calculateNoOfDays();
//			});

			period_startdateField.addValueChangeListener(event2 -> {
				calculateNoOfDays();
			});
		});

		opening_readingField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				Double value = event.getValue();
				double opening_readingValue = 0.0;
				double closing_readingValue = 0.0;
//				if(value!=null && closing_readingField.getValue()!=null)
//				{
//					double val = closing_readingField.getValue()-opening_readingField.getValue();
//					calculated_consumptionField.setValue(val);
//				}

				if (opening_readingField.getValue() == null) {
					opening_readingValue = 0.0;
				} else {
					opening_readingValue = opening_readingField.getValue();
				}

				if (closing_readingField.getValue() == null) {
					closing_readingValue = 0.0;
				} else {
					closing_readingValue = closing_readingField.getValue();
				}

				double val = closing_readingValue - opening_readingValue;
				calculated_consumptionField.setValue(val);

			}
		});

		closing_readingField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				Double value = event.getValue();
				double opening_readingValue = 0.0;
				double closing_readingValue = 0.0;
				/*
				 * if(value!=null && closing_readingField.getValue()!=null) { Double
				 * opening_readingvalue = opening_readingField.getValue();
				 * if(opening_readingField.getValue()==null) { opening_readingvalue=0.0; }
				 * double val = closing_readingField.getValue()-opening_readingvalue;
				 * calculated_consumptionField.setValue(val); }
				 */

				if (opening_readingField.getValue() == null) {
					opening_readingValue = 0.0;
				} else {
					opening_readingValue = opening_readingField.getValue();
				}

				if (closing_readingField.getValue() == null) {
					closing_readingValue = 0.0;
				} else {
					closing_readingValue = closing_readingField.getValue();
				}

				double val = closing_readingValue - opening_readingValue;
				calculated_consumptionField.setValue(val);

			}
		});

		calculated_consumptionField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				try {
					Double value = event.getValue();
					double calculated_consumptionFieldVal = 1.0;
					double noofdaysFieldValue = 1.0;
					/*
					 * if(calculated_consumptionField.getValue()!=null &&
					 * noofdaysField.getValue()!=null && noofdaysField.getValue()>0 && value>0) {
					 * double val=(calculated_consumptionField.getValue()/noofdaysField.getValue());
					 * per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(
					 * val,2))); }
					 */
					if (calculated_consumptionField.getValue() == null) {
						calculated_consumptionFieldVal = 1.0;
					} else {
						calculated_consumptionFieldVal = calculated_consumptionField.getValue();
					}
					if (noofdaysField.getValue() == null || noofdaysField.getValue() <= 0) {
						noofdaysFieldValue = 1.0;
					} else {
						noofdaysFieldValue = noofdaysField.getValue();
					}
//				double val=(calculated_consumptionFieldVal/noofdaysFieldValue);
//				per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));
					if ((manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0)
							&& (calculated_consumptionField.getValue() > 0)) {
						double val = (calculated_consumptionFieldVal / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if ((manual_consumptionField.getValue() != null && manual_consumptionField.getValue() > 0)) {
						double val = (manual_consumptionField.getValue() / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else {
						per_day_consumptionField.clear();
					}

					if (eb_amountField.getValue() != null) {
						if (calculated_consumptionField.getValue() != null
								&& calculated_consumptionField.getValue() > 0) {
							double val2 = (eb_amountField.getValue() / calculated_consumptionField.getValue());
							unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val2, 2)));
						}
						if (calculated_consumptionField.getValue() == null
								&& manual_consumptionField.getValue() != null) {
							double val2 = (eb_amountField.getValue() / manual_consumptionField.getValue());
							unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val2, 2)));
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		noofdaysField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				try {

					Double value = event.getValue();
					double calculated_consumptionFieldVal = 0.0;
					double noofdaysFieldValue = 1.0;
					if (calculated_consumptionField.getValue() == null) {
						calculated_consumptionFieldVal = 0.0;
					} else {
						calculated_consumptionFieldVal = calculated_consumptionField.getValue();
					}
					if (noofdaysField.getValue() == null || noofdaysField.getValue() <= 0) {
						noofdaysFieldValue = 1.0;
					} else {
						noofdaysFieldValue = noofdaysField.getValue();
					}
					// double val=(calculated_consumptionFieldVal/noofdaysFieldValue);
					// per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));
					if ((manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0)
							&& (calculated_consumptionField.getValue() > 0)) {
						double val = (calculated_consumptionFieldVal / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if ((manual_consumptionField.getValue() != null || manual_consumptionField.getValue() > 0)) {
						double val = (manual_consumptionField.getValue() / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		manual_consumptionField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				Double value = event.getValue();
				double manual_consumptionvalue = 1.0;
				double noofdaysFieldValue = 1.0;
				/*
				 * if(value!=null && noofdaysField.getValue()!=null &&
				 * noofdaysField.getValue()>0 && value>0) { double
				 * val=(manual_consumptionField.getValue()/noofdaysField.getValue());
				 * per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(
				 * val,2)));
				 * 
				 * // double
				 * val2=(eb_amountField.getValue()/manual_consumptionField.getValue()); //
				 * unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val2,2)));
				 * }
				 */
				if (noofdaysField.getValue() == null || noofdaysField.getValue() <= 0) {
					noofdaysFieldValue = 1.0;
				} else {
					noofdaysFieldValue = noofdaysField.getValue();
				}
				
				if (manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0) {
					manual_consumptionvalue = 1.0;
				} else {
					manual_consumptionvalue = manual_consumptionField.getValue();
				}
				try {
					if ((manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0)
							&& (calculated_consumptionField.getValue() != null
									&& calculated_consumptionField.getValue() > 0)) {
						double val = (calculated_consumptionField.getValue() / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if ((manual_consumptionField.getValue() != null && manual_consumptionField.getValue() > 0)) {
						double val = (manual_consumptionField.getValue() / noofdaysFieldValue);
						per_day_consumptionField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				if (value == null && eb_amountField.getValue() != null
						&& calculated_consumptionField.getValue() != null) {
					double val2 = (eb_amountField.getValue() / calculated_consumptionField.getValue());
					unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val2, 2)));
				}
				if (manual_consumptionField.getValue() != null) {
					//double val2 = (eb_amountField.getValue() / manual_consumptionField.getValue());
					double val2 = (eb_amountField.getValue() / manual_consumptionvalue);
					unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val2, 2)));
				}

//				if(manual_consumptionField.getValue()==null || manual_consumptionField.getValue()<=0) {
//					manual_consumptionvalue = 1.0;
//				}
//				double val=(eb_amountField.getValue()/manual_consumptionvalue);
//				unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

			}
		});

		eb_amountField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
				Double value = event.getValue();

				Double grossinvoiceamountFieldVal = 0.0;
				Double ebamountFieldVal = 0.0;
				Double fix_load_chargeFieldVal = 0.0;
				Double dg_chargeFieldVal = 0.0;
				Double fcu_chargeFieldVal = 0.0;

				if (grossinvoiceamountField.getValue() != null) {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}
				if (eb_amountField.getValue() != null) {
					ebamountFieldVal = eb_amountField.getValue();
				}
				if (fix_load_chargeField.getValue() != null) {
					fix_load_chargeFieldVal = fix_load_chargeField.getValue();
				}
				if (dg_chargeField.getValue() != null) {
					dg_chargeFieldVal = dg_chargeField.getValue();
				}
				if (fcu_chargeField.getValue() != null) {
					fcu_chargeFieldVal = fcu_chargeField.getValue();
				}

				/*
				 * if(value!=null && noofdaysField.getValue()!=null &&
				 * noofdaysField.getValue()>0 && value>0) {
				 * if(manual_consumptionField.getValue()!=null &&
				 * manual_consumptionField.getValue()>0) { double
				 * val=(manual_consumptionField.getValue()/noofdaysField.getValue()); //
				 * unit_rateField.setValue(val);
				 * unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));
				 * }else if(calculated_consumptionField.getValue()!=null &&
				 * calculated_consumptionField.getValue()>0) { double
				 * val=(calculated_consumptionField.getValue()/noofdaysField.getValue()); //
				 * unit_rateField.setValue(val);
				 * unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));
				 * }else {
				 * 
				 * }
				 * 
				 * }
				 */
				if (value != null) {
					Double manual_consumptionvalue = 1.0;
					if (manual_consumptionField.getValue() != null || manual_consumptionField.getValue()<=0) {
						manual_consumptionvalue = 1.0;
					} else {
						manual_consumptionvalue = manual_consumptionField.getValue();
					}
					if (calculated_consumptionField.getValue() != null && manual_consumptionField.getValue() != null) {
						double val = (eb_amountField.getValue() / manual_consumptionvalue);
						unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if (calculated_consumptionField.getValue() != null
							&& calculated_consumptionField.getValue() > 0) {
						double val = (eb_amountField.getValue() / calculated_consumptionField.getValue());
						unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if (calculated_consumptionField.getValue() == null
							|| calculated_consumptionField.getValue() < 0) {
						if (manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0) {
							manual_consumptionvalue = 1.0;
						}
						double val = (eb_amountField.getValue() / manual_consumptionvalue);
						unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else {

					}

//					double val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//							fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue());
//					otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

//					double val=(grossinvoiceamountField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//							fcu_chargeField.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);

					double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
							- dg_chargeFieldVal
							- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
					otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

				}
				if (value == null) {
					Double manual_consumptionvalue = 1.0;
					Double eb_amountFieldvalue = 0.0;
					/*
					 * if(calculated_consumptionField.getValue()!=null &&
					 * manual_consumptionField.getValue()!=null) { double
					 * val=(eb_amountFieldvalue/manual_consumptionField.getValue());
					 * unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2))); }
					 */
					if (calculated_consumptionField.getValue() != null && calculated_consumptionField.getValue() > 0) {
						double val = (eb_amountFieldvalue / calculated_consumptionField.getValue());
						unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
					} else if (calculated_consumptionField.getValue() == null
							|| calculated_consumptionField.getValue() < 0) {
						if (manual_consumptionField.getValue() == null || manual_consumptionField.getValue() <= 0) {
							manual_consumptionvalue = 1.0;
							double val = (eb_amountFieldvalue / manual_consumptionvalue);
							unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
						} else if (manual_consumptionField.getValue() != null
								&& manual_consumptionField.getValue() > 0) {
							double val = (eb_amountFieldvalue / manual_consumptionField.getValue());
							unit_rateField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
						} else {
						}

					} else {

					}

					double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
							- dg_chargeFieldVal
							- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
					otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));
				}

			}
		});

		fix_load_chargeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
//				double val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue());
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

				Double grossinvoiceamountFieldVal = 0.0;
				Double ebamountFieldVal = 0.0;
				Double fix_load_chargeFieldVal = 0.0;
				Double dg_chargeFieldVal = 0.0;
				Double fcu_chargeFieldVal = 0.0;

				if (grossinvoiceamountField.getValue() != null) {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}
				if (eb_amountField.getValue() != null) {
					ebamountFieldVal = eb_amountField.getValue();
				}
				if (fix_load_chargeField.getValue() != null) {
					fix_load_chargeFieldVal = fix_load_chargeField.getValue();
				}
				if (dg_chargeField.getValue() != null) {
					dg_chargeFieldVal = dg_chargeField.getValue();
				}
				if (fcu_chargeField.getValue() != null) {
					fcu_chargeFieldVal = fcu_chargeField.getValue();
				}

				double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
						- dg_chargeFieldVal
						- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

//				double val=(grossinvoiceamountField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

			}
		});

		dg_chargeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
//				double val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue());
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

//				double val=(grossinvoiceamountField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

				Double grossinvoiceamountFieldVal = 0.0;
				Double ebamountFieldVal = 0.0;
				Double fix_load_chargeFieldVal = 0.0;
				Double dg_chargeFieldVal = 0.0;
				Double fcu_chargeFieldVal = 0.0;

				if (grossinvoiceamountField.getValue() != null) {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}
				if (eb_amountField.getValue() != null) {
					ebamountFieldVal = eb_amountField.getValue();
				}
				if (fix_load_chargeField.getValue() != null) {
					fix_load_chargeFieldVal = fix_load_chargeField.getValue();
				}
				if (dg_chargeField.getValue() != null) {
					dg_chargeFieldVal = dg_chargeField.getValue();
				}
				if (fcu_chargeField.getValue() != null) {
					fcu_chargeFieldVal = fcu_chargeField.getValue();
				}

				double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
						- dg_chargeFieldVal
						- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

			}
		});

		fcu_chargeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
//				double val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue());
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

//				double val=(grossinvoiceamountField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

				Double grossinvoiceamountFieldVal = 0.0;
				Double ebamountFieldVal = 0.0;
				Double fix_load_chargeFieldVal = 0.0;
				Double dg_chargeFieldVal = 0.0;
				Double fcu_chargeFieldVal = 0.0;

				if (grossinvoiceamountField.getValue() != null) {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}
				if (eb_amountField.getValue() != null) {
					ebamountFieldVal = eb_amountField.getValue();
				}
				if (fix_load_chargeField.getValue() != null) {
					fix_load_chargeFieldVal = fix_load_chargeField.getValue();
				}
				if (dg_chargeField.getValue() != null) {
					dg_chargeFieldVal = dg_chargeField.getValue();
				}
				if (fcu_chargeField.getValue() != null) {
					fcu_chargeFieldVal = fcu_chargeField.getValue();
				}

				double val = (grossinvoiceamountFieldVal - ebamountFieldVal - fix_load_chargeFieldVal
						- dg_chargeFieldVal
						- fcu_chargeFieldVal/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

			}
		});

		late_payment_service_chargeField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			/*
			 * public void valueChanged(ValueChangeEvent<Double> event) { double
			 * val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.
			 * getValue()-dg_chargeField.getValue()-
			 * fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-
			 * invoicearrearsField.getValue());
			 * otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)))
			 * ;
			 * 
			 * 
			 * Double invoiceamountFieldVal=0.0; if(invoiceamountField.getValue()==null) {
			 * invoiceamountFieldVal=0.0; }else {
			 * invoiceamountFieldVal=invoiceamountField.getValue(); }
			 * if(lpsc_payableField.getValue()!=null &&
			 * lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
			 * if(late_payment_service_chargeField.getValue()!=null) { double
			 * value=invoiceamountFieldVal+late_payment_service_chargeField.getValue();
			 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
			 * value,2))); }else { double value=invoiceamountFieldVal+0.0;
			 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
			 * value,2))); }
			 * 
			 * }else if(lpsc_payableField.getValue()!=null &&
			 * lpsc_payableField.getValue().equalsIgnoreCase("No")) { double
			 * value=invoiceamountFieldVal;
			 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
			 * value,2))); }else {
			 * 
			 * }
			 * 
			 * 
			 * }
			 */
			public void valueChanged(ValueChangeEvent<Double> event) {
				double val = (grossinvoiceamountField.getValue() - eb_amountField.getValue()
						- fix_load_chargeField.getValue() - dg_chargeField.getValue() - fcu_chargeField
								.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

				Double grossinvoiceamountFieldVal = 0.0;
				Double invoiceamountFieldFieldVal = 0.0;
				if (grossinvoiceamountField.getValue() == null) {
					grossinvoiceamountFieldVal = 0.0;
				} else {
					grossinvoiceamountFieldVal = grossinvoiceamountField.getValue();
				}

				if (invoiceamountField.getValue() == null) {
					invoiceamountFieldFieldVal = 0.0;
				} else {
					invoiceamountFieldFieldVal = invoiceamountField.getValue();
				}

				// System.out.println("lpsc_payableField.getValue()=="+lpsc_payableField.getValue());
				if (lpsc_payableField.getValue() != null && lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
					if (late_payment_service_chargeField.getValue() != null) {
						// double
						// value=grossinvoiceamountFieldVal+late_payment_service_chargeField.getValue();
						double value = invoiceamountFieldFieldVal + late_payment_service_chargeField.getValue();
						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
					} else {
						// double value=grossinvoiceamountFieldVal+0.0;
						double value = invoiceamountFieldFieldVal + 0.0;
						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
					}

				} else if (lpsc_payableField.getValue() != null
						&& lpsc_payableField.getValue().equalsIgnoreCase("No")) {

					double value = invoiceamountFieldFieldVal;
					// double value=grossinvoiceamountFieldVal;
					// System.out.println("value=="+value);
					final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
				} else {

				}

			}
		});

		invoicearrearsField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<Double>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<Double> event) {
//				double val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.getValue()-dg_chargeField.getValue()-
//						fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue());
//				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)));

				double val = (grossinvoiceamountField.getValue() - eb_amountField.getValue()
						- fix_load_chargeField.getValue() - dg_chargeField.getValue() - fcu_chargeField
								.getValue()/*-late_payment_service_chargeField.getValue()-invoicearrearsField.getValue()*/);
				otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val, 2)));

			}
		});

		/*
		 * totalField.addValueChangeListener(new
		 * ValueChangeListener<ValueChangeEvent<Double>>() { private static final long
		 * serialVersionUID = 1L;
		 * 
		 * @Override public void valueChanged(ValueChangeEvent<Double> event) { Double
		 * value = event.getValue(); // if(value!=null &&
		 * eb_amountField.getValue()!=null && fix_load_chargeField.getValue()!=null //
		 * && dg_chargeField.getValue()!=null && fcu_chargeField.getValue()!=null // &&
		 * late_payment_service_chargeField.getValue()!=null &&
		 * invoicearrearsField.getValue()!=null ) // { // double
		 * val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.
		 * getValue()-dg_chargeField.getValue()- //
		 * fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-
		 * invoicearrearsField.getValue()); //
		 * otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)))
		 * ; // }
		 * 
		 * double
		 * val=(totalField.getValue()-eb_amountField.getValue()-fix_load_chargeField.
		 * getValue()-dg_chargeField.getValue()-
		 * fcu_chargeField.getValue()-late_payment_service_chargeField.getValue()-
		 * invoicearrearsField.getValue());
		 * otherchargesField.setValue(Double.parseDouble(CommonUtils.roundValue(val,2)))
		 * ;
		 * 
		 * 
		 * } });
		 */

		lpsc_payableField.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String val = event.getValue();
				Double invoiceamountFieldVal = 0.0;
				if (invoiceamountField.getValue() == null) {
					invoiceamountFieldVal = 0.0;
				} else {
					invoiceamountFieldVal = invoiceamountField.getValue();
				}
				if (val != null && val.equalsIgnoreCase("Yes")) {
					if (late_payment_service_chargeField.getValue() != null) {
						double value = invoiceamountFieldVal + late_payment_service_chargeField.getValue();
						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
					} else {
						double value = invoiceamountFieldVal + 0.0;
						final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
					}

				} else if (val != null && val.equalsIgnoreCase("No")) {
					double value = invoiceamountFieldVal;
					final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(value, 2)));
				} else {

				}
			}
		});

		/*
		 * invoiceamountField.addValueChangeListener(new
		 * ValueChangeListener<ValueChangeEvent<Double>>() { private static final long
		 * serialVersionUID = 1L;
		 * 
		 * @Override public void valueChanged(ValueChangeEvent<Double> event) {
		 * if(lpsc_payableField.getValue()!=null &&
		 * lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
		 * if(late_payment_service_chargeField.getValue()!=null) { double
		 * value=invoiceamountField.getValue()+late_payment_service_chargeField.getValue
		 * ();
		 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
		 * value,2))); }else { double value=invoiceamountField.getValue()+0.0;
		 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
		 * value,2))); }
		 * 
		 * }else if(lpsc_payableField.getValue()!=null &&
		 * lpsc_payableField.getValue().equalsIgnoreCase("No")) { double
		 * value=invoiceamountField.getValue();
		 * final_payable_amountField.setValue(Double.parseDouble(CommonUtils.roundValue(
		 * value,2))); }else {
		 * 
		 * } } });
		 */

		disableFields();

		if (mode.equalsIgnoreCase("edit")) {
			TitleLbl.setText("Edit Invoice");
		} else {
			TitleLbl.setText("Add Invoice");
		}
		
		if(invoicetypeField.getValue()!=null) {
			if (invoicetypeField.getValue().equalsIgnoreCase("EB+DG") || invoicetypeField.getValue().equalsIgnoreCase("DG")) {
				dg_chargeField.setEnabled(true);
			} else if ((!invoicetypeField.getValue().equalsIgnoreCase("EB+DG") || !invoicetypeField.getValue().equalsIgnoreCase("DG"))) {
				dg_chargeField.setValue(0.0);
				dg_chargeField.setEnabled(false);
			} 
			if (invoicetypeField.getValue().equalsIgnoreCase("EB+FCU") || invoicetypeField.getValue().equalsIgnoreCase("FCU")) {
			//	System.out.println("inside");
				fcu_chargeField.setEnabled(true);
			} else if (!invoicetypeField.getValue().equalsIgnoreCase("EB+FCU") || !invoicetypeField.getValue().equalsIgnoreCase("FCU")) {
				fcu_chargeField.setValue(0.0);
				fcu_chargeField.setEnabled(false);
			} else {
				fcu_chargeField.setValue(0.0);
				fcu_chargeField.setEnabled(false);
			}
		}

	}

	private void disableFields() {
		sitenameField.setEnabled(false);
		sapvendorcodeField.setEnabled(false);
		rentshareField.setEnabled(false);
		circleField.setEnabled(false);
		invoiceamountField.setEnabled(false);
		due_dateAsPerAgreementField.setEnabled(false);
		billingcycleField.setEnabled(false);
		rentstatusField.setEnabled(false);

		consumerNoField.setEnabled(false);
		noofdaysField.setEnabled(false);
		per_day_consumptionField.setEnabled(false);
		unit_rateField.setEnabled(false);
		sanctionloadField.setEnabled(false);
		final_payable_amountField.setEnabled(false);
		calculated_consumptionField.setEnabled(false);
		otherchargesField.setEnabled(false);
		invoiceamountField.setEnabled(false);
		metertypeField.setEnabled(false);
		fcu_chargeField.setEnabled(false);
		dg_chargeField.setEnabled(false);
	}

	protected void populateTdsField(String LandlordId) {
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETLANDLORDATTRIBUTES");
			url = url + "?LandlordId=" + URLEncoder.encode(LandlordId);
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			if (res != null && res.trim().length() > 0) {
				JSONObject js = new JSONObject(res);
				if (js.length() > 0) {
					if (js.has("TDS") && js.getString("TDS").length() > 0) {
						tdsField.setValue(Double.parseDouble(js.getString("TDS")));
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void populateLpscPayableField() {
		lpscList = new ArrayList<String>();

		String str[] = { "No", "Yes" };

		for (int i = 0; i < str.length; i++) {
			lpscList.add(str[i]);
		}

		lpsc_payableField.setItems(lpscList);
		lpsc_payableField.setValue(lpscList.get(0));

	}

	private void calculateNoOfDays() {
		try {
//			System.out.println("period_startdateField=="+period_startdateField.getValue());//"2023-03-09"
//			System.out.println("period_enddateField.getValue()=="+period_enddateField.getValue());
			if (period_startdateField.getValue() != null && period_enddateField.getValue() != null) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String startDateStr = period_startdateField.getValue().format(formatter);
				String endDateStr = period_enddateField.getValue().format(formatter);

				LocalDate startDate = LocalDate.parse(startDateStr);
				LocalDate endDate = LocalDate.parse(endDateStr);

				long days = ChronoUnit.DAYS.between(startDate, endDate) + 1;
				noofdaysField.setValue((double) days);

				// System.out.println("days="+days);
			} else if (period_startdateField.getValue() == null && period_enddateField.getValue() == null) {
				noofdaysField.setValue(1.0);
			} else if (period_startdateField.getValue() != null && period_enddateField.getValue() == null) {
				noofdaysField.setValue(1.0);
			} else if (period_startdateField.getValue() == null && period_enddateField.getValue() != null) {
				System.out.println("inside");
				noofdaysField.setValue(1.0);
			} else {
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void populateMeterTypeField() {
		metertypeList = new ArrayList<String>();
		meterTypeMap = new HashMap<String, Integer>();
		meterTypeMap2.clear();
		int count = 1;
		String str[] = { "SEB Meter", "Sub Meter", "Prepaid Meter", "SEB Prepaid Meter" };

		for (int i = 0; i < str.length; i++) {
			metertypeList.add(str[i]);
			meterTypeMap.put(str[i], count);
			meterTypeMap2.put(count, str[i]);
			count++;
		}

		metertypeField.setItems(metertypeList);

	}

	private void populateMeterSerialNo(String sitecode) {
		try {
			meterNoList = new ArrayList<String>();
			meterNoMap = new HashMap<String, String>();
			String response1 = "";
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url = url + "?StoreSerialNo=-1&StoreId=9996&StatusId=-1&VendorId=" + "-1" + "&EquipmentTypeId=" + "-1"
					+ "&StoreLocId=" + URLEncoder.encode(sitecode) + "&EquipmentSerialNo=-1";

			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());

			// System.out.println("url ::::::: "+url);
			// System.out.println("response ::::::: "+response);
			if (res != null && res.trim().length() > 0) {
				JSONArray jsarr = new JSONArray(res);
				if (jsarr.length() > 0) {
					for (int i = 0; i < jsarr.length(); i++) {
						meterNoList.add(jsarr.getJSONObject(i).getString("EquipmentSerialNo"));
						// JSONObject
						// otherInfo=getEquipmentAttributes(jsarr.getJSONObject(i).getString("StoreSerialNo"));
						meterNoMap.put(jsarr.getJSONObject(i).getString("EquipmentSerialNo"),
								jsarr.getJSONObject(i).getString("StoreSerialNo"));
					}
				}
			}
			meterserialNoField.setItems(meterNoList);
			if (meterNoList.size() > 0) {
				meterserialNoField.setValue(meterNoList.get(0));
			}

			System.out.println("meterNoMap==" + meterNoMap);

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	private void getEquipmentAttributes(String equipmentserialno) {
		try {

			String storeserialno = meterNoMap.get(equipmentserialno);
			JSONObject js = new JSONObject();
			JSONObject otherinfojs = null;
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTSATTRIBUTES");
			url = url + "?StoreSerialNo=" + storeserialno;
			String resp = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			if (resp != null || !resp.equals("null") || !resp.equals("{}")) {
				js = new JSONObject(resp);
				if (js != null && js.length() > 0) {
					otherinfojs = new JSONObject(js.getString("OtherInfo"));
					if (otherinfojs != null && otherinfojs.length() > 0) {
						try {
							if (otherinfojs.has("Meter Category")
									&& otherinfojs.getString("Meter Category").length() > 0) {
								metertypeField.setValue(otherinfojs.getString("Meter Category"));
							}
							if (otherinfojs.has("Consumer No") && otherinfojs.getString("Consumer No").length() > 0) {
								consumerNoField.setValue(otherinfojs.getString("Consumer No"));

							}

						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	protected void populateBillOperatorsComboList(String sitecode) {
		try {
			siteOPList = new ArrayList<String>();

			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEOPERATORS");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());

			if (res != null && res.trim().length() > 0) {
				JSONArray jsarr = new JSONArray(res);
				if (jsarr.length() > 0) {
					for (int i = 0; i < jsarr.length(); i++) {
						siteOPList.add(jsarr.getJSONObject(i).getString("OpCoName"));
					}
				}
				billforoperatorField.setItems(siteOPList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void populateSiteComboLists() {
		/*
		 * try { siteList=new ArrayList<String>(); circleList=new ArrayList<String>();
		 * 
		 * siteList.clear(); circleList.clear(); String url =
		 * ApplicationConfiguration.getServiceEndpoint("SEARCHSITE"); url = url +
		 * "?searchText=" + ""; String res = RestServiceHandler.retriveJSON_GET(url,
		 * SiteAssetInventoryUIFramework.getFramework().getToken());
		 * 
		 * if (res != null && res.trim().length() > 0) { JSONArray jsarr = new
		 * JSONArray(res); if (jsarr.length() > 0) { for (int i = 0; i < jsarr.length();
		 * i++) { siteList.add(jsarr.getJSONObject(i).getString("SiteCode")); //
		 * circleList.add(jsarr.getJSONObject(i).getString("Region")); } } //
		 * sitecodeField.setValue(siteList.get(0)); } } catch (Exception e) {
		 * e.printStackTrace(); }
		 */

		try {
			siteList = new ArrayList<String>();
			circleList = new ArrayList<String>();

			siteList.clear();
			circleList.clear();
			String url = ApplicationConfiguration.getServiceEndpoint("GETALLSITECODES");
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());

			if (res != null && res.trim().length() > 0) {
				JSONArray jsarr = new JSONArray(res);
				if (jsarr.length() > 0) {
					for (int i = 0; i < jsarr.length(); i++) {
						siteList.add(jsarr.getJSONObject(i).getString("SiteCode"));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void populateCircleComboLists(String sitecode) {
		/*
		 * try { circleList=new ArrayList<String>();
		 * 
		 * circleList.clear(); sitenameList.clear(); String url =
		 * ApplicationConfiguration.getServiceEndpoint("SEARCHSITE"); url = url +
		 * "?searchText=" + ""; String res = RestServiceHandler.retriveJSON_GET(url,
		 * SiteAssetInventoryUIFramework.getFramework().getToken());
		 * 
		 * if (res != null && res.trim().length() > 0) { JSONArray jsarr = new
		 * JSONArray(res); if (jsarr.length() > 0) { for (int i = 0; i < jsarr.length();
		 * i++) { String SiteCode=jsarr.getJSONObject(i).getString("SiteCode");
		 * if(sitecode.equalsIgnoreCase(SiteCode)) {
		 * circleList.add(jsarr.getJSONObject(i).getString("Region"));
		 * sitenameList.add(jsarr.getJSONObject(i).getString("SiteName")); }
		 * 
		 * } } // circleField.setItems(circleList); //
		 * sitenameField.setItems(sitenameList); //
		 * System.out.println("circleList="+circleList); if(circleList.size()>0) {
		 * circleField.setValue(circleList.get(0)); } if(sitenameList.size()>0) {
		 * sitenameField.setValue(sitenameList.get(0)); }
		 * 
		 * 
		 * } } catch (Exception e) { e.printStackTrace(); }
		 */
		try {
			circleList = new ArrayList<String>();

			circleList.clear();
			sitenameList.clear();
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEDETAILS");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());

			if (res != null && res.trim().length() > 0) {
				// JSONArray jsarr = new JSONArray(res);
				JSONObject js = new JSONObject(res);
				if (js.length() > 0) {
					circleList.add(js.getString("Region"));
					sitenameList.add(js.getString("SiteName"));
					populateSolutionTypeLists2(js.getString("OtherInfo"));
				}

				if (circleList.size() > 0) {
					circleField.setValue(circleList.get(0));
				}
				if (sitenameList.size() > 0) {
					sitenameField.setValue(sitenameList.get(0));
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * private void populateSiteNameComboLists(String sitecode) { try {
	 * sitenameList=new ArrayList<String>();
	 * 
	 * sitenameList.clear(); String url =
	 * ApplicationConfiguration.getServiceEndpoint("SEARCHSITE"); url = url +
	 * "?searchText=" + ""; String res = RestServiceHandler.retriveJSON_GET(url,
	 * SiteAssetInventoryUIFramework.getFramework().getToken());
	 * 
	 * if (res != null && res.trim().length() > 0) { JSONArray jsarr = new
	 * JSONArray(res); if (jsarr.length() > 0) { for (int i = 0; i < jsarr.length();
	 * i++) { sitenameList.add(jsarr.getJSONObject(i).getString("SiteName")); } } //
	 * sitenameField.setItems(sitenameList);
	 * sitenameField.setValue(sitenameList.get(0)); //
	 * System.out.println("sitenameList="+sitenameList); } } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * }
	 */

	protected void populateAgreementComboList(String sitecode) {
		try {
			agreementnameList = new ArrayList<String>();
			billcycleList = new ArrayList<String>();
			rentstatusList = new ArrayList<String>();
			agreementMap = new HashMap<String, JSONObject>();
			agreementNameIdMap2 = new HashMap<String, String>();
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEAGREEMENTS");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			// System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			JSONArray jsonobj = new JSONArray(response);
			for (int i = 0; i < jsonobj.length(); i++) {
				JSONObject agreementJson = jsonobj.getJSONObject(i);
				// agreementJson.getLong("AgreementId"),
				if (agreementJson.getString("Status").equalsIgnoreCase("1")) {// Active Agreements only

					// String
					// agreementname=agreementJson.getString("Name")+"_"+agreementJson.getString("AgreementId");

					String agreementName = agreementJson.getString("Name") + "("
							+ agreementJson.getString("AgreementId") + ")";
					agreementnameList.add(agreementName);
					// agreementnameList.add(agreementJson.getString("Name"));

					// agreementnameList.add(agreementname);
					// billcycleList.add(agreementJson.getString("Rent_Frequency"));
					JSONObject agreementMapObj = new JSONObject();
					if (agreementJson.has("FileDetails")
							&& agreementJson.getString("FileDetails").trim().length() > 0) {
						JSONArray fileDetailsJA = new JSONArray(agreementJson.getString("FileDetails"));
						if (fileDetailsJA.length() > 0) {
							JSONObject fileDetailsJson = fileDetailsJA.getJSONObject(0);
							// System.out.println("fileDetailsJson="+fileDetailsJson);
							if (fileDetailsJson.has("attributes")
									&& fileDetailsJson.getString("attributes").trim().length() > 0) {
								JSONObject fileAttributesJson = new JSONObject(fileDetailsJson.getString("attributes"));
								if (fileAttributesJson != null && fileAttributesJson.length() > 0
										&& fileAttributesJson.has("agreementdetails")) {
									String details = fileAttributesJson.getString("agreementdetails");
									JSONObject js = new JSONObject(details);
									// System.out.println("js="+js);

									if (js != null && js.length() > 0) {
										if (js.has("Rent_Frequency")
												&& js.getString("Rent_Frequency").trim().length() > 0) {
											billcycleList.add(js.getString("Rent_Frequency"));
											agreementMapObj.put("RentFrequency", js.getString("Rent_Frequency"));

										}
										if (js.has("Rent Status") && js.getString("Rent Status").trim().length() > 0) {
											rentstatusList.add(js.getString("Rent Status"));
											agreementMapObj.put("RentStatus", js.getString("Rent Status"));
										}
										if (js.has("Payment Day of Month")
												&& js.getString("Payment Day of Month").trim().length() > 0) {
											paymentDayOfMonth = js.getString("Payment Day of Month");
											agreementMapObj.put("PaymentDayofMonth",
													js.getString("Payment Day of Month"));
											// due_dateAsPerAgreementField.setValue(paymentDayOfMonth);
										}
									}
								}
							}

						}

					}
					agreementMap.put(agreementJson.getString("AgreementId"), agreementMapObj);
					// agreementMap2.put(agreementJson.getString("AgreementId"),agreementJson.getString("Name"));
					// agreementMap2.put(agreementJson.getString("Name"),agreementJson.getString("AgreementId"));

					agreementNameIdMap2.put(agreementName, agreementJson.getString("AgreementId"));

					agreementIdNameMap.put(agreementJson.getString("AgreementId"), agreementJson.getString("Name"));
				}
			}
			agreementNameField.setItems(agreementnameList);
			// billingcycleField.setItems(billcycleList);
			// rentstatusField.setItems(rentstatusList);
			// System.out.println("agreementnameList="+agreementnameList);

			System.out.println("agreementMap=" + agreementMap);
			System.out.println("agreementNameIdMap2=" + agreementNameIdMap2);
			System.out.println("agreementNameIdMap=" + agreementIdNameMap);

			if (agreementnameList.size() > 0) {
				agreementNameField.setValue(agreementnameList.get(0));
				if (agreementNameField.getValue() != null) {
					// System.out.println("agreementNameField.getValue()="+agreementNameField.getValue());
					populateFieldBasedOnAgreement(agreementNameField.getValue());
				}
			}

			/*
			 * if(billcycleList.size()>0) {
			 * billingcycleField.setValue(billcycleList.get(0)); }
			 * if(rentstatusList.size()>0) {
			 * rentstatusField.setValue(rentstatusList.get(0)); }
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void populateFieldBasedOnAgreement(String agreementname) {
		try {
			/*
			 * if(agreementMap!=null && agreementMap.size()>0) { JSONObject
			 * js=agreementMap.get(agreementId); if(js!=null && js.length()>0) {
			 * if(js.has("RentFrequency") && js.getString("RentFrequency").length()>0) {
			 * billingcycleField.setValue(js.getString("RentFrequency")); }
			 * if(js.has("RentStatus") && js.getString("RentStatus").length()>0) {
			 * rentstatusField.setValue(js.getString("RentStatus")); }
			 * if(js.has("PaymentDayofMonth") &&
			 * js.getString("PaymentDayofMonth").length()>0) {
			 * due_dateAsPerAgreementField.setValue(js.getString("PaymentDayofMonth")); } }
			 * }
			 */
			// String AgreementId=
			String agreementId = agreementNameIdMap2.get(agreementname);

			String url = ApplicationConfiguration.getServiceEndpoint("GETAGREEMENTATTRIBUTES");
			url = url + "?SiteCode=" + URLEncoder.encode(siteCode2) + "&AgreementId=" + agreementId;
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());

			System.out.println("res=" + res);
			if (res != null && res.trim().length() > 0) {
				JSONObject js = new JSONObject(res);
				if (js != null && js.length() > 0) {
					if (js.has("Rent Frequency") && js.getString("Rent Frequency") != null
							&& js.getString("Rent Frequency").length() > 0) {
						billingcycleField.setValue(js.getString("Rent Frequency"));
					}
					if (js.has("Rent Status") && js.getString("Rent Status") != null
							&& js.getString("Rent Status").length() > 0) {
						rentstatusField.setValue(js.getString("Rent Status"));
					}
					if (js.has("Payment Day of Month") && js.getString("Payment Day of Month") != null
							&& js.getString("Payment Day of Month").length() > 0) {
						due_dateAsPerAgreementField.setValue(js.getString("Payment Day of Month"));
					}

				} else {
					billingcycleField.setValue("");
					rentstatusField.setValue("");
					due_dateAsPerAgreementField.setValue("");

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void populateLandlordIdComboList(String sitecode) {
		try {
			landlordJsrr = new JSONArray();
			landlordnameList = new ArrayList<String>();
			landlordidList = new ArrayList<String>();
			rentShareList = new ArrayList<String>();
			landlordMap = new HashMap<String, String>();

			String url = ApplicationConfiguration.getServiceEndpoint("GETSITELANDLORDDETAILS");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			// System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			JSONArray agreementsJA = new JSONArray(response);

			for (int i = 0; i < agreementsJA.length(); i++) {
				JSONObject agreementJson = agreementsJA.getJSONObject(i);
				if(agreementJson.getString("Status").equalsIgnoreCase("1")&& Double.parseDouble(agreementJson.getString("PayoutAmount"))>0.0) {//Active Landlord Only
				landlordnameList.add(agreementJson.getString("LandlordName"));
				landlordidList.add(agreementJson.getString("LandlordId"));
				rentShareList.add(agreementJson.getString("PayoutAmount"));

				landlordMap.put(agreementJson.getString("LandlordName"), agreementJson.getString("LandlordId"));
				JSONObject js = new JSONObject();
				js.put("LandlordName", agreementJson.getString("LandlordName"));
				js.put("LandlordId", agreementJson.getString("LandlordId"));
				js.put("PayoutAmount", agreementJson.getString("PayoutAmount"));
				landlordJsrr.put(js);
				}
			}
			landlordnameField.setItems(landlordnameList);
			landlordidField.setItems(landlordidList);
//		rentshareField.setItems(rentShareList);

//		System.out.println("landlordnameList="+landlordnameList);

//		if(landlordidList.size()>0) {
//			landlordidField.setValue(landlordidList.get(0));
//		}

			if (landlordnameList.size() > 0) {
				landlordnameField.setValue(landlordnameList.get(0));
			}

			landlordidField.setValue(landlordMap.get(landlordnameField.getValue()));

			// landlordnameField.setValue(landlordnameList.get(0));
//		rentshareField.setValue(rentShareList.get(0));
//		

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * protected void populateLandlordNameComboList(String landlordid) { try {
	 * 
	 * if(landlordJsrr!=null && landlordJsrr.length()>0) { for(int
	 * i=0;i<landlordJsrr.length();i++) { String
	 * id=landlordJsrr.getJSONObject(i).getString("LandlordId");
	 * if(landlordid.equalsIgnoreCase(id)) {
	 * landlordnameField.setValue(landlordJsrr.getJSONObject(i).getString(
	 * "LandlordName"));
	 * rentshareField.setValue(landlordJsrr.getJSONObject(i).getString(
	 * "PayoutAmount")); } } }
	 * 
	 * } catch(Exception e) { e.printStackTrace(); }
	 * 
	 * 
	 * }
	 */
	protected void populateRentShareField(String landlordid) {
		try {

			if (landlordJsrr != null && landlordJsrr.length() > 0) {
				for (int i = 0; i < landlordJsrr.length(); i++) {
					String id = landlordJsrr.getJSONObject(i).getString("LandlordId");
					if (landlordid.equalsIgnoreCase(id)) {
						// landlordnameField.setValue(landlordJsrr.getJSONObject(i).getString("LandlordName"));
						//rentshareField.setValue(landlordJsrr.getJSONObject(i).getString("PayoutAmount"));
						rentshareField.setValue(CommonUtils.roundValue(landlordJsrr.getJSONObject(i).getString("PayoutAmount"),2));
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void populateSapVendorCodeList(String landlordid) {
		try {
			sapvendorcodeList = new ArrayList<String>();

			String url = ApplicationConfiguration.getServiceEndpoint("GETLANDLORDATTRIBUTES");
			url = url + "?LandlordId=" + URLEncoder.encode(landlordid);
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			System.out.println("res====" + res);
			// System.out.println("landlordMap===="+landlordMap);
			if (res != null && res.trim().length() > 0) {
				// JSONArray jsarr = new JSONArray(res);
				JSONObject jsobj = new JSONObject(res);
				// System.out.println("jsobj sapvendorcodeList="+jsobj);
				if (jsobj.length() > 0) {
					// for (int i = 0; i < jsarr.length(); i++) {
					String str = jsobj.getString("OtherInfo");
					if (str != null) {
						JSONObject otherinfo = new JSONObject(str);
						// System.out.println("otherinfo="+otherinfo);
						if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("SAP Vendor Code")) {
							sapvendorcodeList.add(otherinfo.getString("SAP Vendor Code"));
						} else if (otherinfo != null && otherinfo.length() > 0 && !otherinfo.has("SAP Vendor Code")) {
							sapvendorcodeList.add("none");
						} else {
						}
					}

					// }
				}
				// System.out.println("sapvendorcodeList="+sapvendorcodeList);
				// sapvendorcodeField.setItems(sapvendorcodeList);

				if (sapvendorcodeList.size() > 0) {
					if (!sapvendorcodeList.get(0).equalsIgnoreCase("none")) {
						sapvendorcodeField.setValue(sapvendorcodeList.get(0));
					} else {
						sapvendorcodeField.clear();
					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void populateSolutionTypeLists(String sitecode) {
		try {
			solutiontypeList = new ArrayList<String>();
			String url = ApplicationConfiguration.getServiceEndpoint("GETSITEATTRIBUTE");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			String res = RestServiceHandler.retriveJSON_GET(url,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			if (res != null && res.trim().length() > 0) {
				JSONObject jsobj = new JSONObject(res);
				// System.out.println("jsobj solutiontypeList="+jsobj);
				if (jsobj.length() > 0) {
					String str = jsobj.getString("OtherInfo");
					if (str != null) {
						JSONObject otherinfo = new JSONObject(str);
						if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("Solution Type")) {
							solutiontypeList.add(otherinfo.getString("Solution Type"));
						}
						if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("Sanction Load")) {
							sanctionloadField.setValue(otherinfo.getString("Sanction Load"));
						}
					}
				}
			}
			solutiontypeField.setItems(solutiontypeList);
			// System.out.println("solutiontypeList="+solutiontypeList);
			if (solutiontypeList.size() > 0) {
				solutiontypeField.setValue(solutiontypeList.get(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void populateSolutionTypeLists2(String otherinfostr) {
		try {

			solutiontypeList = new ArrayList<String>();

			if (otherinfostr != null || otherinfostr.trim().length() > 0) {
				JSONObject otherinfo = new JSONObject(otherinfostr);
				if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("Solution Type")) {
					solutiontypeList.add(otherinfo.getString("Solution Type"));
				}
				if (otherinfo != null && otherinfo.length() > 0 && otherinfo.has("Sanction Load")) {
					sanctionloadField.setValue(otherinfo.getString("Sanction Load"));
				}
			}

			solutiontypeField.setItems(solutiontypeList);
			// System.out.println("solutiontypeList="+solutiontypeList);
			if (solutiontypeList.size() > 0) {
				solutiontypeField.setValue(solutiontypeList.get(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void populateInvoiceTypeRentalLists() {
		invoiceTypeList = new ArrayList<String>();
		invoicetypemap.clear();
		invoicetypemap2.clear();
		int count = 1;
		String str[] = { "Rent", "Maintenance", "Escalation", "Rent+ Space Charges + Conservancy Fee",
				"Space Charges & Conservancy Fee", "Space Charges", "Waiver", "Debit Note", "Credit Note",
				"Interest Charges", "NFA", "SD - License Fee", "Others", "Advance" };

		for (int i = 0; i < str.length; i++) {
			invoiceTypeList.add(str[i]);
			invoicetypemap.put(str[i], count);
			invoicetypemap2.put(count, str[i]);
			count++;
		}

		invoicetypeField.setItems(invoiceTypeList);
//		System.out.println("invoicetypemap="+invoicetypemap);
	}

	private void populateInvoiceTypeUsageLists() {
		invoiceTypeList = new ArrayList<String>();
		invoicetypemap.clear();
		invoicetypemap2.clear();
		int count = 15;

		String str[] = { "SD-EB", "EB-Advance", "EB", "FCU", "DG", "EB+FCU", "EB+DG", "EBFixedCharges" };

		for (int i = 0; i < str.length; i++) {
			invoiceTypeList.add(str[i]);
			invoicetypemap.put(str[i], count);
			invoicetypemap2.put(count, str[i]);
			count++;
		}

		invoicetypeField.setItems(invoiceTypeList);
//		System.out.println("invoicetypemap="+invoicetypemap);
	}

	private void populateBillingTypeLists() {
		billingTypeList = new ArrayList<String>();
		billtypemap.clear();
		billtypemap2.clear();

		if (isrentalTab == false && isUsageTab == true) {// usage tab
			billingTypeList = new ArrayList<String>();
			billtypemap.clear();
			billtypemap2.clear();
			int count = 1;
			String str[] = { "Agreement Based", "Invoice Based", "NFA Based", "Galaxy Based" };
			for (int i = 0; i < str.length; i++) {
				billingTypeList.add(str[i]);
				billtypemap.put(str[i], count);
				billtypemap2.put(count, str[i]);
				count++;
			}
		} else {// rental tab
			billingTypeList = new ArrayList<String>();
			billtypemap.clear();
			billtypemap2.clear();
			int count = 1;
			String str[] = { "Agreement Based", "Invoice Based", "NFA Based" };
			for (int i = 0; i < str.length; i++) {
				billingTypeList.add(str[i]);
				billtypemap.put(str[i], count);
				billtypemap2.put(count, str[i]);
				count++;
			}
		}

		// billingtypeField.setItems(billingTypeList);
		// System.out.println("billtypemap="+billtypemap);
	}

	protected void saveData(boolean isrentalTab, boolean isUsageTab) {
		try {
			// System.out.println("click2222");
			// boolean isvalid=validateFields2();
			boolean isvalid = validateFields();
			// System.out.println("isvalid=="+isvalid);

			if (!isvalid) {
				return;
			} else {
				String operators = "", operators2 = "";
				JSONObject invoiceJson = new JSONObject();

				Set<String> op = billforoperatorField.getValue();
				// System.out.println("op=="+op);
				if (op.size() > 0) {
					Iterator value = op.iterator();
					while (value.hasNext()) {
						operators += value.next() + ",";
					}
					operators2 = operators.substring(0, operators.length() - 1);
				}

				int invoicetype = invoicetypemap.get(invoicetypeField.getValue());
				int billtype = billtypemap.get(billingtypeField.getValue());

				invoiceJson.put("invoiceno", invoiceNoField.getValue());
				invoiceJson.put("sitecode", sitecodeField.getValue());
				invoiceJson.put("circle", circleField.getValue());
				invoiceJson.put("sitename", sitenameField.getValue());
				invoiceJson.put("landlordid", Integer.parseInt(landlordidField.getValue()));

//			if(sapvendorcodeField.getValue()!=null) {
//				invoiceJson.put("sapvendorcode","");
//			}else {
				invoiceJson.put("sapvendorcode", sapvendorcodeField.getValue());
//			}

				invoiceJson.put("landlordname", landlordnameField.getValue());
				if (rentshareField.getValue() != null) {
					invoiceJson.put("rentshare", Double.parseDouble(rentshareField.getValue()));
				} else {
					invoiceJson.put("rentshare", "");
				}

				if (solutiontypeField.getValue() == null) {
					invoiceJson.put("solutiontype", "");
				} else {
					invoiceJson.put("solutiontype", solutiontypeField.getValue());
				}

				invoiceJson.put("billingtype", billtype);
				invoiceJson.put("rentstatus", rentstatusField.getValue());
				invoiceJson.put("invoicetype", invoicetype);
				invoiceJson.put("invoicedate", CommonUtils.convertLocalDateToString(invoicedateField.getValue()));
				invoiceJson.put("dueon", due_dateAsPerAgreementField.getValue());
				invoiceJson.put("billingcycle", billingcycleField.getValue());
				invoiceJson.put("period_startdate",
						CommonUtils.convertLocalDateToString(period_startdateField.getValue()));
				invoiceJson.put("period_enddate", CommonUtils.convertLocalDateToString(period_enddateField.getValue()));
				invoiceJson.put("grossinvoiceamount", grossinvoiceamountField.getValue());
				invoiceJson.put("gst_rate", Double.parseDouble(gst_rateField.getValue()));
				invoiceJson.put("invoiceamount", invoiceamountField.getValue());
				invoiceJson.put("billforoperator", operators2);
				invoiceJson.put("invoicearrears", invoicearrearsField.getValue());
				invoiceJson.put("submissiondate", CommonUtils.convertLocalDateToString(submissiondateField.getValue()));
				invoiceJson.put("receiveddate", CommonUtils.convertLocalDateToString(receiveddateField.getValue()));
				invoiceJson.put("duedate", CommonUtils.convertLocalDateToString(duedateField.getValue()));
				invoiceJson.put("remarks", remarksField.getValue());
				
				System.out.println("agreementNameIdMap2=========22222"+agreementNameIdMap2);

				if (agreementNameField.getValue() != null) {
					invoiceJson.put("agreementName", agreementNameField.getValue());
					invoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
				} else {
					invoiceJson.put("agreementName", "");
					invoiceJson.put("agreementId", "");
				}

				saveBtn.setEnabled(false);
//				System.out.println("invoiceJson==" + invoiceJson);
				if (isrentalTab == true && isUsageTab == false) {// rental
					
					
					
					
					
				/*	if(rentalDraftForm==null && agreementNameField.getValue() != null) {
						invoiceJson.put("agreementName", agreementNameField.getValue());
						invoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
					} else if(rentalDraftForm==null && agreementNameField.getValue() == null) {
						invoiceJson.put("agreementName", "");
						invoiceJson.put("agreementId", "");
					
					}else if(rentalDraftForm!=null) {
						
						JSONObject InvoiceJson = new JSONObject(rentalDraftForm);
						JSONObject js = new JSONObject(InvoiceJson.getString("InvoiceJson"));
						
						if (js.getString("agreementName") != null || js.getString("agreementName").length() > 0) {
							invoiceJson.put("agreementName",js.getString("agreementName"));
						}
						if (js.getString("agreementId") != null || js.getString("agreementId").length() > 0) {
							invoiceJson.put("agreementId",js.getString("agreementId"));
						}
							
					}else {
						
					}*/

					System.out.println("invoiceJson==" + invoiceJson);
					JSONObject fileDetailsJson = new JSONObject();
					if (fileName.length() > 0 && fileType.length() > 0 && docDesc.length() > 0
							&& base64EncodedFileContent.length() > 0) {
						fileDetailsJson.put("Name", fileName.trim());
						fileDetailsJson.put("Type", fileType.trim());
						fileDetailsJson.put("Description", docDesc.trim());
						fileDetailsJson.put("Content", base64EncodedFileContent);
						// System.out.println("fileDetailsJson3=="+fileDetailsJson);
					} else {
						fileDetailsJson = new JSONObject();
					}

					if (fileDetailsJson.length() <= 0) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a document",
								ApplicationConstants.DialogTypes.ERROR);
						return;
					} else {
						// System.out.println("fileDetailsJson2=="+fileDetailsJson);

						callcreateRentalInvoiceApi(invoiceJson, fileDetailsJson);
					}

				} else if (isrentalTab == false && isUsageTab == true) {// usage
					saveBtn.setEnabled(false);
					int metertype = meterTypeMap.get(metertypeField.getValue());
					int lpsc_pay = 0;
					Double manualconsumption = 0.0, unitrate = 0.0;
					String meterserialNo, consumerNo;
					Double noofdays, openingreading, closingreading, calconsumption, perdayconsumption, ebAmt,
							fixloadcharge, dgcharge, fcucharge, lpsccharge, othercharge, finalpay;
					
					
					
				/*	if(usageDraftForm==null && agreementNameField.getValue() != null) {
						invoiceJson.put("agreementName", agreementNameField.getValue());
						invoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
					} else if(rentalDraftForm==null && agreementNameField.getValue() == null) {
						invoiceJson.put("agreementName", "");
						invoiceJson.put("agreementId", "");
					
					}else if(usageDraftForm!=null) {
						
						JSONObject InvoiceJson = new JSONObject(usageDraftForm);
						JSONObject js = new JSONObject(InvoiceJson.getString("InvoiceJson"));
						
						if (js.getString("agreementName") != null || js.getString("agreementName").length() > 0) {
							invoiceJson.put("agreementName",js.getString("agreementName"));
						}
						if (js.getString("agreementId") != null || js.getString("agreementId").length() > 0) {
							invoiceJson.put("agreementId",js.getString("agreementId"));
						}
							
					}else {
						
					}*/

					if (meterserialNoField.getValue() == null) {
						meterserialNo = "0";
					} else {
						meterserialNo = meterserialNoField.getValue();
					}
					if (consumerNoField.getValue() == null) {
						consumerNo = "0";
					} else {
						consumerNo = consumerNoField.getValue();
					}
					if (noofdaysField.getValue() == null) {
						noofdays = 0.0;
					} else {
						noofdays = noofdaysField.getValue();
					}
					if (opening_readingField.getValue() == null) {
						openingreading = 0.0;
					} else {
						openingreading = opening_readingField.getValue();
					}
					if (closing_readingField.getValue() == null) {
						closingreading = 0.0;
					} else {
						closingreading = closing_readingField.getValue();
					}

					if (lpsc_payableField.getValue() != null && lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
						lpsc_pay = 1;
					} else {
						lpsc_pay = 0;
					}
					if (manual_consumptionField.getValue() == null) {
						manualconsumption = 0.0;
					} else {
						manualconsumption = manual_consumptionField.getValue();
					}
					if (calculated_consumptionField.getValue() == null) {
						calconsumption = 0.0;
					} else {
						calconsumption = calculated_consumptionField.getValue();
					}
					if (per_day_consumptionField.getValue() == null) {
						perdayconsumption = 0.0;
					} else {
						perdayconsumption = per_day_consumptionField.getValue();
					}
					if (unit_rateField.getValue() == null) {
						unitrate = 0.0;
					} else {
						unitrate = unit_rateField.getValue();
					}
					if (eb_amountField.getValue() == null) {
						ebAmt = 0.0;
					} else {
						ebAmt = eb_amountField.getValue();
					}
					if (fix_load_chargeField.getValue() == null) {
						fixloadcharge = 0.0;
					} else {
						fixloadcharge = fix_load_chargeField.getValue();
					}
					if (dg_chargeField.getValue() == null) {
						dgcharge = 0.0;
					} else {
						dgcharge = dg_chargeField.getValue();
					}
					if (fcu_chargeField.getValue() == null) {
						fcucharge = 0.0;
					} else {
						fcucharge = fcu_chargeField.getValue();
					}
					if (late_payment_service_chargeField.getValue() == null) {
						lpsccharge = 0.0;
					} else {
						lpsccharge = late_payment_service_chargeField.getValue();
					}
					if (otherchargesField.getValue() == null) {
						othercharge = 0.0;
					} else {
						othercharge = otherchargesField.getValue();
					}
					if (final_payable_amountField.getValue() == null) {
						finalpay = 0.0;
					} else {
						finalpay = final_payable_amountField.getValue();
					}

					/*
					 * JSONObject usage_detailsJson = new JSONObject();
					 * usage_detailsJson.put("meterserialno",meterserialNoField.getValue());
					 * usage_detailsJson.put("consumerno",consumerNoField.getValue());
					 * //usage_detailsJson.put("metertype",metertypeField.getValue());
					 * usage_detailsJson.put("metertype",metertype);
					 * usage_detailsJson.put("sanctionload",sanctionloadField.getValue());
					 * usage_detailsJson.put("noofdays",noofdaysField.getValue());
					 * usage_detailsJson.put("opening_reading",opening_readingField.getValue());
					 * usage_detailsJson.put("closing_reading",closing_readingField.getValue());
					 * usage_detailsJson.put("calculated_consumption",calculated_consumptionField.
					 * getValue()); //
					 * usage_detailsJson.put("manual_consumption",manual_consumptionField.getValue()
					 * ); usage_detailsJson.put("manual_consumption",manualconsumption);
					 * usage_detailsJson.put("per_day_consumption",per_day_consumptionField.getValue
					 * ()); usage_detailsJson.put("eb_amount",eb_amountField.getValue()); //
					 * usage_detailsJson.put("unit_rate",unit_rateField.getValue());
					 * usage_detailsJson.put("unit_rate",unitrate);
					 * usage_detailsJson.put("fix_load_charge",fix_load_chargeField.getValue());
					 * usage_detailsJson.put("dg_charge",dg_chargeField.getValue());
					 * usage_detailsJson.put("fcu_charge",fcu_chargeField.getValue());
					 * usage_detailsJson.put("late_payment_service_charge",
					 * late_payment_service_chargeField.getValue());
					 * usage_detailsJson.put("othercharges",otherchargesField.getValue()); //
					 * usage_detailsJson.put("lpsc_payable",lpsc_payableField.getValue());
					 * usage_detailsJson.put("lpsc_payable",lpsc_pay);
					 * usage_detailsJson.put("final_payable_amount",final_payable_amountField.
					 * getValue());
					 * 
					 */

					JSONObject usage_detailsJson = new JSONObject();
					usage_detailsJson.put("meterserialno", meterserialNo);
					usage_detailsJson.put("consumerno", consumerNo);
					usage_detailsJson.put("metertype", metertype);
					usage_detailsJson.put("sanctionload", sanctionloadField.getValue());
					usage_detailsJson.put("noofdays", noofdays);
					usage_detailsJson.put("opening_reading", openingreading);
					usage_detailsJson.put("closing_reading", closingreading);
					usage_detailsJson.put("calculated_consumption", calconsumption);
					usage_detailsJson.put("manual_consumption", manualconsumption);
					usage_detailsJson.put("per_day_consumption", perdayconsumption);
					usage_detailsJson.put("eb_amount", ebAmt);
					usage_detailsJson.put("unit_rate", unitrate);
					usage_detailsJson.put("fix_load_charge", fixloadcharge);
					usage_detailsJson.put("dg_charge", dgcharge);
					usage_detailsJson.put("fcu_charge", fcucharge);
					usage_detailsJson.put("late_payment_service_charge", lpsccharge);
					usage_detailsJson.put("othercharges", othercharge);
					usage_detailsJson.put("lpsc_payable", lpsc_pay);
					usage_detailsJson.put("final_payable_amount", finalpay);

					invoiceJson.put("usage_details", usage_detailsJson);

					System.out.println("invoiceJson==" + invoiceJson);

					JSONObject fileDetailsJson = new JSONObject();
					if (fileName.length() > 0 && fileType.length() > 0 && docDesc.length() > 0
							&& base64EncodedFileContent.length() > 0) {
						fileDetailsJson.put("Name", fileName.trim());
						fileDetailsJson.put("Type", fileType.trim());
						fileDetailsJson.put("Description", docDesc.trim());
						fileDetailsJson.put("Content", base64EncodedFileContent);
						// System.out.println("fileDetailsJson3=="+fileDetailsJson);
					} else {
						fileDetailsJson = new JSONObject();
					}
					if (fileDetailsJson.length() <= 0) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a document",
								ApplicationConstants.DialogTypes.ERROR);
						return;
					} else {
						callcreateUsageInvoiceApi(invoiceJson, fileDetailsJson);
					}
				} else {

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		} finally {
			saveBtn.setEnabled(true);
		}
	}

	private void callcreateRentalInvoiceApi(JSONObject invoiceJson, JSONObject fileDetailsJson) {
		try {
			System.out.println("invoiceJsonRental=" + invoiceJson);
			Form formData = new Form();
			formData.add("InvoiceJson", invoiceJson);

			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("CREATE_RENTAL_INVOICE");
			String resp = RestServiceHandler.createJSON_POST(serviceEndPoint, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			// System.out.println("resp="+resp);
			uploadDocument(fileDetailsJson.toString(), Integer.parseInt(resp));

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		}
	}

	private void callcreateUsageInvoiceApi(JSONObject usage_detailsJson, JSONObject fileDetailsJson) {
		try {
			System.out.println("usage_detailsJson=" + usage_detailsJson);
			Form formData = new Form();
			formData.add("usageInvoiceDetails", usage_detailsJson);

			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("CREATE_USAGE_INVOICE");
			String resp = RestServiceHandler.createJSON_POST(serviceEndPoint, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			uploadDocument(fileDetailsJson.toString(), Integer.parseInt(resp));
//			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"ADD_USAGE_INVOICE",ApplicationConstants.DialogTypes.INFO);	
//			success=true;
//			close();

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		}
	}

	private boolean validateFields() {
		boolean valid = true;
		try {
//			System.out.println("period_startdateField.isEmpty()=="+period_startdateField.isEmpty());
//			System.out.println("period_startdateField.isInvalid()=="+period_startdateField.isInvalid());
//			System.out.println("period_startdateField.isNull()=="+period_startdateField.getValue());

			if (sitecodeField.getValue() == null || sitecodeField.getValue().length() <= 0) {
				System.out.println("sitecodeField");
				sitecodeField.setInvalid(true);
				sitecodeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (sitenameField.getValue() == null || sitenameField.getValue().length() <= 0) {
				System.out.println("sitenameField");
				sitenameField.setInvalid(true);
				sitenameField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (circleField.getValue() == null || circleField.getValue().length() <= 0) {
				System.out.println("circleField");
				circleField.setInvalid(true);
				circleField.setErrorMessage("Please Fill up this field");
				valid = false;
			} /*
				 * else if(agreementNameField.getValue()==null ||
				 * agreementNameField.getValue().length()<=0) {
				 * agreementNameField.setInvalid(true);
				 * agreementNameField.setErrorMessage("Please Fill up this field"); valid=false;
				 * }else if(billingcycleField.getValue()==null ||
				 * billingcycleField.getValue().length()<=0) {
				 * billingcycleField.setInvalid(true);
				 * billingcycleField.setErrorMessage("Please Fill up this field"); valid=false;
				 * }else if(rentstatusField.getValue()==null ||
				 * rentstatusField.getValue().length()<=0) { rentstatusField.setInvalid(true);
				 * rentstatusField.setErrorMessage("Please Fill up this field"); valid=false; }
				 */else if (landlordidField.getValue() == null || landlordidField.getValue().length() <= 0) {
				System.out.println("landlordidField");
				landlordidField.setInvalid(true);
				landlordidField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (landlordnameField.getValue() == null || landlordnameField.getValue().length() <= 0) {
				System.out.println("landlordnameField");
				landlordnameField.setInvalid(true);
				landlordnameField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (sapvendorcodeField.getValue() == null || sapvendorcodeField.getValue().length() <= 0) {
				System.out.println("sapvendorcodeField");
				sapvendorcodeField.setInvalid(true);
				sapvendorcodeField.setErrorMessage("Please Fill up this field");
				valid = false;
			}
			/*
			 * else if(rentshareField.getValue()==null ||
			 * rentshareField.getValue().length()<=0) { rentshareField.setInvalid(true);
			 * rentshareField.setErrorMessage("Please Fill up this field"); valid=false;
			 * }else if(billforoperatorField.getValue()==null ) {
			 * billforoperatorField.setInvalid(true);
			 * billforoperatorField.setErrorMessage("Please Fill up this field");
			 * valid=false; } else if(sapvendorcodeField.getValue()==null ||
			 * sapvendorcodeField.getValue().length()<=0) {
			 * sapvendorcodeField.setInvalid(true);
			 * sapvendorcodeField.setErrorMessage("Please Fill up this field"); valid=false;
			 * } else if(solutiontypeField.getValue()==null ||
			 * solutiontypeField.getValue().length()<=0) {
			 * solutiontypeField.setInvalid(true);
			 * solutiontypeField.setErrorMessage("Please Fill up this field"); valid=false;
			 * }
			 */else if (invoicetypeField.getValue() == null || invoicetypeField.getValue().length() <= 0) {
				System.out.println("invoicetypeField");
				invoicetypeField.setInvalid(true);
				invoicetypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (billingtypeField.getValue() == null || billingtypeField.getValue().length() <= 0) {
				System.out.println("billingtypeField");
				billingtypeField.setInvalid(true);
				billingtypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (period_startdateField.getValue() == null) {
				// System.out.println("period_startdateField");
				period_startdateField.setInvalid(true);
				period_startdateField.setErrorMessage("Please provide a valid date");
				valid = false;
			} else if (period_enddateField.getValue() == null) {
				// System.out.println("period_startdateField");
				period_enddateField.setInvalid(true);
				period_enddateField.setErrorMessage("Please provide a valid date");
				valid = false;
			} else if (period_startdateField.getValue() != null && period_enddateField.getValue() != null
					&& (period_startdateField.getValue().compareTo(period_enddateField.getValue()) > 0)) {
				System.out.println("period_startdateField11");
				period_startdateField.setInvalid(true);
				period_startdateField.setErrorMessage("Invoice start date cannot be greater than end date");
				valid = false;
			} else if (period_startdateField.getValue() != null && period_enddateField.getValue() != null
					&& (period_enddateField.getValue().compareTo(period_startdateField.getValue()) == 0)) {
				System.out.println("period_enddateField11");
				period_enddateField.setInvalid(true);
				period_enddateField.setErrorMessage("Invoice end date must be greater than start date");
				valid = false;
			} else if (grossinvoiceamountField.getValue() == null) {
				System.out.println("grossinvoiceamountField");
				grossinvoiceamountField.setInvalid(true);
				grossinvoiceamountField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (gst_rateField.getValue().length() <= 0) {
				System.out.println("gst_rateField");
				gst_rateField.setInvalid(true);
				gst_rateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (invoiceamountField.getValue() == null) {
				System.out.println("invoiceamountField");
				invoiceamountField.setInvalid(true);
				invoiceamountField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (invoicedateField.getValue() == null) {
				System.out.println("invoicedateField");
				invoicedateField.setInvalid(true);
				invoicedateField.setErrorMessage("Please provide a valid date");
				valid = false;
			} /*
				 * else if(invoicearrearsField.getValue()==null) {
				 * invoicearrearsField.setInvalid(true);
				 * invoicearrearsField.setErrorMessage("Please Fill up this field");
				 * valid=false; }
				 */else if (submissiondateField.getValue() == null) {
				System.out.println("submissiondateField");
				submissiondateField.setInvalid(true);
				submissiondateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if (receiveddateField.getValue() == null) {
				System.out.println("receiveddateField");
				receiveddateField.setInvalid(true);
				receiveddateField.setErrorMessage("Please provide a valid date");
				valid = false;
			} else if (duedateField.getValue() == null) {
				System.out.println("duedateField");
				duedateField.setInvalid(true);
				duedateField.setErrorMessage("Please provide a valid date");
				valid = false;
			} else if (invoiceNoField.getValue() == null || invoiceNoField.getValue().length() <= 0) {
				System.out.println("invoiceNoField");
				invoiceNoField.setInvalid(true);
				invoiceNoField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if ((isrentalTab == false && isUsageTab == true)
					&& (meterserialNoField.getValue() == null || meterserialNoField.getValue().length() <= 0)) {
				System.out.println("meterserialNoField");
				meterserialNoField.setInvalid(true);
				meterserialNoField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if ((isrentalTab == false && isUsageTab == true)
					&& (metertypeField.getValue() == null || metertypeField.getValue().length() <= 0)) {
				System.out.println("metertypeField");
				metertypeField.setInvalid(true);
				metertypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else if ((isrentalTab == false && isUsageTab == true && mode.equals("create"))
					&& (manual_consumptionField.getValue() != null && manual_consumptionField.getValue() <= 0)) {
				manual_consumptionField.setInvalid(true);
				manual_consumptionField.setErrorMessage("Value must be greater than 0");
				calculated_consumptionField.setInvalid(false);
				calculated_consumptionField.setErrorMessage("");
				valid = false;
			}
			/*
			 * else if((isrentalTab==false && isUsageTab==true) &&
			 * (calculated_consumptionField.getValue()!=null &&
			 * calculated_consumptionField.getValue()<=0)) {
			 * calculated_consumptionField.setInvalid(true);
			 * calculated_consumptionField.setErrorMessage("Value must be greater than 0");
			 * valid=false; }
			 */
			else if ((isrentalTab == false && isUsageTab == true)
					&& (calculated_consumptionField.getValue() != null && calculated_consumptionField.getValue() <= 0)
					&& (manual_consumptionField.getValue() == null)) {

				calculated_consumptionField.setInvalid(true);
			//	calculated_consumptionField.setErrorMessage("Value must be greater than 0");
				calculated_consumptionField.setErrorMessage("Closing reading must be greater than opening reading");
				valid = false;
			}else if ((isrentalTab == false && isUsageTab == true)
					&& (calculated_consumptionField.getValue() != null && calculated_consumptionField.getValue() <= 0)
					&& (manual_consumptionField.getValue() != null)) {

				calculated_consumptionField.setInvalid(false);
				calculated_consumptionField.setErrorMessage("");
				valid = false;
			} else {
			}
			/*
			 * else if(due_dateAsPerAgreementField.getValue()==null) {
			 * due_dateAsPerAgreementField.setInvalid(true);
			 * due_dateAsPerAgreementField.setErrorMessage("Please Fill up this field");
			 * valid=false; }
			 */
			// return valid;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return valid;

	}

	private boolean validateFields2() {
		boolean valid = true;
		try {
			System.out.println("period_startdateField.isEmpty()==" + period_startdateField.isEmpty());
			System.out.println("period_startdateField.isInvalid()==" + period_startdateField.isInvalid());

			if (sitecodeField.getValue() == null || sitecodeField.getValue().length() <= 0) {
				System.out.println("sitecodeField");
				sitecodeField.setInvalid(true);
				sitecodeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				sitecodeField.setInvalid(false);
				sitecodeField.setErrorMessage("");
				valid = true;
			}
			if (sitenameField.getValue() == null || sitenameField.getValue().length() <= 0) {
				System.out.println("sitenameField");
				sitenameField.setInvalid(true);
				sitenameField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				sitenameField.setInvalid(false);
				sitenameField.setErrorMessage("");
				valid = true;
			}
			if (circleField.getValue() == null || circleField.getValue().length() <= 0) {
				System.out.println("circleField");
				circleField.setInvalid(true);
				circleField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				circleField.setInvalid(false);
				circleField.setErrorMessage("");
				valid = true;
			}

			if (landlordidField.getValue() == null || landlordidField.getValue().length() <= 0) {
				System.out.println("landlordidField");
				landlordidField.setInvalid(true);
				landlordidField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				landlordidField.setInvalid(false);
				landlordidField.setErrorMessage("");
				valid = true;
			}
			if (landlordnameField.getValue() == null || landlordnameField.getValue().length() <= 0) {
				System.out.println("landlordnameField");
				landlordnameField.setInvalid(true);
				landlordnameField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				landlordnameField.setInvalid(false);
				landlordnameField.setErrorMessage("");
				valid = true;
			}
			if (sapvendorcodeField.getValue() == null || sapvendorcodeField.getValue().length() <= 0) {
				System.out.println("sapvendorcodeField");
				sapvendorcodeField.setInvalid(true);
				sapvendorcodeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				sapvendorcodeField.setInvalid(false);
				sapvendorcodeField.setErrorMessage("");
				valid = true;
			}
			if (invoicetypeField.getValue() == null || invoicetypeField.getValue().length() <= 0) {
				System.out.println("invoicetypeField");
				invoicetypeField.setInvalid(true);
				invoicetypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				invoicetypeField.setInvalid(false);
				invoicetypeField.setErrorMessage("");
				valid = true;
			}
			if (billingtypeField.getValue() == null || billingtypeField.getValue().length() <= 0) {
				System.out.println("billingtypeField");
				billingtypeField.setInvalid(true);
				billingtypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				billingtypeField.setInvalid(false);
				billingtypeField.setErrorMessage("");
				valid = true;
			}
			if (period_startdateField.getValue() == null) {

//				if(period_startdateField.isEmpty()){
//					System.out.println("empty");
//				}else {
//					System.out.println("notempty");
//				}
//				
				if (period_startdateField.isInvalid()) {
					System.out.println("invalid");
					period_startdateField.setInvalid(true);
					period_startdateField.setErrorMessage("Please select a valid date");
				} else {
					System.out.println("valid");
					period_startdateField.setInvalid(true);
					period_startdateField.setErrorMessage("Please Fill up this field");
				}

				System.out.println("period_startdateField");
				// period_startdateField.clear();
				// period_startdateField.getValue().
//				period_startdateField.setInvalid(true);
//				period_startdateField.setErrorMessage("Please Fill up this field");

				// System.out.println("period_startdateField.isInvalid()=="+);
				valid = false;
			} else {
				System.out.println("period_startdateField===" + period_startdateField.getValue());
				// period_startdateField.setValue(null);
				period_startdateField.setInvalid(false);
				period_startdateField.setErrorMessage("");
				valid = true;
			}
			if (period_enddateField.getValue() == null) {
				System.out.println("period_enddateField");
				period_enddateField.setInvalid(true);
				period_enddateField.setErrorMessage("Please Fill up this field");
				// period_enddateField.clear();
				valid = false;
			} else {
				period_enddateField.setInvalid(false);
				period_enddateField.setErrorMessage("");
				valid = true;
			}
			if (period_startdateField.getValue().compareTo(period_enddateField.getValue()) > 0) {
				System.out.println("period_startdateField11");
				period_startdateField.setInvalid(true);
				period_startdateField.setErrorMessage("Invoice start date cannot be greater than end date");
				valid = false;
			} else {
				period_startdateField.setInvalid(false);
				period_startdateField.setErrorMessage("");
				valid = true;
			}
			if (period_enddateField.getValue().compareTo(period_startdateField.getValue()) == 0) {
				System.out.println("period_enddateField11");
				period_enddateField.setInvalid(true);
				period_enddateField.setErrorMessage("Invoice end date must be greater than start date");
				valid = false;
			} else {
				period_enddateField.setInvalid(false);
				period_enddateField.setErrorMessage("");
				valid = true;
			}
			if (grossinvoiceamountField.getValue() == null) {
				System.out.println("grossinvoiceamountField");
				grossinvoiceamountField.setInvalid(true);
				grossinvoiceamountField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				grossinvoiceamountField.setInvalid(false);
				grossinvoiceamountField.setErrorMessage("");
				valid = true;
			}

			if (gst_rateField.getValue() == null) {
				System.out.println("gst_rateField");
				gst_rateField.setInvalid(true);
				gst_rateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				gst_rateField.setInvalid(false);
				gst_rateField.setErrorMessage("");
				valid = true;
			}
			if (invoiceamountField.getValue() == null) {
				System.out.println("invoiceamountField");
				invoiceamountField.setInvalid(true);
				invoiceamountField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				invoiceamountField.setInvalid(false);
				invoiceamountField.setErrorMessage("");
				valid = true;
			}
			if (invoicedateField.getValue() == null) {
				System.out.println("invoicedateField");
				invoicedateField.setInvalid(true);
				invoicedateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				invoicedateField.setInvalid(false);
				invoicedateField.setErrorMessage("");
				valid = true;
			}
			if (submissiondateField.getValue() == null) {
				System.out.println("submissiondateField");
				submissiondateField.setInvalid(true);
				submissiondateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				submissiondateField.setInvalid(false);
				submissiondateField.setErrorMessage("");
				valid = true;
			}
			if (receiveddateField.getValue() == null) {
				System.out.println("receiveddateField");
				receiveddateField.setInvalid(true);
				receiveddateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				receiveddateField.setInvalid(false);
				receiveddateField.setErrorMessage("");
				valid = true;
			}
			if (duedateField.getValue() == null) {
				System.out.println("duedateField");
				duedateField.setInvalid(true);
				duedateField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				duedateField.setInvalid(false);
				duedateField.setErrorMessage("");
				valid = true;
			}
			if (invoiceNoField.getValue() == null || invoiceNoField.getValue().length() <= 0) {
				System.out.println("invoiceNoField");
				invoiceNoField.setInvalid(true);
				invoiceNoField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				invoiceNoField.setInvalid(false);
				invoiceNoField.setErrorMessage("");
				valid = true;
			}
			if ((isrentalTab == false && isUsageTab == true)
					&& (meterserialNoField.getValue() == null || meterserialNoField.getValue().length() <= 0)) {
				System.out.println("meterserialNoField");
				meterserialNoField.setInvalid(true);
				meterserialNoField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				meterserialNoField.setInvalid(false);
				meterserialNoField.setErrorMessage("");
				valid = true;
			}
			if ((isrentalTab == false && isUsageTab == true)
					&& (metertypeField.getValue() == null || metertypeField.getValue().length() <= 0)) {
				System.out.println("metertypeField");
				metertypeField.setInvalid(true);
				metertypeField.setErrorMessage("Please Fill up this field");
				valid = false;
			} else {
				metertypeField.setInvalid(false);
				metertypeField.setErrorMessage("");
				valid = true;
			}
			if ((isrentalTab == false && isUsageTab == true)
					&& (manual_consumptionField.getValue() != null && manual_consumptionField.getValue() <= 0)) {
				manual_consumptionField.setInvalid(true);
				manual_consumptionField.setErrorMessage("Value must be greater than 0");
				calculated_consumptionField.setInvalid(false);
				calculated_consumptionField.setErrorMessage("");
				valid = false;
			} else if ((isrentalTab == false && isUsageTab == true)
					&& (calculated_consumptionField.getValue() != null && calculated_consumptionField.getValue() <= 0)
					&& (manual_consumptionField.getValue() == null)) {

				calculated_consumptionField.setInvalid(true);
				calculated_consumptionField.setErrorMessage("Value must be greater than 0");
				valid = false;
			} else {
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return valid;

	}

	private void uploadDocument(String fileDetailsJson, int invoiceid) {
		try {
			// System.out.println("fileDetailsJson=="+fileDetailsJson);

			if (fileDetailsJson != null) {
				Form formData = new Form();
				formData.add("InvoiceId", invoiceid);
				// formData.add("FileDetails",URLEncoder.encode(fileDetailsJson.toString()));
				formData.add("FileDetails", (fileDetailsJson));

				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPLOAD_INVOICE_DOCUMENT");
				RestServiceHandler.createJSON_POST(serviceEndPoint, formData,
						SiteAssetInventoryUIFramework.getFramework().getToken());

				if (isrentalTab == true && isUsageTab == false && mode.equalsIgnoreCase("create")) {// rental
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "ADD_RENTAL_INVOICE",
							ApplicationConstants.DialogTypes.INFO);
					CommonUtils.resetDraftData("3", "none");
				} else if (isrentalTab == false && isUsageTab == true && mode.equalsIgnoreCase("create")) {// uasge
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "ADD_USAGE_INVOICE",
							ApplicationConstants.DialogTypes.INFO);
					CommonUtils.resetDraftData("4", "none");
				}
				if (isrentalTab == true && isUsageTab == false && mode.equalsIgnoreCase("edit")) {// rental
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "UPDATE_RENTAL_INVOICE",
							ApplicationConstants.DialogTypes.INFO);
				} else if (isrentalTab == false && isUsageTab == true && mode.equalsIgnoreCase("edit")) {// uasge
					SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "UPDATE_USAGE_INVOICE",
							ApplicationConstants.DialogTypes.INFO);
				} else {
				}

				success = true;
				close();
			}

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		}

	}

	@SuppressWarnings("null")
	public void setDataFieldsValue(String invoiceid, String siteCode, String Sitename, String Circle,
			String Landlordname, String Billingcycle, String rentStatus, String dueDate, String invoiceno,
			String Billingtype, String RentShare, String invoiceType, String invoicedate, String Period_StartDate,
			String Period_EndDate, String grossInvoiceAmount, String SubmissionDate, String solutiontype,
			String SapVendorCode, String Status, String DueOn, String Gst_Rate, String ReceivedDate,
			String InvoiceArrears, String BillForOperator, String Remarks1, String InvoiceAmount,
			JSONObject usage_detailsjs, String agreementName, String agreementId) {

		Set<String> hash_Set = null;
		// System.out.println("BillForOperator.trim().length()=="+BillForOperator.trim().length());
		if (BillForOperator != null || BillForOperator.trim().length() > 0) {
			String[] arrOfStr = BillForOperator.split(",");
			hash_Set = new HashSet<String>();
			for (String a : arrOfStr) {
				hash_Set.add(a);
			}

		}

		// System.out.println("hash_Set isEmpty()=="+hash_Set.isEmpty());

		// System.out.println("hash_Set size=="+hash_Set.size());

		this.invoiceid = invoiceid;
		sitecodeField.setValue(siteCode);
		sitenameField.setValue(Sitename);
		circleField.setValue(Circle);
		landlordnameField.setValue(Landlordname);
		billingcycleField.setValue(Billingcycle);
		rentstatusField.setValue(rentStatus);
		due_dateAsPerAgreementField.setValue(DueOn);
		rentshareField.setValue(RentShare);
		if (BillForOperator.trim().length() > 0) {
			billforoperatorField.setValue(hash_Set);
		}
		sapvendorcodeField.setValue(SapVendorCode);
		solutiontypeField.setValue(solutiontype);
		invoicetypeField.setValue(invoicetypemap2.get(Integer.parseInt(invoiceType)));
		billingtypeField.setValue(billtypemap2.get(Integer.parseInt(Billingtype)));
		period_startdateField.setValue(CommonUtils.convertStringToLocalDate(
				CommonUtils.convertDateToDifferentFormat(Period_StartDate, "dd-MMM-yyyy", "dd/MM/yyyy"), "dd/MM/yyyy"));
		period_enddateField.setValue(CommonUtils.convertStringToLocalDate(
				CommonUtils.convertDateToDifferentFormat(Period_EndDate, "dd-MMM-yyyy", "dd/MM/yyyy"), "dd/MM/yyyy"));
		grossinvoiceamountField.setValue(Double.parseDouble(grossInvoiceAmount));
		// gst_rateField.setValue(Double.parseDouble(Gst_Rate));
		gst_rateField.setValue((Gst_Rate));
		invoiceamountField.setValue(Double.parseDouble(InvoiceAmount));
		invoicedateField.setValue(CommonUtils.convertStringToLocalDate(
				CommonUtils.convertDateToDifferentFormat(invoicedate, "dd-MMM-yyyy", "dd/MM/yyyy"), "dd/MM/yyyy"));
		invoicearrearsField.setValue(Double.parseDouble(InvoiceArrears));
		submissiondateField.setValue(CommonUtils.convertStringToLocalDate(
				CommonUtils.convertDateToDifferentFormat(SubmissionDate, "dd-MMM-yyyy", "dd/MM/yyyy"), "dd/MM/yyyy"));
		receiveddateField.setValue(CommonUtils.convertStringToLocalDate(ReceivedDate, "dd/MM/yyyy"));

		duedateField.setValue(CommonUtils.convertStringToLocalDate(
				CommonUtils.convertDateToDifferentFormat(dueDate, "dd-MMM-yyyy", "dd/MM/yyyy"), "dd/MM/yyyy"));
		remarksField.setValue(Remarks1);
		invoiceNoField.setValue(invoiceno);
		invoiceNoField.setEnabled(true);

		if (agreementName.trim().length() > 0) {
			agreementNameField.setValue(agreementName);
		}

		// row2.add(,agreementNameField);

		// row5.add(rentshareField,billforoperatorField);

//		row9.add(grossinvoiceamountField,gst_rateField);
//		row10.add(invoiceamountField,invoicedateField);
//		row11.add(invoicearrearsField,submissiondateField);
//		row12.add(receiveddateField,duedateField);
//		row13.add(invoiceNoField,remarksField);

//		usagerow10.add(totalField);

		if (isrentalTab == false && isUsageTab == true) {
			if (usage_detailsjs != null || usage_detailsjs.length() > 0) {
				try {
					System.out.println("usage_detailsjs==" + usage_detailsjs);
					consumerNoField.setValue(usage_detailsjs.getString("ConsumerNo"));
					metertypeField
							.setValue(meterTypeMap2.get(Integer.parseInt(usage_detailsjs.getString("MeterType"))));
					sanctionloadField.setValue(usage_detailsjs.getString("SanctionLoad"));
					noofdaysField.setValue(Double.parseDouble(usage_detailsjs.getString("NoOfDays")));
					closing_readingField.setValue(Double.parseDouble(usage_detailsjs.getString("ClosingReading")));
					opening_readingField.setValue(Double.parseDouble(usage_detailsjs.getString("OpeningReading")));
					calculated_consumptionField
							.setValue(Double.parseDouble(usage_detailsjs.getString("CalculatedConsumption")));
					manual_consumptionField
							.setValue(Double.parseDouble(usage_detailsjs.getString("ManualConsumption")));
					per_day_consumptionField
							.setValue(Double.parseDouble(usage_detailsjs.getString("PerDayConsumption")));
					eb_amountField.setValue(Double.parseDouble(usage_detailsjs.getString("EBAmount")));
					unit_rateField.setValue(Double.parseDouble(usage_detailsjs.getString("UnitRate")));
					fix_load_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("FixLoadCharge")));
					dg_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("DGCharge")));
					fcu_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("FCUCharge")));
					late_payment_service_chargeField
							.setValue(Double.parseDouble(usage_detailsjs.getString("LatePaymentServiceCharge")));
					otherchargesField.setValue(Double.parseDouble(usage_detailsjs.getString("OtherCharges")));
					// lpsc_payableField.setValue((usage_detailsjs.getString("LpscPayable")));
					final_payable_amountField
							.setValue(Double.parseDouble(usage_detailsjs.getString("FinalPayableAmount")));
					meterserialNoField.setValue(usage_detailsjs.getString("MeterSerialNo"));

					// System.out.println("opening_readingField=="+opening_readingField.getValue());
					if (usage_detailsjs.getString("LpscPayable").equals("1")) {
						lpsc_payableField.setValue("Yes");
					} else {
						lpsc_payableField.setValue("No");
					}

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

	}

	/*-----------------------------EDIT---------------------------------------*/
	protected void updateData(boolean isrentalTab2, boolean isUsageTab2) {
		try {
			boolean isvalid = validateFields();
			if (!isvalid) {
				return;
			} else {
				String operators = "", operators2 = "";
				JSONObject invoiceJson = new JSONObject();

				Set<String> op = billforoperatorField.getValue();
				// System.out.println("op=="+op);
				if (op.size() > 0) {
					Iterator value = op.iterator();
					while (value.hasNext()) {
						operators += value.next() + ",";
					}
					operators2 = operators.substring(0, operators.length() - 1);
				}

				int invoicetype = invoicetypemap.get(invoicetypeField.getValue());
				int billtype = billtypemap.get(billingtypeField.getValue());

				invoiceJson.put("invoiceno", invoiceNoField.getValue());
				invoiceJson.put("sitecode", sitecodeField.getValue());
				invoiceJson.put("circle", circleField.getValue());
				invoiceJson.put("sitename", sitenameField.getValue());
				invoiceJson.put("landlordid", Integer.parseInt(landlordidField.getValue()));

				invoiceJson.put("sapvendorcode", sapvendorcodeField.getValue());

				invoiceJson.put("landlordname", landlordnameField.getValue());
				if (rentshareField.getValue() != null) {
					invoiceJson.put("rentshare", Double.parseDouble(rentshareField.getValue()));
				} else {
					invoiceJson.put("rentshare", "");
				}

				// invoiceJson.put("solutiontype",solutiontypeField.getValue());
				if (solutiontypeField.getValue() == null) {
					invoiceJson.put("solutiontype", "");
				} else {
					invoiceJson.put("solutiontype", solutiontypeField.getValue());
				}
				invoiceJson.put("billingtype", billtype);
				invoiceJson.put("rentstatus", rentstatusField.getValue());
				invoiceJson.put("invoicetype", invoicetype);
				invoiceJson.put("invoicedate", CommonUtils.convertLocalDateToString(invoicedateField.getValue()));
				invoiceJson.put("dueon", due_dateAsPerAgreementField.getValue());
				invoiceJson.put("billingcycle", billingcycleField.getValue());
				invoiceJson.put("period_startdate",
						CommonUtils.convertLocalDateToString(period_startdateField.getValue()));
				invoiceJson.put("period_enddate", CommonUtils.convertLocalDateToString(period_enddateField.getValue()));
				invoiceJson.put("grossinvoiceamount", grossinvoiceamountField.getValue());
				invoiceJson.put("gst_rate", Double.parseDouble(gst_rateField.getValue()));
				invoiceJson.put("invoiceamount", invoiceamountField.getValue());
				invoiceJson.put("billforoperator", operators2);
				invoiceJson.put("invoicearrears", invoicearrearsField.getValue());
				invoiceJson.put("submissiondate", CommonUtils.convertLocalDateToString(submissiondateField.getValue()));
				invoiceJson.put("receiveddate", CommonUtils.convertLocalDateToString(receiveddateField.getValue()));
				invoiceJson.put("duedate", CommonUtils.convertLocalDateToString(duedateField.getValue()));
				invoiceJson.put("remarks", remarksField.getValue());

				if (agreementNameField.getValue() != null) {
					invoiceJson.put("agreementName", agreementNameField.getValue());
					invoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
				} else {
					invoiceJson.put("agreementName", "");
					invoiceJson.put("agreementId", "");
				}

				saveBtn.setEnabled(false);
				System.out.println("invoiceJson edit==" + invoiceJson);
				if (isrentalTab == true && isUsageTab == false) {// rental

					JSONObject fileDetailsJson = new JSONObject();
					if (fileName.length() > 0 && fileType.length() > 0 && docDesc.length() > 0
							&& base64EncodedFileContent.length() > 0) {
						fileDetailsJson.put("Name", fileName.trim());
						fileDetailsJson.put("Type", fileType.trim());
						fileDetailsJson.put("Description", docDesc.trim());
						fileDetailsJson.put("Content", base64EncodedFileContent);
						// System.out.println("fileDetailsJson3=="+fileDetailsJson);
					} else {
						fileDetailsJson = new JSONObject();
					}

					if (fileDetailsJson.length() <= 0) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a document",
								ApplicationConstants.DialogTypes.ERROR);
						return;
					} else {
						// System.out.println("fileDetailsJson2=="+fileDetailsJson);

						callupdateRentalInvoiceApi(invoiceJson, fileDetailsJson);
					}

				} else if (isrentalTab == false && isUsageTab == true) {// usage
					int metertype = meterTypeMap.get(metertypeField.getValue());
					int lpsc_pay = 0;
					Double manualconsumption = 0.0, unitrate = 0.0;
					String meterserialNo, consumerNo;
					Double noofdays, openingreading, closingreading, calconsumption, perdayconsumption, ebAmt,
							fixloadcharge, dgcharge, fcucharge, lpsccharge, othercharge, finalpay;

					if (meterserialNoField.getValue() == null) {
						meterserialNo = "0";
					} else {
						meterserialNo = meterserialNoField.getValue();
					}
					if (consumerNoField.getValue() == null) {
						consumerNo = "0";
					} else {
						consumerNo = consumerNoField.getValue();
					}
					if (noofdaysField.getValue() == null) {
						noofdays = 0.0;
					} else {
						noofdays = noofdaysField.getValue();
					}
					if (opening_readingField.getValue() == null) {
						openingreading = 0.0;
					} else {
						openingreading = opening_readingField.getValue();
					}
					if (closing_readingField.getValue() == null) {
						closingreading = 0.0;
					} else {
						closingreading = closing_readingField.getValue();
					}

					if (lpsc_payableField.getValue() != null && lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
						lpsc_pay = 1;
					} else {
						lpsc_pay = 0;
					}
					if (manual_consumptionField.getValue() == null) {
						manualconsumption = 0.0;
					} else {
						manualconsumption = manual_consumptionField.getValue();
					}
					if (calculated_consumptionField.getValue() == null) {
						calconsumption = 0.0;
					} else {
						calconsumption = calculated_consumptionField.getValue();
					}
					if (per_day_consumptionField.getValue() == null) {
						perdayconsumption = 0.0;
					} else {
						perdayconsumption = per_day_consumptionField.getValue();
					}
					if (unit_rateField.getValue() == null) {
						unitrate = 0.0;
					} else {
						unitrate = unit_rateField.getValue();
					}
					if (eb_amountField.getValue() == null) {
						ebAmt = 0.0;
					} else {
						ebAmt = eb_amountField.getValue();
					}
					if (fix_load_chargeField.getValue() == null) {
						fixloadcharge = 0.0;
					} else {
						fixloadcharge = fix_load_chargeField.getValue();
					}
					if (dg_chargeField.getValue() == null) {
						dgcharge = 0.0;
					} else {
						dgcharge = dg_chargeField.getValue();
					}
					if (fcu_chargeField.getValue() == null) {
						fcucharge = 0.0;
					} else {
						fcucharge = fcu_chargeField.getValue();
					}
					if (late_payment_service_chargeField.getValue() == null) {
						lpsccharge = 0.0;
					} else {
						lpsccharge = late_payment_service_chargeField.getValue();
					}
					if (otherchargesField.getValue() == null) {
						othercharge = 0.0;
					} else {
						othercharge = otherchargesField.getValue();
					}
					if (final_payable_amountField.getValue() == null) {
						finalpay = 0.0;
					} else {
						finalpay = final_payable_amountField.getValue();
					}

					JSONObject usage_detailsJson = new JSONObject();
					usage_detailsJson.put("meterserialno", meterserialNo);
					usage_detailsJson.put("consumerno", consumerNo);
					usage_detailsJson.put("metertype", metertype);
					usage_detailsJson.put("sanctionload", sanctionloadField.getValue());
					usage_detailsJson.put("noofdays", noofdays);
					usage_detailsJson.put("opening_reading", openingreading);
					usage_detailsJson.put("closing_reading", closingreading);
					usage_detailsJson.put("calculated_consumption", calconsumption);
					usage_detailsJson.put("manual_consumption", manualconsumption);
					usage_detailsJson.put("per_day_consumption", perdayconsumption);
					usage_detailsJson.put("eb_amount", ebAmt);
					usage_detailsJson.put("unit_rate", unitrate);
					usage_detailsJson.put("fix_load_charge", fixloadcharge);
					usage_detailsJson.put("dg_charge", dgcharge);
					usage_detailsJson.put("fcu_charge", fcucharge);
					usage_detailsJson.put("late_payment_service_charge", lpsccharge);
					usage_detailsJson.put("othercharges", othercharge);
					usage_detailsJson.put("lpsc_payable", lpsc_pay);
					usage_detailsJson.put("final_payable_amount", finalpay);

					invoiceJson.put("usage_details", usage_detailsJson);

					System.out.println("invoiceJson edit==" + invoiceJson);
			//		saveBtn.setEnabled(false);
					JSONObject fileDetailsJson = new JSONObject();
					if (fileName.length() > 0 && fileType.length() > 0 && docDesc.length() > 0
							&& base64EncodedFileContent.length() > 0) {
						fileDetailsJson.put("Name", fileName.trim());
						fileDetailsJson.put("Type", fileType.trim());
						fileDetailsJson.put("Description", docDesc.trim());
						fileDetailsJson.put("Content", base64EncodedFileContent);
						// System.out.println("fileDetailsJson3=="+fileDetailsJson);
					} else {
						fileDetailsJson = new JSONObject();
					}
					if (fileDetailsJson.length() <= 0) {
						SiteAssetInventoryUIFramework.getFramework().showMessage("Please upload a document",
								ApplicationConstants.DialogTypes.ERROR);
						return;
					} else {
						// System.out.println("fileDetailsJson2=="+fileDetailsJson);

						callupdateUsageInvoiceApi(invoiceJson, fileDetailsJson);
					}

				} else {

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		} finally {
			saveBtn.setEnabled(true);
		}

	}

	private void callupdateUsageInvoiceApi(JSONObject usage_detailsJson, JSONObject fileDetailsJson) {
		try {
			System.out.println("usage_detailsJson=" + usage_detailsJson);
			Form formData = new Form();
			formData.add("invoiceId", invoiceid);
			formData.add("invoiceJson", usage_detailsJson);

			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPDATE_USAGE_INVOICE");
			String resp = RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			uploadDocument(fileDetailsJson.toString(), Integer.parseInt(invoiceid));

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		}

	}

	private void callupdateRentalInvoiceApi(JSONObject invoiceJson, JSONObject fileDetailsJson) {
		try {

			System.out.println("invoiceJsonRental=" + invoiceJson);
			Form formData = new Form();
			formData.add("invoiceId", invoiceid);
			formData.add("InvoiceJson", invoiceJson);

			String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPDATE_RENTAL_INVOICE");
			String resp = RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,
					SiteAssetInventoryUIFramework.getFramework().getToken());
			uploadDocument(fileDetailsJson.toString(), Integer.parseInt(invoiceid));
		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
			success = false;
		}
	}

	private void saveAsDraft(boolean isrentalTab2, boolean isUsageTab2, boolean isEmgTab2, String mode2) {
		try {

			if (isrentalTab2 == true && isUsageTab2 == false && mode2.equalsIgnoreCase("create")) {
				getRentalFormValues();

				JSONObject formvalue = new JSONObject();

				formvalue.put("InvoiceJson", temp_RentalInvoiceJson);

//				LocalStorage.setItem(KEY_NAME,formvalue.toString());
//				LocalStorage.showStoredValue(KEY_NAME);
//				SiteAssetInventoryUIFramework.getFramework().showMessage("Rental Invoice saved as draft", ApplicationConstants.DialogTypes.INFO);
				CommonUtils.insertDraftData("3", formvalue.toString(), "Rental Invoice saved as draft");
				System.out.println("saveAsDraft Rental::::::::::" + formvalue);

			} else if (isrentalTab2 == false && isUsageTab2 == true && mode2.equalsIgnoreCase("create")) {

				getUsageFormValues();

				JSONObject formvalue = new JSONObject();

				formvalue.put("InvoiceJson", temp_UsageInvoiceJson);

				KEY_NAME = "ADD_USAGE_INVOICE_FORMVALUE";

//				LocalStorage.setItem(KEY_NAME,formvalue.toString());
//				LocalStorage.showStoredValue(KEY_NAME);
//				SiteAssetInventoryUIFramework.getFramework().showMessage("Usage Invoice saved as draft", ApplicationConstants.DialogTypes.INFO);
				CommonUtils.insertDraftData("4", formvalue.toString(), "Electricity Invoice saved as draft");
				System.out.println("saveAsDraft Usage::::::::::" + formvalue);
			} else {

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void clearDraft(boolean isrentalTab2, boolean isUsageTab2, boolean isEmgTab2, String mode2) {
		// LocalStorage.removeItem(KEY_NAME);
		// LocalStorage.showStoredValue(KEY_NAME);
		try {
			if (isrentalTab == true && isUsageTab == false) {
				CommonUtils.resetDraftData("3", "Rental invoice details reset successfully");
			} else if (isrentalTab == false && isUsageTab == true) {
				CommonUtils.resetDraftData("4", "Electricity invoice details reset successfully");
			}
			resetFormValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void resetFormValue() {

		try {

			sitecodeField.clear();
			sitenameField.clear();
			agreementNameField.clear();
			circleField.clear();
			landlordnameField.clear();
			billingcycleField.clear();
			rentstatusField.clear();
			due_dateAsPerAgreementField.clear();
			rentshareField.clear();
			billforoperatorField.clear();
			sapvendorcodeField.clear();
			solutiontypeField.clear();
			invoicetypeField.clear();
			billingtypeField.clear();
			period_startdateField.clear();
			period_enddateField.clear();
			// grossinvoiceamountField.clear();
			grossinvoiceamountField.setValue(0.0);
			// gst_rateField.clear();
			gst_rateField.setValue("0");
			invoiceamountField.clear();
			invoicedateField.clear();
			invoicearrearsField.setValue(0.0);
			LocalDate now = LocalDate.now();
			submissiondateField.setValue(now);
			receiveddateField.clear();

			duedateField.clear();
			remarksField.clear();
			invoiceNoField.clear();

			if (isrentalTab == false && isUsageTab == true && mode.equalsIgnoreCase("create")) {
				meterserialNoField.clear();
				consumerNoField.clear();
				metertypeField.clear();
				sanctionloadField.clear();
				// noofdaysField.clear();
				closing_readingField.clear();
				opening_readingField.clear();
				calculated_consumptionField.clear();
				manual_consumptionField.clear();

//				unit_rateField.clear();
//				fix_load_chargeField.clear();
//				dg_chargeField.clear();
//				fcu_chargeField.clear();
//				late_payment_service_chargeField.clear();
//				per_day_consumptionField.clear();
//				eb_amountField.clear();

//				otherchargesField.clear();
//				final_payable_amountField.clear();
				lpsc_payableField.clear();

				final_payable_amountField.setValue(0.0);
				eb_amountField.setValue(0.0);
				fix_load_chargeField.setValue(0.0);
				dg_chargeField.setValue(0.0);
				fcu_chargeField.setValue(0.0);
				late_payment_service_chargeField.setValue(0.0);
				noofdaysField.setValue(1.0);
				totalField.setValue(0.0);
				per_day_consumptionField.setValue(0.0);

				otherchargesField.setValue(0.0);
				unit_rateField.setValue(0.0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	private void resetFormValue2() {

		try {

		//	sitecodeField.clear();
			sitenameField.clear();
			agreementNameField.clear();
			circleField.clear();
			landlordnameField.clear();
			billingcycleField.clear();
			rentstatusField.clear();
			due_dateAsPerAgreementField.clear();
			rentshareField.clear();
			billforoperatorField.clear();
			sapvendorcodeField.clear();
			solutiontypeField.clear();
			invoicetypeField.clear();
			billingtypeField.clear();
			period_startdateField.clear();
			period_enddateField.clear();
			// grossinvoiceamountField.clear();
			grossinvoiceamountField.setValue(0.0);
			// gst_rateField.clear();
			gst_rateField.setValue("0");
			invoiceamountField.clear();
			invoicedateField.clear();
			invoicearrearsField.setValue(0.0);
			LocalDate now = LocalDate.now();
			submissiondateField.setValue(now);
			receiveddateField.clear();

			duedateField.clear();
			remarksField.clear();
			invoiceNoField.clear();

			if (isrentalTab == false && isUsageTab == true && mode.equalsIgnoreCase("create")) {
				meterserialNoField.clear();
				consumerNoField.clear();
				metertypeField.clear();
				sanctionloadField.clear();
				// noofdaysField.clear();
				closing_readingField.clear();
				opening_readingField.clear();
				calculated_consumptionField.clear();
				manual_consumptionField.clear();

				lpsc_payableField.clear();

				final_payable_amountField.setValue(0.0);
				eb_amountField.setValue(0.0);
				fix_load_chargeField.setValue(0.0);
				dg_chargeField.setValue(0.0);
				fcu_chargeField.setValue(0.0);
				late_payment_service_chargeField.setValue(0.0);
				noofdaysField.setValue(1.0);
				totalField.setValue(0.0);
				per_day_consumptionField.setValue(0.0);

				otherchargesField.setValue(0.0);
				unit_rateField.setValue(0.0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setRentalFormValue(boolean isrentalTab2, boolean isUsageTab2, boolean isEmgTab2, String mode2) {
		try {

//			LocalStorage.getItem(
//					KEY_NAME,
//		            value -> {
//		            	System.out.println("Stored value::=="+value);
//		            	if(isrentalTab2==true && isUsageTab2==false && mode2.equalsIgnoreCase("create")) {
//		            		rentalInvoiceForm(value);
//		            	}
//		            	
//		            	
//		            }
//		     );	

			String resp = CommonUtils.getDraftData("3");
			rentalDraftForm=resp;
			rentalInvoiceForm(resp);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setUsageFormValue(boolean isrentalTab2, boolean isUsageTab2, boolean isEmgTab2, String mode2) {
		try {

//			LocalStorage.getItem(
//					KEY_NAME,
//		            value -> {
//		            	System.out.println("Stored value::=="+value);
//		            	 if(isrentalTab2==false && isUsageTab2==true && mode2.equalsIgnoreCase("create")) {
//		            		usageInvoiceForm(value);
//		            	 }
//		            	
//		            }
//		     );	

			String resp = CommonUtils.getDraftData("4");
			usageDraftForm=resp;
			usageInvoiceForm(resp);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void rentalInvoiceForm(String formvalue) {
		try {
			System.out.println("formvalue:==" + formvalue);
			if (formvalue != null) {
				JSONObject InvoiceJson = new JSONObject(formvalue);
				JSONObject js = new JSONObject(InvoiceJson.getString("InvoiceJson"));

				Set<String> hash_Set = null;
				// System.out.println("BillForOperator.trim().length()=="+js.getString("billforoperator").length());
				if (js.getString("billforoperator") != null && js.getString("billforoperator").trim().length() > 0) {
					String[] arrOfStr = js.getString("billforoperator").split(",");
					hash_Set = new HashSet<String>();
					for (String a : arrOfStr) {
						hash_Set.add(a);
					}

					billforoperatorField.setValue(hash_Set);
				}

//					System.out.println("len===="+js.getString("billingtype").length());
//					System.out.println("len===="+js.getString("invoicetype").length());

				if (js.getString("sitecode") != null || js.getString("sitecode").length() > 0) {
					sitecodeField.setValue(js.getString("sitecode"));
				}
				if (js.getString("sitename") != null || js.getString("sitename").length() > 0) {
					sitenameField.setValue(js.getString("sitename"));
				}
				if (js.getString("circle") != null || js.getString("circle").length() > 0) {
					circleField.setValue(js.getString("circle"));
				}
				if (js.getString("agreementName") != null || js.getString("agreementName").length() > 0) {
					agreementNameField.setValue(js.getString("agreementName"));
				}
		/*		if (js.has("agreementId") && js.getString("agreementId") != null || js.getString("agreementId").length() > 0) {
					//agreementNameField.setValue(js.getString("agreementID"));
				}*/
				if (js.getString("landlordname") != null || js.getString("landlordname").length() > 0) {
					landlordnameField.setValue(js.getString("landlordname"));
				}
				if (js.getString("landlordid") != null || js.getString("landlordid").length() > 0) {
					landlordidField.setValue(js.getString("landlordid"));
				}
				if (js.getString("billingcycle") != null || js.getString("billingcycle").length() > 0) {
					billingcycleField.setValue(js.getString("billingcycle"));
				}
				if (js.getString("rentstatus") != null || js.getString("rentstatus").length() > 0) {
					rentstatusField.setValue(js.getString("rentstatus"));
				}
				if (js.getString("dueon") != null || js.getString("dueon").length() > 0) {
					due_dateAsPerAgreementField.setValue(js.getString("dueon"));
				}
				if (js.getString("rentshare") != null || js.getString("rentshare").length() > 0) {
					rentshareField.setValue(js.getString("rentshare"));
				}
				if (js.getString("sapvendorcode") != null || js.getString("sapvendorcode").length() > 0) {
					sapvendorcodeField.setValue(js.getString("sapvendorcode"));
				}
				if (js.getString("solutiontype") != null || js.getString("solutiontype").length() > 0) {
					solutiontypeField.setValue(js.getString("solutiontype"));
				}
				if (js.getString("invoicetype") != null && js.getString("invoicetype").length() > 0) {
					invoicetypeField.setValue(invoicetypemap2.get(Integer.parseInt(js.getString("invoicetype"))));
				}
				if (js.getString("billingtype") != null && js.getString("billingtype").length() > 0) {
					billingtypeField.setValue(billtypemap2.get(Integer.parseInt(js.getString("billingtype"))));
				}

				if (js.getString("period_startdate") != null && js.getString("period_startdate").length() > 0) {
					period_startdateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("period_startdate"), "dd/MM/yyyy"));

				}
				if (js.getString("period_enddate") != null && js.getString("period_enddate").length() > 0) {
					period_enddateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("period_enddate"), "dd/MM/yyyy"));
				}
				if (js.getString("grossinvoiceamount") != null && js.getString("grossinvoiceamount").length() > 0) {
					grossinvoiceamountField.setValue(Double.parseDouble(js.getString("grossinvoiceamount")));
				}
				if (js.getString("gst_rate") != null && js.getString("gst_rate").length() > 0) {
					gst_rateField.setValue(js.getString("gst_rate"));
				}
				if (js.getString("invoiceamount") != null && js.getString("invoiceamount").length() > 0) {
					invoiceamountField.setValue(Double.parseDouble(js.getString("invoiceamount")));
				}
				if (js.getString("invoicedate") != null && js.getString("invoicedate").length() > 0) {
					invoicedateField
							.setValue(CommonUtils.convertStringToLocalDate(js.getString("invoicedate"), "dd/MM/yyyy"));
				}
				if (js.getString("invoicearrears") != null && js.getString("invoicearrears").length() > 0) {
					invoicearrearsField.setValue(Double.parseDouble(js.getString("invoicearrears")));
				}
				if (js.getString("submissiondate") != null && js.getString("submissiondate").length() > 0) {
					submissiondateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("submissiondate"), "dd/MM/yyyy"));
				}
				if (js.getString("receiveddate") != null && js.getString("receiveddate").length() > 0) {
					receiveddateField
							.setValue(CommonUtils.convertStringToLocalDate(js.getString("receiveddate"), "dd/MM/yyyy"));
				}
				if (js.getString("duedate") != null && js.getString("duedate").length() > 0) {
					duedateField.setValue(CommonUtils.convertStringToLocalDate(js.getString("duedate"), "dd/MM/yyyy"));
				}
				if (js.getString("invoiceno") != null && js.getString("invoiceno").length() > 0) {
					invoiceNoField.setValue((js.getString("invoiceno")));
				}
				if (js.getString("remarks") != null && js.getString("remarks").length() > 0) {
					remarksField.setValue((js.getString("remarks")));
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void usageInvoiceForm(String formvalue) {
		try {
			System.out.println("formvalue:==" + formvalue);
			if (formvalue != null) {
				JSONObject InvoiceJson = new JSONObject(formvalue);
				JSONObject js = new JSONObject(InvoiceJson.getString("InvoiceJson"));
				JSONObject usage_detailsjs = new JSONObject(js.getString("usage_details"));

				Set<String> hash_Set = null;
				// System.out.println("BillForOperator.trim().length()=="+BillForOperator.trim().length());
				if (js.getString("billforoperator") != null && js.getString("billforoperator").trim().length() > 0) {
					String[] arrOfStr = js.getString("billforoperator").split(",");
					hash_Set = new HashSet<String>();
					for (String a : arrOfStr) {
						hash_Set.add(a);
					}
//				    	System.out.println("hash_Set isEmpty()=="+hash_Set.isEmpty());

					// System.out.println("hash_Set size=="+hash_Set.size());
					billforoperatorField.setValue(hash_Set);
				}

				if (js.getString("sitecode") != null || js.getString("sitecode").length() > 0) {
					sitecodeField.setValue(js.getString("sitecode"));
				}
				if (js.getString("sitename") != null || js.getString("sitename").length() > 0) {
					sitenameField.setValue(js.getString("sitename"));
				}
				if (js.getString("circle") != null || js.getString("circle").length() > 0) {
					circleField.setValue(js.getString("circle"));
				}
				if (js.getString("agreementName") != null || js.getString("agreementName").length() > 0) {
					agreementNameField.setValue(js.getString("agreementName"));
				}
			/*	if (js.has("agreementId") && js.getString("agreementId") != null || js.getString("agreementId").length() > 0) {
					//agreementNameField.setValue(js.getString("agreementId"));
				}*/
				if (js.getString("landlordname") != null || js.getString("landlordname").length() > 0) {
					landlordnameField.setValue(js.getString("landlordname"));
				}
				if (js.getString("landlordid") != null || js.getString("landlordid").length() > 0) {
					landlordidField.setValue(js.getString("landlordid"));
				}
				if (js.getString("billingcycle") != null || js.getString("billingcycle").length() > 0) {
					billingcycleField.setValue(js.getString("billingcycle"));
				}
				if (js.getString("rentstatus") != null || js.getString("rentstatus").length() > 0) {
					rentstatusField.setValue(js.getString("rentstatus"));
				}
				if (js.getString("dueon") != null || js.getString("dueon").length() > 0) {
					due_dateAsPerAgreementField.setValue(js.getString("dueon"));
				}
				// System.out.println("js.getString(\"rentshare\")=="+js.getString("rentshare"));
				if (js.getString("rentshare") != null && js.getString("rentshare").length() > 0) {
					rentshareField.setValue(js.getString("rentshare"));
				}
				if (js.getString("sapvendorcode") != null || js.getString("sapvendorcode").length() > 0) {
					sapvendorcodeField.setValue(js.getString("sapvendorcode"));
				}
				if (js.getString("solutiontype") != null || js.getString("solutiontype").length() > 0) {
					solutiontypeField.setValue(js.getString("solutiontype"));
				}
				if (js.getString("invoicetype") != null && js.getString("invoicetype").length() > 0) {
					invoicetypeField.setValue(invoicetypemap2.get(Integer.parseInt(js.getString("invoicetype"))));

					/*
					 * if(invoicetypeField.getValue().equalsIgnoreCase("EB+DG")||invoicetypeField.
					 * getValue().equalsIgnoreCase("DG")) { dg_chargeField.setEnabled(true); }else
					 * if(invoicetypeField.getValue()!=null &&
					 * (!invoicetypeField.getValue().equalsIgnoreCase("EB+DG")
					 * ||!invoicetypeField.getValue().equalsIgnoreCase("DG"))){
					 * dg_chargeField.setEnabled(false); }else { dg_chargeField.setEnabled(false); }
					 * if(invoicetypeField.getValue().equalsIgnoreCase("EB+FCU")||invoicetypeField.
					 * getValue().equalsIgnoreCase("FCU")){ fcu_chargeField.setEnabled(true); }else
					 * if(!invoicetypeField.getValue().equalsIgnoreCase("EB+FCU")||!invoicetypeField
					 * .getValue().equalsIgnoreCase("FCU")){ fcu_chargeField.setEnabled(false);
					 * }else { fcu_chargeField.setEnabled(false); }
					 */

				}
				if (js.getString("billingtype") != null && js.getString("billingtype").length() > 0) {
					billingtypeField.setValue(billtypemap2.get(Integer.parseInt(js.getString("billingtype"))));
				}

				if (js.getString("period_startdate") != null && js.getString("period_startdate").length() > 0) {
					period_startdateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("period_startdate"), "dd/MM/yyyy"));

				}
				if (js.getString("period_enddate") != null && js.getString("period_enddate").length() > 0) {
					period_enddateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("period_enddate"), "dd/MM/yyyy"));
				}
				if (js.getString("grossinvoiceamount") != null || js.getString("grossinvoiceamount").length() > 0) {
					grossinvoiceamountField.setValue(Double.parseDouble(js.getString("grossinvoiceamount")));
				}
				if (js.getString("gst_rate") != null && js.getString("gst_rate").length() > 0) {
					gst_rateField.setValue(js.getString("gst_rate"));
				}
				if (js.getString("invoiceamount") != null && js.getString("invoiceamount").length() > 0) {
					invoiceamountField.setValue(Double.parseDouble(js.getString("invoiceamount")));
				}
				if (js.getString("invoicedate") != null && js.getString("invoicedate").length() > 0) {
					invoicedateField
							.setValue(CommonUtils.convertStringToLocalDate(js.getString("invoicedate"), "dd/MM/yyyy"));
				}
				if (js.getString("invoicearrears") != null && js.getString("invoicearrears").length() > 0) {
					invoicearrearsField.setValue(Double.parseDouble(js.getString("invoicearrears")));
				}
				if (js.getString("submissiondate") != null && js.getString("submissiondate").length() > 0) {
					submissiondateField.setValue(
							CommonUtils.convertStringToLocalDate(js.getString("submissiondate"), "dd/MM/yyyy"));
				}
				if (js.getString("receiveddate") != null && js.getString("receiveddate").length() > 0) {
					receiveddateField
							.setValue(CommonUtils.convertStringToLocalDate(js.getString("receiveddate"), "dd/MM/yyyy"));
				}
				if (js.getString("duedate") != null && js.getString("duedate").length() > 0) {
					duedateField.setValue(CommonUtils.convertStringToLocalDate(js.getString("duedate"), "dd/MM/yyyy"));
				}
				if (js.getString("invoiceno") != null && js.getString("invoiceno").length() > 0) {
					invoiceNoField.setValue((js.getString("invoiceno")));
				}
				if (js.getString("remarks") != null && js.getString("remarks").length() > 0) {
					remarksField.setValue((js.getString("remarks")));
				}

				if (usage_detailsjs != null || usage_detailsjs.length() > 0) {
					try {
						System.out.println("usage_detailsjs==" + usage_detailsjs);
//						consumerNoField.setValue(usage_detailsjs.getString("consumerno"));
//						metertypeField.setValue(meterTypeMap2.get(Integer.parseInt(usage_detailsjs.getString("metertype"))));
//						sanctionloadField.setValue(usage_detailsjs.getString("sanctionload"));
//						noofdaysField.setValue(Double.parseDouble(usage_detailsjs.getString("noofdays")));
//						closing_readingField.setValue(Double.parseDouble(usage_detailsjs.getString("closing_reading")));
//						opening_readingField.setValue(Double.parseDouble(usage_detailsjs.getString("opening_reading")));
//						calculated_consumptionField.setValue(Double.parseDouble(usage_detailsjs.getString("calculated_consumption")));
//						manual_consumptionField.setValue(Double.parseDouble(usage_detailsjs.getString("manual_consumption")));
//						per_day_consumptionField.setValue(Double.parseDouble(usage_detailsjs.getString("per_day_consumption")));
//						eb_amountField.setValue(Double.parseDouble(usage_detailsjs.getString("eb_amount")));
//						unit_rateField.setValue(Double.parseDouble(usage_detailsjs.getString("unit_rate")));
//						fix_load_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("fix_load_charge")));
//						dg_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("dg_charge")));
//						fcu_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("fcu_charge")));
//						late_payment_service_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("late_payment_service_charge")));
//						otherchargesField.setValue(Double.parseDouble(usage_detailsjs.getString("othercharges")));
//						final_payable_amountField.setValue(Double.parseDouble(usage_detailsjs.getString("final_payable_amount")));

						// System.out.println("opening_readingField=="+opening_readingField.getValue());

						if (usage_detailsjs.getString("meterserialno") != null
								&& usage_detailsjs.getString("meterserialno").length() > 0) {
							meterserialNoField.setValue(usage_detailsjs.getString("meterserialno"));
						}
						if (usage_detailsjs.getString("consumerno") != null
								&& usage_detailsjs.getString("consumerno").length() > 0) {
							consumerNoField.setValue(usage_detailsjs.getString("consumerno"));
						}
						if (usage_detailsjs.getString("metertype") != null
								&& usage_detailsjs.getString("metertype").length() > 0) {
							metertypeField.setValue(
									meterTypeMap2.get(Integer.parseInt(usage_detailsjs.getString("metertype"))));
						}
						if (usage_detailsjs.getString("sanctionload") != null
								&& usage_detailsjs.getString("sanctionload").length() > 0) {
							sanctionloadField.setValue(usage_detailsjs.getString("sanctionload"));
						}
						if (usage_detailsjs.getString("noofdays") != null
								&& usage_detailsjs.getString("noofdays").length() > 0) {
							noofdaysField.setValue(Double.parseDouble(usage_detailsjs.getString("noofdays")));
						}
						if (usage_detailsjs.getString("closing_reading") != null
								&& usage_detailsjs.getString("closing_reading").length() > 0) {
							closing_readingField
									.setValue(Double.parseDouble(usage_detailsjs.getString("closing_reading")));
						}
						if (usage_detailsjs.getString("opening_reading") != null
								&& usage_detailsjs.getString("opening_reading").length() > 0) {
							opening_readingField
									.setValue(Double.parseDouble(usage_detailsjs.getString("opening_reading")));
						}
						if (usage_detailsjs.getString("calculated_consumption") != null
								&& usage_detailsjs.getString("calculated_consumption").length() > 0) {
							calculated_consumptionField
									.setValue(Double.parseDouble(usage_detailsjs.getString("calculated_consumption")));
						}
						if (usage_detailsjs.getBoolean("isManualGiven")==true && usage_detailsjs.getString("manual_consumption") != null
								&& usage_detailsjs.getString("manual_consumption").length() > 0) {
							manual_consumptionField
									.setValue(Double.parseDouble(usage_detailsjs.getString("manual_consumption")));
						}
						if (usage_detailsjs.getBoolean("isManualGiven")==false) {
							//manual_consumptionField.setValue(Double.parseDouble(usage_detailsjs.getString("manual_consumption")));
							manual_consumptionField.clear();
									
						}
						if (usage_detailsjs.getString("per_day_consumption") != null
								&& usage_detailsjs.getString("per_day_consumption").length() > 0) {
							per_day_consumptionField
									.setValue(Double.parseDouble(usage_detailsjs.getString("per_day_consumption")));
						}
						if (usage_detailsjs.getString("eb_amount") != null
								&& usage_detailsjs.getString("eb_amount").length() > 0) {
							eb_amountField.setValue(Double.parseDouble(usage_detailsjs.getString("eb_amount")));
						}
						if (usage_detailsjs.getString("unit_rate") != null
								&& usage_detailsjs.getString("unit_rate").length() > 0) {
							unit_rateField.setValue(Double.parseDouble(usage_detailsjs.getString("unit_rate")));
						}
						if (usage_detailsjs.getString("fix_load_charge") != null
								&& usage_detailsjs.getString("fix_load_charge").length() > 0) {
							fix_load_chargeField
									.setValue(Double.parseDouble(usage_detailsjs.getString("fix_load_charge")));
						}
						if (usage_detailsjs.getString("dg_charge") != null
								&& usage_detailsjs.getString("dg_charge").length() > 0) {
							dg_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("dg_charge")));
						}
						if (usage_detailsjs.getString("fcu_charge") != null
								&& usage_detailsjs.getString("fcu_charge").length() > 0) {
							fcu_chargeField.setValue(Double.parseDouble(usage_detailsjs.getString("fcu_charge")));
						}
						if (usage_detailsjs.getString("late_payment_service_charge") != null
								&& usage_detailsjs.getString("late_payment_service_charge").length() > 0) {
							late_payment_service_chargeField.setValue(
									Double.parseDouble(usage_detailsjs.getString("late_payment_service_charge")));
						}
						if (usage_detailsjs.getString("othercharges") != null
								&& usage_detailsjs.getString("othercharges").length() > 0) {
							otherchargesField.setValue(Double.parseDouble(usage_detailsjs.getString("othercharges")));
						}
						if (usage_detailsjs.getString("final_payable_amount") != null
								&& usage_detailsjs.getString("final_payable_amount").length() > 0) {
							final_payable_amountField
									.setValue(Double.parseDouble(usage_detailsjs.getString("final_payable_amount")));
						}

						if (usage_detailsjs.getString("lpsc_payable").equals("1")) {
							lpsc_payableField.setValue("Yes");
						} else {
							lpsc_payableField.setValue("No");
						}

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void getRentalFormValues() {

		try {

			String operators = "", operators2 = "";

			temp_RentalInvoiceJson = new JSONObject();

			Set<String> op = billforoperatorField.getValue();
			// System.out.println("op=="+op);
			if (op.size() > 0) {
				Iterator value = op.iterator();
				while (value.hasNext()) {
					operators += value.next() + ",";
				}
				operators2 = operators.substring(0, operators.length() - 1);
			} else {
				operators2 = "";
			}

			if (invoiceNoField.getValue() != null || invoiceNoField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("invoiceno", invoiceNoField.getValue());
			} else {
				temp_RentalInvoiceJson.put("invoiceno", "");
			}
			temp_RentalInvoiceJson.put("sitecode", sitecodeField.getValue());
			if (circleField.getValue() != null || circleField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("circle", circleField.getValue());
			} else {
				temp_RentalInvoiceJson.put("circle", "");
			}
			if (sitenameField.getValue() != null || sitenameField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("sitename", sitenameField.getValue());
			} else {
				temp_RentalInvoiceJson.put("sitename", "");
			}
			if (landlordidField.getValue() != null && landlordidField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("landlordid", Integer.parseInt(landlordidField.getValue()));
			} else {
				temp_RentalInvoiceJson.put("landlordid", "");
			}
			if (sapvendorcodeField.getValue() != null || sapvendorcodeField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("sapvendorcode", sapvendorcodeField.getValue());
			} else {
				temp_RentalInvoiceJson.put("sapvendorcode", "");
			}
			if (landlordnameField.getValue() != null && landlordnameField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("landlordname", landlordnameField.getValue());
			} else {
				temp_RentalInvoiceJson.put("landlordname", "");
			}

			if (rentshareField.getValue() != null && rentshareField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("rentshare", Double.parseDouble(rentshareField.getValue()));
			} else {
				temp_RentalInvoiceJson.put("rentshare", "");
			}

			if (solutiontypeField.getValue() == null) {
				temp_RentalInvoiceJson.put("solutiontype", "");
			} else {
				temp_RentalInvoiceJson.put("solutiontype", solutiontypeField.getValue());
			}

			if (billingtypeField.getValue() != null) {
				int billtype = billtypemap.get(billingtypeField.getValue());
				temp_RentalInvoiceJson.put("billingtype", billtype);
			} else {
				temp_RentalInvoiceJson.put("billingtype", "");
			}

			temp_RentalInvoiceJson.put("rentstatus", rentstatusField.getValue());

			if (invoicetypeField.getValue() != null) {
				int invoicetype = invoicetypemap.get(invoicetypeField.getValue());
				temp_RentalInvoiceJson.put("invoicetype", invoicetype);
			} else {
				temp_RentalInvoiceJson.put("invoicetype", "");
			}

			if (invoicedateField.getValue() == null) {
				temp_RentalInvoiceJson.put("invoicedate", "");
			} else {
				temp_RentalInvoiceJson.put("invoicedate",
						CommonUtils.convertLocalDateToString(invoicedateField.getValue()));
			}

			temp_RentalInvoiceJson.put("dueon", due_dateAsPerAgreementField.getValue());
			temp_RentalInvoiceJson.put("billingcycle", billingcycleField.getValue());

			if (period_startdateField.getValue() == null) {
				temp_RentalInvoiceJson.put("period_startdate", "");
			} else {
				temp_RentalInvoiceJson.put("period_startdate",
						CommonUtils.convertLocalDateToString(period_startdateField.getValue()));
			}

			if (period_enddateField.getValue() == null) {
				temp_RentalInvoiceJson.put("period_enddate", "");
			} else {
				temp_RentalInvoiceJson.put("period_enddate",
						CommonUtils.convertLocalDateToString(period_enddateField.getValue()));
			}

			temp_RentalInvoiceJson.put("grossinvoiceamount", grossinvoiceamountField.getValue());
			System.out.println("gst_rateField.getValue().length()==" + gst_rateField.getValue().length());
			if (gst_rateField.getValue().length() > 0) {
				temp_RentalInvoiceJson.put("gst_rate", Double.parseDouble(gst_rateField.getValue()));
			} else {
				temp_RentalInvoiceJson.put("gst_rate", 0.0);
			}

			if (invoiceamountField.getValue() == null) {
				temp_RentalInvoiceJson.put("invoiceamount", "");
			} else {
				temp_RentalInvoiceJson.put("invoiceamount", invoiceamountField.getValue());
			}

			temp_RentalInvoiceJson.put("billforoperator", operators2);
			temp_RentalInvoiceJson.put("invoicearrears", invoicearrearsField.getValue());

			if (submissiondateField.getValue() == null) {
				temp_RentalInvoiceJson.put("submissiondate", "");
			} else {
				temp_RentalInvoiceJson.put("submissiondate",
						CommonUtils.convertLocalDateToString(submissiondateField.getValue()));
			}

			if (receiveddateField.getValue() == null) {
				temp_RentalInvoiceJson.put("receiveddate", "");
			} else {
				temp_RentalInvoiceJson.put("receiveddate",
						CommonUtils.convertLocalDateToString(receiveddateField.getValue()));
			}

			if (duedateField.getValue() == null) {
				temp_RentalInvoiceJson.put("duedate", "");
			} else {
				temp_RentalInvoiceJson.put("duedate", CommonUtils.convertLocalDateToString(duedateField.getValue()));
			}

			temp_RentalInvoiceJson.put("agreementName", "");
			temp_RentalInvoiceJson.put("agreementId", "");
		
			System.out.println("agreementNameIdMap2====="+agreementNameIdMap2);
			System.out.println("agreementNameField.getValue()====="+agreementNameField.getValue());
			if (agreementNameField.getValue()!= null) {
				temp_RentalInvoiceJson.put("agreementName", agreementNameField.getValue());
				temp_RentalInvoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
			} else {
				temp_RentalInvoiceJson.put("agreementName", "");
				temp_RentalInvoiceJson.put("agreementId", "");
			}
			
			
			temp_RentalInvoiceJson.put("remarks", remarksField.getValue());

			// JSONObject saveobjJson=new JSONObject();
			// temp_RentalInvoiceJson.put("InvoiceJson",invoiceJson);

			// System.out.println("invoiceJson=="+invoiceJson);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void getUsageFormValues() {
		try {

			String operators = "", operators2 = "";

			// JSONObject temp_UsageInvoiceJson=new JSONObject();
			temp_UsageInvoiceJson = new JSONObject();

			Set<String> op = billforoperatorField.getValue();
			// System.out.println("op=="+op);
			if (op.size() > 0) {
				Iterator value = op.iterator();
				while (value.hasNext()) {
					operators += value.next() + ",";
				}
				operators2 = operators.substring(0, operators.length() - 1);
			} else {
				operators2 = "";
			}

			if (invoiceNoField.getValue() != null || invoiceNoField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("invoiceno", invoiceNoField.getValue());
			} else {
				temp_UsageInvoiceJson.put("invoiceno", "");
			}
			temp_UsageInvoiceJson.put("sitecode", sitecodeField.getValue());
			if (circleField.getValue() != null || circleField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("circle", circleField.getValue());
			} else {
				temp_UsageInvoiceJson.put("circle", "");
			}
			if (sitenameField.getValue() != null || sitenameField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("sitename", sitenameField.getValue());
			} else {
				temp_UsageInvoiceJson.put("sitename", "");
			}
			if (landlordidField.getValue() != null && landlordidField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("landlordid", Integer.parseInt(landlordidField.getValue()));
			} else {
				temp_UsageInvoiceJson.put("landlordid", "");
			}
			if (sapvendorcodeField.getValue() != null || sapvendorcodeField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("sapvendorcode", sapvendorcodeField.getValue());
			} else {
				temp_UsageInvoiceJson.put("sapvendorcode", "");
			}
			if (landlordnameField.getValue() != null && landlordnameField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("landlordname", landlordnameField.getValue());
			} else {
				temp_UsageInvoiceJson.put("landlordname", "");
			}

			if (rentshareField.getValue() != null && rentshareField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("rentshare", Double.parseDouble(rentshareField.getValue()));
			} else {
				temp_UsageInvoiceJson.put("rentshare", "");
			}

			if (solutiontypeField.getValue() == null) {
				temp_UsageInvoiceJson.put("solutiontype", "");
			} else {
				temp_UsageInvoiceJson.put("solutiontype", solutiontypeField.getValue());
			}

			if (billingtypeField.getValue() != null) {
				int billtype = billtypemap.get(billingtypeField.getValue());
				temp_UsageInvoiceJson.put("billingtype", billtype);
			} else {
				temp_UsageInvoiceJson.put("billingtype", "");
			}

			temp_UsageInvoiceJson.put("rentstatus", rentstatusField.getValue());

			if (invoicetypeField.getValue() != null) {
				int invoicetype = invoicetypemap.get(invoicetypeField.getValue());
				temp_UsageInvoiceJson.put("invoicetype", invoicetype);
			} else {
				temp_UsageInvoiceJson.put("invoicetype", "");
			}

			if (invoicedateField.getValue() == null) {
				temp_UsageInvoiceJson.put("invoicedate", "");
			} else {
				temp_UsageInvoiceJson.put("invoicedate",
						CommonUtils.convertLocalDateToString(invoicedateField.getValue()));
			}

			temp_UsageInvoiceJson.put("dueon", due_dateAsPerAgreementField.getValue());
			temp_UsageInvoiceJson.put("billingcycle", billingcycleField.getValue());

			if (period_startdateField.getValue() == null) {
				temp_UsageInvoiceJson.put("period_startdate", "");
			} else {
				temp_UsageInvoiceJson.put("period_startdate",
						CommonUtils.convertLocalDateToString(period_startdateField.getValue()));
			}

			if (period_enddateField.getValue() == null) {
				temp_UsageInvoiceJson.put("period_enddate", "");
			} else {
				temp_UsageInvoiceJson.put("period_enddate",
						CommonUtils.convertLocalDateToString(period_enddateField.getValue()));
			}

			temp_UsageInvoiceJson.put("grossinvoiceamount", grossinvoiceamountField.getValue());
			if (gst_rateField.getValue().length() > 0) {
				temp_UsageInvoiceJson.put("gst_rate", Double.parseDouble(gst_rateField.getValue()));
			} else {
				temp_UsageInvoiceJson.put("gst_rate", 0.0);
			}

			if (invoiceamountField.getValue() == null) {
				temp_UsageInvoiceJson.put("invoiceamount", "");
			} else {
				temp_UsageInvoiceJson.put("invoiceamount", invoiceamountField.getValue());
			}
			temp_UsageInvoiceJson.put("billforoperator", operators2);
			temp_UsageInvoiceJson.put("invoicearrears", invoicearrearsField.getValue());

			if (submissiondateField.getValue() == null) {
				temp_UsageInvoiceJson.put("submissiondate", "");
			} else {
				temp_UsageInvoiceJson.put("submissiondate",
						CommonUtils.convertLocalDateToString(submissiondateField.getValue()));
			}

			if (receiveddateField.getValue() == null) {
				temp_UsageInvoiceJson.put("receiveddate", "");
			} else {
				temp_UsageInvoiceJson.put("receiveddate",
						CommonUtils.convertLocalDateToString(receiveddateField.getValue()));
			}

			if (duedateField.getValue() == null) {
				temp_UsageInvoiceJson.put("duedate", "");
			} else {
				temp_UsageInvoiceJson.put("duedate", CommonUtils.convertLocalDateToString(duedateField.getValue()));
			}

		
			if (agreementNameField.getValue() != null) {
				temp_UsageInvoiceJson.put("agreementName", agreementNameField.getValue());
				temp_UsageInvoiceJson.put("agreementId", agreementNameIdMap2.get(agreementNameField.getValue()));
			} else {
				temp_UsageInvoiceJson.put("agreementName", "");
				temp_UsageInvoiceJson.put("agreementId", "");
			}
			

			temp_UsageInvoiceJson.put("remarks", remarksField.getValue());

			int lpsc_pay = 0;
			Double manualconsumption = 0.0, unitrate = 0.0;
			String meterserialNo, consumerNo;
			Double noofdays, openingreading, closingreading, calconsumption, perdayconsumption, ebAmt, fixloadcharge,
					dgcharge, fcucharge = 0.0, lpsccharge = 0.0, othercharge = 0.0, finalpay = 0.0;

			if (meterserialNoField.getValue() == null) {
				meterserialNo = "0";
			} else {
				meterserialNo = meterserialNoField.getValue();
			}
			if (consumerNoField.getValue() == null) {
				consumerNo = "0";
			} else {
				consumerNo = consumerNoField.getValue();
			}
			if (noofdaysField.getValue() == null) {
				noofdays = 0.0;
			} else {
				noofdays = noofdaysField.getValue();
			}
			if (opening_readingField.getValue() == null) {
				openingreading = 0.0;
			} else {
				openingreading = opening_readingField.getValue();
			}
			if (closing_readingField.getValue() == null) {
				closingreading = 0.0;
			} else {
				closingreading = closing_readingField.getValue();
			}

			if (lpsc_payableField.getValue()!=null && lpsc_payableField.getValue().equalsIgnoreCase("Yes")) {
				lpsc_pay = 1;
			} else {
				lpsc_pay = 0;
			}
			if (manual_consumptionField.getValue() == null) {
				manualconsumption = 0.0;
				isManualGiven=false;
			} else {
				manualconsumption = manual_consumptionField.getValue();
				isManualGiven=true;
			}
			if (calculated_consumptionField.getValue() == null) {
				calconsumption = 0.0;
			} else {
				calconsumption = calculated_consumptionField.getValue();
			}
			if (per_day_consumptionField.getValue() == null) {
				perdayconsumption = 0.0;
			} else {
				perdayconsumption = per_day_consumptionField.getValue();
			}
			if (unit_rateField.getValue() == null) {
				unitrate = 0.0;
			} else {
				unitrate = unit_rateField.getValue();
			}
			if (eb_amountField.getValue() == null) {
				ebAmt = 0.0;
			} else {
				ebAmt = eb_amountField.getValue();
			}
			if (fix_load_chargeField.getValue() == null) {
				fixloadcharge = 0.0;
			} else {
				fixloadcharge = fix_load_chargeField.getValue();
			}
			if (dg_chargeField.getValue() == null) {
				dgcharge = 0.0;
			} else {
				dgcharge = dg_chargeField.getValue();
			}
			if (fcu_chargeField.getValue() == null) {
				fcucharge = 0.0;
			} else {
				fcucharge = fcu_chargeField.getValue();
			}
			if (late_payment_service_chargeField.getValue() == null) {
				lpsccharge = 0.0;
			} else {
				lpsccharge = late_payment_service_chargeField.getValue();
			}
			if (otherchargesField.getValue() == null) {
				othercharge = 0.0;
			} else {
				othercharge = otherchargesField.getValue();
			}
			if (final_payable_amountField.getValue() == null) {
				finalpay = 0.0;
			} else {
				finalpay = final_payable_amountField.getValue();
			}

			JSONObject usage_detailsJson = new JSONObject();
			usage_detailsJson.put("meterserialno", meterserialNo);
			usage_detailsJson.put("consumerno", consumerNo);

			if (metertypeField.getValue() != null) {
				int metertype = meterTypeMap.get(metertypeField.getValue());
				usage_detailsJson.put("metertype", metertype);
			} else {
				usage_detailsJson.put("metertype", "");
			}
			usage_detailsJson.put("sanctionload", sanctionloadField.getValue());
			usage_detailsJson.put("noofdays", noofdays);
			usage_detailsJson.put("opening_reading", openingreading);
			usage_detailsJson.put("closing_reading", closingreading);
			usage_detailsJson.put("calculated_consumption", calconsumption);
			usage_detailsJson.put("manual_consumption", manualconsumption);
			usage_detailsJson.put("isManualGiven", isManualGiven);
			usage_detailsJson.put("per_day_consumption", perdayconsumption);
			usage_detailsJson.put("eb_amount", ebAmt);
			usage_detailsJson.put("unit_rate", unitrate);
			usage_detailsJson.put("fix_load_charge", fixloadcharge);
			usage_detailsJson.put("dg_charge", dgcharge);
			usage_detailsJson.put("fcu_charge", fcucharge);
			usage_detailsJson.put("late_payment_service_charge", lpsccharge);
			usage_detailsJson.put("othercharges", othercharge);
			usage_detailsJson.put("lpsc_payable", lpsc_pay);
			usage_detailsJson.put("final_payable_amount", finalpay);

			temp_UsageInvoiceJson.put("usage_details", usage_detailsJson);

			// temp_UsageInvoiceJson.put("Itemp_UsageInvoiceJson,invoiceJson);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void getUsageInvoiceRecordsForEmg(String sitecode) {
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GET_USAGE_INVOICE");
			url = url + "?SiteCode=" + URLEncoder.encode(sitecode);
			String resp = RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
					
			// System.out.println(resp);
			

			JSONArray sortedjsArr = sortByInvoiceStartDate(resp);
			System.out.println("sortedjsArr==" + sortedjsArr);
			String storedvalue = CommonUtils.getDraftData("4");
			System.out.println("storedvalue==" + storedvalue);
			if (storedvalue == null) {
				try {
//					opening_readingField
//							.setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString("OpeningReading")));
//					closing_readingField
//							.setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString("ClosingReading")));
//					calculated_consumptionField.setValue(
//							Double.parseDouble(sortedjsArr.getJSONObject(0).getString("CalculatedConsumption")));
					

					if(sortedjsArr!=null) {
						opening_readingField.setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString("ClosingReading")));
						
						closing_readingField.setValue(0.0);
					}
					

//					calculated_consumptionField.setValue(
//							Double.parseDouble(sortedjsArr.getJSONObject(0).getString("CalculatedConsumption")));
				} catch (Exception e) {
					e.printStackTrace();

				}
			}else {
				
				try {
					System.out.println("else");
					JSONObject js=new JSONObject(storedvalue);
					String invoiceStr=js.getString("InvoiceJson");
					JSONObject invoiceJson=new JSONObject(invoiceStr);
					String sitecode2=invoiceJson.getString("sitecode");
					if(!sitecode2.equalsIgnoreCase(sitecode)) {
						if(sortedjsArr!=null) {
							opening_readingField.setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString("ClosingReading")));
							
							closing_readingField.setValue(0.0);
						}
					}
					
				}catch (Exception e) {
					e.printStackTrace();

				}
			}
			/*
			 * LocalStorage.getItem(KEY_NAME, storedvalue -> {
			 * System.out.println("Stored value::==" + storedvalue); if (storedvalue ==
			 * null) { try { opening_readingField
			 * .setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
			 * "OpeningReading"))); closing_readingField
			 * .setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
			 * "ClosingReading"))); calculated_consumptionField.setValue(
			 * Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
			 * "CalculatedConsumption"))); } catch (Exception e) { e.printStackTrace();
			 * 
			 * } } });
			 */

		} catch (Exception e) {
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
					ApplicationConstants.DialogTypes.ERROR);
		}
	}

	/*
	 * private void getUsageInvoiceRecordsForFinance(String sitecode) { try {
	 * 
	 * String url =
	 * ApplicationConfiguration.getServiceEndpoint("GET_USAGE_INVOICE_FOR_FINANCE");
	 * url=url+"?SiteCode="+URLEncoder.encode(sitecode); String resp =
	 * RestServiceHandler.retriveJSON_GET(url,
	 * SiteAssetInventoryUIFramework.getFramework().getToken());
	 * 
	 * JSONArray sortedjsArr = sortByInvoiceStartDate(resp);
	 * LocalStorage.getItem(KEY_NAME, value -> {
	 * System.out.println("Stored value::==" + value); if (value == null) { try {
	 * opening_readingField
	 * .setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
	 * "OpeningReading"))); closing_readingField
	 * .setValue(Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
	 * "ClosingReading"))); calculated_consumptionField.setValue(
	 * Double.parseDouble(sortedjsArr.getJSONObject(0).getString(
	 * "CalculatedConsumption"))); } catch (Exception e) { e.printStackTrace();
	 * 
	 * } } });
	 * 
	 * 
	 * }catch(Exception e) { e.printStackTrace();
	 * SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(),
	 * ApplicationConstants.DialogTypes.ERROR); } }
	 */

	private JSONArray sortByInvoiceStartDate(String res) {//sort by max closing reading chnged on 5th Aug2023
		try {
			
			if (res != null || res.trim().length() > 0) {
				JSONArray jsonArray = new JSONArray(res);
				if (jsonArray.length() > 0) {
					List<JSONObject> jsonsList = new ArrayList<JSONObject>();
					for (int i = 0; i < jsonArray.length(); i++) {
						jsonsList.add(jsonArray.getJSONObject(i));
					}

					Collections.sort(jsonsList, new Comparator<JSONObject>() {
						@Override
						public int compare(JSONObject jo1, JSONObject jo2) {
							try {
							/*	String str1 = jo1.getString("Period_StartDate");
								String str2 = jo2.getString("Period_StartDate");

								date1 = CommonUtils.convertStringToLocalDate(str1, "dd-MMM-yyyy");
								date2 = CommonUtils.convertStringToLocalDate(str2, "dd-MMM-yyyy");*/
								
//								str1 = Integer.parseInt(jo1.getString("ClosingReading"));
//								str2 = Integer.parseInt(jo2.getString("ClosingReading"));
								
								
								d1 = Double.parseDouble(jo1.getString("ClosingReading"));
								d2 = Double.parseDouble(jo2.getString("ClosingReading"));
								
								
							} catch (JSONException e) {
								e.printStackTrace();
							}
							
//							Integer x = new Integer(str1);
//					        Integer y = new Integer(str2);
					        
					        Double x = new Double(d1);
					        Double y = new Double(d2);
							
							//return date1.compareTo(date2);
					        return x.compareTo(y);
						}
					});

					Collections.reverse(jsonsList);// descending
					sortedjsArr = new JSONArray(jsonsList);

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return sortedjsArr;

	}

}
