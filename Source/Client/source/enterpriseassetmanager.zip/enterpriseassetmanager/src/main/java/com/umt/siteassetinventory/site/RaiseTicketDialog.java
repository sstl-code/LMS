package com.umt.siteassetinventory.site;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.framework.componentfactory.UploadDialog;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.FailedEvent;
import com.vaadin.flow.component.upload.FileRejectedEvent;
import com.vaadin.flow.component.upload.Upload;

@CssImport("./styles/raise_ticket_dialog-styles.css")
public class RaiseTicketDialog extends Dialog 
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "RAISE_TICKET_DLG";

	private Div mainLayoutDiv;
	private Div titleBar;
	private Div buttonBar;
	private Div bodyLayout;
	private TextField siteCodeField;
	private ComboBox<String> problemCategoryCombo;
	private ComboBox<String> problemTypeCombo;
	//private TextArea problemDescArea;
	private Button saveBtn,cancelBtn;
	private String siteCode = "";
	//private VerticalLayout documentsVL;
	private VerticalLayout paramLayout;
	private HashMap<String, String> fileData = new HashMap<>();
	private HashMap<String, JSONObject> workflowNameDetailMap = new HashMap<>();
	private HashMap<String, List<Object>> workflowDataKeyValMap;
	private Set<String> troubleTicketCategorySet = new LinkedHashSet();
	private boolean dataSaved = false;
	//private List<Object> paramObjList = new ArrayList<>();
	//private Div paramSection;

	public RaiseTicketDialog(String siteCode, Set<String> troubleTicketCategorySet, HashMap<String, JSONObject> workflowNameDetailMap) 
	{
		this.siteCode = siteCode;
		if(workflowNameDetailMap!=null && workflowNameDetailMap.size()>0)
			this.workflowNameDetailMap = workflowNameDetailMap;
		if(troubleTicketCategorySet!=null && troubleTicketCategorySet.size()>0)
			this.troubleTicketCategorySet = troubleTicketCategorySet;
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		Label titleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(titleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		bodyLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_LAYOUT");

		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");

		buttonBar.add(saveBtn,cancelBtn);

		siteCodeField = UIFieldFactory.createTextField("", false, SCREENCD, "SITE_CODE");
		if (siteCode!=null && siteCode.trim().length()>0) {
			siteCodeField.setValue(siteCode);
		}
		siteCodeField.setEnabled(false);
		if(troubleTicketCategorySet==null || troubleTicketCategorySet.size()==0)
			troubleTicketCategorySet = new LinkedHashSet<>();
		problemCategoryCombo = UIFieldFactory.createComboBox(new ArrayList<>(), true, SCREENCD, "PROBLEM_CATEGORY");
		problemCategoryCombo.setLabel("Incident Category"); 
		problemCategoryCombo.setItems(troubleTicketCategorySet.stream());

		problemTypeCombo = UIFieldFactory.createComboBox(new ArrayList<>(), true, SCREENCD, "PROBLEM_TYPE");
		problemTypeCombo.setLabel("Incident Type");
		problemTypeCombo.setEnabled(false);

		//problemDescArea = UIFieldFactory.createTextArea("", true, SCREENCD, "PROBLEM_DESC");


		/*Label docHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_HEADER_LBL");

		Button docAddbtn = UIFieldFactory.createButton(SCREENCD, "DOC_ADD_BTN");

		HorizontalLayout docHeaderLayout = UIOrderedLayoutFactory.createHorizontalLayout(SCREENCD, "DOC_HEADER_HL");
		docHeaderLayout.add(docHeaderLbl, docAddbtn);

		Div documentheaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DOCUMENT_HEADER_DIV");
		Label docType = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_TYPE");
		documentheaderDiv.add(docType);*/

		VerticalLayout topLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "TOP_LAYOUT");
		paramLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DATA_DESC_LAYOUT");
		/*VerticalLayout lowerVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "LOWER_VL");
		documentsVL = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "DOCUMENT_VL");*/

		Div paramSectionHeader = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_SECTION_HEADER_DIV");
		Div paramSection = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_SECTION_DIV");
		Div paramSectionBoolean = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_SECTION_DIV_BOOLEAN");
		Div paramSectionText = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_SECTION_DIV_TEXT");
		Div paramSectionFile = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_SECTION_DIV_FILE");
		Label paramFieldHeaderLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATA_DESC_FIELD_HEADER_LBL");
		//		Label paramFieldNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATA_DESC_FIELD_NAME_LBL");
		//		Label paramFieldValLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATA_DESC_FIELD_VALUE_LBL");
		paramSectionHeader.add(paramFieldHeaderLbl);

		paramSection.add(paramSectionBoolean, paramSectionText, paramSectionFile);
		paramLayout.add(paramSectionHeader, paramSection);
		paramLayout.setVisible(false);
		/*documentsVL.setVisible(false);*/

		topLayout.add(siteCodeField, problemCategoryCombo, problemTypeCombo);
		//lowerVL.add(docHeaderLayout,documentheaderDiv,documentsVL);

		bodyLayout.add(topLayout, paramLayout/*, lowerVL*/);

		/*docAddbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {

				AccountDocumentUploadDialog dlg= new AccountDocumentUploadDialog(siteCode,1,"",customerVerificationStatus,true);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						AccountDocumentUploadDialog srcDlg = (AccountDocumentUploadDialog)event.getSource();
						if (dlg.isSaveBtnClicked()) {
							////System.out.println("dlg.isSaveBtnClicked()=="+dlg.isSaveBtnClicked());
							generateOtherDocumentRow(dlg,siteCode);
						} 
					}
				});
			}
		});*/

		problemCategoryCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				if (event.getValue()!=null && event.getValue().toString().trim().length()>0) {
					problemTypeCombo.setEnabled(true);
					loadIncidentTypes(event.getValue().toString());
				}
				else {
					problemTypeCombo.clear();
					problemTypeCombo.setEnabled(false);
				}
			}

		});

		problemTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				paramSectionBoolean.removeAll();
				paramSectionText.removeAll();
				paramSectionFile.removeAll();
				if (event.getValue()!=null && event.getValue().toString().trim().length()>0) {
					try 
					{
						paramLayout.setVisible(true);
						workflowDataKeyValMap = new HashMap<>();
						JSONObject launchDataJson = workflowNameDetailMap.get(problemTypeCombo.getValue().trim()).getJSONObject("launchDataTemplate");
						Iterator<String> paramKeysIterator = launchDataJson.keys();
						//paramSection.removeAll();

						while (paramKeysIterator.hasNext()) {
							String paramKey = paramKeysIterator.next();
							JSONObject paramJson = launchDataJson.getJSONObject(paramKey);

							/*if (paramType.equalsIgnoreCase("STRING") || paramType.equalsIgnoreCase("LONG") || paramType.equalsIgnoreCase("INTEGER")) {

							} */
							if (paramKey.equalsIgnoreCase("siteCode")) {
								continue;
							}
							else 
								if(paramJson.getBoolean("launchParam") /*&& paramJson.getBoolean("editable")*/) {
									List<Object> paramObjList = new ArrayList<>();
									String paramType = paramJson.getString("dataType");
									String contentType = paramJson.getString("contentType");

									Div eachDataDescSection = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DESC_SECTION_DIV");
									Label paramLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DATA_DESC_LBL");
									paramLbl.setText(paramKey);
									//eachDataDescSection.add(paramLbl);
									switch (contentType.toUpperCase()) {
									case "TEXT":
										paramObjList.add(paramType);
										switch (paramType.toUpperCase()) {
										case "DOUBLE":
											NumberField paramNumField = UIFieldFactory.createNumberField(false, SCREENCD, "DATA_DESC_FIELD");
											//paramNumField.setLabel(paramKey);	
											paramObjList.add(paramNumField);
											eachDataDescSection.add(paramNumField);
											paramNumField.setLabel(paramKey);
											paramSectionText.add(eachDataDescSection);	
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										case "DATE":
											DatePicker paramDateField = UIFieldFactory.createDatePicker(false, SCREENCD, "DATA_DESC_FIELD");
											//paramDateField.setLabel(paramKey);
											paramObjList.add(paramDateField);
											eachDataDescSection.add(paramDateField);
											paramDateField.setLabel(paramKey);
											paramSectionText.add(eachDataDescSection);
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										case "BOOLEAN":
											Checkbox paramChkBox = UIFieldFactory.createCheckbox(false, false, SCREENCD, "DATA_DESC_FIELD");
											//paramChkBox.setLabel(paramKey);
											paramObjList.add(paramChkBox);
											eachDataDescSection.add(paramChkBox);
											paramChkBox.setLabel(paramKey);
											paramSectionBoolean.add(eachDataDescSection);
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										case "INTEGER":
											TextField paramTextFieldInt = UIFieldFactory.createTextField("", false, SCREENCD, "DATA_DESC_FIELD");
											paramTextFieldInt.setPattern("[0-9]+");
											paramTextFieldInt.setPreventInvalidInput(true);
											//paramTextField.setLabel(paramKey);
											paramObjList.add(paramTextFieldInt);
											eachDataDescSection.add(paramTextFieldInt);
											paramTextFieldInt.setLabel(paramKey);
											paramSectionText.add(eachDataDescSection);
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										case "LONG":
											TextField paramTextFieldLong = UIFieldFactory.createTextField("", false, SCREENCD, "DATA_DESC_FIELD");
											paramTextFieldLong.setPattern("[0-9]+");
											paramTextFieldLong.setPreventInvalidInput(true);
											//paramTextField.setLabel(paramKey);
											paramObjList.add(paramTextFieldLong);
											eachDataDescSection.add(paramTextFieldLong);
											paramTextFieldLong.setLabel(paramKey);
											paramSectionText.add(eachDataDescSection);
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										default:
											TextField paramTextField = UIFieldFactory.createTextField("", false, SCREENCD, "DATA_DESC_FIELD");
											//paramTextField.setLabel(paramKey);
											paramObjList.add(paramTextField);
											eachDataDescSection.add(paramTextField);
											paramTextField.setLabel(paramKey);
											paramSectionText.add(eachDataDescSection);
											//workflowDataKeyValMap.put(paramKey, paramObjList);
											break;
										}
										break;
									case "FILE":
										paramObjList.add(contentType);
										eachDataDescSection.add(paramLbl);
										paramSectionFile.add(eachDataDescSection);
										eachDataDescSection.add(generateUploadRow(paramKey, paramJson.getString("fileType"), contentType));
										//workflowDataKeyValMap.put(paramKey, paramObjList);
										break;
									case "CHOICE":
										paramObjList.add(contentType);
										List<Object> choicesList = new ArrayList<>();
										JSONArray choicesJson = paramJson.getJSONArray("choices");
										for (int j = 0; j < choicesJson.length(); j++) {
											//System.out.println("paramJson.getJSONArray(\"choices\").getString(j)= "+choicesJson.get(j));
											choicesList.add(paramJson.getJSONArray("choices").get(j));
										}

										//System.out.println("choicesList= "+choicesList);
										ComboBox<Object> paramCombo = UIFieldFactory.createComboBox(choicesList, false, SCREENCD, "DATA_DESC_FIELD");
										paramObjList.add(paramCombo);
										eachDataDescSection.add(paramCombo);
										paramCombo.setLabel(paramKey);
										paramSectionText.add(eachDataDescSection);
										break;
										/*default:
										break;*/
									}
									workflowDataKeyValMap.put(paramKey, paramObjList);
									//paramSection.add(eachDataDescSection);	
									//System.out.println("paramObjList="+paramObjList.toString());
									//System.out.println("workflowDataKeyValMap="+workflowDataKeyValMap.toString());
								}
						}
					} 
					catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});



		mainLayoutDiv.add(titleBar,bodyLayout,buttonBar);

		add(mainLayoutDiv);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(false);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				cancelBtnClicked();
			}
		});

		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				if (validate()) {
					saveBtnClicked();
				}
			}
		});
	}

	private Div generateUploadRow(String paramName, String fileType, String contentType) 
	{
		Div uploadDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "DATA_DESC_UPLOAD_DIV");
		Div uploadedFileDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "UPLOADED_FILE_DIV");
		Label docNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DOC_NAME_LBL");
		Image removeIcon = UIHtmlFieldFactory.createImage(SCREENCD, "REMOVE_BTN_ICON");
		Div removeBtn = UIHtmlFieldFactory.createDiv(SCREENCD, "REMOVE_BTN");
		removeBtn.add(removeIcon);
		Button uploadbtn = UIFieldFactory.createButton(SCREENCD, "DATA_DESC_UPLOAD_BTN");
		//uploadbtn.setText("Upload"/*+fileType+" "+contentType*/);
		com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon uploadIcon = FontAwesome.Solid.UPLOAD.create();
		uploadbtn.setIcon(uploadIcon); 
		uploadDiv.add(uploadbtn, uploadedFileDiv);

		uploadbtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {

			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				//System.out.println("uploadbtn clicked....");
				UploadDialog uploadDlg = new UploadDialog(fileType);

				switch (fileType.toUpperCase()) {
				case "IMAGE":
					String[] acceptedFileTypes1 = {".png", ".jpg", ".jpeg", ".gif"};
					uploadDlg.setAcceptedFileTypes(acceptedFileTypes1);
					break;
				case "TEXT":
					String[] acceptedFileTypes2 = {".txt"};
					uploadDlg.setAcceptedFileTypes(acceptedFileTypes2);
					break;
				default:
					String[] acceptedFileTypes3 = {".xlsx",".xls", ".csv", ".pdf", ".doc", ".docx", ".txt", ".png", ".jpg", ".jpeg", ".gif"};
					uploadDlg.setAcceptedFileTypes(acceptedFileTypes3);
					break;
				}
				uploadDlg.open();
				Upload uploadDoc = uploadDlg.getUpload();

				uploadDoc.addFailedListener(new ComponentEventListener<FailedEvent>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(FailedEvent event) {			
						List<Object> workflowDataVal = workflowDataKeyValMap.get(paramName);
						workflowDataVal.add(new JSONObject());
						workflowDataKeyValMap.put(paramName, workflowDataVal);
						//System.out.println("workflowDataKeyValMap failed="+workflowDataKeyValMap.toString());
						uploadedFileDiv.removeAll();
					}
				});

				uploadDoc.addFileRejectedListener(new ComponentEventListener<FileRejectedEvent>() {
					private static final long serialVersionUID = 1L;

					@Override
					public void onComponentEvent(FileRejectedEvent event) {
						String acceptedFileTypes = "";
						for (int i = 0; i < uploadDoc.getAcceptedFileTypes().size(); i++) {
							acceptedFileTypes+= uploadDoc.getAcceptedFileTypes().get(i)+", ";
						}
						String msg = "File must be of "+acceptedFileTypes.substring(0, acceptedFileTypes.lastIndexOf(","))+" format.Please upload proper file.";
						SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.ERROR);
						List<Object> workflowDataVal = workflowDataKeyValMap.get(paramName);
						workflowDataVal.add(new JSONObject());
						workflowDataKeyValMap.put(paramName, workflowDataVal);
						//System.out.println("workflowDataKeyValMap Rejected="+workflowDataKeyValMap.toString());
						uploadedFileDiv.removeAll();
					}
				});

				uploadDlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							if(event.getSource() instanceof UploadDialog) {
								UploadDialog eventSrcDlg = (UploadDialog)event.getSource();
								JSONObject filedataJson = new JSONObject();
								List<Object> workflowDataVal = workflowDataKeyValMap.get(paramName);
								String base64EncodedFileContent="";
								if (workflowDataVal.size()>0) {
									for (int i = workflowDataVal.size()-1; i > 0; i--) {
										workflowDataVal.remove(i);
									}
								}
								if(eventSrcDlg.isDoneClicked()) {							
									try
									{
										String fileExtension = uploadDlg.getFileExtension();
										if (uploadDlg.getInputStream()!=null) {
											if (fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif")) 
											{
												BufferedImage image = ImageIO.read(uploadDlg.getInputStream());
												ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
												ImageIO.write(image, fileExtension, outputStream);
												base64EncodedFileContent = Base64.getEncoder().encodeToString(outputStream.toByteArray());
												if (base64EncodedFileContent!=null && base64EncodedFileContent.trim().length()>0) {
													ThumbnailImage img = new ThumbnailImage(base64EncodedFileContent);
													uploadedFileDiv.add(img.displayFileImage(), removeBtn);

												}

											}
											else
											{
												byte[] bytes = IOUtils.toByteArray(uploadDlg.getInputStream());
												base64EncodedFileContent = Base64.getEncoder().encodeToString(bytes);
												if (base64EncodedFileContent!=null && base64EncodedFileContent.trim().length()>0) {
													docNameLbl.setText(uploadDlg.getFileName());
													uploadedFileDiv.add(docNameLbl, removeBtn);
												}

											}	
										}
										if (base64EncodedFileContent!=null && base64EncodedFileContent.trim().length()>0) {
											filedataJson.put("filename", uploadDlg.getFileName());
											filedataJson.put("content", base64EncodedFileContent);
											//System.out.println("filedataJson="+filedataJson);
											workflowDataVal.add(filedataJson);
											//docNameLbl.setText(uploadDlg.getFileName());
											//uploadDiv.add(docNameLbl, removeBtn);
										}

									} catch (Exception ex) {
										ex.printStackTrace();
										//base64EncodedFileContent = "";
										workflowDataVal.add(new JSONObject());
									}
									workflowDataKeyValMap.put(paramName, workflowDataVal);
									//System.out.println("workflowDataKeyValMap="+workflowDataKeyValMap.toString());
								}     
								if(eventSrcDlg.isCancelClicked()) {  
									/*workflowDataVal.add(new JSONObject());                                           
									workflowDataKeyValMap.put(paramName, workflowDataVal);                */           
									//System.out.println("workflowDataKeyValMap="+workflowDataKeyValMap.toString()); 
								}
							}
						}
					}
				});

			}
		});

		removeBtn.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				List<Object> workflowDataVal = workflowDataKeyValMap.get(paramName);
				workflowDataVal.remove(1);
				workflowDataVal.add(new JSONObject());
				workflowDataKeyValMap.put(paramName, workflowDataVal);
				//System.out.println("workflowDataKeyValMap removeBtn clicked="+workflowDataKeyValMap.toString());
				uploadedFileDiv.removeAll();
			}
		});

		return uploadDiv;	
	}


	private void loadIncidentTypes(String incidentCategory)
	{
		List<String> incidentNameList = new ArrayList<>();
		//System.out.println(workflowNameDetailMap.toString());
		try {
				workflowNameDetailMap.forEach((k,v) -> {
				JSONObject properties;
				//System.out.println(k);
				try {
					properties = v.getJSONObject("properties");
					if(properties.has("Category") && properties.getString("Category")!=null && properties.getString("Category").trim().length()>0 &&
							properties.getString("Category").equals(incidentCategory))
					{
						incidentNameList.add(k);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

			});
			problemTypeCombo.setItems(incidentNameList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*private void generateOtherDocumentRow(AccountDocumentUploadDialog obj, String siteCode) 
	{
		////System.out.println("entered generateOtherDocumentRow...");
		if(obj.getBase64EncodedFileContent()==null || obj.getBase64EncodedFileContent().trim().length()==0)
		{
			SiteAssetInventoryUIFramework.getFramework().showMessage("COMMON", "DOC_UPLOAD_ERROR", ApplicationConstants.DialogTypes.INFO);
			return;
		}
		else
		{
			documentsVL.setVisible(true);
			RaiseTicketDocUploadBean docUploadBean = new RaiseTicketDocUploadBean(obj.getDocumentNameTextfield().getValue(), this, siteCode, SCREENCD);
			documentsVL.add(docUploadBean.getRaiseTicketDocUploadBean());
			uploadedFilelist.add(docUploadBean);
			fileData.put(obj.getDocumentNameTextfield().getValue(), "data:"+obj.getFileFormat()+":"+obj.getBase64EncodedFileContent());
		}
	}

	public void removeOtherDocumentrow(RaiseTicketDocUploadBean beanobj) 
	{
		documentsVL.remove(beanobj.recordHL);
		uploadedFilelist.remove(beanobj);
		fileData.remove(beanobj.getDocNameLbl().getText());
	}

	protected void addDocument(String documentName, String documentContent) 
	{
		try 
		{

			Form l_objInputForm = new Form();
			l_objInputForm.add("siteCode",siteCode);
			l_objInputForm.add("DocumentType", documentName);
			l_objInputForm.add("DocumentContent", documentContent);
			l_objInputForm.add("ModBy", SiteAssetInventoryUIFramework.getFramework().getUserInfo().getEmailId());

			String base_URL = ApplicationConfiguration.getServiceEndpoint("ADDACCOUNTDOCUMENT");
			//////System.out.println(base_URL+" ::::::::: "+l_objInputForm);
			RestServiceHandler.createJSON_POST(base_URL, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());

		} 
		catch (Exception ex) 
		{
			//ex.printStackTrace();
			logger.error(ex.getMessage());
			SiteAssetInventoryUIFramework.getFramework().showMessage(ex.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			//getDocUploadStatus = false;

		}

	}
	 */

	protected void saveBtnClicked()
	{
		try
		{
			Iterator<String> problemDescKeys = workflowDataKeyValMap.keySet().iterator();
			Form l_objInputForm = new Form();
			l_objInputForm.add("siteCode", siteCode);
			while (problemDescKeys.hasNext()) {
				String problemDescKey = problemDescKeys.next();
				switch (workflowDataKeyValMap.get(problemDescKey).get(0).toString().toUpperCase()) {
				case "DOUBLE":
					if (((NumberField)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue()==null) {
						l_objInputForm.add(problemDescKey, "");
					}
					else
						l_objInputForm.add(problemDescKey, ((NumberField)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue());
					break;
				case "DATE":
					if (((DatePicker)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue()==null) {
						l_objInputForm.add(problemDescKey, "");
					}
					else
						l_objInputForm.add(problemDescKey, CommonUtils.convertLocalDateToString(((DatePicker)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue()));
					break;
				case "BOOLEAN":
					l_objInputForm.add(problemDescKey, ((Checkbox)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue());
					break;
				case "CHOICE":
					l_objInputForm.add(problemDescKey, ((ComboBox<Object>)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue());
					break;
				case "FILE":
					if (workflowDataKeyValMap.get(problemDescKey).size()<2) {
						l_objInputForm.add(problemDescKey, new JSONObject());
					} 
					else {
						l_objInputForm.add(problemDescKey, workflowDataKeyValMap.get(problemDescKey).get(1));
					}			
					break;
				default:
					if (((TextField)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue()==null) {
						l_objInputForm.add(problemDescKey, "");
					}
					else
						l_objInputForm.add(problemDescKey, ((TextField)workflowDataKeyValMap.get(problemDescKey).get(1)).getValue());
					break;
				}
			}
			//l_objInputForm.add("Problem Description", problemDescArea.getValue().trim());
			String create_URL = ApplicationConfiguration.getServiceEndpoint("CREATETROUBLETICKET");
			//System.out.println(create_URL+" ::::::::: "+l_objInputForm.toString());

			String urlPathParamEngineName = workflowNameDetailMap.get(problemTypeCombo.getValue().trim()).getString("engine"); 
			urlPathParamEngineName = CommonUtils.getEncodedText(urlPathParamEngineName).replaceAll("\\+","%20");
			String urlPathParamWorkflowName = CommonUtils.getEncodedText(problemTypeCombo.getValue().trim()).replaceAll("\\+","%20");
			create_URL += urlPathParamEngineName + "/" + urlPathParamWorkflowName;
			//System.out.println(create_URL+" ::::::::: "+l_objInputForm.toString());
			String instanceId = RestServiceHandler.createJSON_POST(create_URL, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());

			//System.out.println(create_URL+"::::"+instanceId);
			/*Form l_objInputForm = new Form();
			l_objInputForm.add("siteCode", problemDescArea.getValue().trim());
			l_objInputForm.add("Problem Description", problemDescArea.getValue().trim());
			String base_URL = ApplicationConfiguration.getServiceEndpoint("GET_WORKFLOWSDETAILS");
			//////System.out.println(base_URL+" ::::::::: "+l_objInputForm);
			RestServiceHandler.updateJSON_PUT(base_URL+instanceId, l_objInputForm, SiteAssetInventoryUIFramework.getFramework().getToken());
			////System.out.println(base_URL+instanceId);*/

			/*Iterator<String> documentNameKeyIterator = fileData.keySet().iterator();
			while (documentNameKeyIterator.hasNext()) {
				String documentNameKey = documentNameKeyIterator.next();
				addDocument(documentNameKey, fileData.get(documentNameKey));
			}*/

			/*
			 * if(fileData.size()>0) SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,
			 * "DOC_ADDITION_SUCCESSFUL", ApplicationConstants.DialogTypes.INFO);
			 */
			String msg= SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "TROUBLETICKET_SAVE_SUCCESSFUL");
			msg = msg.replaceAll("@@INSTANCEID@@", instanceId);
			Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
			dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
					if(!event.isOpened()) {
						dataSaved = true;
						close();	
					}
				}
			});
		}
		catch (Exception e) {
			close();
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}
	}

	public boolean isNewTicketCreated() {
		return dataSaved;
	}

	protected void cancelBtnClicked()
	{
		close();	
	}

	private boolean validate()
	{
		problemTypeCombo.setInvalid(false);

		if(problemTypeCombo.getValue() == null || problemTypeCombo.getValue().trim().length() == 0)
		{
			problemTypeCombo.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "PROBLEM_TYPE_MANDATORY"));
			problemTypeCombo.setInvalid(true);
			problemTypeCombo.focus();
			return false;
		}
		return true;

	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

}
