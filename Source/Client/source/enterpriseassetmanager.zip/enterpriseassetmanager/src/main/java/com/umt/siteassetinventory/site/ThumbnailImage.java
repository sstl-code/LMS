package com.umt.siteassetinventory.site;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Base64;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.server.InputStreamFactory;
import com.vaadin.flow.server.StreamResource;

@CssImport("./styles/thumbnail_img-styles.css")
public class ThumbnailImage extends VerticalLayout
{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "THUMBNAIL_IMAGE";
	private String base64EncodedFileContent = "";
	private Image fileImage;
	private Div imageDiv;
	/*private String imagefilename;
	private Label TitleLbl;
	private Div titleBar;*/


	public ThumbnailImage(String base64EncodedFileContent/*, String imagefilename*/) 
	{
		this.base64EncodedFileContent = base64EncodedFileContent;
		//this.imagefilename = imagefilename;
		addClassName(SCREENCD+"_MAIN_LAYOUT");		
	}

	public Div displayFileImage()
	{
		imageDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "IMAGE_DIV");
		if(base64EncodedFileContent != null && base64EncodedFileContent.trim().length() > 0) 
		{
			byte[] imageFileContent = Base64.getDecoder().decode(base64EncodedFileContent);
			StreamResource fileStreamResource = new StreamResource("FILE_IMAGE", new InputStreamFactory() {
				private static final long serialVersionUID = 1L;

				@Override
				public InputStream createInputStream() {

					return new ByteArrayInputStream(imageFileContent);
				}
			});

			fileImage = new Image(fileStreamResource, "FILE_IMAGE1");
			fileImage.addClassName(SCREENCD + "_FILE_IMAGE1");
		}
		else {
			fileImage = UIHtmlFieldFactory.createImage(SCREENCD, "FILE_IMAGE1");

		}
		imageDiv.removeAll();
		imageDiv.add(fileImage);

		return imageDiv;

	}

}
