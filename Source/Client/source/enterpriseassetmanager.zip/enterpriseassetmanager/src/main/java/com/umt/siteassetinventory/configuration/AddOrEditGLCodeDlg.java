package com.umt.siteassetinventory.configuration;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;


@CssImport("./styles/equipment_type_master-styles.css")
public class AddOrEditGLCodeDlg extends Dialog{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_GLCODE_DLG";

	private TextField glCodeField, glNameField, descFld;
	private ComboBox<String> statusCombo;
	private String id;
	private Div titleBar;
	private Div buttonBar;
	private Div bodyDiv;
	private Div mainLayout;
	private Button saveBtn,cancelBtn;
	private Label TitleLbl;
	public boolean success=true;
	
	public AddOrEditGLCodeDlg(ConfigView parent,String mode) {
		
		mainLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT");
		bodyDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BODY_DIV");
		titleBar = UIHtmlFieldFactory.createDiv(SCREENCD, "TITLE_BAR");
		TitleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TITLE_LBL");
		titleBar.add(TitleLbl);
		buttonBar = UIHtmlFieldFactory.createDiv(SCREENCD, "BUTTON_BAR");
		saveBtn = UIFieldFactory.createButton(SCREENCD, "SAVE_BTN");
		cancelBtn = UIFieldFactory.createButton(SCREENCD, "CANCEL_BTN");
		buttonBar.add(saveBtn,cancelBtn);
		
		glCodeField = UIFieldFactory.createTextField("", true, SCREENCD, "GLCODE_FIELD");
	//	glNameField = UIFieldFactory.createTextField("", true, SCREENCD, "GLCODE_NAME_FIELD");
		descFld = UIFieldFactory.createTextField("", true, SCREENCD, "DESC_FIELD");

		statusCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV(SCREENCD, "SERVICE_TYPE_LIST", ','), true, 
				SCREENCD, "SERVICE_TYPE_COMBO");
		
		bodyDiv.add(glCodeField,descFld, statusCombo);
		
		mainLayout.add(bodyDiv);
		add(titleBar, mainLayout,buttonBar);
		getElement().setAttribute("theme", "capture-timed-value-dialog");
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		open();

		cancelBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				close();
			}
		});
		
		saveBtn.setDisableOnClick(true);
		saveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				if(mode.equalsIgnoreCase("Add")) {
					saveData();
				}else {
					updateData();
				}
				
			}
		});
		
		
		statusCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<String> event) {
				String value = event.getValue();
				if (value != null) {
					statusCombo.setInvalid(false);
					statusCombo.setErrorMessage("");
				}else {
					statusCombo.setInvalid(true);
					statusCombo.focus();
					statusCombo.setErrorMessage("Please Fill up this field");
				}

			}
		});
		

	}

	

	protected void saveData() {
		boolean valid=validation();
		try {
		if(!valid) {
			return;
		}else {
				String status;
				if(statusCombo.getValue().equalsIgnoreCase("Active")) {
					status="1";
				}else {
					status="0";
				}
		//		saveBtn.setEnabled(false);
				Form formData = new Form();
				formData.add("GLCode",glCodeField.getValue());
				formData.add("Description",descFld.getValue());
				formData.add("Status",status);
				
				System.out.println("formData="+formData);
		
				String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("ADDGLCODE");
				RestServiceHandler.createJSON_POST(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"ADD_GLCODE",ApplicationConstants.DialogTypes.INFO);
				success=true;
				close();
			
			
		}
		}catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			success=false;
//			saveBtn.setEnabled(true);
		}
		finally {
			saveBtn.setEnabled(true);
		}
		
	}
	
	protected void updateData() {
		boolean valid=validation();
		try {
				if(!valid) {
					return;
				}else {
					
						String status;
						if(statusCombo.getValue().equalsIgnoreCase("Active")) {
							status="1";
						}else {
							status="0";
						}
		//				saveBtn.setEnabled(false);
						Form formData = new Form();
						formData.add("Id",id);
						formData.add("GLCode",glCodeField.getValue());
						formData.add("Description",descFld.getValue());
						formData.add("Status",status);
						
						System.out.println("formData="+formData);
				
						String serviceEndPoint = ApplicationConfiguration.getServiceEndpoint("UPDATEGLCODE");
						RestServiceHandler.updateJSON_PUT(serviceEndPoint, formData,SiteAssetInventoryUIFramework.getFramework().getToken());
						SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"UPDATE_GLCODE",ApplicationConstants.DialogTypes.INFO);
						success=true;
						close();
					
					
				}
		}catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}else {
				SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
			success=false;
			saveBtn.setEnabled(true);
		}
		finally {
			saveBtn.setEnabled(true);
		}
				
			}
	
	private boolean validation() {
		boolean valid=true;
		if(glCodeField.getValue()==null || glCodeField.getValue().length()<=0) {
			glCodeField.setInvalid(true);
			glCodeField.setErrorMessage("Please fill out this field");
			valid=false;
		}else if(descFld.getValue()==null || descFld.getValue().length()<=0) {
			descFld.setInvalid(true);
			descFld.setErrorMessage("Please fill out this field");
			valid=false;
		}else if(statusCombo.getValue()==null || statusCombo.getValue().length()<=0) {
			statusCombo.setInvalid(true);
			statusCombo.setErrorMessage("Please fill out this field");
			valid=false;
		}else {
		}
		return valid;
	}



	

	public void setFieldValue(String glcode,String desc, String status, String id) {
		
		glCodeField.setValue(glcode); 
		descFld.setValue(desc); 
		statusCombo.setValue(status); 
		glCodeField.setEnabled(false);
		TitleLbl.setText("Edit GL Code");
		this.id=id;
	}

}
