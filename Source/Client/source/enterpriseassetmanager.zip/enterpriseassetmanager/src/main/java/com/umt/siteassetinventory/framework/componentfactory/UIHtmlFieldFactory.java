package com.umt.siteassetinventory.framework.componentfactory;

import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.resourcemanager.ResourceUtil;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Span;

public class UIHtmlFieldFactory 
{
	public static Label createLabel(String screencd, String componentcd)
	{
		String value = SiteAssetInventoryUIFramework.getFramework().getLabel(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);

		Label label = new Label(ResourceUtil.getConfiguredValueAt(configuredvalues, 0));
		label.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return label;
	}
	
	public static Label createLabel(String text, String screencd, String componentcd)
	{
		Label label = new Label(text);
		label.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return label;
	}
	
	public static Div createDiv(String screencd, String componentcd)
	{
		Div div = new Div();
		div.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return div;
	}
	
	public static Hr createHR(String screencd, String componentcd)
	{
		Hr hr = new Hr();
		hr.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return hr;
	}
	
	public static H1 createH1(String screencd, String componentcd)
	{
		H1 h1 = new H1();
		h1.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return h1;
	}
	
	public static H3 createH3(String screencd, String componentcd)
	{
		H3 h3 = new H3();
		h3.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return h3;
	}
	
	public static Image createImage(String screencd, String componentcd)
	{
		String value = SiteAssetInventoryUIFramework.getFramework().getImageConfiguration(screencd, componentcd);
		String[] configuredvalues = ResourceUtil.parseConfiguredValue(value);
		
		Image image = new Image(ResourceUtil.getConfiguredValueAt(configuredvalues, 0), ResourceUtil.getConfiguredValueAt(configuredvalues, 1));
		image.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return image;
	}
	
	public static Span createSpan(String text, String screencd, String componentcd) {
		Span span = new Span(text);	
		span.addClassName(screencd.toUpperCase() + "_" + componentcd.toUpperCase());
		return span;
	}
}
