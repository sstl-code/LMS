package com.umt.siteassetinventory.application;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/siteassetinventorylauncher", loadOnStartup = 0)
public class Launcher extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static String applicationRootDirectory;
    
    public Launcher() {
        super();
    }
    
    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
    	
    	ApplicationConfiguration.init();
    	String rootPath = getServletContext().getRealPath("/");
    	setApplicationRootDirectory(rootPath);
    	
    }
          
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("Invalid request!!!");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public static void setApplicationRootDirectory(String rootPath) {
		applicationRootDirectory = rootPath;
	}
	
	protected static String getApplicationRootDirectory() {
		return applicationRootDirectory;
	}
}
