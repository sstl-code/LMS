package com.umt.siteassetinventory.login;

import java.util.LinkedHashMap;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.flowingcode.vaadin.addons.fontawesome.FontAwesome;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.MainView;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIOrderedLayoutFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;

@Route(value = "changepassword", layout = MainView.class)
@CssImport("./styles/changepassword-styles.css")
public class ChangePassword extends VerticalLayout
{
	private static final long serialVersionUID = 1L;
	public static final String SCREENCD = "CHANGEPASSWORD";
	private Button submitBtn;
	
	private String strPasswdMinLengthCnt = "";
    private String strPasswdMaxLengthCnt = "";
    private String strUpperCaseCnt = "";
    private String strLowerCaseCnt = "";
    private String strDigitCnt = "";
    private String strSpecialCharCnt = "";
    private String strPasswordPolicy = "";
    private String strAllowableSpecialChars = "";
    private PasswordField oldPassword = null; 
    private PasswordField newPassword = null; 
    private PasswordField confirmPassword = null; 
    private Div infodiv = null;
    private com.flowingcode.vaadin.addons.fontawesome.FontAwesome.Solid.Icon infoIcon = null;
 
	
	public ChangePassword()
	{
		SiteAssetInventoryUIFramework.getFramework().getApplicationMainView().showNavigationBar("Change Password");
		addClassName(SCREENCD +"_MAIN_LAYOUT");
		
		VerticalLayout parentLayout = UIOrderedLayoutFactory.createVerticalLayout(SCREENCD, "PARENT_LAYOUT");

		oldPassword = UIFieldFactory.createPasswordField(true, SCREENCD, "OLD_PASSWORD_INPUT");
		newPassword = UIFieldFactory.createPasswordField(true, SCREENCD, "NEW_PASSWORD_INPUT");
		confirmPassword = UIFieldFactory.createPasswordField(true, SCREENCD, "CONFIRM_PASSWORD_INPUT");
		submitBtn = UIFieldFactory.createButton(SCREENCD, "SUBMIT_BTN");
		
		
		infodiv = UIHtmlFieldFactory.createDiv(SCREENCD, "INFO_DIV");
		Label l_objInfo = UIHtmlFieldFactory.createLabel(SCREENCD, "");
		infoIcon = FontAwesome.Solid.INFO_CIRCLE.create();
		infoIcon.addClassName("icon_style");
		strPasswdMinLengthCnt = ApplicationConfiguration.getConfigurationValue("PASSWORD_MIN_LENGTH");
		strPasswdMaxLengthCnt = ApplicationConfiguration.getConfigurationValue("PASSWORD_MAX_LENGTH");
		strUpperCaseCnt = ApplicationConfiguration.getConfigurationValue("PASSWORD_UPPERCASE_CNT");
		strLowerCaseCnt = ApplicationConfiguration.getConfigurationValue("PASSWORD_SMALLCASE_CNT");
		strDigitCnt = ApplicationConfiguration.getConfigurationValue("PASSWORD_DIGIT_CNT");
		strSpecialCharCnt = ApplicationConfiguration.getConfigurationValue("SPECIAL_CHAR_CNT");
		strAllowableSpecialChars = ApplicationConfiguration.getConfigurationValue("SPECIAL_CHAR_ALLOWED");
		strPasswordPolicy = ApplicationConfiguration.getConfigurationValue("PASSWORD_POLICY");
		l_objInfo.setTitle(strPasswordPolicy);
		l_objInfo.add(infoIcon);
		infodiv.add(oldPassword,newPassword,l_objInfo,confirmPassword);
	 
		submitBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				submitButtonClickHandler(oldPassword, newPassword, confirmPassword);
			}
		});
		
		parentLayout.add(infodiv, submitBtn);
		add(parentLayout);
	}
	protected void submitButtonClickHandler(PasswordField oldPassword, PasswordField newPassword, PasswordField confirmPassword) {
			
			if(!validatePassword()) 
			{ 
				return;
			}	
		
			changePassword(oldPassword.getValue(), newPassword.getValue());
	}
	private boolean validatePassword() 
	{
		oldPassword.setInvalid(false);
		newPassword.setInvalid(false);
		confirmPassword.setInvalid(false);
		
		int i_lowercasecnt = 0;
		int i_uppercasecnt = 0;
		int i_digitcnt = 0;
		int i_specialcharcnt = 0;
		int i_count = 0;
		int i_spclcharnotfound = 0;
		String strChar = "";
	    String strPassword = newPassword.getValue();
	  
	    while(i_count < strPassword.length())
    	{
    	    char ch = strPassword.charAt(i_count);
    	    strChar = Character.toString(ch);
    	    if(ch >= 'A' && ch <= 'Z')
    	    {
    	    	i_uppercasecnt++;
    	    }
    	    else if(ch >='a' && ch <= 'z')
    	    {
    	    	i_lowercasecnt++;
    	    }
    	    else if(ch >= '0' && ch <= '9')
    	    {
    	    	i_digitcnt++;
    	    }
    	    else 
    	    {
    	    	if(!strAllowableSpecialChars.contains(strChar))
    	    	{
    	    		i_spclcharnotfound++;
    	        }
    	    	i_specialcharcnt++;
    	    }
    	    i_count++;
    	}
		
			
		if (oldPassword.getValue() == null || oldPassword.getValue().trim().length() == 0) 
		{
			oldPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "OLDPASSWORD_MANDATORY"));
			oldPassword.setInvalid(true);
			oldPassword.focus();
			return false;
		}
	
		else if (newPassword.getValue() == null || newPassword.getValue().trim().length() == 0) 
		{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "NEWPASSWORD_MANDATORY"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
	
		else if(newPassword.getValue().equals(oldPassword.getValue()))
		{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "NEWANDOLDPWDMATCH"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
	 
		else if(strPassword.length() < Integer.parseInt(strPasswdMinLengthCnt))
		{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "MIN_LENGTH")+" "+strPasswdMinLengthCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CHARACTERS"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
		
		else if(strPassword.length() > Integer.parseInt(strPasswdMaxLengthCnt))
		{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "MAX_LENGTH")+" "+strPasswdMaxLengthCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CHARACTERS"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
		else if(i_uppercasecnt < Integer.parseInt(strUpperCaseCnt))
    	{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CASE_CNT")+" "+strUpperCaseCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "UPPERCASE_CNT"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
	    }
		else if(i_lowercasecnt < Integer.parseInt(strLowerCaseCnt))
    	{
			newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CASE_CNT")+" "+strLowerCaseCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "LOWERCASE_CNT"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
		else if(i_digitcnt < Integer.parseInt(strDigitCnt))
    	{
    		newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CASE_CNT")+" "+strDigitCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "DIGITS"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
	    }
    	else if(i_specialcharcnt < Integer.parseInt(strSpecialCharCnt))
    	{
    		newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CASE_CNT")+" "+strSpecialCharCnt+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "SPECIALCASE_CNT"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
		}
    	else if(i_spclcharnotfound > 0)
    	{
    		newPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "SPECIALCASE_ALLOWED")+" "+strAllowableSpecialChars+" "+SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "SPECIALCASE_CNT"));
			newPassword.setInvalid(true);
			newPassword.focus();
			return false;
    	}

		else if (confirmPassword.getValue() == null || confirmPassword.getValue().trim().length() == 0) {
			confirmPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "CONFIRMPASSWORD_MANDATORY"));
			confirmPassword.setInvalid(true);
			confirmPassword.focus();
			return false;
		}
	
		else if(!confirmPassword.getValue().equals(newPassword.getValue()))
		{
			confirmPassword.setErrorMessage(SiteAssetInventoryUIFramework.getFramework().getMessage(SCREENCD, "NEWANDCONFPWDMISMATCH"));
			confirmPassword.setInvalid(true);
			confirmPassword.focus();
			return false;
		}
		return true;
	}
	protected void changePassword(String oldPassword, String newPassword)
	{
		 String outputResponse="";
		
		try
		{
			String base_URL=ApplicationConfiguration.getServiceEndpoint("CHANGE_PASSWORD_USERMODE");

			Form formData = new Form();
			formData.add("oldpassword", oldPassword);
			formData.add("newpassword", newPassword);
			
			outputResponse = RestServiceHandler.createJSON_POST(base_URL,formData, SiteAssetInventoryUIFramework.getFramework().getToken());
			SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD,"PASSWORD_CHANGED", ApplicationConstants.DialogTypes.INFO);
			clearFields();
		}
		catch(Exception e)
		{
			String msg1=e.getMessage();
			String msg="";
			if(msg1.contains("Exception-Old password Mismatch")) {
				msg="Old password Mismatch";
			}else {
				msg=e.getMessage();
			}
			SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.ERROR);
			e.printStackTrace();
		}
		
	}
	private void clearFields() {
		oldPassword.clear();
		newPassword.clear();
		confirmPassword.clear();
		
		newPassword.setInvalid(false);
		oldPassword.setInvalid(false);
		confirmPassword.setInvalid(false);
		
		newPassword.setErrorMessage("");
		oldPassword.setErrorMessage("");
		confirmPassword.setErrorMessage("");
	}

}