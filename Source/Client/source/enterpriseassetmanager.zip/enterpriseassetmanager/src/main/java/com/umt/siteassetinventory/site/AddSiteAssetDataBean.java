package com.umt.siteassetinventory.site;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/add_site_asset-styles.css")
public class AddSiteAssetDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_SITE_ASSET_DATA_BEAN";
	private String assetId, assetType, assetName, serialNo, vendorName, status;
	private AddSiteAsset parent;
	private Div eachrowDiv;
	private boolean selected = false;


	public AddSiteAssetDataBean(String assetId, String assetType, String assetName, String serialNo, String vendorName, String status, AddSiteAsset addSiteAsset) 
	{
		this.assetId = assetId;
		this.assetType = assetType;
		this.assetName = assetName;
		this.serialNo = serialNo;
		this.vendorName = vendorName;
		this.status = status;
		this.parent = addSiteAsset;
		eachrowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");

		Div eachdataDiv1 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		Div eachdataDiv4 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV4");
		Div eachdataDiv5 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV5");
		Div eachdataDiv6 = UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV6");


		Label assetIdVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_ID_VAL");
		assetIdVal.setText(assetId);
		eachdataDiv1.add(assetIdVal);

		Label assetTypeVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_TYPE_VAL");
		assetTypeVal.setText(assetType);
		eachdataDiv2.add(assetTypeVal);

		Label assetNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "ASSET_NAME_VAL");
		assetNameVal.setText(assetName);
		eachdataDiv3.add(assetNameVal);

		Label serialNoVal = UIHtmlFieldFactory.createLabel(SCREENCD, "SERIAL_NO_VAL");
		serialNoVal.setText(serialNo);
		eachdataDiv4.add(serialNoVal);

		Label vendorNameVal = UIHtmlFieldFactory.createLabel(SCREENCD, "VENDOR_NAME_VAL");
		vendorNameVal.setText(vendorName);
		eachdataDiv5.add(vendorNameVal);

		Label statusVal = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_VAL");
		statusVal.setText(status);
		eachdataDiv6.add(statusVal);

		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3,eachdataDiv4,eachdataDiv5,eachdataDiv6);
		add(eachrowDiv);

		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				selectedRowChangeHandler();
			}
		});
	}
	
	private void selectedRowChangeHandler()
	{
		selectDeselect(selected);
		parent.selectedRowChangeHandler(this);
	}
	
	protected void selectDeselect(boolean selectedOrDeselected)
	{
		if (selectedOrDeselected) {
			selected = false;
			eachrowDiv.removeClassName("ADD_SITE_ASSET_DATA_BEAN_DATA_ROW_SELECTED");
		}
		else
		{
			selected = true;
			eachrowDiv.addClassName("ADD_SITE_ASSET_DATA_BEAN_DATA_ROW_SELECTED");
		}
	}

	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}

	public String getAssetId() {
		return assetId;
	}
	public String getAssetType() {
		return assetType;
	}

	public String getAssetName() {
		return assetName;
	}

	public String getSerialNo() {
		return serialNo;
	}
	
	public String getVendorName() {
		return vendorName;
	}

	public String getStatus() {
		return status;
	}

	public boolean isSelected() {
		return selected;
	}

}
