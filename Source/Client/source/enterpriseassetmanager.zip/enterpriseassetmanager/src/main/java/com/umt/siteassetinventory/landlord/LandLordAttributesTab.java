package com.umt.siteassetinventory.landlord;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.site.EditSiteAttributesDetails;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Span;

@CssImport("./styles/landlord_attributes-style.css")
public class LandLordAttributesTab extends Div{
	
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_ATTRIBUTES_TAB";
	private JSONArray arrayList;
	private ArrayList<String> atrri_title;
	private Map<String, String> attri_data;
	private Div infoDiv, edit_Div;
	private Button edit_btn;
	private HashMap<String, String> attributeDataTypeMap = new HashMap<String, String>();
	String partitionid = "";

	public LandLordAttributesTab(String landLordId, LandlordView landView) {
		edit_Div = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_DIV");
		edit_btn = UIFieldFactory.createButton(SCREENCD, "EDIT_BTN");
		
		infoDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "INFO_DIV");
		
		try {
			getAttributesMaster();
			populateAttributes(landLordId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			partitionid = CommonUtils.getUserPartition(SiteAssetInventoryUIFramework.getFramework().getToken());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		attri_data.forEach((k,v) -> 
		infoDiv.add(generateAttributeUI(k, v))
				
				);
		
        edit_Div.add(edit_btn);
		
		add(edit_Div,infoDiv);
		
		if (attri_data==null || attri_data.size()==0) {
			edit_btn.setEnabled(false);
		}
		
        edit_btn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> event) {
				//System.out.println("work");
//				save_attributes(SiteCode);
//				EditSiteAttributesDetails edit = new EditSiteAttributesDetails(arrayList, attri_data, SiteCode, siteView);
				EditLandlordAttributes edit = new EditLandlordAttributes(arrayList, attri_data,landLordId, landView);
				
				
			}
		});
		
	}
	
	public Div generateAttributeUI(String title, String value) {
		Div row = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		
		String attrDataType = attributeDataTypeMap.get(title);
		if(attrDataType == null) {
			attrDataType = "";
		}
		
		if((attrDataType.equals("8") || attrDataType.equals("9") || attrDataType.equals("10")) && !value.trim().equals("-")) {
			Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
			attri_nme.setText(title);
			row.add(attri_nme);
			try {
				JSONObject fileDetailJSON = new JSONObject(value);
				
				Anchor link = new Anchor();
				link.addClassName(SCREENCD + "_FILE_ATTRIBUTE_VALUE");
				link.setText(fileDetailJSON.getString("Name"));
				String href = getFileURL(fileDetailJSON.getString("UUID"));
				link.setHref(href);
				link.setTarget("_blank");
				row.add(link);				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (attrDataType.equals("7") && !value.trim().equals("-")) {
			Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
			attri_nme.setText(title);
			row.add(attri_nme);
			try {
				JSONObject multiSelectValueJSON = new JSONObject(value);
				JSONArray valArray = new JSONArray(multiSelectValueJSON.getString("MultiSelectValue"));
				StringBuilder multiSelectListHtmlView = new StringBuilder();
				multiSelectListHtmlView.append("<ul style = \"margin-block-start: 0px; margin-block-end: 0px; padding-inline-start: 16px;\">");
				for(int i = 0; i < valArray.length(); i++) {
					multiSelectListHtmlView.append("<li>" + valArray.getString(i) + "</li>");
				}
				multiSelectListHtmlView.append("</ul>");
				Span attri_value = UIHtmlFieldFactory.createSpan("", SCREENCD, "ATTRI_VALUE_LBL");
				attri_value.getElement().setProperty("innerHTML", multiSelectListHtmlView.toString());
				row.add(attri_value);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Label attri_nme = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_HEADER_LBL");
			Label attri_value = UIHtmlFieldFactory.createLabel(SCREENCD, "ATTRI_VALUE_LBL");
			attri_nme.setText(title);
			attri_value.setText(value);
			
			row.add(attri_nme, attri_value);
		}
		
		return row;
	}
	
	protected String getFileURL(String fileId) {
		String retVal = "";
		try {
			String truebyl_domain = System.getenv("TRUEBYL_DOMAIN");
			if (truebyl_domain!=null && truebyl_domain.trim().length()>0) {
				retVal = truebyl_domain + "RuleServer/files/" + partitionid + "/Landlord/" + fileId + "/stream";
			}
			else
			{
				retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
						       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/Landlord/" 
						       + fileId + "/stream";
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			retVal = ApplicationConfiguration.getScheme() + "://"+ ApplicationConfiguration.getServerIp() + 
				       ApplicationConfiguration.getServerPort() + "/RuleServer/files/" + partitionid + "/Landlord/" 
				       + fileId + "/stream";	
		}
		return retVal;
	}
	
	private void getAttributesMaster() {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETATTRIBUTE");
		try {
			String res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println("Response: " + res);
			
			arrayList = new JSONArray(res);
			
			atrri_title = new ArrayList<>();
			for(int i = 0; i<arrayList.length(); i++) {
				JSONObject json = arrayList.getJSONObject(i);
				if(json.getString("AttributeType").equals("8")) {
					atrri_title.add(json.getString("AttributeName"));
					attributeDataTypeMap.put(json.getString("AttributeName"), json.getString("AttributeDatatype"));
				}
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void populateAttributes(String landLordId) throws Exception {
		String base_URL=ApplicationConfiguration.getServiceEndpoint("GETLANDLORDATTRIBUTES");
		base_URL = base_URL + "?LandlordId=" + landLordId;
		
		String res = RestServiceHandler.retriveJSON_GET(base_URL, SiteAssetInventoryUIFramework.getFramework().getToken());
		
		//System.out.println("outPut: " + res);
		JSONObject json = new JSONObject(res);
		String otherInfo= json.getString("OtherInfo");
		JSONObject json_otherinfo = new JSONObject(otherInfo);
		Iterator<String> keys = json_otherinfo.keys();
		
		
		ArrayList<String> keyValue = new ArrayList<>();
		Map<String, String> attri_value_key = new LinkedHashMap<>();
		
		
		while(keys.hasNext()) {
			String key = keys.next();
			attri_value_key.put(key, json_otherinfo.getString(key));
		}
		
		attri_data = new LinkedHashMap<>();
		Set<String> key_set = attri_value_key.keySet();
		//System.out.println(atrri_title.size());
		for(int i = 0; i<atrri_title.size(); i++) {

			attri_data.put(atrri_title.get(i), "-");
	
		}
		
		for(int i = 0; i<atrri_title.size(); i++) {
			for(String key : key_set) {
				if(atrri_title.get(i).equals(key) && attri_value_key.get(key)!=null && attri_value_key.get(key).trim().length()>0) {
					attri_data.replace(atrri_title.get(i), attri_value_key.get(key));	
				}
			}
		}

		
		
		
	}
	

}
