package com.umt.siteassetinventory.landlord;

import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.vaadin.flow.component.Component;

public class ViewPaymentDetailsPopUp extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;

	public ViewPaymentDetailsPopUp(String title, Component component) {
		super(title, component);
		setWidth("800px");
		footer.setVisible(false);
	}

	@Override
	public void saveOperartion() {

	}

}
