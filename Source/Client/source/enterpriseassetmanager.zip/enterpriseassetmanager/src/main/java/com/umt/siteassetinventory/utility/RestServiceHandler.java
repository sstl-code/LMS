package com.umt.siteassetinventory.utility;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.cookiemanagement.SessionManager;

public class RestServiceHandler {
	// Get Method for Rest Api call //
	public static String retriveJSON_GET(String getURL, String token, boolean logoutOnTokenExpiry) throws Exception {

		String output = "";
		try {

			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			ClientResponse response = null;
			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").get(ClientResponse.class);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.get(ClientResponse.class);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						if (logoutOnTokenExpiry) {
							SessionManager.handleTokenExpiry();
							throw new Exception("User session has expired. Please re-login.");
						} else {
							throw new Exception(output);
						}
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	public static String retriveJSON_GET(String getURL, String token) throws Exception {

		String output = "";
		try {

			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			ClientResponse response = null;
			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").get(ClientResponse.class);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.get(ClientResponse.class);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	public static String retrieveTEXT_GET(String getURL, String token) throws Exception {

		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/text").get(ClientResponse.class);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/text").header("Authorization", "Bearer " + token)
						.get(ClientResponse.class);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	public static String createJSON_POST(String getURL, Form p_formData, String token, boolean logoutOnTokenExpiry)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);

			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").post(ClientResponse.class, p_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.post(ClientResponse.class, p_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						if (logoutOnTokenExpiry) {
							SessionManager.handleTokenExpiry();
							throw new Exception("User session has expired. Please re-login.");
						} else {
							throw new Exception(output);
						}
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}

	// Post method for Rest Call //
	public static String createJSON_POST(String getURL, Form p_formData, String token) throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);

			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").post(ClientResponse.class, p_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.post(ClientResponse.class, p_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}

	public static String updateJSON_PUT(String getURL, String jsonData, String formDataCD, String token)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			Form l_formData = new Form();
			l_formData.add(formDataCD, jsonData);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").put(ClientResponse.class, l_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.put(ClientResponse.class, l_formData);
			}
			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}

	public static String updateJSON_PUT(String getURL, Form p_formData, String token) throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").put(ClientResponse.class, p_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.put(ClientResponse.class, p_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}

	public static String updateJSON_PUT(String getURL, LinkedHashMap<String, String> p_paramMap, String token)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			Form l_formData = new Form();
			Iterator<Entry<String, String>> ite = p_paramMap.entrySet().iterator();
			while (ite.hasNext()) {
				Entry<String, String> l_entry = ite.next();
				l_formData.add(l_entry.getKey(), l_entry.getValue());
			}
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").put(ClientResponse.class, l_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.put(ClientResponse.class, l_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}

	public static String createJSON_POST(String getURL, HashMap<String, String> p_paramMap, String token)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			Form l_formData = new Form();
			Iterator<Entry<String, String>> ite = p_paramMap.entrySet().iterator();
			while (ite.hasNext()) {
				Entry<String, String> l_entry = ite.next();
				l_formData.add(l_entry.getKey(), l_entry.getValue());
			}
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").post(ClientResponse.class, l_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.post(ClientResponse.class, l_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}
			output = response.getEntity(String.class);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	public static String createJSON_POST(String getURL, String jsonData, String formDataCD, String token)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			Form l_formData = new Form();
			if (jsonData != null) {
				l_formData.add(formDataCD, jsonData);
			}
			// l_formData.add(formDataCD, jsonData);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").post(ClientResponse.class, l_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.post(ClientResponse.class, l_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}

			output = response.getEntity(String.class);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	public static String deleteJSON_DELETE(String getURL, String jsonData, String formDataCD, String token)
			throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(getURL);
			Form l_formData = new Form();
			l_formData.add(formDataCD, jsonData);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").delete(ClientResponse.class, l_formData);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.delete(ClientResponse.class, l_formData);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(getURL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}

			output = response.getEntity(String.class);
			/*
			 * Type retObjType = new TypeToken<WFMServerReturnWrapper>(){}.getType(); /*
			 * output = gson.fromJson(output_str, retObjType);
			 */

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;
	}

	/*
	 * private static Gson gson = new
	 * GsonBuilder().setDateFormat("dd-MM-yyyy HH:mm:ss").create();
	 * 
	 * Get Object From Object public static <T> T getObjectFromJSON(String
	 * jsonSource, String key, Type type) { JsonObject gobj = new
	 * Gson().fromJson(jsonSource, JsonObject.class); String l_jsonWithKey = null;
	 * if (gobj.get(key) != null) { l_jsonWithKey = gobj.get(key).toString(); } else
	 * { return null; } return gson.fromJson(l_jsonWithKey, type); }
	 * 
	 * Get JSON From Object public static String getJSONfromObj(Object sourceObj) {
	 * return gson.toJson(sourceObj); }
	 */

	private static String getAssetName(String url) {
		String assetName = "module.";
		int startIndex = url.indexOf("services/");
		if (startIndex != -1) {
			startIndex = startIndex + "services/".length();
		}

		int endIndex = url.indexOf("/assets");
		if (endIndex != -1) {
			if (startIndex < endIndex && startIndex < (url.length() - 1) && endIndex < (url.length() - 1)) {
				assetName = "module " + " " + url.substring(startIndex, endIndex) + ".";
			}
		}
		return assetName;
	}

	public static String deleteJSON_DELETE(String base_URL, Form l_objInputForm, String token) throws Exception {
		String output = "";
		try {
			Client client = ClientHelper.createClient();
			WebResource webResource = client.resource(base_URL);
			ClientResponse response = null;

			if (token == null || token.trim().length() == 0) {
				//response = webResource.accept("application/json").delete(ClientResponse.class, l_objInputForm);
				throw new Exception("User is not current logged in. Please login into the system to perform the desired operations.");
			} else {
				response = webResource.accept("application/json").header("Authorization", "Bearer " + token)
						.delete(ClientResponse.class, l_objInputForm);
			}

			if (response.getStatus() != 200) {
				try {
					output = response.getEntity(String.class);
				} catch (Exception ex) {
					ex.printStackTrace();
					output = "";
				}
				if (output != null && output.trim().length() > 0) {
					if (output.indexOf("ExpiredJwtException") != -1) {
						SessionManager.handleTokenExpiry();
						throw new Exception("User session has expired. Please re-login.");
					} else {
						if (output.indexOf("AuthorizationException-Access violation") != -1) {
							output = "You do not have access to " + getAssetName(base_URL);
						}
						throw new Exception(output);
					}
				} else {
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
			}

			output = response.getEntity(String.class);
			/*
			 * Type retObjType = new TypeToken<WFMServerReturnWrapper>(){}.getType(); /*
			 * output = gson.fromJson(output_str, retObjType);
			 */

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return output;

	}
}
