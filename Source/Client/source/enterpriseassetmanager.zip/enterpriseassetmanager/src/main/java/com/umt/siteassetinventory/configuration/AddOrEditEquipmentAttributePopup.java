package com.umt.siteassetinventory.configuration;


import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.representation.Form;
import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog;

public class AddOrEditEquipmentAttributePopup extends BaseDialogPopup{

	private static final long serialVersionUID = 1L;
	private AddOrEditEquipmentAttribute addOrEditEquipmentAttribute;
	private String screencd;
	private boolean dataSaved;
	private EquipmentAttributeMaster viewEquipmentAttributeMaster;
	private boolean addOrEdit;


	public AddOrEditEquipmentAttributePopup(String title, boolean addOrEdit, Component component, EquipmentAttributeMaster master, String screencd) {

		super(title, component);
		
		if(component.getParent().isPresent()) {
			component.getParent().get().getElement().getStyle().set("overflow-y", "auto");
			component.getParent().get().getElement().getStyle().set("display", "flex");
			component.getParent().get().getElement().getStyle().set("height", "500px");
		}
		
		setWidth("700px");
		
		//setWidth("500px");
		//System.out.println(title);
		this.addOrEditEquipmentAttribute = (AddOrEditEquipmentAttribute) component;
		this.viewEquipmentAttributeMaster = master;
		this.screencd = screencd;
		this.addOrEdit = addOrEdit;
	}

	@Override
	public void saveOperartion() {
		//System.out.println("Working");
		String msg= "";
		try {
			if (addOrEditEquipmentAttribute.validation()) {
				if (addOrEdit) {
					String base_URL=ApplicationConfiguration.getServiceEndpoint("ADDATTRIBUTE");
					JSONObject attributeJson = new JSONObject();
					attributeJson.put("AttributeName", addOrEditEquipmentAttribute.getAttributeName());
					attributeJson.put("AttributeDatatype", CommonUtils.getAttributeDataType(addOrEditEquipmentAttribute.getAttributeDataType()));
					attributeJson.put("Mandatory", addOrEditEquipmentAttribute.getMandatory());
					attributeJson.put("DefaultValue", addOrEditEquipmentAttribute.getDefaultValue());
					//attributeJson.put("FLOV", addOrEditEquipmentAttribute.getFlov());
					
					if(addOrEditEquipmentAttribute.getAttributeDataType().equalsIgnoreCase("Multiple Selection")) {
						attributeJson.put("FLOV", addOrEditEquipmentAttribute.getPossibleValuesForMultiSelection());
					} else {
						attributeJson.put("FLOV", addOrEditEquipmentAttribute.getFlov());
					}					
					
					attributeJson.put("EquipmentTypeId", addOrEditEquipmentAttribute.getEquipmentTypeId());

					Form formData = new Form();
					formData.add("Attribute", attributeJson);

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.createJSON_POST(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Save:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_ATTRIBUTE_SAVE_SUCCESSFUL");	
				}
				else
				{
					String base_URL=ApplicationConfiguration.getServiceEndpoint("UPDATEATTRIBUTE");
					
					Form formData = new Form();
					formData.add("AttributeName", addOrEditEquipmentAttribute.getAttributeName());
					formData.add("AttributeDatatype", CommonUtils.getAttributeDataType(addOrEditEquipmentAttribute.getAttributeDataType()));
					formData.add("Mandatory", addOrEditEquipmentAttribute.getMandatory());
					formData.add("DefaultValue", addOrEditEquipmentAttribute.getDefaultValue());
					//formData.add("FLOV", addOrEditEquipmentAttribute.getFlov());
					
					if(addOrEditEquipmentAttribute.getAttributeDataType().equalsIgnoreCase("Multiple Selection")) {
						formData.add("FLOV", addOrEditEquipmentAttribute.getPossibleValuesForMultiSelection());
					} else {
						formData.add("FLOV", addOrEditEquipmentAttribute.getFlov());
					}
					
					formData.add("EquipmentTypeId", addOrEditEquipmentAttribute.getEquipmentTypeId());

					//System.out.println(base_URL+" input:: " + formData.toString());
					String response = RestServiceHandler.updateJSON_PUT(base_URL, formData, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println("Update:" + response);
					closeDialog();
					msg= SiteAssetInventoryUIFramework.getFramework().getMessage(screencd, "EQUIPMENT_ATTRIBUTE_UPDATE_SUCCESSFUL");	
				}
				Dialog dlg = SiteAssetInventoryUIFramework.getFramework().showMessage(msg, ApplicationConstants.DialogTypes.INFO);
				dlg.addOpenedChangeListener(new ComponentEventListener<GeneratedVaadinDialog.OpenedChangeEvent<Dialog>>() {
					private static final long serialVersionUID = 1L;


					@Override
					public void onComponentEvent(OpenedChangeEvent<Dialog> event) {
						if(!event.isOpened()) {
							dataSaved = true;
							viewEquipmentAttributeMaster.populateData();
							close();	
						}
					}
				});
			}		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SiteAssetInventoryUIFramework.getFramework().showMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
		}


	}

}
