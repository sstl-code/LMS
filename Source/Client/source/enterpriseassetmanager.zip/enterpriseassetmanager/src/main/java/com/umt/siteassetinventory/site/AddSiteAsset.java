package com.umt.siteassetinventory.site;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;

@CssImport("./styles/add_site_asset-styles.css")
public class AddSiteAsset extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_SITE_ASSET";

	private ComboBox<String> combo1, combo2;
	private TextField serialNoFld;
	private TextField remarksFld;
	private Button retrieveBtn;
	private boolean activeOrPassive;
	private Map<String, String> assetTypeMap;
	private Map<String, String> vendorNameIdMap = new HashedMap<>();
	private Div tableContainerDiv;
	protected List<AddSiteAssetDataBean> addSiteAssetDataBeanList;
	private String siteCode;

	public AddSiteAsset(boolean activeOrPassive, Map<String, String> assetTypeMap, SiteAssetsTab siteAssetsTab) {
		this.activeOrPassive = activeOrPassive;
		this.assetTypeMap = assetTypeMap;
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		Div searchDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "SEARCH_DIV");
		combo1 = UIFieldFactory.createComboBox(new ArrayList<String>(), false, SCREENCD, "COMBO1");
		combo1.setItems(assetTypeMap.keySet().stream());
		combo2 = UIFieldFactory.createComboBox(new ArrayList<String>(), false, SCREENCD, "COMBO2");
		combo2.setEnabled(false);
		serialNoFld = UIFieldFactory.createTextField("", false, SCREENCD, "COMBO3");
		retrieveBtn = UIFieldFactory.createButton(SCREENCD, "RETRIEVE_BTN");
		remarksFld = UIFieldFactory.createTextField("", false, SCREENCD, "REMAKS_TXTFLD");

		tableContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_CONTAINER_DIV");
		Div tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER_DIV");

		Div eachrowDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV1");
		Div eachrowDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV2");
		Div eachrowDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV3");
		Div eachrowDiv4=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV4");
		Div eachrowDiv5=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV5");
		Div eachrowDiv6=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_HEADER_ROW_DIV6");

		Label lbl1 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL1");
		eachrowDiv1.add(lbl1);
		Label lbl2 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL2");
		eachrowDiv2.add(lbl2);
		Label lbl3 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL3");
		eachrowDiv3.add(lbl3);
		Label lbl4 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL4");
		eachrowDiv4.add(lbl4);
		Label lbl5 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL5");
		if (activeOrPassive) {
			lbl5.setText("Operator Name");
		}
		eachrowDiv5.add(lbl5);
		Label lbl6 = UIHtmlFieldFactory.createLabel(SCREENCD, "LBL6");
		eachrowDiv6.add(lbl6);
		tableHeaderDiv.add(eachrowDiv1, eachrowDiv2, eachrowDiv3, eachrowDiv4, eachrowDiv5, eachrowDiv6);

		searchDiv.add(combo1, combo2, serialNoFld, retrieveBtn);
		String assetParam = "";
		combo1.setLabel("Asset Type");
		combo1.setPlaceholder("Select asset type");
		if (activeOrPassive) 
		{
			assetParam = "Active";
			combo2.setLabel("Operator");
			combo2.setPlaceholder("Select operator");
		}
		else 
		{
			assetParam = "Passive";
			combo2.setLabel("Vendor");
			combo2.setPlaceholder("Select vendor");
		}		
		AddSiteAssetPopup popup = new AddSiteAssetPopup("Add " + assetParam + " Asset", this, siteAssetsTab, SCREENCD);

		add(searchDiv, tableHeaderDiv, tableContainerDiv, remarksFld);

		combo1.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event)
			{ 
				vendorNameIdMap = new HashedMap<>();
				if (event.getValue()!=null && combo1.getValue().trim().length()>0) {
					combo2.setEnabled(true);
					loadCombo2();
				}
				else
				{
					combo2.clear();
					combo2.setEnabled(false);
				}

			}
		});

		retrieveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Button> arg0) {
				loadAssets(activeOrPassive);
			}
		});
	}
	
	public void selectedRowChangeHandler(AddSiteAssetDataBean selectedBean) 
	{
		for (AddSiteAssetDataBean addSiteAssetDataBean : addSiteAssetDataBeanList) {
			if (!addSiteAssetDataBean.equals(selectedBean)) {
				addSiteAssetDataBean.selectDeselect(true);
			}
		}
	}

	private void loadCombo2()
	{
		try {
			String equipmentTypeVendor = getEquipmentTypeVendor();
			JSONArray  equipmentTypeVendorJA = new JSONArray(equipmentTypeVendor);
			for (int i = 0; i < equipmentTypeVendorJA.length(); i++) {
				JSONObject equipmentTypeVendorJson = equipmentTypeVendorJA.getJSONObject(i);
				vendorNameIdMap.put(equipmentTypeVendorJson.getString("VendorName"), equipmentTypeVendorJson.getString("VendorId"));
			}
			combo2.setItems(vendorNameIdMap.keySet().stream());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void loadAssets(boolean activeOrPassive)
	{
		tableContainerDiv.removeAll();
		addSiteAssetDataBeanList = new ArrayList<>();
		try {
			JSONArray allAssetsJA;
			JSONArray assetsJA = new JSONArray();
			String equipments = "";
			String serialNo = "";
			if (activeOrPassive)
			{ 
				String tenancyId = "";
				String vendorId = "";

				if (combo1.getValue()!=null && combo1.getValue().trim().length()>0 && assetTypeMap.size()>0 && 
						assetTypeMap.get(combo1.getValue())!=null) {
					tenancyId = assetTypeMap.get(combo1.getValue());
				}
				else
				{
					tenancyId = "-1";
				}
				if (combo2.getValue()!=null && combo2.getValue().trim().length()>0 && vendorNameIdMap.size()>0 && 
						vendorNameIdMap.get(combo2.getValue())!=null) {
					vendorId = vendorNameIdMap.get(combo2.getValue());
				}
				else
				{
					vendorId = "-1";
				}
				if (serialNoFld.getValue()!=null && serialNoFld.getValue().trim().length()>0) {
					serialNo = serialNoFld.getValue();
				}
				else
				{
					serialNo = "-1";
				}
				equipments = getEquipments(tenancyId, vendorId, serialNo);
				allAssetsJA = new JSONArray(equipments);
				for (int i = 0; i < allAssetsJA.length(); i++) {
					JSONObject allAssetJson = allAssetsJA.getJSONObject(i);
					if (allAssetJson.getInt("ServiceType")==1) {
						assetsJA.put(allAssetJson);
					}
				}
			}
			else
			{
				String equipmentId = "";
				String vendorId = "";
				if (combo1.getValue()!=null && combo1.getValue().trim().length()>0 && assetTypeMap.size()>0 && 
						assetTypeMap.get(combo1.getValue())!=null) {
					equipmentId = assetTypeMap.get(combo1.getValue());
				}
				else
				{
					equipmentId = "-1";
				}
				if (combo2.getValue()!=null && combo2.getValue().trim().length()>0 && vendorNameIdMap.size()>0 && 
						vendorNameIdMap.get(combo2.getValue())!=null) {
					vendorId = vendorNameIdMap.get(combo2.getValue());
				}
				else
				{
					vendorId = "-1";
				}
				if (serialNoFld.getValue()!=null && serialNoFld.getValue().trim().length()>0) {
					serialNo = serialNoFld.getValue();
				}
				else
				{
					serialNo = "-1";
				}
				equipments = getEquipments(equipmentId, vendorId , serialNo);
				allAssetsJA = new JSONArray(equipments);
				for (int i = 0; i < allAssetsJA.length(); i++) {
					JSONObject allAssetJson = allAssetsJA.getJSONObject(i);
					if (allAssetJson.getInt("ServiceType")==0) {
						assetsJA.put(allAssetJson);
					}
				}
			}
			/*AddSiteAssetDataBean bean1 = new AddSiteAssetDataBean("998777", "Radio Antenna", "North Radio", "9987456321", "12-03-2022", "Active", this);
			tableContainerDiv.add(bean1);
			AddSiteAssetDataBean bean2 = new AddSiteAssetDataBean("998777", "Radio Antenna", "North Radio", "9987456321", "12-03-2022", "Active", this);
			tableContainerDiv.add(bean2);*/
			if (assetsJA.length()==0) {
				if (activeOrPassive) {
					SiteAssetInventoryUIFramework.getFramework().showMessage("SITE_ASSETS_TAB", "ACTIVE_NO_RECORD", ApplicationConstants.DialogTypes.INFO);
				}
				else {
					SiteAssetInventoryUIFramework.getFramework().showMessage("SITE_ASSETS_TAB", "PASSIVE_NO_RECORD", ApplicationConstants.DialogTypes.INFO);
				}
			}
			for (int i = 0; i < assetsJA.length(); i++) {
				JSONObject assetJson = assetsJA.getJSONObject(i);
				AddSiteAssetDataBean bean = new AddSiteAssetDataBean(assetJson.getString("StoreSerialNo"), assetJson.getString("EquipmentType"), 
						assetJson.getString("Description"), assetJson.getString("EquipmentSerialNo"), 
						assetJson.getString("VendorName"), assetJson.getString("StatusCode"), this);
				tableContainerDiv.add(bean);
				addSiteAssetDataBeanList.add(bean);
			}

		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getEquipmentTypeVendor()
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTTYPEVENDOR");
			String response = RestServiceHandler.retriveJSON_GET(url + "?EquipmentTypeId=" + assetTypeMap.get(getAssetType()), SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url + "?EquipmentTypeId=" + getAssetType()+" response ::::::: "+response);
			return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	private String getEquipments(String equipmentTypeId, String vendorId, String serialNo)
	{
		try {
			String url = ApplicationConfiguration.getServiceEndpoint("GETEQUIPMENTS");
			url = url + "?StoreSerialNo=-1&StoreId=9995&StatusId=9999&VendorId=" + vendorId + "&EquipmentTypeId=" 
					+ equipmentTypeId + "&StoreLocId=-1" + "&EquipmentSerialNo=" + serialNo;;
					String response = RestServiceHandler.retriveJSON_GET(url, SiteAssetInventoryUIFramework.getFramework().getToken());
					//System.out.println(url + " response ::::::: "+response);
					return response;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}		
	}

	public String getAssetType() {
		return combo1.getValue();
	}
	public String getSiteAddress() {
		return combo2.getValue();
	}
	public String getSerialNo() {
		return serialNoFld.getValue();
	}
	public String getRemarks() {
		return remarksFld.getValue();
	}
	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

}
