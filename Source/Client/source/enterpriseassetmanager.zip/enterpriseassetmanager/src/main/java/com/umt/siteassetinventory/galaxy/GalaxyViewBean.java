package com.umt.siteassetinventory.galaxy;

import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.galaxy.GalaxyView;
import com.umt.siteassetinventory.utility.CommonUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.server.VaadinServletRequest;

public class GalaxyViewBean extends Div{
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "GALAXY_VIEW_BEAN";
	private Div rowDiv;
	private Checkbox selectRow;
	private String activityId,siteId,siteName,siteType,circle,submitBy,submitDate,readingDate,previousReadingDate,subMeterNo,recordId,
	currentSubMeterReading,previousSubMeterReading,currentSubMeterPicURL,errorFlag,errorDescription,currentRemark,rejectReason,status;
	
	private GalaxyView parent;
	
	private Label activityIdLbl,siteIdLbl,siteNameLbl,siteTypeLbl,circleLbl,submittedByLbl,submitDateLbl,readingDateLbl,previousreadingDateLbl,
	submeterNoLbl,currentSubmeterReadingLbl,prevoiusSubmeterReadingLbl,errorFlagLbl,errorDescLbl,
	currentRemarkLbl,rejectReasonLbl,statusLbl,consumptionLbl;
	private Div urlDiv;
	private Image viewImg;
	private TextField remarkField;
	private String consumption;


	public GalaxyViewBean(String recordId,String activityId, String siteId, String siteName, String siteType, String circle, String submitBy,
			String submitDate, String readingDate, String previousReadingDate, String subMeterNo, String currentSubMeterReading, String previousSubMeterReading,
			String currentSubMeterPicURL, String errorFlag, String errorDescription, String currentRemark, 
			String rejectReason,String status,GalaxyView parent) {
		
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.activityId=activityId;
		this.siteId=siteId;
		this.siteName=siteName;
		this.siteType=siteType;
		this.parent=parent;
		this.circle=circle;
		this.submitBy=submitBy;
		this.submitDate=submitDate;
		this.readingDate=readingDate;
		this.previousReadingDate=previousReadingDate;
		this.subMeterNo=subMeterNo;
		this.currentSubMeterReading=currentSubMeterReading;
		this.previousSubMeterReading=previousSubMeterReading;
		this.rejectReason=rejectReason;
		this.currentSubMeterPicURL=currentSubMeterPicURL;
		this.status=status;
		this.errorFlag=errorFlag;
		this.errorDescription=errorDescription;
		this.currentRemark=currentRemark;
		this.recordId=recordId;
		
		//populateMap();
		
	//	System.out.println(Integer.toBinaryString(Integer.parseInt(errorFlag)));
		
		rowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW_DIV");
		 activityIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ACTIVITY_ID_LBL");
		 circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		 siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		 siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
		 siteTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITETYPE_LBL");
		 submittedByLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMITTEDBY_LBL");
		 submitDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMITDATELBL");
		 readingDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "READINGDATE_LBL");
		 previousreadingDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PREV_READING_DATE_LBL");
		 submeterNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SUBMETERNO_LBL");
		 currentSubmeterReadingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CURRENT_SUBMETER_READING_LBL");
		 prevoiusSubmeterReadingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PREV_SUBMETER_READING_LBL");
		 consumptionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CONSUMPTION_LBL");
		
		urlDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "URL_DIV");
	//	Label picUrlLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "PIC_URL_LBL");
		viewImg = UIHtmlFieldFactory.createImage(SCREENCD, "VIEW_ICON");
		urlDiv.add(viewImg);
		viewImg.setTitle(currentSubMeterPicURL);
		
		currentRemarkLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CURRENT_REMARK_LBL");
		remarkField= UIFieldFactory.createTextField("", true, SCREENCD,"REMARKS_FIELD");
		 statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
	//	 rejectReasonLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REJECT_REASON_LBL");
		 errorFlagLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ERROR_FLAG_LBL");
		 errorDescLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "ERROR_DESC_LBL");
	//	Label selectLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SELECT_LBL");
		selectRow = UIFieldFactory.createCheckbox(false, false, SCREENCD, "SELECT_ROW");
		
		activityIdLbl.setText(activityId);
		circleLbl.setText(circle);
		siteIdLbl.setText(siteId);
		siteNameLbl.setText(siteName);
		siteTypeLbl.setText(siteType);
		submittedByLbl.setText(submitBy);
		
		
		submitDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(submitDate)));
		readingDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(readingDate)));
		previousreadingDateLbl.setText(CommonUtils.convertTimeStamp(Long.parseLong(previousReadingDate)));
	
//		submitDateLbl.setText(CommonUtils.convertDateToDifferentFormat(submitDate,"dd/MM/yyyy","dd-MMM-yy"));
//		readingDateLbl.setText(CommonUtils.convertDateToDifferentFormat(readingDate,"dd/MM/yyyy","dd-MMM-yy"));
//		previousreadingDateLbl.setText(CommonUtils.convertDateToDifferentFormat(previousReadingDate,"dd/MM/yyyy","dd-MMM-yy"));
	
		currentSubmeterReadingLbl.setText(currentSubMeterReading);
		prevoiusSubmeterReadingLbl.setText(previousSubMeterReading);
		submeterNoLbl.setText(subMeterNo);
	//	picUrlLbl.setText(currentSubMeterPicURL);
		currentRemarkLbl.setText(currentRemark);
	//	rejectReasonLbl.setText(rejectReason);
	//	errorFlagLbl.setText(errorFlag);
		errorDescLbl.setText(errorDescription);
		consumption=String.valueOf(Integer.parseInt(currentSubMeterReading)-Integer.parseInt(previousSubMeterReading));
		consumptionLbl.setText(String.valueOf(Integer.parseInt(currentSubMeterReading)-Integer.parseInt(previousSubMeterReading)));
		
		rowDiv.add(activityIdLbl,siteIdLbl,siteNameLbl,siteTypeLbl,circleLbl,submittedByLbl,submitDateLbl,readingDateLbl,previousreadingDateLbl,
				submeterNoLbl,currentSubmeterReadingLbl,prevoiusSubmeterReadingLbl,consumptionLbl,urlDiv,errorFlagLbl,errorDescLbl,
				currentRemarkLbl,remarkField,statusLbl,selectRow);
		
		add(rowDiv);
		
		
		urlDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				openUrl();
				
			}
		});
		

		if(errorFlag!=null && Integer.parseInt(errorFlag)>0) {
			errorFlagLbl.setText("Error");
			determineErrorField();
		}else {
			errorFlagLbl.setText("Ok");
		}	
		
		if(rejectReason!=null) {
			remarkField.setValue(rejectReason);
			remarkField.setTitle(rejectReason);
		}
		
		if(Integer.parseInt(status)==0) {
			statusLbl.setText("To be processed");
			selectRow.setEnabled(true);
		}else if(Integer.parseInt(status)==1) {
			statusLbl.setText("Approved");
			selectRow.setEnabled(false);
		}else if(Integer.parseInt(status)==2) {
			statusLbl.setText("Rejected");
			selectRow.setEnabled(false);
		}else {
			statusLbl.setText("-");
		}
		
		
	}
	
	protected void openUrl() {
		try
		{
			String url = VaadinServletRequest.getCurrent().getScheme() 
					+ "://" + VaadinServletRequest.getCurrent().getServerName() 
					+ ":" + VaadinServletRequest.getCurrent().getServerPort() 
//					+ "/" + VaadinServletRequest.getCurrent().getContextPath()
					+ VaadinServletRequest.getCurrent().getContextPath()
					+ "/ViewDocument";
			url = url + "?imgUrl=" + currentSubMeterPicURL;
			UI.getCurrent().getPage().open(url);
		}catch (Exception e) {
			e.printStackTrace();
			
	    }
		
	}


	private void determineErrorField() {
		
		String binarystring=Integer.toBinaryString(Integer.parseInt(errorFlag));
//		System.out.println("binarystring="+binarystring);	
		int len=binarystring.length();
		int limit=12-len;
		String s="";
		for(int i=0;i<limit;i++) {
			String k="0";
			s=s+k;
		}
		String finalStr=s+binarystring;
//		System.out.println("finalStr="+finalStr);	
		
		
		for(int i=1;i<=finalStr.length();i++) {
			char ch=finalStr.charAt(i-1);
			
			if(String.valueOf(ch).equals("1")) {

				switch (i) {
		        case 1:
		        	activityIdLbl.getStyle().set("color","red");
		            break;
		        case 2:
		        	siteIdLbl.getStyle().set("color","red");
		            break;
		        case 3:
		        	siteNameLbl.getStyle().set("color","red");
		            break;
		        case 4:
		        	siteTypeLbl.getStyle().set("color","red");
		            break;
		        case 5:
		        	submittedByLbl.getStyle().set("color","red");
		            break;
		        case 6:
		        	submitDateLbl.getStyle().set("color","red");
		            break;
		        case 7:
		        	readingDateLbl.getStyle().set("color","red");
		            break;
		        case 8:
		        	previousreadingDateLbl.getStyle().set("color","red");
		            break;
		        case 9:
		        	submeterNoLbl.getStyle().set("color","red");
		            break;
		        case 10:
		        	currentSubmeterReadingLbl.getStyle().set("color","red");
		            break;
		        case 11:
		        	prevoiusSubmeterReadingLbl.getStyle().set("color","red");
		            break;
		        case 12:
		        	viewImg.getStyle().set("background-color","red");
		            break;
		        default:
		            break;
		            
			 }

			}
		
		}
		
	}

	

	

	public Div getRowDiv() {
		return rowDiv;
	}
	
	public String getActivityId() {
		return activityId;
		
	}
	
	public String getSiteId() {
		return siteId;
	}
	public String getSiteName() {
		return siteName;
	}
	public String getSiteType() {
		return siteType;
	}
	
	public String getCircle() {
		return circle;
	}
	public String getSubmittedBy() {
		return submitBy;
	}

	public boolean isChecked() {
		return selectRow.getValue();
	}

	public String getRecordId() {
		return recordId;
	}


	public String rejectReason() {
		return remarkField.getValue().toString();
		
	}

	public String getSubmitDate() {
		// TODO Auto-generated method stub
		return CommonUtils.convertTimeStamp(Long.parseLong(submitDate));
	}

	public String getReading() {
		// TODO Auto-generated method stub
		return CommonUtils.convertTimeStamp(Long.parseLong(readingDate));
	}

	public String getPreviousReadingDate() {
		// TODO Auto-generated method stub
		return CommonUtils.convertTimeStamp(Long.parseLong(previousReadingDate));
	}

	public String getSubmeterNo() {
		// TODO Auto-generated method stub
		return subMeterNo;
	}

	public String getCurrentSubmterReading() {
		// TODO Auto-generated method stub
		return currentSubMeterReading;
	}

	public String getPrevSubmeterReading() {
		// TODO Auto-generated method stub
		return previousSubMeterReading;
	}

	public String getConsumption() {
		
		return consumption;
	}

	public String getErrorFlag() {
		// TODO Auto-generated method stub
		//return errorFlag;
		return errorFlagLbl.getText();
	}

	public CharSequence getErrorDesc() {
		// TODO Auto-generated method stub
		return errorDescription;
	}

	public String getCurrentRemark() {
		// TODO Auto-generated method stub
		return currentRemark;
	}

	public String getRejectReason() {
		// TODO Auto-generated method stub
		return rejectReason;
	}
	public String status() {
		return status;
		
	}

	public String getStatus() {
		return statusLbl.getText();
	}
}
