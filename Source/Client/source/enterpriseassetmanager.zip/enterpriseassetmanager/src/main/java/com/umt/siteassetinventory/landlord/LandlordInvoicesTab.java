package com.umt.siteassetinventory.landlord;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.ApplicationConstants;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.utility.RestServiceHandler;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;

@CssImport("./styles/landlord-invoice.css")
public class LandlordInvoicesTab extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "LANDLORD_INVOICES_TAB";
	private String selectedLandlordId;
	private LandlordView parent;
	private TextField searchInvoices;
	private Div listContainerDiv,row1Div,row2Div/*,btnDiv*/;
	private Button retrieveBtn,updateBtn,regenerateBtn,resetBtn;
	private List<LandlordInvoicesTabBean> invoicebeanList=new ArrayList<LandlordInvoicesTabBean>();
	//private List<LandlordInvoicesTabBean> invoicePagingbeanList=new ArrayList<LandlordInvoicesTabBean>();
	//private String invoiceIdList,invoiceAmtList;
	private String landlordname;
	private Div tableHeaderDiv,footerLayout,prevBtndiv,nextBtndiv;
	//private String getLandlordInvoicesRes= "";

	//pagination
	//	private int remainder,pg,numberofpg;
	//	private int limit = 6;
	//	private int clickCnt = 0;
	//	private int totalCnt;
	//	private int remainingCnt,quotientCnt;
	private Label pagenumberLbl;
	private int pageNo = 0, pageSize = 5;




	public LandlordInvoicesTab(String selectedLandlordId, String landlordname, LandlordView landlordView) {

		//System.out.println("landlordname::::="+landlordname);
		this.landlordname=landlordname;
		addClassName(SCREENCD+"_MAIN_LAYOUT");
		this.selectedLandlordId=selectedLandlordId;
		this.parent=landlordView;

		row1Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW1_DIV");
		row2Div = UIHtmlFieldFactory.createDiv(SCREENCD, "ROW2_DIV");
		//btnDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "BTN_DIV");

		searchInvoices = UIFieldFactory.createTextField("", false, SCREENCD,"SEARCH_INVOICE");
		searchInvoices.setSuffixComponent(VaadinIcon.SEARCH.create());
		searchInvoices.setValueChangeMode(ValueChangeMode.EAGER);
		retrieveBtn = UIFieldFactory.createButton(SCREENCD, "RETRIEVE_BTN");
		row1Div.add(searchInvoices/*,retrieveBtn*/);

		listContainerDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "CONTAINER_DIV");
		footerLayout = UIHtmlFieldFactory.createDiv(SCREENCD, "FOOTER_LAYOUT");

		updateBtn = UIFieldFactory.createButton(SCREENCD, "UPDATE_BTN");
		regenerateBtn = UIFieldFactory.createButton(SCREENCD, "REGENERATE_BTN");
		resetBtn = UIFieldFactory.createButton(SCREENCD, "RESET_BTN");
		//	btnDiv.add(updateBtn,regenerateBtn,resetBtn);

		pageSize = Integer.parseInt(ApplicationConfiguration.getConfigurationValue("LANDLORD_INVOICES_TAB_RECORD_COUNT_LIMIT"));

		createContainerLayout();

		add(row1Div,row2Div/*,btnDiv*/,footerLayout);

		searchInvoices.setValueChangeMode(ValueChangeMode.EAGER);
		searchInvoices.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<?>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void valueChanged(ValueChangeEvent<?> event) {
				invoicebeanList.stream().filter(new Predicate<LandlordInvoicesTabBean>() {

					@Override
					public boolean test(LandlordInvoicesTabBean t) {
						String searchTxt = searchInvoices.getValue().trim();
						if(searchTxt == null || searchTxt.trim().length() == 0) {
							t.setVisible(true);
							return true;
						}
						if(StringUtils.containsIgnoreCase(t.getSiteId(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getSiteName(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getCircle(), searchTxt)
								|| StringUtils.containsIgnoreCase(String.valueOf(t.getInvoiceId()), searchTxt)
								|| StringUtils.containsIgnoreCase(t.Invoicetype(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.billType(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.rentStatus(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getInvoiceNo(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getInvoicedate(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getDueDate(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getPeriod_StartDate(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getPeriod_EndDate(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getRentShare(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getInvoiceAmount(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getSolutiontype(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getBillingcycle(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getStatus(), searchTxt)
								|| StringUtils.containsIgnoreCase(t.getRemarks(), searchTxt))
						{
							t.setVisible(true);
							return true;
						}
						t.setVisible(false);
						return false;


					}
				}).collect(Collectors.toList());		
			}
		});

//		retrieveBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public void onComponentEvent(ClickEvent<Button> event) {
//				createContainerLayout();
//			}
//		});

		//		updateBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(ClickEvent<Button> event) {
		//				updateInvoices();
		//			}
		//		});
		//		
		//		regenerateBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(ClickEvent<Button> event) {
		//				regenerateInvoices();
		//			}
		//		});
		//		
		//		resetBtn.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
		//			private static final long serialVersionUID = 1L;
		//
		//			@Override
		//			public void onComponentEvent(ClickEvent<Button> event) {
		//				//resetInvoices();
		//				searchInvoices.clear();
		//			}
		//		});
	}



	private void createContainerLayout() {


		tableHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "TABLE_HEADER");

		Label circleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "CIRCLE_LBL");
		Label siteIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITEID_LBL");
		Label siteNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITENAME_LBL");
//		Label landlordNameLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORDNAME_LBL");
//		Label sapvendorCodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SAPVENDORCODE_LBL");
		Label landlordrentsharePercentageLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "LANDLORD_RENT_SHARE_PERCENT_LBL");
		Label solutionTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SOLUTION_TYPE_LBL");
		Label billingTypeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_TYPE_LBL");
		Label rentStatusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RENT_STATUS_LBL");
		Label typeofinvoiceLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "TYPE_OF_INVOICE_LBL");
		Label invoiceIdLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_ID_LBL");
		Label invoiceNoLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICENO_LBL");
		Label invoiceDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_DATE_LBL");
		Label dueDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "DUE_DATE_LBL");
		Label billingCycleLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "BILLING_CYCLE_LBL");
		Label invoiceStartDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_START_DATE_LBL");
		Label invoiceEndDateLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_END_DATE_LBL");
		//Label grossAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "GROSS_AMT_LBL");
		Label invoiceAmtLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "INVOICE_AMT_LBL");
		//	Label rejectreasonLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REJECT_REASON_LBL");
		Label remarkLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REMARK_LBL");
		Label statusLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "STATUS_LBL");
		//Label selectLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SELECT_LBL");

		tableHeaderDiv.removeAll();

		tableHeaderDiv.add(siteIdLbl,circleLbl,siteNameLbl,/*landlordNameLbl,sapvendorCodeLbl,*/landlordrentsharePercentageLbl,solutionTypeLbl,billingTypeLbl,
				rentStatusLbl,typeofinvoiceLbl,invoiceIdLbl,invoiceNoLbl,invoiceDateLbl,invoiceStartDateLbl,invoiceEndDateLbl,dueDateLbl,invoiceAmtLbl,
				billingCycleLbl,statusLbl,/*rejectreasonLbl,*/remarkLbl/*,selectLbl*/);

		row2Div.removeAll();
		//btnDiv.removeAll();

		row2Div.add(tableHeaderDiv, listContainerDiv);
		//btnDiv.add(updateBtn, regenerateBtn, resetBtn);

		createPagination();
		populateLandlordInvoices(0, pageSize);
	}

	private void populateLandlordInvoices(int pageNo, int pageSize) {

		try {
			listContainerDiv.removeAll();
			invoicebeanList.clear();
			//invoicePagingbeanList.clear();
			searchInvoices.clear();

			String url = ApplicationConfiguration.getServiceEndpoint("GETLANDLORDINVOICE");
			//			Form form =new Form();
			//			form.add("LandlordId",selectedLandlordId);
			url=url+"?LandlordId="+selectedLandlordId+"&PageNo="+pageNo+"&PageSize="+pageSize;
			//System.out.println(url);
			String response = RestServiceHandler.retriveJSON_GET(url,SiteAssetInventoryUIFramework.getFramework().getToken());
			//System.out.println(url+" ::"+response);


			JSONArray jsarr = new JSONArray(response);
			if (jsarr.length() > 0) {

				for (int i = 0; i < jsarr.length(); i++) {

					LandlordInvoicesTabBean beanobj=new LandlordInvoicesTabBean(
							jsarr.getJSONObject(i).getString("InvoiceId"),
							jsarr.getJSONObject(i).getString("Circle"),
							jsarr.getJSONObject(i).getString("SiteCode"),
							jsarr.getJSONObject(i).getString("SiteName"),
							/*jsarr.getJSONObject(i).getString("LandlordName"),
							jsarr.getJSONObject(i).getString("SAPVendorCode"),*/
							jsarr.getJSONObject(i).getString("InvoiceDate"),
							jsarr.getJSONObject(i).getString("DueDate"),
							jsarr.getJSONObject(i).getString("Period_Startdate"),
							jsarr.getJSONObject(i).getString("Period_Enddate"),
							jsarr.getJSONObject(i).getString("RentShare"),
							jsarr.getJSONObject(i).getString("SolutionType"),
							jsarr.getJSONObject(i).getString("BillingType"),
							jsarr.getJSONObject(i).getString("BillingCycle"),
							jsarr.getJSONObject(i).getString("RentStatus"),
							jsarr.getJSONObject(i).getString("InvoiceType"),
							jsarr.getJSONObject(i).getString("Status"),
							jsarr.getJSONObject(i).getString("InvoiceNo"),
							jsarr.getJSONObject(i).getString("GrossInvoiceAmount"),
							jsarr.getJSONObject(i).getString("DueOn"),
							jsarr.getJSONObject(i).getString("Gst_Rate"),
							jsarr.getJSONObject(i).getString("InvoiceaAmount"),
							jsarr.getJSONObject(i).getString("BillForOperator"),
							jsarr.getJSONObject(i).getString("InvoiceArrears"),
							jsarr.getJSONObject(i).getString("SubmissionDate"),
							jsarr.getJSONObject(i).getString("ReceivedDate"),
							jsarr.getJSONObject(i).getString("Tds_Rate"),
							jsarr.getJSONObject(i).getString("RejectReason"),
							jsarr.getJSONObject(i).getString("Remarks1"),
							jsarr.getJSONObject(i).getString("Remarks2"),this);
					
					listContainerDiv.add(beanobj);
					invoicebeanList.add(beanobj);
					
				}
				int pageNumber = pageNo+1;
				pagenumberLbl.setText(pageNumber+"");
				if(jsarr.length()>=pageSize) {
					nextBtndiv.setEnabled(true);
				}
				else {
					nextBtndiv.setEnabled(false);
				}
				tableHeaderDiv.setVisible(true);
				//displayNextRecords();

			}else {
				row2Div.removeAll();
				tableHeaderDiv.setVisible(false);
				invoicebeanList.clear();
				//invoicePagingbeanList.clear();
				//btnDiv.removeAll();
				listContainerDiv.removeAll();
				//	SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NO_RECORD", ApplicationConstants.DialogTypes.INFO);
				Label norecLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "NO_RECORD_LBL");
				row2Div.add(norecLbl);
			}
		} catch (Exception e) {
			e.printStackTrace();
			if(e.getMessage().contains("AppException-Access Violation")) {
				SiteAssetInventoryUIFramework.getFramework().showApiErrorMessage(e.getMessage(), ApplicationConstants.DialogTypes.ERROR);
			}
		}

	}


	//	protected void updateInvoices() {
	//		try {
	//			invoiceIdList=getSelectedInvoiceIds();
	//			invoiceAmtList=getSelectedInvoiceAmt();
	//			
	//			if (invoiceIdList.length() == 0) {
	//				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NOTHING_SELECTED",ApplicationConstants.DialogTypes.INFO);
	//				return;
	//			}else {
	//				
	//				
	//				Form form =new Form();
	//				form.add("LandlordId",selectedLandlordId);
	//				form.add("InvoiceId",invoiceIdList);
	//				form.add("Amount",invoiceAmtList);
	//				
	//			//	System.out.println("invoiceIdList::"+invoiceIdList);
	//			//	System.out.println("invoiceAmtList::"+invoiceAmtList);
	//				String url = ApplicationConfiguration.getServiceEndpoint("UPDATE_LANDLORD_INVOICES");
	//				RestServiceHandler.updateJSON_PUT(url,form,SiteAssetInventoryUIFramework.getFramework().getToken());
	//				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "INVOICE_UPDATE_SUCCESS",ApplicationConstants.DialogTypes.INFO);
	//				retrieveLandlordInvoices();
	//				
	//			}
	//			
	//			
	//			
	//		}catch (Exception e) {
	//			e.printStackTrace();
	//		}
	//		
	//	}
	//	
	//
	//
	//
	//	protected void regenerateInvoices() {
	//		try {
	////			String url = ApplicationConfiguration.getServiceEndpoint("GET_NEARBY_SITEAGREEMENTS");
	////			url = url + "?SiteCode=" + URLEncoder.encode(siteCode) ;
	////					
	////			String response = RestServiceHandler.retriveJSON_GET(url,
	////					SiteAssetInventoryUIFramework.getFramework().getToken());
	//			invoiceIdList=getSelectedInvoiceIds();
	//			
	//			if (invoiceIdList.length() == 0) {
	//				SiteAssetInventoryUIFramework.getFramework().showMessage(SCREENCD, "NOTHING_SELECTED",ApplicationConstants.DialogTypes.INFO);
	//				return;
	//			}else {
	//				System.out.println("invoiceIdList2::"+invoiceIdList);
	//			}
	//			
	//			
	//			
	//		}catch (Exception e) {
	//			e.printStackTrace();
	//		}
	//		
	//	}



	private String getSelectedInvoiceIds() {

		String invoiceIdList = "";
		for (LandlordInvoicesTabBean eachRow : invoicebeanList) {
			if (eachRow.isChecked()) {
				invoiceIdList += eachRow.getInvoiceId() + ",";
				//invoiceIdList=eachRow.getInvoiceId();
			}

		}
		return invoiceIdList;
	}

	//	private String getSelectedInvoiceAmt() {
	//		String invoiceAmtList = "";
	//		for (LandlordInvoicesTabBean eachRow : invoicebeanList) {
	//			if (eachRow.isChecked()) {
	//				//invoiceAmtList += eachRow.getInvoiceId() + ",";
	//				invoiceAmtList= eachRow.getInvoiceAmt();
	//			}
	//
	//		}
	//		return invoiceAmtList;
	//
	//	}


	// Pagination

	private void createPagination() {

		Label pageLabel=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_LBL");
		pageLabel.setText("Page");
		Div pgNumberdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PG_NO_DIV");
		pagenumberLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"PAGE_NO_LBL");
		pgNumberdiv.add(pagenumberLbl);
		//totalcountLbl=UIHtmlFieldFactory.createLabel(SCREENCD,"TOTAL_COUNT_LBL");

		Div arrowdiv=UIHtmlFieldFactory.createDiv(SCREENCD, "ARROW_DIV");
		nextBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "NEXT_BTN_DIV");
		Icon rightarrowIcon = VaadinIcon.ANGLE_RIGHT.create();
		nextBtndiv.add(rightarrowIcon);
		prevBtndiv=UIHtmlFieldFactory.createDiv(SCREENCD, "PREV_BTN_DIV");
		Icon leftarrowIcon = VaadinIcon.ANGLE_LEFT.create();
		prevBtndiv.add(leftarrowIcon);
		arrowdiv.add(prevBtndiv,nextBtndiv);

		leftarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		rightarrowIcon.addClassName(SCREENCD+"_ARROW_ICON");
		prevBtndiv.setEnabled(false);
		nextBtndiv.setEnabled(false);
		
		footerLayout.removeAll();

		footerLayout.add(pageLabel,pgNumberdiv,/*totalcountLbl,*/arrowdiv);

		//limit = Integer.parseInt(ApplicationConfiguration.getConfigurationValue("LANDLORD_INVOICES_TAB_RECORD_LIMIT"));
		//		System.out.println("limit= "+limit);


		nextBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//clickCnt++;
				prevBtndiv.setEnabled(true);

				pageNo++;
				populateLandlordInvoices(pageNo, pageSize);
				
				//		displayNextRecords();

//				int clickcount=clickCnt+1;
//				int startNo = (clickCnt*limit)+1;
//				int endNo = (clickCnt+1)*limit;
//				if(endNo>totalCnt)
//				{
//					pagenumberLbl.setText(clickcount+"");
//					totalcountLbl.setText(" of "+ pg);
//				}
//				else
//				{
//					pagenumberLbl.setText(clickcount+"");
//					totalcountLbl.setText(" of "+ pg);
//				}
//				if(remainingCnt!=0 && clickCnt==quotientCnt) {
//					nextBtndiv.setEnabled(false);
//				}
//				if(remainingCnt!=0 && clickCnt==quotientCnt) {
//					nextBtndiv.setEnabled(false);
//				}
			}
		});

		prevBtndiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				//clickCnt--;
				nextBtndiv.setEnabled(true);
				pageNo--;
				populateLandlordInvoices(pageNo, pageSize);
				if(pageNo==0) {
					prevBtndiv.setEnabled(false);
				}

				
				
				//		displayNextRecords();

				//				int clickcount=clickCnt+1;
				//				int startNo = (clickCnt*limit)+1;
				//				int endNo = (clickCnt+1)*limit;
				//
				
				//totalcountLbl.setText(" of "+ pg);

			}
		});

	}

	//	private void displayNextRecords() {
	//		listContainerDiv.removeAll();
	//
	//		int totalCnt = invoicebeanList.size();
	//		remainder=totalCnt%limit;
	//		numberofpg=totalCnt/limit;
	//		remainingCnt = totalCnt%limit;
	//		quotientCnt = totalCnt/limit;
	//
	//		if(invoicebeanList.size()!=0) {
	//			if(clickCnt!=quotientCnt) {
	//				for(int i=clickCnt*limit;i<(clickCnt+1)*limit;i++) {
	//					listContainerDiv.add(invoicebeanList.get(i));
	//					//invoicePagingbeanList.add(invoicebeanList.get(i));
	//				}
	//			}
	//			else {
	//				for(int j = quotientCnt*limit;j<(quotientCnt*limit)+remainingCnt;j++) {
	//					listContainerDiv.add(invoicebeanList.get(j));
	//					//invoicePagingbeanList.add(invoicebeanList.get(j));
	//
	//				}
	//			}
	//		}
	//
	//		if(remainder==0)
	//		{
	//			pg=numberofpg;
	//		}
	//		if(remainder!=0)
	//		{
	//			pg=numberofpg+1;
	//		}
	//
	//		int startNo = (clickCnt*limit)+1;
	//		int endNo = (clickCnt+1)*limit;
	//		if(endNo>totalCnt) {
	//			pagenumberLbl.setText(startNo+"");
	//			totalcountLbl.setText(" of "+ pg);
	//		}
	//		else {
	//			pagenumberLbl.setText(startNo+"");
	//			totalcountLbl.setText(" of "+ pg);
	//		}
	//
	//		if(totalCnt>limit) {
	//			nextBtndiv.setEnabled(true);
	//		}
	//		else {
	//			nextBtndiv.setEnabled(false);
	//		}
	//
	//
	//	}

}
