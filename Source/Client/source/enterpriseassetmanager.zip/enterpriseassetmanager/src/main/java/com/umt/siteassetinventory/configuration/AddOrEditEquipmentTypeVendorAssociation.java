package com.umt.siteassetinventory.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.umt.siteassetinventory.framework.componentfactory.UIFieldFactory;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;

@CssImport("./styles/add_edit_equipment_type_vendor_association-styles.css")
public class AddOrEditEquipmentTypeVendorAssociation extends Div {

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "ADD_EDIT_EQUIPMENT_TYPE_VENDOR_ASSOCIATION";

	private TextField inputFileFormatFld, outputFileFormatFld, serviceAgentFld;	
	//	private NumberField warrantyPeriodFld;
	private ComboBox<String> vendorCombo, /*equipmentTypeCombo,*/ equipmentCombo;
	private boolean vendorOrOperator;
	//private String siteCode;
	private Map<Long, String> vendorMap, activeEquipmentTypeMap, passiveEquipmentTypeMap;

	public AddOrEditEquipmentTypeVendorAssociation(EquipmentTypeVendorAssociationMaster equipmentTypeVendorAssociationMaster, 
			Map<Long, String> vendorMap, Map<Long, String> activeEquipmentTypeMap, Map<Long, String> passiveEquipmentTypeMap, 
			boolean vendorOrOperator) {
		addClassName(SCREENCD + "_MAIN_LAYOUT");

		this.vendorMap = vendorMap;
		this.activeEquipmentTypeMap = activeEquipmentTypeMap;
		this.passiveEquipmentTypeMap = passiveEquipmentTypeMap;
		this.vendorOrOperator = vendorOrOperator;
		vendorCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "VENDOR_COMBO");
		List<String> valuesList = new ArrayList<String>();
		//System.out.println("vendorMap size="+vendorMap.size()+" vendorMap="+vendorMap.toString());
		vendorMap.forEach((k,v) -> {
			//System.out.println("key="+k);
			valuesList.add(vendorMap.get(k));
		});
		vendorCombo.setDataProvider(new ListDataProvider<String>(valuesList));
//		equipmentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV("ADD_EDIT_EQUIPMENT_TYPE", "SERVICE_TYPE_LIST", ','),
//				true, SCREENCD, "EQUIPMENT_TYPE_COMBO");
//		equipmentTypeCombo.setValue("Active");
		List<String> listOfValues = new ArrayList<String>();
		//System.out.println("equipmentTypeMap size="+equipmentTypeMap.size()+" equipmentTypeMap="+equipmentTypeMap.toString());
		if (vendorOrOperator) {
			passiveEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				listOfValues.add(passiveEquipmentTypeMap.get(k));
			});
		} else {
			activeEquipmentTypeMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				listOfValues.add(activeEquipmentTypeMap.get(k));
			});
		}
		equipmentCombo = UIFieldFactory.createComboBox(listOfValues,true, SCREENCD, "EQUIPMENT_COMBO");
		
		inputFileFormatFld = UIFieldFactory.createTextField("", true, SCREENCD, "INPUT_FILE_FORMAT_FIELD");
		outputFileFormatFld = UIFieldFactory.createTextField("", true, SCREENCD, "OUTPUT_FILE_FORMAT_FIELD");
		serviceAgentFld = UIFieldFactory.createTextField("", true, SCREENCD, "SERVICE_AGENT_FIELD");
		//		warrantyPeriodFld = UIFieldFactory.createNumberField(true, SCREENCD, "WARRANTY_PERIOD_FIELD");
		String title = "";
		if (vendorOrOperator) {
			title = "Vendor";
		} else {
			title = "Operator";
			vendorCombo.setLabel("Operator");
		}
		AddOrEditEquipmentTypeVendorAssociationPopup popup = new AddOrEditEquipmentTypeVendorAssociationPopup("Add Equipment Type " +title+ " Association", true, vendorOrOperator, this, equipmentTypeVendorAssociationMaster, SCREENCD);

		add(vendorCombo, equipmentCombo);
		if (vendorOrOperator) {
			add(inputFileFormatFld, outputFileFormatFld, serviceAgentFld);
		}
//		equipmentTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public void valueChanged(ValueChangeEvent<String> event) {
//				equipmentTypeChangeHandler();
//			}
//		});
	}

	public AddOrEditEquipmentTypeVendorAssociation(EquipmentTypeVendorAssociationMaster equipmentTypeVendorAssociationMaster, EquipmentTypeVendorAssociationMasterDataBean 
			equipmentTypeVendorAssociationMasterDataBean, String vendor, String equipmentType, String inputFileFormat, String outputFileFormat, String serviceAgent, /*String 
			warrantyPeriod,*/ Map<Long, String> vendorMap, Map<Long, String> activeEquipmentTypeMap, Map<Long, String> passiveEquipmentTypeMap, boolean vendorOrOperator) {

		//System.out.println("Edit.....");
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.vendorMap = vendorMap;
		this.activeEquipmentTypeMap = activeEquipmentTypeMap;
		this.passiveEquipmentTypeMap = passiveEquipmentTypeMap;
		this.vendorOrOperator = vendorOrOperator;
		try {
			vendorCombo = UIFieldFactory.createComboBox(new ArrayList<String>(), true, SCREENCD, "VENDOR_COMBO");
			List<String> valuesList = new ArrayList<String>();
			//System.out.println("vendorMap size="+vendorMap.size()+" vendorMap="+vendorMap.toString());
			vendorMap.forEach((k,v) -> {
				//System.out.println("key="+k);
				valuesList.add(vendorMap.get(k));
			});
			vendorCombo.setDataProvider(new ListDataProvider<String>(valuesList));
			vendorCombo.setValue(vendor);
			vendorCombo.setEnabled(false);
			//vendorCombo.setEnabled(false);
//			equipmentTypeCombo = UIFieldFactory.createComboBox(CommonUtils.parseFLOV("ADD_EDIT_EQUIPMENT_TYPE", "SERVICE_TYPE_LIST", ','),
//					true, SCREENCD, "EQUIPMENT_TYPE_COMBO");
//			activeEquipmentTypeMap.forEach((k,v) -> {
//				//System.out.println("key="+k);
//				if(activeEquipmentTypeMap.get(k).equals(equipmentType))
//				{
//					equipmentTypeCombo.setValue("Active");
//				}
//			});
//			passiveEquipmentTypeMap.forEach((k,v) -> {
//				//System.out.println("key="+k);
//				if(passiveEquipmentTypeMap.get(k).equals(equipmentType))
//				{
//					equipmentTypeCombo.setValue("Passive");
//				}
//			});
//			equipmentTypeCombo.setEnabled(false);
			List<String> listOfValues = new ArrayList<String>();
			if (vendorOrOperator) {
				passiveEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(passiveEquipmentTypeMap.get(k));
				});
			} else {
				activeEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(activeEquipmentTypeMap.get(k));
				});
			}
			equipmentCombo = UIFieldFactory.createComboBox(listOfValues,true, SCREENCD, "EQUIPMENT_COMBO");
			
			equipmentCombo.setValue(equipmentType);
			//equipmentTypeCombo.setEnabled(false);
			equipmentCombo.setEnabled(false);
			inputFileFormatFld = UIFieldFactory.createTextField(inputFileFormat, true, SCREENCD, "INPUT_FILE_FORMAT_FIELD");
			outputFileFormatFld = UIFieldFactory.createTextField(outputFileFormat, true, SCREENCD, "OUTPUT_FILE_FORMAT_FIELD");
			serviceAgentFld = UIFieldFactory.createTextField(serviceAgent, true, SCREENCD, "SERVICE_AGENT_FIELD");
			//			warrantyPeriodFld = UIFieldFactory.createNumberField(true, SCREENCD, "WARRANTY_PERIOD_FIELD");
			//			if (warrantyPeriod!=null && warrantyPeriod.trim().length()>0) {
			//				warrantyPeriodFld.setValue(Double.valueOf(warrantyPeriod));
			//			}
			String title = "";
			if (vendorOrOperator) {
				title = "Vendor";
			} else {
				title = "Operator";
				vendorCombo.setLabel("Operator");
			}

			AddOrEditEquipmentTypeVendorAssociationPopup popup = new AddOrEditEquipmentTypeVendorAssociationPopup("Edit Equipment Type " +title+ " Association", false, vendorOrOperator, this, equipmentTypeVendorAssociationMaster, SCREENCD);

			add(vendorCombo, equipmentCombo);
			if (vendorOrOperator) {
				add(inputFileFormatFld, outputFileFormatFld, serviceAgentFld);
			}
			else {
				popup.save_btn.setEnabled(false);
			}
			
//			equipmentTypeCombo.addValueChangeListener(new ValueChangeListener<ValueChangeEvent<String>>() {
//				private static final long serialVersionUID = 1L;
//
//				@Override
//				public void valueChanged(ValueChangeEvent<String> event) {
//					equipmentTypeChangeHandler();
//				}
//			});

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*private void equipmentTypeChangeHandler() {
		List<String> listOfValues = new ArrayList<String>();
		if (equipmentTypeCombo.getValue()!=null && equipmentTypeCombo.getValue().trim().length()>0) {
			if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("ACTIVE")) {
				activeEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(activeEquipmentTypeMap.get(k));
				});	
			} else if (equipmentTypeCombo.getValue().trim().equalsIgnoreCase("PASSIVE")) {
				passiveEquipmentTypeMap.forEach((k,v) -> {
					//System.out.println("key="+k);
					listOfValues.add(passiveEquipmentTypeMap.get(k));
				});	
			}				
		}
		equipmentCombo.setDataProvider(new ListDataProvider<String>(listOfValues));
	}*/

	public boolean validation() {
		vendorCombo.setInvalid(false);
		//equipmentTypeCombo.setInvalid(false);
		inputFileFormatFld.setInvalid(false);
		outputFileFormatFld.setInvalid(false);
		serviceAgentFld.setInvalid(false);
		//		warrantyPeriodFld.setInvalid(false);

		if (vendorCombo.getValue()==null || vendorCombo.getValue().trim().length()==0) {
			vendorCombo.setInvalid(true);
			vendorCombo.setErrorMessage("Please enter "+vendorCombo.getLabel().toLowerCase());
			return false;
		}

		/*if (equipmentTypeCombo.getValue()==null || equipmentTypeCombo.getValue().trim().length()==0) {
			equipmentTypeCombo.setInvalid(true);
			equipmentTypeCombo.setErrorMessage("Please enter "+equipmentTypeCombo.getLabel().toLowerCase());
			return false;
		}*/
		
		if (equipmentCombo.getValue()==null || equipmentCombo.getValue().trim().length()==0) {
			equipmentCombo.setInvalid(true);
			equipmentCombo.setErrorMessage("Please enter "+equipmentCombo.getLabel().toLowerCase());
			return false;
		}

		//		if (inputFileFormatFld.getValue()==null || inputFileFormatFld.getValue().trim().length()==0) {
		//			inputFileFormatFld.setInvalid(true);
		//			inputFileFormatFld.setErrorMessage("Please enter "+inputFileFormatFld.getLabel().toLowerCase());
		//			return false;
		//		}
		//
		//		if (outputFileFormatFld.getValue()==null || outputFileFormatFld.getValue().trim().length()==0) {
		//			outputFileFormatFld.setInvalid(true);
		//			outputFileFormatFld.setErrorMessage("Please enter "+outputFileFormatFld.getLabel().toLowerCase());
		//			return false;
		//		}
		//		
		//		if (serviceAgentFld.getValue()==null || serviceAgentFld.getValue().trim().length()==0) {
		//			serviceAgentFld.setInvalid(true);
		//			serviceAgentFld.setErrorMessage("Please enter "+serviceAgentFld.getLabel().toLowerCase());
		//			return false;
		//		}

		//		if (warrantyPeriodFld.getValue()==null) {
		//			warrantyPeriodFld.setInvalid(true);
		//			warrantyPeriodFld.setErrorMessage("Please enter "+warrantyPeriodFld.getLabel().toLowerCase());
		//			return false;
		//		}

		return true;
	}

	public String getVendor() {
		if (vendorCombo.getValue()==null)
			return "";
		else
			return vendorCombo.getValue();
	}

	public int getVendorId() {
		if (vendorCombo.getValue()==null)
			return 0;
		else
		{
			Iterator<Long> equipmentKeys = vendorMap.keySet().iterator();
			while (equipmentKeys.hasNext()) {
				long key = equipmentKeys.next();
				if (vendorMap.get(key).trim().equals(vendorCombo.getValue().trim())) {
					//System.out.println("key from get="+key);
					return Integer.valueOf(key+"");
				}

			}
		}
		return 0;
	}

	public String getEquipment() {
		if (equipmentCombo.getValue()==null)
			return "";
		else
			return equipmentCombo.getValue();
	}

	public int getEquipmentTypeId() {
		Map<Long, String> equipmentTypeMap = new HashMap<>();
		//System.out.println("equipmentCombo.getValue()==="+equipmentCombo.getValue());
		if (equipmentCombo.getValue()==null)
			return 0;
		else
		{
				if (!vendorOrOperator) {
					equipmentTypeMap = activeEquipmentTypeMap;
					//System.out.println("activeEquipmentTypeMap = "+equipmentTypeMap.toString());
				} else {
					equipmentTypeMap = passiveEquipmentTypeMap;
				}
				Iterator<Long> equipmentKeys = equipmentTypeMap.keySet().iterator();
				while (equipmentKeys.hasNext()) {
					long key = equipmentKeys.next();
					if (equipmentTypeMap.get(key).trim().equals(equipmentCombo.getValue().trim())) {
						//System.out.println("key from get="+key);
						return Integer.valueOf(key+"");
					}

				}
			
		}
		return 0;
	}

	public String getInputFileFormat() {
		if (inputFileFormatFld.getValue()==null)
			return "";
		else
			return inputFileFormatFld.getValue();
	}

	public String getOutputFileFormat() {
		if (outputFileFormatFld.getValue()==null)
			return "";
		else
			return outputFileFormatFld.getValue();
	}

	public String getServiceAgent() {
		if (serviceAgentFld.getValue()==null)
			return "";
		else
			return serviceAgentFld.getValue();
	}

	//	public String getWarrantyPeriod() {
	//		if (warrantyPeriodFld.getValue()==null)
	//			return "";
	//		else
	//			return warrantyPeriodFld.getValue()+"";
	//	}

}
