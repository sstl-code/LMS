package com.umt.siteassetinventory.assetinventory;

import java.util.Iterator;
import java.util.LinkedHashMap;

import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class EquipmentDetailsDialog extends AssetOperationsDialog {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "EQUIPMENTS_DIALOG";

	public EquipmentDetailsDialog(String screenName, LinkedHashMap<String, String> dataMap, JSONObject dataJSON) {
		super(screenName, new LinkedHashMap<String, String>());
		containerBody.removeAll();
		buttons_div.removeAll();
		buttons_div.add(closeBtn);
		try {
			headerTitle.setText("Equipment: " + dataJSON.getString("OfferingName"));
			String otherInfo = dataJSON.getString("OtherInfo");
			JSONObject otherInfoJSON = new JSONObject(otherInfo);
			
			Iterator iterator = otherInfoJSON.keys();
			
			Div equipAttribHeaderDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EQUIP_ATTRIB_HEADER_DIV");
			Label equipAttribNameHeaderLbl = UIHtmlFieldFactory.createLabel("Attribute", SCREENCD, "EQUIP_ATTRIB_NAME_HEADER_LBL");
			Label equipAttribValueHeaderLbl = UIHtmlFieldFactory.createLabel("Value", SCREENCD, "EQUIP_ATTRIB_VALUE_HEADER_LBL");
			equipAttribHeaderDiv.add(equipAttribNameHeaderLbl, equipAttribValueHeaderLbl);
			containerBody.add(equipAttribHeaderDiv);
			while(iterator.hasNext()) {
				String eachKey = (String)iterator.next();
				String eachVal = otherInfoJSON.get(eachKey) + "";
				Div equipAttribRowDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "EQUIP_ATTRIB_ROW_DIV");
				Label equipAttribNameRowLbl = UIHtmlFieldFactory.createLabel(eachKey, SCREENCD, "EQUIP_ATTRIB_NAME_ROW_LBL");
				Label equipAttribValueRowLbl = UIHtmlFieldFactory.createLabel(eachVal, SCREENCD, "EQUIP_ATTRIB_VALUE_ROW_LBL");
				equipAttribRowDiv.add(equipAttribNameRowLbl, equipAttribValueRowLbl);
				containerBody.add(equipAttribRowDiv);
			}
			
			mainLayout.addClassName(SCREENCD + "_MAIN_LAYOUT");
			containerBody.addClassName(SCREENCD + "_CONTAINER_BODY");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
