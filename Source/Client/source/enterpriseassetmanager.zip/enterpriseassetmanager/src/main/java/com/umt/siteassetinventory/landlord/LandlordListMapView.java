package com.umt.siteassetinventory.landlord;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;

import com.flowingcode.vaadin.addons.googlemaps.GoogleMap;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker;
import com.flowingcode.vaadin.addons.googlemaps.LatLon;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMap.MapType;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker.GoogleMapMarkerClickEvent;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.umt.siteassetinventory.site.SiteView;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.html.Div;

public class LandlordListMapView extends Div{

	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_LIST_MAP_VIEW";
	private GoogleMap siteMap;
	private String selectedSitecode;
	private LandlordView parent;
	private List<MapMarkerData> mapMarkerList = new ArrayList<LandlordListMapView.MapMarkerData>();
	private Div mainLayoutDiv;
	private String lat,longi;
	
	public LandlordListMapView(LandlordView parent) 
	{
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		this.parent=parent;
		siteMap = new GoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", null, null);
		siteMap.setSizeFull();
		siteMap.setMapType(MapType.ROADMAP);
		siteMap.setDraggable(true);
		siteMap.setZoom(5);
		siteMap.setHeightFull();
		
		mainLayoutDiv = UIHtmlFieldFactory.createDiv(SCREENCD, "MAIN_LAYOUT2");
		mainLayoutDiv.add(siteMap);
		add(mainLayoutDiv);
	}
	public void populateLandlordDetails(String response) 
	{
		//System.out.println("landlordmapresponse::"+response);
		try
		{
			
			mapMarkerList.clear();
	
			JSONArray jsarr=new JSONArray(response);
			for(int i=0;i<jsarr.length();i++)
			{	
				lat=jsarr.getJSONObject(i).getString("Lattitude");
				longi=jsarr.getJSONObject(i).getString("Longitude");
				if(lat.trim().length()>0 && longi.trim().length()>0)
				{
					MapMarkerData marker = new MapMarkerData();
					marker.setSiteCode(jsarr.getJSONObject(i).getString("LandlordId"));
					marker.setName(jsarr.getJSONObject(i).getString("Name"));
					marker.setContact(jsarr.getJSONObject(i).getString("ContactNo"));
					marker.setSiteAddress(jsarr.getJSONObject(i).getString("Address"));
					marker.setEmail(jsarr.getJSONObject(i).getString("Email"));
					marker.setSiteRegion(jsarr.getJSONObject(i).getString("Region"));
					marker.setLatitude(jsarr.getJSONObject(i).getString("Lattitude"));
					marker.setLongitude(jsarr.getJSONObject(i).getString("Longitude"));
					
					mapMarkerList.add(marker);	
				}
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
			
		populateMap();
	}
	private void populateMap() {
		siteMap = new GoogleMap("AIzaSyA9xXmHPEXZhWDqJAS1_HvZKblPCdnoFxA", null, null);
		siteMap.setSizeFull();
		siteMap.setMapType(MapType.ROADMAP);
		siteMap.setDraggable(true);
		siteMap.setZoom(5);
		siteMap.setHeightFull();
	//	siteMap.setId("MY_GOOGLE_MAP");
		addClassName(SCREENCD + "_MAIN_LAYOUT");
		//siteMap.getStyle().set("", "");
		
	//	System.out.println("mapMarkerList.size()="+mapMarkerList.size());
		for(int i = 0; i < mapMarkerList.size(); i++) {
			
			MapMarkerData eachItem = mapMarkerList.get(i);
			GoogleMapMarker marker = siteMap.addMarker(eachItem.getSiteCode(), new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())), false, "");
			
			
			
			mapMarkerList.get(i).setMarker(marker);
			String htmlContent = "<html><body><span style=\"font-size:18px\">" + eachItem.getName() + "</span><br><em>" + eachItem.getSiteRegion() + "</em><br><div style=\"width:200px\"><small>" + eachItem.getSiteAddress() + "</small></div></body></html>"; 
			
			marker.addInfoWindow(htmlContent);
			
			marker.setAnimationEnabled(true);
			
			marker.addClickListener(new ComponentEventListener<GoogleMapMarker.GoogleMapMarkerClickEvent>() {
				private static final long serialVersionUID = 1L;

				@Override
				public void onComponentEvent(GoogleMapMarkerClickEvent event) {
					GoogleMapMarker marker = event.getSource();
					
					if(parent != null) {
					//	parent.setSelectedSite(marker.getCaption());
						closeOtherMarkerInfoWindow(marker.getCaption());
						parent.addMapMarkerClickHandler(marker.getCaption());
					}
				}
			});
			
		}
	
		mainLayoutDiv.removeAll();
		mainLayoutDiv.add(siteMap);
	}
	public void closeOtherMarkerInfoWindow(String code) {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if (!eachItem.getSiteCode().trim().equalsIgnoreCase(code)) {
					eachItem.getMarker().setInfoWindowVisible(false);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void closeMarkerInfoWindow() {
		try {
			for (int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				//if (eachItem.getSiteCode().trim().equalsIgnoreCase(selectedSiteCode)) {
					eachItem.getMarker().setInfoWindowVisible(false);
					//break;
				//}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void setSelectedSite(String siteCode) 
	{
		//System.out.println("selectedLandId2="+siteCode);
		try {
			selectedSitecode = siteCode;
			for(int i = 0; i < mapMarkerList.size(); i++) {
				MapMarkerData eachItem = mapMarkerList.get(i);
				if(eachItem.getSiteCode().trim().equalsIgnoreCase(siteCode)) {
					siteMap.setCenter(new LatLon(Double.parseDouble(eachItem.getLatitude()), Double.parseDouble(eachItem.getLongitude())));
					eachItem.getMarker().setInfoWindowVisible(true);
					break;
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	private class MapMarkerData implements Serializable {
		private static final long serialVersionUID = 1L;
		private String siteCode;
		private String siteAddress;
		private String siteRegion;
		private String latitude;
		private String longitude;
		private String name,email,contact;
		private GoogleMapMarker marker;
		
		public MapMarkerData() {
			
		}

		public void setEmail(String email) {
			this.email=email;
			
		}

		public void setContact(String contact) {
			this.contact=contact;
			
		}

		public void setName(String name) {
			this.name = name;
		}
		public String getName() {
			return name;
		}

		public GoogleMapMarker getMarker() {
			return marker;
		}

		public void setMarker(GoogleMapMarker marker) {
			this.marker = marker;
		}

		public String getSiteCode() {
			return siteCode;
		}

		public void setSiteCode(String siteCode) {
			this.siteCode = siteCode;
		}

		public String getSiteAddress() {
			return siteAddress;
		}

		public void setSiteAddress(String siteAddress) {
			this.siteAddress = siteAddress;
		}

		public String getSiteRegion() {
			return siteRegion;
		}

		public void setSiteRegion(String siteRegion) {
			this.siteRegion = siteRegion;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}
	}

}
