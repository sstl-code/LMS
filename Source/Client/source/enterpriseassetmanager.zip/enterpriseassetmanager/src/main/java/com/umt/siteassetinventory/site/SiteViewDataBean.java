package com.umt.siteassetinventory.site;

import java.util.List;

import org.codehaus.jettison.json.JSONObject;

import com.umt.siteassetinventory.application.ApplicationConfiguration;
import com.umt.siteassetinventory.application.BaseDialogPopup;
import com.umt.siteassetinventory.framework.SiteAssetInventoryUIFramework;
import com.umt.siteassetinventory.framework.componentfactory.UIHtmlFieldFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@CssImport("./styles/site-view.css")
public class SiteViewDataBean extends Div {
	private static final long serialVersionUID = 1L;
	private static final String SCREENCD = "SITE_VIEW_BEAN";
	private String sitecode,region, creationDate,address,latitude,longitude,siteName;
	private SiteView parent;
	private Div eachrowDiv;
	private SiteViewDataBean child;
	

	public SiteViewDataBean(String sitecode, String region, String creationDate, String address, String latitude,
			String longitude,String siteName, SiteView siteView) 
	{
		this.sitecode=sitecode;
		this.region=region;
		this.creationDate=creationDate;
		this.parent=siteView;
		this.address=address;
		this.latitude=latitude;
		this.longitude=longitude;
		this.siteName=siteName;
		child=this;
		eachrowDiv=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_ROW_DIV");
		
		Div eachdataDiv1=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV1");
		Div eachdataDiv2=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV2");
		Div eachdataDiv3=UIHtmlFieldFactory.createDiv(SCREENCD, "EACH_DATA_DIV3");
		
		
		Label sitecodeLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "SITECODE_LBL");
		sitecodeLbl.setText(sitecode);
		eachdataDiv1.add(sitecodeLbl);
		
		Label regionLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "REGION_LBL");
		regionLbl.setText(region);
		eachdataDiv2.add(regionLbl);
		
		Label ratingLbl = UIHtmlFieldFactory.createLabel(SCREENCD, "RATING_LBL");
		ratingLbl.setText(creationDate);
		eachdataDiv3.add(ratingLbl);
		
		eachrowDiv.add(eachdataDiv1,eachdataDiv2,eachdataDiv3);
		add(eachrowDiv);
		
		
		
		eachrowDiv.addClickListener(new ComponentEventListener<ClickEvent<Div>>() {
			private static final long serialVersionUID = 1L;

			@Override
			public void onComponentEvent(ClickEvent<Div> event) {
				eachRowSelectionChangeHandler(sitecode,event.getSource());
				System.out.println(sitecode);
//				populateSiteDetails(sitecode);
				parent.addDetailsTab(sitecode);
				
				siteView.setSelectedsitecode(sitecode);
				
				
			}
		});
	}
	public void eachRowSelectionChangeHandler(String sitecode2, Div selectedRow) 
	{
		parent.selectedRowChangeHandler(sitecode2);
		parent.deselectOtherRows(child);
		parent.sendSiteName(siteName,sitecode);
		selectedRow.addClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
		
		parent.setSelectedLatLong(this.latitude,this.longitude);
	}

	public String getselectedSiteCode()
	{
		return this.sitecode;
		
	}
	public void setSelectedSiteCode(String code) {
		 this.sitecode=code;
		
	}
	public String getRegion()
	{
		return region;
		
	}
	public String getRating()
	{
		return creationDate;
		
	}
	public Div getEachRowDiv() {
		// TODO Auto-generated method stub
		return eachrowDiv;
	}
	public void deselectEachDiv(SiteViewDataBean child2)
	{
		
		for(int i = 0; i < parent.getSiteBeanList().size(); i++) 
		{
			if(!child2.equals(parent.getSiteBeanList().get(i))) 
			{
				eachrowDiv.removeClassName("SITE_VIEW_BEAN_DATA_ROW_SELECTED");
			}
		}
		
	}
	
	public void selectSiteViewBeanNode(String paramsiteCode2)
	{
		deselectEachDiv(this);
		
		if(paramsiteCode2.equalsIgnoreCase(sitecode))
		{
			if(eachrowDiv != null)
			{
				eachrowDiv.addClassName(SCREENCD + "_DATA_ROW_SELECTED");
				parent.sendSiteName(siteName,sitecode);
			}
		}
	}

}
