(function(window) {
    window.__env = window.__env || {};
    window.__env.envBaseURL = 'http://localhost:8080';
    window.__env.logoURL='http://localhost:8080/RuleServer/files/default/monitor/04cbceda-9bcc-4b28-ba48-835da00f7d63/stream'
}(this));
