(function(window) {
  window.__env = window.__env || {};
  window.__env.apibaseURL = 'http://localhost:8080'; //replace this path with environment specific base Url
  window.__env.signupRedirectionURL ='/enterpriseassetmanager';
}(this));
