(function(window) {    
    window.__env = window.__env || {};    
    window.__env.baseURL = window.location.protocol;
   
}(this));