(function(window) {
    window.__env = window.__env || {};
    window.__env.envBaseURL = window.location.protocol;
    window.__env.baseURL = window.location.protocol;
   
    /****** Set flag value 'default' => to show both tickets & order tab
   Set flag value 'tickets' => to show only tickets tab
   Set flag value 'orders'  => to show only orders tab ******/
   
   window.__env.flag_ticketsOrorders = 'tickets';

   /****** The values for attribute key name mentioned in this array, will be visible in My Task Left panel ******/ 
   window.__env.taskDetailsToShow = ['Instance Id','Docket No','Subject'];

}(this));
