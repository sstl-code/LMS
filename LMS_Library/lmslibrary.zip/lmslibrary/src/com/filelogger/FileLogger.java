//==============================================================================================================================================================
// Change History																																
// SL		ID				     	Date         		By			    	Description																	
// 001  	Log file generation		04-Nov-2020			AnnuA				Partition, engine, date-time, size wise log file generation.
// 002		Log_Rearrange			28-Jun-2021			AyanC				1. change method name "_getLoggerRoot" to "getLoggerRoot"
//																			2. Re-arranging log writing
// 003		Bug_Fix					23-Mar-2023			PratimG				1. UTF-8 support added
//																			2. File splitting error
//==============================================================================================================================================================


package com.filelogger;

import com.ruleengine.common.Constants;
import com.ruleengine.fields.UserField;
import com.ruleengine.manager.RuleManager;
import com.ruleengine.settings.LocalParams;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


import org.apache.commons.io.FileUtils;

public class FileLogger {
	private RuleManager rm = null;
	private String rootDirectory = null;

	private String getLoggerRoot(String PartitionId) throws Exception {
		String methodRef = "Logger::FileLogger::getLoggerRoot()"; //002
		if (this.rm == null) {
			this.rm = RuleManager.getContextInstance();
//Start 002 			
//			if (this.rm == null)
//				throw new Exception("Invalid PARE Context!");
			if (this.rm == null) {
				String errorMessage = "Error: "+methodRef+":invalid PARE context form Rule Manager";
				throw new Exception(errorMessage);							
			}
//End 002			
		}
//Start 002 		
		try {
			this.rootDirectory = LocalParams.getLparams(PartitionId).getProperty("LOGGER_ROOT");
			if (this.rootDirectory == null) {
				if (this.rootDirectory == null)
					this.rootDirectory = System.getProperty("user.dir");
				this.rootDirectory = this.rootDirectory.replace("\\", "/");
				(new File(this.rootDirectory)).mkdirs();
			}	
		}
		catch(Exception e) {
			String errorMessage = "Error: "+methodRef+":creating directory structure to place server log";
			e.printStackTrace();
			throw new Exception(errorMessage);							
			
		}
//		this.rootDirectory = LocalParams.getLparams(PartitionId).getProperty("LOGGER_ROOT");
//		if (this.rootDirectory == null) {
//			// this.rootDirectory =
//			// LocalParams.getLparams(this.rm.getPartition()).getProperty("LOGGER_ROOT");
//			if (this.rootDirectory == null)
//				this.rootDirectory = System.getProperty("user.dir");
//			this.rootDirectory = this.rootDirectory.replace("\\", "/");
//			(new File(this.rootDirectory)).mkdirs();
//		}
//		System.out.println("## PATH = " + this.rootDirectory);
//End 002 		
		return this.rootDirectory;
	}

	// public void writeLine(String line) throws Exception {
	// Date now = new Date();
	// UserField f = new UserField("", Constants.DATATYPE.DATE);
	// f.setManager(this.rm);
	// f.setValue(now);
	// File logFile = new File(String.valueOf(_getLoggerRoot()) + "/" +
	// this.rm.getName() + "_" + f.getValueString() + ".log");
	// f.setType(Constants.DATATYPE.DATETIME);
	// FileUtils.writeLines(logFile, Arrays.asList(new String[] {
	// String.valueOf(f.getValueString()) + "/" + this.rm.getName() + " - " + line
	// }), true);
	// }

	// Start 001

//	public void writeLine2(String engine, String line, String PartitionId) throws Exception {
//		Date now = new Date();
//		UserField f = new UserField("", Constants.DATATYPE.DATE);
//		f.setManager(this.rm);
//		f.setValue(now);
//		File logFile = new File(
//				String.valueOf(_getLoggerRoot(PartitionId)) + "/" + engine + "_" + f.getValueString() + ".log");
//		f.setType(Constants.DATATYPE.DATETIME);
//		FileUtils.writeLines(logFile,
//				Arrays.asList(new String[] { String.valueOf(f.getValueString()) + "/" + engine + " - " + line }), true);
//	}

	public void writeLine2(String engine, String line, String PartitionId) throws Exception {
		List<File> engineFiles = new ArrayList<File>();
		File theNewestFile = null;
		String loggerRoot = getLoggerRoot(PartitionId);
		Long fileSize = null;
		File f = new File(loggerRoot + "/");
		ArrayList<File> files = null;
		
		String methodRef = "Logger::FileLogger::writeLine2()"; //002

		Date now = new Date();
		UserField uf = new UserField("", Constants.DATATYPE.DATETIME);
		uf.setManager(this.rm);
		uf.setValue(now);

		try { //002
				if (f.exists()) {
					try {
						files = new ArrayList(Arrays.asList(f.listFiles())); //listing all files present in loggerRoot folder
					} catch (ArrayIndexOutOfBoundsException e) {
//Start 002 				
//						System.out.println("ArrayIndexOutOfBoundsException generated");
						String errorMessage = "Error: "+methodRef+":"+e.getMessage();
						e.printStackTrace();
						throw new Exception(errorMessage);							
//End 002 				
					}
					
					if (files != null) {
						for (File fi : files) {
//Start 003
//							String fname = fi.getName().split("_")[0];
							String fname = fi.getName().split("_log_")[0];
//End 003
							
							if(fname.equalsIgnoreCase(engine)) {
								engineFiles.add(fi);
							}
		
						}
						Collections.sort(engineFiles, new Comparator<File>() { // sorting specific engine files according to lastModifiedDate
							public int compare(File f1, File f2) {
								return Long.compare(f1.lastModified(), f2.lastModified());
							}
						});
		
						if (engineFiles.size() > 0) {
							theNewestFile = engineFiles.get(engineFiles.size() - 1); //getting the last modified engine file
							fileSize = FileUtils.sizeOf(theNewestFile); //getting the size of the last modified engine file
							uf.setType(Constants.DATATYPE.DATE);
							String currentDate = uf.getValueString();
//Start 003
//							String newestFileDate = theNewestFile.getName().split("_")[1];
							String newestFileDate = theNewestFile.getName().split("_log_")[1]; //getting the date value from file name of last modified engine file
							String log_date = newestFileDate.split("_")[0];
//End 003
							uf.setType(Constants.DATATYPE.DATETIME);					
						
							long maxLogSize = Constant.DEFAULT_MAX_LOG_SIZE;
							
							try {
									String value = (String) LocalParams.getLparams(PartitionId).getProperty("MAX_LOG_SIZE"); //getting the value of maximum log size from host parameter
									maxLogSize = (Long.parseLong(value) * 1024);
							}catch(Exception e) {
//Start 002 						
//							System.out.println(e.getMessage());
//							System.out.println("Host Parameter does not contain the value of MAX_LOG_SIZE");
								String errorMessage = "Error: "+methodRef+":PARE host parameter not configured for MAX_LOG_SIZE, proceeding with default value "+Constant.DEFAULT_MAX_LOG_SIZE;
								System.out.println(errorMessage);
								e.printStackTrace();
//End 002 							
							}
//Start 003
							if (fileSize >= maxLogSize || !currentDate.equals(log_date)) {
//							if (fileSize >= maxLogSize || !currentDate.equals(newestFileDate)) {
//End 003
								createLogFile(engine, line, loggerRoot, uf);
							} else {
//Start 003
//								FileUtils.writeLines(theNewestFile, Arrays.asList(
//										new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),
//										true);
								FileUtils.writeLines(theNewestFile,"UTF-8", Arrays.asList(
										new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),
										true);
							}
						} else {
							createLogFile(engine, line, loggerRoot, uf);
						}
		
					}
				} else {
					createLogFile(engine, line, loggerRoot, uf);
				}
//Start 002 				
		}
		catch(Exception e) {
			String errorMessage = "Error: "+methodRef+":"+e.getMessage();
			e.printStackTrace();
			throw new Exception(errorMessage);							
		}
//End 002 		
	}

	private void createLogFile(String engine, String line, String loggerRoot, UserField uf)
			throws Exception, IOException {													// method to create a new log file on satisfying above conditions
// Start 003 		
//		File logFile = new File(String.valueOf(loggerRoot) + "/" + engine + "_"
//				+ uf.getValueString().replaceAll("\\s+", "_").replaceAll(":", "-") + ".log"); // generating a log file which contains engine name and date time value of file creation
//		FileUtils.writeLines(logFile,
//				Arrays.asList(new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),
//				true);																								// adding a line(log entry) in the log file	which contains engine name, date time value and line
		File logFile = new File(String.valueOf(loggerRoot) + "/" + engine + "_log_"	+ uf.getValueString().replaceAll("\\s+", "_").replaceAll(":", "-") + ".log");
		FileUtils.writeLines(logFile,"UTF-8",Arrays.asList(new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),true);
		
// End 003	
	}

	// End 001
	
	public static void main(String[] args) throws Exception
	{
		
	}

}
