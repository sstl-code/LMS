package usha.pare.connectors;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class JExcelWriter {

	private SXSSFWorkbook workbook;
	private Sheet sheet;
	private int iRowNum = 0;
	private FileOutputStream file;
	private FileInputStream  file_in;
	private XSSFCellStyle numberCellStyle;
	private XSSFCellStyle floatCellStyle;
	private XSSFCellStyle textCellStyle;
	private String row_delim = "\\|";
	private ArrayList<String> dataTypes;
	public void openBook(String strFileName) throws Exception
	{
		try
		{
			File f = new File(strFileName);

			file_in = new FileInputStream(f);
			workbook = new SXSSFWorkbook((XSSFWorkbook)WorkbookFactory.create(file_in));
			
			
			file = new FileOutputStream(f);
			iRowNum = 0;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
		finally
		{
			try
			{
				file_in.close();
			}
			catch(Exception ex)
			{}
		}
	}
	
	public void createBook(String strFileName) throws Exception
	{
		try
		{
			File f = new File(strFileName);
			if(f.exists())
			{
				throw new Exception("File "+strFileName+" already exists");
			}
			
			file = new FileOutputStream(strFileName);
			workbook = new SXSSFWorkbook(1000);
			iRowNum = 0;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
	}
	public void createSheet(String strSheetName) throws Exception
	{
		if(workbook == null)
		{
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		}
		sheet = workbook.createSheet(strSheetName);
		
		
		DataFormat format = workbook.createDataFormat();
		
		numberCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		numberCellStyle.setDataFormat(format.getFormat("0")); 
		
		floatCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		floatCellStyle.setDataFormat(format.getFormat("0.00")); 
				
		textCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		textCellStyle.setDataFormat(format.getFormat("text")); 
		
		iRowNum = 0;
	
	}
	
	public void getSheetByName(String strSheetName) throws Exception
	{
		if(workbook == null)
		{
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		}
		sheet = workbook.getSheet(strSheetName);
		
		if(sheet == null)
		{
			throw new Exception("Sheet does not exist");
		}
		
		DataFormat format = workbook.createDataFormat();
		
		numberCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		numberCellStyle.setDataFormat(format.getFormat("#")); 
		
		floatCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		floatCellStyle.setDataFormat(format.getFormat("0.00")); 
				
		textCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		textCellStyle.setDataFormat(format.getFormat("text")); 
		
		iRowNum = sheet.getLastRowNum()+1;
	
	}
	
	public void getSheetByIndex(int index) throws Exception
	{
		if(workbook == null)
		{
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		}
		sheet = workbook.getSheetAt(index);
		if(sheet == null)
		{
			throw new Exception("Sheet does not exist");
		}
		
		DataFormat format = workbook.createDataFormat();
		
		numberCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		numberCellStyle.setDataFormat(format.getFormat("0")); 
		
		floatCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		floatCellStyle.setDataFormat(format.getFormat("0.00")); 
				
		textCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		textCellStyle.setDataFormat(format.getFormat("text")); 
		
		iRowNum = sheet.getLastRowNum()+1;
	
	}
	
	public void addHeader(String strHeader) throws Exception
	{
		if(workbook == null)
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		if(sheet == null)
			throw new Exception("Sheet is not created yet. Call createSheet first");
		Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerFont.setColor(IndexedColors.BLACK.getIndex());
		Row headerRow = sheet.createRow(iRowNum);
		iRowNum++;
		
		dataTypes = new ArrayList<String>();
		CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        
        String[] headerElements = strHeader.split("\\|");
        for(int i = 0; i < headerElements.length; i++) {
        	String subHeaderElements[] = headerElements[i].split("#");
        	if(subHeaderElements.length < 2)
        		dataTypes.add("S");  
        	else
        		dataTypes.add(subHeaderElements[1]);
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(subHeaderElements[0]);
            cell.setCellStyle(headerCellStyle);
        }
        if(dataTypes.size() != headerElements.length)
        {
        	throw new Exception("Header and Datatype mismatch");
        }
    }
	
	public void setHeader(String strHeader) throws Exception
	{
		if(workbook == null)
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		if(sheet == null)
			throw new Exception("Sheet is not created yet. Call createSheet first");
		Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerFont.setColor(IndexedColors.BLACK.getIndex());
		
		
		dataTypes = new ArrayList<String>();
		CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
      
        String[] headerElements = strHeader.split("\\|");
        for(int i = 0; i < headerElements.length; i++) {
        	String subHeaderElements[] = headerElements[i].split("#");
        	if(subHeaderElements.length < 2)
        		dataTypes.add("S"); 
        	else
        		dataTypes.add(subHeaderElements[1]);
           
        }
        if(dataTypes.size() != headerElements.length)
        {
        	throw new Exception("Header and Datatype mismatch");
        }
    }
	public void setRowDelimiter(String delim)
	{
		this.row_delim = delim;
	}
	public void addRow(String strRowData) throws Exception
	{
		if(workbook == null)
			throw new Exception("Workbook is not created yet. Call createBook or openBook first");
		if(sheet == null)
			throw new Exception("Sheet is not created yet. Call createSheet first");
		
		
		Row row = sheet.createRow(iRowNum);
        iRowNum++;
		String[] rowElements = strRowData.split(row_delim);
        for(int i = 0; i < rowElements.length; i++) {
            Cell cell = row.createCell(i);
            String dataType = dataTypes.get(i);
            if(dataType == null)
            	dataType = "S";
            
	        try
	        {
	        	switch(dataType)
	            {
	            	case "S" :
		            	cell.setCellStyle(textCellStyle);
		            	cell.setCellValue(rowElements[i]);
		            	break;
	            	case "D" :
	            		double d = Double.parseDouble(rowElements[i]);
	                	cell.setCellStyle(floatCellStyle);
		            	cell.setCellValue(d);
		            	break;
	            	case "N" :
	            		int n = Integer.parseInt(rowElements[i]);
	                	cell.setCellStyle(numberCellStyle);
		            	cell.setCellValue(n);
		            	break;
	            	default:
	            		cell.setCellStyle(textCellStyle);
		            	cell.setCellValue(rowElements[i]);
		            	break;
	            }
	        }
            catch(Exception e)
            {
            	cell.setCellStyle(textCellStyle);
            	cell.setCellValue(rowElements[i]);
            }
        }
	}
	
	public void closeBook() throws Exception
	{
		try
		{
			workbook.write(file);
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
		finally
		{
			
	       
	        workbook.close();
	        workbook.dispose();
	        file.close();
		}
	}
	

	
}
