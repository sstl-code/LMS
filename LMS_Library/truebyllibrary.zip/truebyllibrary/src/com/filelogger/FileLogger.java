
package com.filelogger;

import com.ruleengine.common.Constants;
import com.ruleengine.fields.UserField;
import com.ruleengine.manager.RuleManager;
import com.ruleengine.settings.LocalParams;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


import org.apache.commons.io.FileUtils;

public class FileLogger {
	private RuleManager rm = null;
	private String rootDirectory = null;

	private String getLoggerRoot(String PartitionId) throws Exception {
		String methodRef = "Logger::FileLogger::getLoggerRoot()"; 
		if (this.rm == null) {
			this.rm = RuleManager.getContextInstance();

			if (this.rm == null) {
				String errorMessage = "Error: "+methodRef+":invalid PARE context form Rule Manager";
				throw new Exception(errorMessage);							
			}
			
		}
		
		try {
			this.rootDirectory = LocalParams.getLparams(PartitionId).getProperty("LOGGER_ROOT");
			if (this.rootDirectory == null) {
				if (this.rootDirectory == null)
					this.rootDirectory = System.getProperty("user.dir");
				this.rootDirectory = this.rootDirectory.replace("\\", "/");
				(new File(this.rootDirectory)).mkdirs();
			}	
		}
		catch(Exception e) {
			String errorMessage = "Error: "+methodRef+":creating directory structure to place server log";
			e.printStackTrace();
			throw new Exception(errorMessage);							
			
		}
		
		return this.rootDirectory;
	}
	

	public void writeLine2(String engine, String line, String PartitionId) throws Exception {
		List<File> engineFiles = new ArrayList<File>();
		File theNewestFile = null;
		String loggerRoot = getLoggerRoot(PartitionId);
		Long fileSize = null;
		File f = new File(loggerRoot + "/");
		ArrayList<File> files = null;
		
		String methodRef = "Logger::FileLogger::writeLine2()"; //002

		Date now = new Date();
		UserField uf = new UserField("", Constants.DATATYPE.DATETIME);
		uf.setManager(this.rm);
		uf.setValue(now);

		try { 
				if (f.exists()) {
					try {
						files = new ArrayList(Arrays.asList(f.listFiles())); //listing all files present in loggerRoot folder
					} catch (ArrayIndexOutOfBoundsException e) {
				

						String errorMessage = "Error: "+methodRef+":"+e.getMessage();
						e.printStackTrace();
						throw new Exception(errorMessage);							
			
					}
					
					if (files != null) {
						for (File fi : files) {


							String fname = fi.getName().split("_log_")[0];

							
							if(fname.equalsIgnoreCase(engine)) {
								engineFiles.add(fi);
							}
		
						}
						Collections.sort(engineFiles, new Comparator<File>() { 
							public int compare(File f1, File f2) {
								return Long.compare(f1.lastModified(), f2.lastModified());
							}
						});
		
						if (engineFiles.size() > 0) {
							theNewestFile = engineFiles.get(engineFiles.size() - 1); 
							fileSize = FileUtils.sizeOf(theNewestFile); 
							uf.setType(Constants.DATATYPE.DATE);
							String currentDate = uf.getValueString();

							String newestFileDate = theNewestFile.getName().split("_log_")[1]; //getting the date value from file name of last modified engine file
							String log_date = newestFileDate.split("_")[0];

							uf.setType(Constants.DATATYPE.DATETIME);					
						
							long maxLogSize = Constant.DEFAULT_MAX_LOG_SIZE;
							
							try {
									String value = (String) LocalParams.getLparams(PartitionId).getProperty("MAX_LOG_SIZE"); //getting the value of maximum log size from host parameter
									maxLogSize = (Long.parseLong(value) * 1024);
							}catch(Exception e) {

								String errorMessage = "Error: "+methodRef+":PARE host parameter not configured for MAX_LOG_SIZE, proceeding with default value "+Constant.DEFAULT_MAX_LOG_SIZE;
								System.out.println(errorMessage);
								e.printStackTrace();
							
							}

							if (fileSize >= maxLogSize || !currentDate.equals(log_date)) {

								createLogFile(engine, line, loggerRoot, uf);
							} else {

								FileUtils.writeLines(theNewestFile,"UTF-8", Arrays.asList(
										new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),
										true);
							}
						} else {
							createLogFile(engine, line, loggerRoot, uf);
						}
		
					}
				} else {
					createLogFile(engine, line, loggerRoot, uf);
				}
				
		}
		catch(Exception e) {
			String errorMessage = "Error: "+methodRef+":"+e.getMessage();
			e.printStackTrace();
			throw new Exception(errorMessage);							
		}
 		
	}

	private void createLogFile(String engine, String line, String loggerRoot, UserField uf)
			throws Exception, IOException {													// method to create a new log file on satisfying above conditions
																						// adding a line(log entry) in the log file	which contains engine name, date time value and line
		File logFile = new File(String.valueOf(loggerRoot) + "/" + engine + "_log_"	+ uf.getValueString().replaceAll("\\s+", "_").replaceAll(":", "-") + ".log");
		FileUtils.writeLines(logFile,"UTF-8",Arrays.asList(new String[] { String.valueOf(uf.getValueString()) + " " + engine + " - " + line }),true);
		
	
	}

	
	
	public static void main(String[] args) throws Exception
	{
		
	}

}
