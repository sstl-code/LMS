package com.filelogger;

public interface Constant 
{
		
	//DEFAULT MAXIMUM LOG SIZE
	public static final long DEFAULT_MAX_LOG_SIZE = 5242880;
	
	

}
